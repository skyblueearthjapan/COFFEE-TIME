from pathlib import Path
import re
import sys

source = Path(sys.argv[1])
text = source.read_text(encoding="utf-8")
out = Path("ai_esper_handoff")
out.mkdir(exist_ok=True)
for name in ("catalog.json", "verify_catalog.py"):
    pattern = (re.escape(f"<!-- BEGIN:{name} -->") +
               r"\s*```[a-z]+\n(.*?)\n```\s*" +
               re.escape(f"<!-- END:{name} -->"))
    match = re.search(pattern, text, re.S)
    if not match:
        raise ValueError(f"Embedded block not found: {name}")
    content = (match.group(1) + "\n").encode("utf-8")
    destination = out / name
    if destination.exists() and destination.read_bytes() != content:
        raise FileExistsError(f"Refusing to overwrite different content: {destination}")
    destination.write_bytes(content)
    print(destination)
