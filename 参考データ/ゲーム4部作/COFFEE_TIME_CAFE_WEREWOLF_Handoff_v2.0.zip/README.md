# COFFEE TIME / CAFE WEREWOLF — 3〜10人共通版 v2.0.0

**「閉店後の人狼会」の5人専用版を全面更新する、単一アプリ用の設計・参考コードです。**
同じ第4メニュー、同じ `game_id=cafe_werewolf` で、開始前に3〜10人を選びます。新規設定の初期人数は3です。

## 最初に読むもの

`COFFEE_TIME_CAFE_WEREWOLF_Design_v2.0.md` が正本です。単独のMarkdownにも、この一式の全ファイルが埋め込まれています。旧v1の仕様・ソースと部分的に混ぜないでください。

本一式は**書込み済みESP32ファームではありません**。ポータブルC++コアと検査はホストで実行済みですが、既存LVGL/BSPとの接続、物理的な秘密画面消去、日本語の描画、電池、実プレイ評価は未実施です。

## 一つのルール

N人で、人狼1・占い師1・村人NのN+2枚から役職を配り、2枚を伏せ札A/Bとして残します。伏せ札は参加者ではありません。占い師は一人または一枚について人狼かどうかを確認でき、全員が同じ夜の操作をします。人狼が配られない回もあるため、投票には「人狼はいない」を含めます。

一人一票、単独最多票、最高同票なら一度だけ決選、再同票なら引き分け。人狼不在で誰かを選べば全員不正解です。夜の襲撃・途中脱落・役職交換はありません。

## 保持する構成

- ESP32-S3-Touch-LCD-2.8C、丸型480×480タッチ。
- 選定済み803450 / 3.7V / 1500mAh、B案の本体電池一体・折りたたみスタンド。
- LCD/GT911初期化、コーヒー＋1、既存3ゲーム、Google連携。
- 第4ゲームにJev、AI補充、個人登録、新しいGoogle連携は追加しません。
- 秘密はRAMだけ。再起動した局は無効で、途中再抽選による続行はしません。

## 取り出しと検査

Python 3.9以上とホスト用のC++17コンパイラー（g++/clang++）を用意します。ESP32用クロスコンパイラーでPC向けテスト実行ファイルを作らないでください。

```sh
python tools/run_checks.py
python tools/run_checks.py --sanitize
```

コンパイラーを指定する場合は `--compiler /実際のホスト用コンパイラー`。サニタイザーのない環境は未実施と記録します。Windowsでは使用可能な `python` または `py -3` を使用し、必要なら整備済みWSLなどでホスト検査します。未整備ツールや存在しないパスを推測で実行しません。

通常試験はO2。サニタイザー試験はtest_coreをO0、test_vote_spaceをO1で実行します。オプションと環境は `tests/*_results.json` に記録されます。メモリー検査用実行ファイルは一時フォルダーに生成し、ESP32へ書き込みません。

MDだけからは、付録の `tools/extract_from_md.py` を保存して次を実行します。

```sh
python extract_from_md.py COFFEE_TIME_CAFE_WEREWOLF_Design_v2.0.md extracted_wolf_v2
cd extracted_wolf_v2
python tools/run_checks.py
```

## ファイルの役割

| パス | 内容 |
|---|---|
| `src/werewolf_core.hpp` | 3〜10人の配布・夜・投票・決選・結果・一時停止・SecretGate |
| `src/public_meta.hpp` | 20バイトのCTW2、旧CTW1検査と移行 |
| `src/paging.hpp` | 実人数から4席ずつのページを作る |
| `src/privacy_fence.hpp` | 古い表示完了通知を拒否するepoch管理。物理描画ではない |
| `src/port_contract.hpp` | 既存の乱数・時計・画面・設定・カフェへ接続するアプリ契約 |
| `src/lvgl_binding.example.cpp` | LVGL 8イベントの接続パターン。実機コンパイル未実施 |
| `data/rules.json` | 全ルール・人数・時間・ID・定数 |
| `data/content.ja.json` | 全文言・説明・導入・終了後メッセージ |
| `data/layout.json` | 480×480丸型の配置、ページ化 |
| `data/acceptance_tests.json` | 99項目の未実施受入試験 |
| `data/font_chars.txt` | 文字一覧。フォントそのものではない |
| `data/text_wrap_examples.json` | 等幅換算の改行参考。実フォントの幅保証ではない |
| `tests/test_core.cpp` | ゲーム進行・全配布・境界/秘密/保存のホスト試験 |
| `tests/test_vote_space.cpp` | 3〜10人の到達可能な全得票ベクトル検査 |
| `tests/*_results.json` | 実行したPC上の検査結果 |
| `docs/MIGRATION_v1_to_v2.md` | 旧5人版の監査・置換・設定移行 |
| `docs/TEST_RECORD.md` | 検査済み範囲と実装担当の記録票 |
| `manifest.json` | 取り出し前後のSHA-256照合 |

配布直後にmanifestで一致を確認します。実装や別環境での再試験によって生成物・環境入り結果JSONが変化した後は、配布時のSHA-256と一致しなくて正常です。元データとの比較と変更記録を残してください。

## 完成判定

ホストPASSだけで製品完成とはしません。3人・4人の実プレイを優先し、対応人数すべての機能と99項目の受入結果を記録します。「3人以上」に無制限対応を含めず、v2は3〜10人と明示します。
