#include "../src/werewolf_core.hpp"
#include "../src/public_meta.hpp"
#include "../src/paging.hpp"
#include "../src/privacy_fence.hpp"
#include "../src/port_contract.hpp"
#include <algorithm>
#include <functional>
#include <iostream>
#include <map>
#include <random>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>
using namespace coffee::wolf;
static uint64_t checks=0,full_games=0,first_profiles=0,runoff_profiles=0,layout_total=0;
static unsigned groups=0;
#define CHECK(x) do {++checks;if(!(x))throw std::runtime_error(std::string(#x)+" @"+std::to_string(__LINE__));} while(false)
#define OK(x) CHECK((x)==Err::Ok)
static void group(const std::function<void()>& f){f();++groups;}
static Votes emptyVotes(){Votes v;v.fill(NONE);return v;}
static Tally independent(uint8_t n,const Votes& v,Mask allowed) {
    Tally t;std::map<int,int> counts;
    for(int a=0;a<n;++a) {
        const int x=v[a];
        if(x==a || !((x>=0&&x<n)||x==PEACE) || !(allowed&(1u<<x)))return t;
        ++counts[x];
    }
    for(int a=n;a<MAX_PLAYERS;++a)if(v[a]!=NONE)return t;
    int maximum=0;for(const auto& kv:counts)maximum=std::max(maximum,kv.second);
    int winners=0;
    for(const auto& kv:counts) {
        t.counts[kv.first]=static_cast<uint8_t>(kv.second);
        if(kv.second==maximum){++winners;t.leaders|=static_cast<Mask>(1u<<kv.first);t.selected=static_cast<int8_t>(kv.first);}
    }
    if(winners!=1)t.selected=NONE;
    t.valid=true;return t;
}
static void compareTally(uint8_t n,const Votes& v,Mask m) {
    auto actual=tally(n,v,m),expected=independent(n,v,m);
    CHECK(actual.valid==expected.valid);CHECK(actual.selected==expected.selected);
    CHECK(actual.leaders==expected.leaders);CHECK(actual.counts==expected.counts);
}
static void enumerateVotes(uint8_t n,Mask allowed,const std::function<void(const Votes&)>& f) {
    Votes v=emptyVotes();std::function<void(uint8_t)> rec=[&](uint8_t a) {
        if(a==n){f(v);return;}
        for(uint8_t x=0;x<TARGET_SLOTS;++x)if(legalVoteTarget(n,a,x,allowed)) {v[a]=static_cast<int8_t>(x);rec(a+1);}
        v[a]=NONE;
    };rec(0);
}
static void night(Engine& e,uint8_t n,uint16_t k,int target_override=NONE,bool finish_talk=true) {
    std::array<Role,ROLE_SLOTS> expected;CHECK(dealFromIndex(n,k,expected));
    OK(e.start(e.stamp(),n,k,1000));Result r;CHECK(e.result(r)==Err::Phase);
    CHECK(e.publicView().player_count==n);
    for(uint8_t a=0;a<n;++a) {
        OK(e.receiveNight(e.stamp(),a));CHECK(e.acknowledgeRole(e.stamp(),a)==Err::Unseen);
        Role role=Role::Empty;CHECK(e.readRole(static_cast<uint8_t>((a+1)%n),role)==Err::Seat);
        OK(e.readRole(a,role));CHECK(role==expected[a]);OK(e.acknowledgeRole(e.stamp(),a));
        CHECK(e.chooseNight(e.stamp(),a,a)==Err::Target);CHECK(e.chooseNight(e.stamp(),a,PEACE)==Err::Target);
        int target=target_override;
        if(target==NONE||target==a)target=(a%2==0)?RESERVE_A:RESERVE_B;
        OK(e.chooseNight(e.stamp(),a,target));CHECK(e.acknowledgeNight(e.stamp(),a)==Err::Unseen);
        NightInfo info;OK(e.readNight(a,info));CHECK(info.target==target);
        const Finding want=role==Role::Seer?(expected[target]==Role::Wolf?Finding::Wolf:Finding::NotWolf):Finding::None;
        CHECK(info.finding==want);OK(e.acknowledgeNight(e.stamp(),a));OK(e.passNight(e.stamp(),a));
    }
    CHECK(e.publicView().phase==Phase::DayReady);OK(e.startTalk(e.stamp(),1100));
    CHECK(e.publicView().remaining_ms==uint64_t(defaultDiscussion(n))*1000);
    if(finish_talk)OK(e.finishTalk(e.stamp(),true));
}
static void submitVotes(Engine& e,uint8_t n,const Votes& v) {
    OK(e.beginVote(e.stamp()));
    for(uint8_t a=0;a<n;++a) {
        OK(e.receiveVote(e.stamp(),a));const auto old=e.stamp();OK(e.selectVote(old,a,v[a]));
        CHECK(e.selectVote(old,a,v[a])==Err::Stale);CHECK(e.confirmVote(e.stamp(),a)==Err::Unseen);
        int8_t target=NONE;OK(e.pendingVote(a,target));CHECK(target==v[a]);const auto before=e.stamp();
        OK(e.confirmVote(before,a));CHECK(e.confirmVote(before,a)==Err::Stale);
        Result result;CHECK(e.result(result)==Err::Phase);OK(e.passVote(e.stamp(),a));
    }
}
static void checkEnd(Engine& e,uint8_t n,uint16_t k,const Votes& first,const Votes* second=nullptr) {
    CHECK(e.publicView().phase==Phase::FinalReady);Result out;CHECK(e.result(out)==Err::Phase);
    CHECK(e.reveal(e.stamp(),false)==Err::Input);OK(e.reveal(e.stamp(),true));OK(e.result(out));
    std::array<Role,ROLE_SLOTS> roles;CHECK(dealFromIndex(n,k,roles));
    const auto t=independent(n,second?*second:first,second?independent(n,first,voteMask(n)).leaders:voteMask(n));
    bool hasWolf=false;for(uint8_t a=0;a<n;++a)hasWolf|=roles[a]==Role::Wolf;
    const Outcome want=t.selected==NONE?Outcome::Draw:t.selected==PEACE?
        (hasWolf?Outcome::WolfEscaped:Outcome::PeaceCorrect):!hasWolf?Outcome::FalseAccusation:
        roles[t.selected]==Role::Wolf?Outcome::CaughtWolf:Outcome::WolfEscaped;
    CHECK(out.outcome==want);CHECK(out.player_count==n);CHECK(out.roles==roles);CHECK(out.first==first);
    CHECK(out.had_runoff==(second!=nullptr));if(second)CHECK(out.runoff==*second);
    if(roles[RESERVE_A]==Role::Seer||roles[RESERVE_B]==Role::Seer) {
        CHECK(out.seer==NONE);CHECK(out.inspected==NONE);CHECK(out.finding==Finding::None);
    } else {CHECK(out.seer>=0&&out.seer<n);CHECK(out.inspected==RESERVE_A||out.inspected==RESERVE_B);}
    OK(e.reset(e.stamp()));CHECK(e.result(out)==Err::Phase);++full_games;
}
static bool src(void* p,uint32_t& out){auto* v=static_cast<std::vector<uint32_t>*>(p);if(v->empty())return false;out=v->back();v->pop_back();return true;}
int main(){try {
    group([]{ // All role placements at every supported N, not just random samples.
        for(uint8_t n=3;n<=10;++n) {
            std::set<std::array<Role,ROLE_SLOTS>> unique;unsigned absent=0;
            std::array<unsigned,ROLE_SLOTS>wcount{},scount{};
            for(uint16_t k=0;k<dealCount(n);++k) {
                std::array<Role,ROLE_SLOTS> r;CHECK(dealFromIndex(n,k,r));CHECK(unique.insert(r).second);
                unsigned w=0,s=0,v=0;bool realWolf=false;
                for(uint8_t slot=0;slot<ROLE_SLOTS;++slot) {
                    if(!roleSlot(n,slot)){CHECK(r[slot]==Role::Empty);continue;}
                    if(r[slot]==Role::Wolf){++w;++wcount[slot];if(slot<n)realWolf=true;}
                    if(r[slot]==Role::Seer){++s;++scount[slot];}
                    if(r[slot]==Role::Villager)++v;
                }
                CHECK(w==1&&s==1&&v==n);if(!realWolf)++absent;++layout_total;
            }
            CHECK(absent==2u*(n+1));
            for(uint8_t slot=0;slot<ROLE_SLOTS;++slot)if(roleSlot(n,slot)) {CHECK(wcount[slot]==unsigned(n+1));CHECK(scount[slot]==unsigned(n+1));}
            std::array<Role,ROLE_SLOTS> r;CHECK(!dealFromIndex(n,dealCount(n),r));
        }
    });
    group([]{Engine e;for(uint8_t n:{uint8_t(0),uint8_t(1),uint8_t(2),uint8_t(11),uint8_t(255)})CHECK(e.start(e.stamp(),n,0,0)==Err::Input);
        CHECK(e.start(e.stamp(),3,0,0,89)==Err::Input);CHECK(e.start(e.stamp(),3,0,0,601)==Err::Input);
    });
    group([]{for(uint8_t n=3;n<=10;++n)for(uint8_t a=0;a<n;++a)for(int x=-2;x<16;++x) {
        bool nightWant=(x>=0&&x<n&&x!=a)||x==10||x==11;
        bool voteWant=(x>=0&&x<n&&x!=a)||x==12;
        CHECK(legalNightTarget(n,a,x)==nightWant);CHECK(legalVoteTarget(n,a,x,voteMask(n))==voteWant);
    }});
    group([]{for(uint8_t n=3;n<=10;++n) {
        std::vector<int> seats;for(uint8_t p=0;p<3;++p){const auto page=seatPage(n,p);if(p<((n+3)/4)){CHECK(page.valid);for(int s:page.seats)if(s!=NONE)seats.push_back(s);}else CHECK(!page.valid);}
        CHECK(seats.size()==n);for(int i=0;i<n;++i)CHECK(seats[i]==i);
    }});
    group([]{ // Exhaustive complete first ballots for 3..6; oracle is independent.
        for(uint8_t n=3;n<=6;++n)enumerateVotes(n,voteMask(n),[&](const Votes& v){compareTally(n,v,voteMask(n));++first_profiles;});
    });
    group([]{ // Every reachable first-vote tie mask, then ALL second ballots for 3..6.
        for(uint8_t n=3;n<=6;++n){std::set<Mask> masks;
            enumerateVotes(n,voteMask(n),[&](const Votes& v){auto t=independent(n,v,voteMask(n));if(t.selected==NONE)masks.insert(t.leaders);});
            for(auto mask:masks)enumerateVotes(n,mask,[&](const Votes& v){compareTally(n,v,mask);++runoff_profiles;});
        }
    });
    group([]{ // All deals x two final paths for all counts, including absent Seer.
        for(uint8_t n=3;n<=10;++n)for(uint16_t k=0;k<dealCount(n);++k)for(int style=0;style<2;++style){
            Engine e;night(e,n,k);Votes first=emptyVotes();
            for(uint8_t a=0;a<n;++a)first[a]=style==0?PEACE:static_cast<int8_t>((a+1)%n);
            submitVotes(e,n,first);
            if(style==0)checkEnd(e,n,k,first);
            else {CHECK(e.publicView().phase==Phase::RunoffReady);OK(e.startTalk(e.stamp(),1200));CHECK(e.publicView().remaining_ms==uint64_t(runoffDiscussion(n))*1000);OK(e.finishTalk(e.stamp(),true));
                Votes second=emptyVotes();for(uint8_t a=0;a<n;++a)second[a]=a==0?1:0;
                submitVotes(e,n,second);checkEnd(e,n,k,first,&second);
            }
        }
    });
    group([]{ // 3 people: every deal x every first ballot; every tied mask x every second ballot.
        const uint8_t n=3;std::map<Mask,Votes> representatives;
        enumerateVotes(n,voteMask(n),[&](const Votes& first){
            auto t=independent(n,first,voteMask(n));if(t.selected==NONE)representatives.emplace(t.leaders,first);
            for(uint16_t k=0;k<dealCount(n);++k){Engine e;night(e,n,k);submitVotes(e,n,first);
                if(t.selected!=NONE)checkEnd(e,n,k,first);else CHECK(e.publicView().phase==Phase::RunoffReady);
            }
        });
        for(const auto& kv:representatives)enumerateVotes(n,kv.first,[&](const Votes& second){
            for(uint16_t k=0;k<dealCount(n);++k){Engine e;night(e,n,k);submitVotes(e,n,kv.second);OK(e.startTalk(e.stamp(),1200));OK(e.finishTalk(e.stamp(),true));submitVotes(e,n,second);checkEnd(e,n,k,kv.second,&second);}
        });
    });
    group([]{ // Full integration fuzz, real phases, all counts, fixed test-only RNG.
        std::mt19937 rng(20260920);
        for(uint8_t n=3;n<=10;++n)for(unsigned trial=0;trial<1000;++trial){
            uint16_t k=static_cast<uint16_t>(rng()%dealCount(n));Engine e;night(e,n,k);
            Votes first=emptyVotes(),second=emptyVotes();
            auto fill=[&](Votes& votes,Mask mask){for(uint8_t a=0;a<n;++a){std::vector<int8_t> options;for(uint8_t x=0;x<TARGET_SLOTS;++x)if(legalVoteTarget(n,a,x,mask))options.push_back(static_cast<int8_t>(x));CHECK(!options.empty());votes[a]=options[rng()%options.size()];}};
            fill(first,voteMask(n));submitVotes(e,n,first);
            if(e.publicView().phase==Phase::RunoffReady){Mask mask=e.publicView().eligible;OK(e.startTalk(e.stamp(),1200));OK(e.finishTalk(e.stamp(),true));fill(second,mask);submitVotes(e,n,second);checkEnd(e,n,k,first,&second);}
            else checkEnd(e,n,k,first);
        }
    });
    group([]{ // No self votes, no reserve votes, no off-roster slots, no truncated / padded ballots.
        for(uint8_t n=3;n<=10;++n){Votes v=emptyVotes();for(uint8_t a=0;a<n;++a)v[a]=PEACE;CHECK(tally(n,v,voteMask(n)).valid);
            for(int x:{-1,0,10,11,13}){Votes bad=v;bad[0]=static_cast<int8_t>(x);CHECK(!tally(n,bad,voteMask(n)).valid);}
            if(n<10){Votes bad=v;bad[n]=PEACE;CHECK(!tally(n,bad,voteMask(n)).valid);}
            CHECK(!tally(n,v,0).valid);CHECK(!tally(n,v,static_cast<Mask>(voteMask(n)|bit(10))).valid);
        }
    });
    group([]{ // Positive/negative Seer and dummy action at every legal target and deal.
        for(uint8_t n=3;n<=10;++n)for(uint16_t k=0;k<dealCount(n);++k)for(uint8_t target=0;target<ROLE_SLOTS;++target)if(roleSlot(n,target)){Engine e;night(e,n,k,target);}
    });
    group([]{Engine e;OK(e.start(e.stamp(),3,0,100));auto s=e.stamp();OK(e.receiveNight(s,0));CHECK(e.receiveNight(s,0)==Err::Stale);Role r;OK(e.readRole(0,r));OK(e.pause(e.stamp(),200));CHECK(e.readRole(0,r)==Err::Paused);OK(e.resume(e.stamp(),300));CHECK(e.acknowledgeRole(e.stamp(),0)==Err::Unseen);OK(e.readRole(0,r));OK(e.acknowledgeRole(e.stamp(),0));});
    group([]{Engine e;night(e,3,0);CHECK(e.finishTalk(e.stamp(),false)==Err::Phase);OK(e.beginVote(e.stamp()));OK(e.receiveVote(e.stamp(),0));OK(e.selectVote(e.stamp(),0,1));int8_t t;OK(e.pendingVote(0,t));OK(e.changeVote(e.stamp(),0));CHECK(e.confirmVote(e.stamp(),0)==Err::Phase);OK(e.selectVote(e.stamp(),0,PEACE));OK(e.pendingVote(0,t));CHECK(t==PEACE);OK(e.pause(e.stamp(),1200));OK(e.resume(e.stamp(),1300));CHECK(e.confirmVote(e.stamp(),0)==Err::Unseen);});
    group([]{Engine e;night(e,3,0);OK(e.pause(e.stamp(),1500));e.tick(1600);OK(e.resume(e.stamp(),1700));e.tick(1600);CHECK(e.publicView().phase==Phase::Aborted);CHECK(e.abortReason()==AbortReason::ClockFault);Result r;CHECK(e.result(r)==Err::Phase);});
    group([]{Engine e;OK(e.start(e.stamp(),10,0,0));OK(e.pause(e.stamp(),10));e.tick(HARD_LIMIT_MS);CHECK(e.publicView().phase==Phase::Aborted);CHECK(e.abortReason()==AbortReason::HardLimit);});
    group([]{Engine e;OK(e.start(e.stamp(),3,0,0));CHECK(e.start(e.stamp(),4,1,10)==Err::Phase);OK(e.abort(e.stamp(),AbortReason::Privacy));Result r;CHECK(e.result(r)==Err::Phase);Role role;CHECK(e.readRole(0,role)==Err::Phase);OK(e.reset(e.stamp()));OK(e.start(e.stamp(),10,131,100));CHECK(e.publicView().player_count==10);});
    group([]{SecretGate g;g.enter(5);CHECK(!g.update(5,0,0,true,true));CHECK(!g.update(5,1,1,false,true));CHECK(!g.update(5,2,2,true,true));CHECK(g.update(5,502,502,true,true));CHECK(!g.update(5,503,503,false,true));});
    group([]{SecretGate g;g.enter(1);g.update(1,0,0,false,true);g.update(1,1,1,true,true);CHECK(g.update(1,501,501,true,true));CHECK(!g.update(1,502,502,true,false));CHECK(!g.update(1,1002,1002,true,true));g.update(1,1003,1003,false,true);g.update(1,1004,1004,true,true);CHECK(g.update(1,1504,1504,true,true));});
    group([]{SecretGate g;g.enter(1);g.update(1,0,0,false,true);g.update(1,1,1,true,true);CHECK(g.update(1,501,501,true,true));CHECK(!g.update(1,702,501,true,true));g.enter(2);CHECK(!g.update(1,703,703,true,true));});
    group([]{SecretGate g;g.enter(1);g.update(1,0,0,false,true);g.update(1,1,1,true,true);CHECK(g.update(1,8500,8500,true,true));CHECK(!g.update(1,8501,8501,true,true));});
    group([]{PrivacyFence p;auto a=p.beginHide();CHECK(!p.canRestore(a));auto b=p.beginHide();CHECK(!p.completeNeutral(a));CHECK(!p.canRestore(b));CHECK(p.completeNeutral(b));CHECK(p.canRestore(b));CHECK(!p.canRestore(a));});
    group([]{uint32_t x=0;for(uint8_t n=3;n<=10;++n){uint32_t bound=dealCount(n),threshold=(0u-bound)%bound;std::vector<uint32_t> words;words.push_back(threshold);if(threshold)words.push_back(threshold-1);CHECK(uniformBelow(bound,src,&words,x));CHECK(x==threshold%bound);}std::vector<uint32_t> fail;CHECK(!uniformBelow(20,src,&fail,x));CHECK(!uniformBelow(0,src,&fail,x));std::vector<uint32_t> stuck(128,0);CHECK(!uniformBelow(20,src,&stuck,x));});
    group([]{const uint8_t v[]={'1','2','3','4','5','6','7','8','9'};CHECK(crc32ieee(v,9)==0xcbf43926u);for(uint8_t n=3;n<=10;++n)for(bool armed:{false,true})for(uint16_t sec:{uint16_t(0),uint16_t(90),uint16_t(600)}){PublicMeta m;m.players=n;m.armed=armed;m.discussion_s=sec;m.flavor_seq=123456;std::array<uint8_t,20>b;CHECK(encodeMeta(m,b));PublicMeta d;CHECK(decodeMeta(b.data(),b.size(),d)==MetaFormat::CurrentV2);CHECK(d.players==n&&d.armed==armed&&d.discussion_s==sec&&d.flavor_seq==m.flavor_seq);for(unsigned i=0;i<160;++i){auto c=b;c[i/8]^=uint8_t(1u<<(i%8));CHECK(decodeMeta(c.data(),c.size(),d)==MetaFormat::Invalid);}}});
    group([]{PublicMeta m;m.players=5;m.discussion_s=180;m.armed=true;m.flavor_seq=99;std::array<uint8_t,20>b;CHECK(encodeMeta(m,b));b[3]='1';b[4]=1;b[7]=0;uint32_t crc=crc32ieee(b.data(),16);for(unsigned i=0;i<4;++i)b[16+i]=static_cast<uint8_t>(crc>>(8*i));PublicMeta d;CHECK(decodeMeta(b.data(),b.size(),d)==MetaFormat::LegacyV1);CHECK(d.players==5&&d.armed&&d.flavor_seq==99);CHECK(encodeMeta(d,b));CHECK(decodeMeta(b.data(),b.size(),d)==MetaFormat::CurrentV2);});
    group([]{ // Natural timer expiry for each supported player count, no early completion.
        for(uint8_t n=3;n<=10;++n){Engine e;night(e,n,0,NONE,false);
            const uint64_t end=1100+uint64_t(defaultDiscussion(n))*1000;
            e.tick(end-1);CHECK(e.publicView().phase==Phase::DayTalk);CHECK(e.publicView().remaining_ms==1);
            auto old=e.stamp();e.tick(end);CHECK(e.publicView().phase==Phase::VoteReady);CHECK(e.publicView().remaining_ms==0);
            CHECK(e.beginVote(old)==Err::Stale);OK(e.beginVote(e.stamp()));
        }
    });
    group([]{ // Pause freezes discussion but not wall time; extension at most once.
        for(uint8_t n=3;n<=10;++n){Engine e;night(e,n,0,NONE,false);
            e.tick(11100);OK(e.pause(e.stamp(),12100));auto remaining=e.publicView().remaining_ms;
            CHECK(remaining==uint64_t(defaultDiscussion(n))*1000-11000);
            e.tick(212100);CHECK(e.publicView().remaining_ms==remaining);
            CHECK(e.extendTalk(e.stamp())==Err::Paused);OK(e.resume(e.stamp(),212100));
            OK(e.extendTalk(e.stamp()));CHECK(e.publicView().remaining_ms==remaining+60000);
            CHECK(e.extendTalk(e.stamp())==Err::Phase);CHECK(e.finishTalk(e.stamp(),false)==Err::Input);
            OK(e.finishTalk(e.stamp(),true));
        }
    });
    group([]{ // Natural runoff duration and no runoff extension, all player counts.
        for(uint8_t n=3;n<=10;++n){Engine e;night(e,n,0);Votes first=emptyVotes();
            for(uint8_t a=0;a<n;++a)first[a]=static_cast<int8_t>((a+1)%n);
            submitVotes(e,n,first);CHECK(e.publicView().phase==Phase::RunoffReady);
            OK(e.startTalk(e.stamp(),1300));CHECK(e.extendTalk(e.stamp())==Err::Phase);
            const uint64_t end=1300+uint64_t(runoffDiscussion(n))*1000;
            e.tick(end-1);CHECK(e.publicView().phase==Phase::RunoffTalk);CHECK(e.publicView().remaining_ms==1);
            e.tick(end);CHECK(e.publicView().phase==Phase::VoteReady);CHECK(e.publicView().vote_cycle==2);
        }
    });
    std::cout<<"{\"status\":\"PASS\",\"groups\":"<<groups<<",\"assertions\":"<<checks<<",\"role_layouts\":"<<layout_total<<",\"first_vote_profiles_3_to_6\":"<<first_profiles<<",\"runoff_vote_profiles_3_to_6\":"<<runoff_profiles<<",\"full_completed_games\":"<<full_games<<",\"sizeof_engine_host_bytes\":"<<sizeof(Engine)<<",\"device_tests\":\"NOT_RUN\"}\n";
    return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
