// Exact coverage of all attainable tally vectors, NOT the Cartesian product of all ballots.
#include "../src/werewolf_core.hpp"
#include <functional>
#include <array>
#include <vector>
#include <set>
#include <iostream>
#include <stdexcept>
using namespace coffee::wolf;
static uint64_t first_classes=0,runoff_classes=0,feasibility_checks=0;
static void require(bool ok){if(!ok)throw std::runtime_error("vote-space verification failed");}
using Counts=std::array<uint8_t,TARGET_SLOTS>;
// Independent bipartite matching of voters to one token for every counted vote.
static bool realize(uint8_t n,const Counts& counts,Mask mask,Votes& votes) {
    std::vector<int> tokens;for(int x=0;x<int(TARGET_SLOTS);++x)for(int j=0;j<counts[x];++j)tokens.push_back(x);
    if(tokens.size()!=n)return false;
    std::array<int,MAX_PLAYERS> owner;owner.fill(-1);
    std::function<bool(int,std::array<bool,MAX_PLAYERS>&)> augment=[&](int actor,std::array<bool,MAX_PLAYERS>& visited){
        for(int i=0;i<n;++i){const int target=tokens[i];if(visited[i]||target==actor||!(mask&(1u<<target)))continue;
            visited[i]=true;if(owner[i]<0||augment(owner[i],visited)){owner[i]=actor;return true;}}
        return false;
    };
    for(int a=0;a<n;++a){std::array<bool,MAX_PLAYERS> visited{};if(!augment(a,visited))return false;}
    votes.fill(NONE);for(int i=0;i<n;++i)votes[owner[i]]=static_cast<int8_t>(tokens[i]);return true;
}
static void classes(uint8_t n,Mask mask,const std::function<void(const Counts&,const Votes&)>& fn) {
    std::vector<uint8_t> targets;for(uint8_t x=0;x<TARGET_SLOTS;++x)if(mask&bit(x))targets.push_back(x);
    Counts counts{};
    std::function<void(std::size_t,int)> rec=[&](std::size_t pos,int left){
        if(pos==targets.size()) {
            if(left)return;
            bool feasible=true;for(uint8_t a=0;a<n;++a)if(counts[a]>n-1)feasible=false;
            Votes votes;bool matched=realize(n,counts,mask,votes);++feasibility_checks;
            require(feasible==matched);if(matched)fn(counts,votes);return;
        }
        for(int c=0;c<=left;++c){counts[targets[pos]]=static_cast<uint8_t>(c);rec(pos+1,left-c);}
        counts[targets[pos]]=0;
    };rec(0,n);
}
static Tally check(uint8_t n,const Counts& c,const Votes& v,Mask mask) {
    auto t=tally(n,v,mask);require(t.valid&&t.counts==c);
    uint8_t best=0;for(auto x:c)if(x>best)best=x;
    Mask leaders=0;int count=0,selected=NONE;
    for(uint8_t x=0;x<TARGET_SLOTS;++x)if((mask&bit(x))&&c[x]==best){leaders|=bit(x);++count;selected=x;}
    if(count!=1)selected=NONE;
    require(t.leaders==leaders&&t.selected==selected);return t;
}
int main(){try {
    std::cout<<"{\"status\":\"PASS\",\"by_player_count\":[";
    for(uint8_t n=3;n<=10;++n){std::set<Mask> tied;const auto beforeF=first_classes,beforeR=runoff_classes;
        classes(n,voteMask(n),[&](const Counts& c,const Votes& v){auto t=check(n,c,v,voteMask(n));if(t.selected==NONE)tied.insert(t.leaders);++first_classes;});
        for(Mask mask:tied)classes(n,mask,[&](const Counts& c,const Votes& v){check(n,c,v,mask);++runoff_classes;});
        if(n>3)std::cout<<',';
        std::cout<<"{\"players\":"<<unsigned(n)<<",\"first_tally_classes\":"<<first_classes-beforeF<<",\"reachable_runoff_masks\":"<<tied.size()<<",\"runoff_tally_classes\":"<<runoff_classes-beforeR<<'}';
    }
    std::cout<<"],\"first_tally_classes\":"<<first_classes<<",\"runoff_tally_classes\":"<<runoff_classes<<",\"feasibility_checks\":"<<feasibility_checks<<",\"scope\":\"all reachable tally vectors with one realized legal vote profile each; not all individual vote sequences\"}\n";
    return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
