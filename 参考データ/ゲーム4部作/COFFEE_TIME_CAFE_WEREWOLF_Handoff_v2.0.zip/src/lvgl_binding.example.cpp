// Integration pattern ONLY: adapt to the existing LVGL 8 project.
// Not compiled by the host tests; don't introduce a second lv_init()/LVGL task.
#include "lvgl.h"
#include "werewolf_core.hpp"
using coffee::wolf::Stamp;

enum class UiAction { ReceiveNight, AckRole, PickNight, CommitNight, AckNight,
                      PassNight, StartTalk, BeginVote, ReceiveVote, PickVote,
                      ConfirmVote, ChangeVote, PassVote, Reveal, Cafe, Abort };
struct UiIntent { UiAction action; Stamp stamp; uint64_t screen_epoch; uint8_t actor; int target; };
// This interface belongs to this application. It is not a Waveshare/LVGL API.
struct ControllerPort {
    virtual ~ControllerPort() = default;
    virtual bool acceptsInput(uint64_t epoch) const = 0;
    virtual bool postIntent(const UiIntent& intent) = 0; // copy by value; bounded queue
    virtual void hideSecretImmediately() = 0;           // blank backlight, invalidate secret view
};
struct Binding { ControllerPort* controller; UiIntent intent; };
// Binding storage must outlive its widget AND any in-flight callback.
static void action_cb(lv_event_t* event) {
    auto* binding = static_cast<Binding*>(lv_event_get_user_data(event));
    if (!binding || !binding->controller) return;
    if (lv_event_get_code(event) != LV_EVENT_CLICKED) return;
    if (!binding->controller->acceptsInput(binding->intent.screen_epoch)) return;
    if (!binding->controller->postIntent(binding->intent)) {
        binding->controller->hideSecretImmediately(); // queue-full -> closed, not click loss/repetition
    }
}
// Hold-to-show uses fresh driver samples + SecretGate, NOT LONG_PRESSED_REPEAT.
static void cover_cb(lv_event_t* event) {
    auto* binding = static_cast<Binding*>(lv_event_get_user_data(event));
    if (!binding || !binding->controller) return;
    switch (lv_event_get_code(event)) {
      case LV_EVENT_RELEASED:
      case LV_EVENT_PRESS_LOST:
      case LV_EVENT_SCREEN_UNLOAD_START:
      case LV_EVENT_DELETE:
        binding->controller->hideSecretImmediately();
        break;
      default: break;
    }
}
// Register on a button whose bounds do not change while it is pressed.
void bind_action(lv_obj_t* object, Binding* binding) {
    lv_obj_add_event_cb(object, action_cb, LV_EVENT_CLICKED, binding);
}
void bind_secret_cover(lv_obj_t* object, Binding* binding) {
    lv_obj_add_event_cb(object, cover_cb, LV_EVENT_ALL, binding);
}
// Dispatch order, implemented inside the existing application's UI task:
// 1. engine.tick(monotonic_now_ms) -- process hard deadline even on HOME.
// 2. validate intent.stamp and screen_epoch; discard stale events.
// 3. close privacy gate before any owner/phase change.
// 4. call exactly ONE matching engine command; handle Err explicitly.
// 5. discard bindings only once callbacks complete; rebuild masked view.
// 6. require physical release + fresh press before next screen accepts a tap.
// 7. show a handoff screen only after all scanout buffers contain the safe frame.
