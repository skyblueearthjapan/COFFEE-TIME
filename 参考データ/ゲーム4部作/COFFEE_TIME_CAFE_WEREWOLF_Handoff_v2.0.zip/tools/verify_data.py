"""Check design assets. This does not test a physical LCD or font metrics."""
from pathlib import Path
import json,re,math,unicodedata
ROOT=Path(__file__).resolve().parents[1]
def load(f):return json.loads((ROOT/f).read_text(encoding='utf-8'))
def walk(o):
 if isinstance(o,str):yield o
 elif isinstance(o,dict):
  for v in o.values():yield from walk(v)
 elif isinstance(o,list):
  for v in o:yield from walk(v)
def main():
 r=load('data/rules.json');c=load('data/content.ja.json');l=load('data/layout.json');a=load('data/acceptance_tests.json')
 tests=[]
 def ck(name,ok):
  if not ok:raise AssertionError(name)
  tests.append(name)
 ck('single_game_identity',r['game_id']=='cafe_werewolf' and r['menu_slot']==4 and r['one_app'])
 ck('all_counts',r['supported_players']==list(range(3,11)) and r['default_players']==3)
 ck('pool',r['pool_formula']=={'wolf':1,'seer':1,'villager':'N','total':'N+2'} and r['reserve_count']==2)
 ck('ids',r['ids']=={'seat_first':0,'seat_last_max':9,'reserve_A':10,'reserve_B':11,'peace':12,'none':-1})
 ck('version',all(o['schema_version']=='2.0.0' for o in [r,c,l,a]))
 ck('offline',not r['ai_required'] and not r['personal_login'] and not r['cloud_logging'])
 ck('votes',r['peace_vote'] and not r['peace_is_abstention'] and not r['self_vote'] and r['max_runoffs']==1)
 for x in r['timing_by_players']:
  n=x['players'];ck(f'table_{n}',x['discussion_s']==120+30*(n-3) and x['deal_count']==(n+2)*(n+1) and x['pool_size']==n+2)
 for name,(x,y,w,h) in l['rects'].items():
  ck('safe_rect_'+name,all(math.hypot(xx-240,yy-240)<=228 for xx in (x,x+w) for yy in (y,y+h)))
 for temp,names in l['templates'].items():
  ck('template_unique_'+temp,len(names)==len(set(names)))
  for i,name in enumerate(names):
   x,y,w,h=l['rects'][name]
   for other in names[i+1:]:
    xx,yy,ww,hh=l['rects'][other]
    ck('no_overlap_'+temp+'_'+name+'_'+other,not(min(x+w,xx+ww)>max(x,xx) and min(y+h,yy+hh)>max(y,yy)))
 ck('brief',len(c['mandatory_brief'])==4)
 ck('tutorials',len(c['tutorial'])==17 and len(set(p['id'] for p in c['tutorial']))==17)
 ck('intro',len(c['intro_variants'])==12)
 ck('endings',set(c['ending_variants'])==set(r['outcomes'])-{'aborted'} and all(len(v)==3 for v in c['ending_variants'].values()))
 ck('acceptance_unique',len(set(t['id'] for t in a['tests']))==len(a['tests']))
 ck('acceptance_not_run',all(t['status']=='NOT_RUN_ON_DEVICE' for t in a['tests']))
 ck('no_legacy_active_strings',not any('5人専用です' in t or '/5' in t or '同じ5人' in t for t in walk(c)))
 permitted={'players','pool','seat','target_label','selected_label','reserve_label','role','count','seconds','page','pages'}
 ck('placeholders',all(set(re.findall(r'\{(\w+)\}',v))<=permitted for v in walk(c)))
 text=''.join(walk(c))+'0123456789AB3〜10人狼はいない伏せ札A伏せ札B'
 chars=''.join(sorted(set(ch for ch in text if ch not in '\n\r\t')))
 (ROOT/'data/font_chars.txt').write_text(chars+'\n',encoding='utf-8')
 # Estimated fixed-cell wrap; actual proportional font metric acceptance remains separate.
 samples=[]
 def pages(text):
  values={'players':'10','pool':'12','seat':'10','target_label':'人狼はいない','selected_label':'人狼はいない','reserve_label':'伏せ札B','role':'占い師','count':'10','seconds':'600','page':'3','pages':'3'}
  for k,v in values.items():text=text.replace('{'+k+'}',v)
  lines=[]
  for raw in text.split('\n'):
   line='';width=0
   for ch in raw:
    w=1 if unicodedata.east_asian_width(ch) in 'WFA' else .5
    if width+w>13:lines.append(line);line='';width=0
    line+=ch;width+=w
   lines.append(line)
  return [lines[i:i+4] for i in range(0,len(lines),4)]
 for p in c['tutorial']+c['mandatory_brief']:samples.append({'id':p['id'],'title':p['title'],'pages':pages(p['body'])})
 (ROOT/'data/text_wrap_examples.json').write_text(json.dumps(samples,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 ck('bounded_body_pagination',all(1<=len(p['pages'])<=2 for p in samples))
 print(json.dumps({'status':'PASS','checks':len(tests),'strings':len(c['strings']),'tutorial_pages':len(c['tutorial']),'mandatory_brief_pages':4,'intro_variants':12,'ending_variants':15,'acceptance_tests':len(a['tests']),'glyph_characters':len(chars),'geometry':'rectangle corner and overlap checked; physical font metrics NOT tested','device_tests':'NOT_RUN'},ensure_ascii=False))
if __name__=='__main__':main()
