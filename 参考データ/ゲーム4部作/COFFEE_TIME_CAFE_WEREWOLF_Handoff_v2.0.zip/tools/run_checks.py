"""Host C++ and data checks. No ESP32, LCD or player testing is performed here."""
from pathlib import Path
import argparse,json,shutil,subprocess,tempfile,sys,platform
ROOT=Path(__file__).resolve().parents[1]
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--sanitize',action='store_true');ap.add_argument('--compiler');a=ap.parse_args()
 cc=a.compiler or shutil.which('g++') or shutil.which('clang++')
 if not cc:raise SystemExit('No host C++ compiler; tests NOT RUN')
 d=subprocess.run([sys.executable,str(ROOT/'tools/verify_data.py')],capture_output=True,text=True,check=True)
 data=json.loads(d.stdout);(ROOT/'tests/data_results.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 results={};build_options={}
 with tempfile.TemporaryDirectory(prefix='wolf_v2_') as tmp:
  for stem in ('test_core','test_vote_space'):
   out=Path(tmp)/(stem+'.exe' if sys.platform=='win32' else stem)
   cmd=[cc,'-std=c++17','-Wall','-Wextra','-Wpedantic','-Werror']
   flags=[('-O0' if stem=='test_core' else '-O1'),'-g','-fsanitize=address,undefined','-fno-omit-frame-pointer'] if a.sanitize else ['-O2']
   build_options[stem]=flags;cmd+=flags
   print('Checking '+stem+(' (sanitizers)' if a.sanitize else ''),file=sys.stderr,flush=True)
   cmd+=[str(ROOT/'tests'/f'{stem}.cpp'),'-o',str(out)]
   subprocess.run(cmd,check=True)
   ran=subprocess.run([str(out)],capture_output=True,text=True,timeout=90,check=True)
   results[stem]=json.loads(ran.stdout)
 report={'status':'PASS','sanitized':a.sanitize,'compiler':subprocess.run([cc,'--version'],capture_output=True,text=True,check=True).stdout.splitlines()[0],
  'build_options':build_options,'python':platform.python_version(),'host':platform.platform(),'results':results,'data':data,'device':'NOT_RUN','human_playtest':'NOT_RUN'}
 dest='sanitizer_results.json' if a.sanitize else 'host_results.json'
 (ROOT/'tests'/dest).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
