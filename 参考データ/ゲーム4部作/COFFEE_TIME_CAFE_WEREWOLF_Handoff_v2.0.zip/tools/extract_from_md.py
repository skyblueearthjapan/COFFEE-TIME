"""Extract the file blocks from the standalone design document without path traversal."""
from pathlib import Path, PurePosixPath
import argparse, re, hashlib, json
BLOCK=re.compile(r'^<!-- BEGIN_FILE: (?P<path>[^\r\n]+) -->\r?\n(?P<fence>`{3,})[^\r\n]*\r?\n(?P<content>.*?)\r?\n(?P=fence)\r?\n<!-- END_FILE: (?P=path) -->',re.M|re.S)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('markdown');ap.add_argument('destination');a=ap.parse_args()
    text=Path(a.markdown).read_text('utf-8');dest=Path(a.destination).resolve();dest.mkdir(parents=True,exist_ok=True)
    seen=set();count=0
    for match in BLOCK.finditer(text):
        rel=PurePosixPath(match['path'])
        if rel.is_absolute() or '..'in rel.parts or '\\'in str(rel) or ':'in str(rel):raise ValueError('Unsafe path: '+str(rel))
        if str(rel)in seen:raise ValueError('Duplicate path: '+str(rel))
        seen.add(str(rel));path=(dest/str(rel)).resolve()
        if not path.is_relative_to(dest):raise ValueError('Path escaped destination')
        data=(match['content']+'\n').encode('utf-8')
        if path.exists() and path.read_bytes()!=data:raise FileExistsError('Would overwrite different file: '+str(path))
        path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data);count+=1
    if not count:raise ValueError('No complete file blocks found')
    manifest=dest/'manifest.json'
    if manifest.exists():
        for f in json.loads(manifest.read_text('utf-8'))['files']:
            p=dest/f['path']
            if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=f['sha256']:raise ValueError('Checksum mismatch: '+f['path'])
    print(f'Extracted {count} files into {dest}; checksums verified when manifest is present.')
if __name__=='__main__':main()
