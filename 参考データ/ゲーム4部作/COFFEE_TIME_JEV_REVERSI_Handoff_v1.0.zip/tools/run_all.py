#!/usr/bin/env python3
"""Rebuild and execute host reference tests; no real cloud/hardware calls."""
from pathlib import Path
import json,platform,shutil,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
def run(args,timeout=180):
    p=subprocess.run(args,cwd=ROOT,text=True,capture_output=True,timeout=timeout)
    if p.returncode:
        print(p.stdout);print(p.stderr,file=sys.stderr)
        raise SystemExit(p.returncode)
    print(p.stdout,end='')
    return p.stdout

def main():
    for tool in ['g++','node']:
        if not shutil.which(tool):raise SystemExit(f'Required tool missing: {tool}. No tests passed.')
    (ROOT/'results').mkdir(exist_ok=True)
    versions={'python':platform.python_version(),'g++':run(['g++','--version']).splitlines()[0],
              'node':run(['node','--version']).strip(),'platform':platform.platform()}
    for name in ['smoke','session_test']:
        output=ROOT/'tests'/(name+('.exe' if sys.platform=='win32' else ''))
        run(['g++','-std=c++17','-O2','-Wall','-Wextra','-Werror',str(ROOT/'tests'/f'{name}.cpp'),'-o',str(output)])
        result=run([str(output)])
        obj=json.loads(result);assert obj['status']=='passed'
        (ROOT/'results'/('cpp_smoke.json' if name=='smoke' else 'session.json')).write_text(json.dumps(obj,indent=2)+'\n')
    run([sys.executable,str(ROOT/'tests/verify_core.py')])
    run(['node',str(ROOT/'tests/test_contract.js')])
    run([sys.executable,str(ROOT/'tests/test_data.py')])
    (ROOT/'results/host_run.json').write_text(json.dumps({'status':'passed','versions':versions,
      'real_hardware':False,'real_google':False,'real_jev':False,'lvgl_compiled':False},ensure_ascii=False,indent=2)+'\n')
    print('HOST TESTS PASSED. Real ESP32 / LVGL integration / GAS / Jev remain untested.')
if __name__=='__main__':main()
