#!/usr/bin/env python3
"""Safely extract text payloads from the handoff Markdown, verifying every SHA-256.
No extracted code is executed. Existing different files are never overwritten.
"""
from __future__ import annotations
import argparse,hashlib,json,pathlib,re
PATTERN=re.compile(r'^<!-- REV_FILE ([A-Za-z0-9_./-]+) sha256=([0-9a-f]{64}) -->\n^``````[^\n]*\n(.*?)^``````\n<!-- REV_END -->$',re.M|re.S)
def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('markdown',type=pathlib.Path)
    parser.add_argument('destination',type=pathlib.Path)
    args=parser.parse_args()
    # Normalize CRLF introduced by text editors; packaged payloads are LF UTF-8.
    text=args.markdown.read_text(encoding='utf-8').replace('\r\n','\n')
    found=PATTERN.findall(text)
    if not found:raise SystemExit('No payload markers found; refusing empty extraction.')
    root=args.destination.resolve();root.mkdir(parents=True,exist_ok=True)
    checked=[];seen=set()
    for name,digest,body in found:
        relative=pathlib.PurePosixPath(name)
        if relative.is_absolute() or any(x in ('..','.') for x in relative.parts) or name in seen:
            raise SystemExit('Unsafe or duplicate path: '+name)
        seen.add(name)
        target=(root/pathlib.Path(*relative.parts)).resolve()
        if root not in target.parents:raise SystemExit('Path escapes destination: '+name)
        data=body.encode('utf-8')
        if hashlib.sha256(data).hexdigest()!=digest:raise SystemExit('Checksum mismatch: '+name)
        if target.exists() and (not target.is_file() or target.read_bytes()!=data):
            raise SystemExit('Refusing to overwrite different existing path: '+name)
        checked.append((target,data))
    for target,data in checked:
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(data)
    print(json.dumps({'status':'verified','files':len(checked),'destination':str(root)},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
