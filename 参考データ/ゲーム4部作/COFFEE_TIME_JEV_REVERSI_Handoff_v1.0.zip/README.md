# COFFEE TIME / JEV REVERSI v1.0.0

本体設計書は `COFFEE_TIME_JEV_REVERSI_Design_v1.0.md`。この一式は完成仕様・参考実装・検査で、書込み済みファームではありません。

## 最初に

1. 設計書の0〜3章を読み、既存LCD/GT911/LVGL・コーヒー＋1・4ゲーム・Google連携を保存する。
2. `python tools/run_all.py` でホスト検査を再実行する（Python3・g++ C++17・Node.js）。
3. `preview.html` をPCブラウザで開き、6×6/8×8の二段階入力と大きい候補一覧を試す。これは端末AIだけの参考版。
4. C++のcore/sessionを既存ファームへ統合し、UI・NVS・非同期controllerを設計書に従って実装する。
5. GASルーター・認証・台帳・保存/再送を実装し、mock→実Google→実Jevの順に接続する。
6. `docs/acceptance.md` の88項目を実施し、未試験を残さず報告する。適用外には理由を書く。

`src/lvgl8_board_example.hpp`は接続例です。実LVGLビルドや実機では未確認です。`gas/decision_machine.js`は純粋な状態遷移モデルであり、ScriptLockやSheetsの実永続化機構ではありません。`provider_adapter.gs`も実キーへ接続していません。

## 保存とコード

core/sessionにはLVGLやHTTPの依存がありません。GASの `reversi_shared.js` とC++を独立したPython oracleと照合しています。

付録のgolden_positionsはテスト用の局面です。通常プレイで任意の盤面をロードする裏口は作りません。

Windowsでg++がない場合は、承認済みのWSL/MSYS2等へ検査コマンドを適応してください。コンパイラがない状態を合格にしないでください。

## 追加ブラウザ検査

`python tests/browser_check.py` はPlaywrightとChromiumが導入済みの環境で使用します。本作成環境では `/usr/bin/chromium` を使いました。他環境は実際の実行ファイルまたはPlaywright管理ブラウザへ適応してください。

## 不用意に変更しないもの

BSP、LVGL版、Flash区画、既存Google権限、旧4ゲームのID、個人認証の扱い。新ゲームのためにNVS全消去はしません。

フォント・メーカー画像・市販ゲームの素材は同梱しません。図柄は描画要素で構成し、日本語は既存の利用許諾済みフォントを共有します。

## 検査結果

`results/*.json`はこの設計書作成時のホスト実行結果です。ESP32実機、GAS本番、Jev実APIの成功証拠ではありません。再検査では上書きされます。
