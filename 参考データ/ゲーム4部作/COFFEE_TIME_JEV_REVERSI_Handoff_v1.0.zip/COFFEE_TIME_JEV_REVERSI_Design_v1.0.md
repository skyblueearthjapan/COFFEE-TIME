# COFFEE TIME 第5ゲーム — JEV REVERSI
## 6×6 / 8×8共通・実装マニュアル／詳細設計書 v1.0.0

**作成・資料確認日：2026-09-22 / 対象：Waveshare ESP32-S3-Touch-LCD-2.8C / 日本語**

> この一冊をコーディングエージェントに渡して実装を開始する。ゲームの全ルール、状態、画面文言、Jev契約、Google連携、復旧、C++/JavaScript参考実装、検査を含む。付録のファイルは全文収録し、このMarkdownだけから取り出せる。
>
> **納品物は実装仕様と検査済みの参考ロジックであり、既存ESP32プロジェクトへ書込み済みのファームではない。** 実機、実Googleアカウント、実Jevキーでは未試験。ホスト検査の成功をそれらの成功へ読み替えない。AIの強さ、応答時間、電池時間、タッチしやすさには実測による受入判定を設ける。

---

## 目次

0. 確定事項・今回決める範囲・最初の作業
1. 体験の完成形と全モード
2. リバーシの完全なルール
3. データ型・座標・棋譜・不変条件
4. 全画面・丸型UI・タッチ設計
5. 状態機械・コントローラー実装
6. Jevに渡す情報・実API・回答検証
7. PRO特徴量・CASUAL抽選・端末AI
8. ESP32 → Google Apps Script → Jevの構成
9. 自社APIの全契約
10. Google Sheets全定義・保存・競合・再送
11. 端末保存・電源断・再開・終了結果
12. 非同期通信・遅延応答・一時停止
13. BSP・LVGL・メモリー・フォント・電源
14. 設定・配備・既存機能との共存
15. 制作物一覧・コードの読み方・実装フェーズ
16. 自動検査と受入試験
17. 運用・トラブル対応・納品判定
18. 根拠資料と確認範囲
19. 今回の実行済み検査結果
付録：全ファイル・安全な取り出し方

---

## 0. 確定事項と最初の指示

### 0.1 継承するユーザー要件

| 項目 | 内容 |
|---|---|
| 装置 | COFFEE TIME。社内カフェの時計・天気・コーヒーカウント端末 |
| 基板 | **ESP32-S3-Touch-LCD-2.8C、丸型480×480**。末尾なし2.8 / 2.8B / 他型式へ変えない |
| 入力 | タッチ。マイク、音声、カメラ、外付けキーを必須にしない |
| 電源・ケース | 803450、3.7V、1500mAh、1.25mm 2ピン、保護回路付きLiPo。本体に電池も入れるB案の折りたたみケース |
| 既存機能 | 動作実績のあるLCD/GT911、コーヒー＋1、Googleスプレッドシート接続を壊さない |
| 既存ゲーム | 第1 AI ESPER、第2 AI DUEL、第3 CAFE DETECTIVE、第4 CAFE WEREWOLF **3〜10人対応v2**を残す |
| 第5ゲーム | 人間1人がJevと盤面上で対戦するリバーシ。別の専用サーバーの購入は必須にしない |

ボードのFlash 16MB、PSRAM 8MB、静電容量タッチ、2.4GHz Wi-Fi、電池端子はメーカー仕様。[S01] 接続極性・実機リビジョン・空き容量は現物で確認する。本書で新しい電源回路は設計しない。

### 0.2 本書が決めるv1の仕様

- アプリID `jev_reversi`、メニュー第5枠。一つのアプリで6×6と8×8を選ぶ。初期は6×6・人間が黒・JEVモード。
- 人間対AIの一人用。CASUAL / JEV / JEV PRO / 端末AIを同一メニュー内で選ぶ。強さの順位は保証しない。
- 個人登録・PIN・公開ランキングは追加しない。匿名の一局単位で結果を記録する。AI DUELの個人履歴と混ぜない。
- 置く場所は選択後、別の「置く」で確定。確定後の待ったはない。8×8用に大きな合法手選択一覧を必須とする。
- 現在の盤面・棋譜はESP32で管理し、Google側も棋譜から再計算する。APIが合法手計算や勝敗を変更することはない。
- オンライン障害時は、本人が選べばその局の残りを端末AIで続ける。途中でJevへ自動復帰しない。
- 再開可能な一局を端末内へ保存。カフェ復帰は一時停止とする。役職を保存しない人狼の仕様を、本ゲームの公開盤面へ誤適用しない。
- Jev vs専用エンジンの観戦、2人対戦、最強探索、ヒントで最善手を教える機能はv1に入れない。

これらは実装の曖昧さをなくすための設計判断であり、すべてをユーザーが個別指定したと表現しない。

### 0.3 最初にエージェントが行うこと

許可されたワークスペースで、実際のソース、ビルドログ、BSP、LVGL、Arduino coreまたはESP-IDF、ゲーム登録、保存領域、Google送信関数、GASを確認する。変更前をコミットまたは別コピーで保存し、元の表示・タッチ・コーヒー＋1が動くことを記録する。

**ライブラリ全更新、Arduino/ESP-IDFの乗り換え、パーティション変更、Flash全消去から始めない。** 既存原本が見つからなくても付録のPC検査は実施できるが、架空のパス・COMポート・APIキーで接続を成功扱いにしない。

優先順位は `最新のユーザー指示 > 本書 > 過去の口頭提案`。数値とIDは`data/rules.json`、文言は`data/content.ja.json`、外部契約は`data/api_contract.json`、動作は本文を正本とする。不一致は検査で止め、関係ファイルを同時に修正する。

---

## 1. 体験の完成形と全モード

### 1.1 基本フロー

`HOME → GAME → JEV REVERSI → 盤面サイズ → 対戦モード → 石の色 → 開始 → 対戦 → 結果 → 再戦 / カフェへ`

保存中の局があるときは、最初に「再開 / 終了して新しく始める」を表示する。新しい局で上書きする前に旧局を`aborted`で閉じ、保存する。前の人の局かどうかは端末が識別できないため、匿名共有端末であることを画面に明記する。

### 1.2 モードの全種類

| ID | 画面名 | 一手の選び方 | Jev入力 |
|---|---|---|---|
| `jev` | JEV | 検証済み確率の最大候補。ほぼ同率なら行優先順 | 盤面、ルール、全合法手 |
| `jev_pro` | JEV PRO | 同上 | 盤面と全合法手に、コードで計算した特徴を追加 |
| `casual` | CASUAL | Jevの確率を使う固定済み抽選 | `jev`と同じ |
| `local` | 端末AI | 一手先の局面評価関数 | 外部送信なし |

JEV PROという名称は「入力補助あり」を表す。JEVより強いことは事前に保証しない。CASUALも必ず弱くなるわけではない。`local`を「Jevオフライン版」と呼ばない。

`device.hello`でJevが使えない場合、Jev系の開始ボタンに理由を出し、端末AIを本人が選択する。気付かないうちに別AIへ切り替えて開始しない。

### 1.3 色と時間

黒先手・白後手。人間は黒・白・おまかせを選べる。おまかせは開始時に一度だけ無偏りに抽選し、実際の色を保存・表示する。保存や再開で再抽選しない。

6×6は短い対戦、8×8は長めの対戦として案内する。固定した「必ず2分」等は表示しない。考慮時間に制限は付けず、無操作120秒で安全に一時停止する。通信待ちやカフェ画面への移動を負けにしない。

### 1.4 目指す楽しさ

説明を読まずに置ける場所が分かり、石が反転し、角を取れた手応えがあること。Jevの選択を見たい人には任意の詳細表示を提供するが、毎手長い説明画面を挟まない。コーヒー＋1が必要になったら、ゲームを中断してカフェへ戻れる。

---

## 2. リバーシの全ルール

### 2.1 初期盤面

`A1`は左上。列は左からA〜FまたはA〜H、行は上から1〜6または1〜8。画面・C++・GAS・Jevの座標を統一し、プレイヤーが白でも盤面を180度回転しない。

| サイズ | 白の初期位置 | 黒の初期位置 | 黒の最初の合法手 |
|---|---|---|---|
| 6×6 | C3、D4 | D3、C4 | C2、B3、E4、D5 |
| 8×8 | D4、E5 | E4、D5 | D3、C4、F5、E6 |

並べる順序は行優先、次に列優先。例えば8×8初期合法手の配列は`D3,C4,F5,E6`である。B/Wは絶対色であり、常に人間/AIという意味ではない。

### 2.2 合法な一手

空きマスへ置いた石から8方向を調べる。隣が相手の石で、一枚以上連続する相手石の先に自分の石がある方向だけ反転できる。そのような方向が一つ以上あれば合法。盤外や空マスで線は途切れる。

- 同時に成立する全方向を反転する。都合のよい一方向だけ選ばない。
- 挟む終端の自分の石は、置く前から存在していなければならない。
- この手で反転した石を使う二次的な連鎖反転はない。
- 盤端から次の行へ走査を巻き戻さない。配列の隣接と盤面の隣接は別。
- 置けない位置、置いた後の再タップ、範囲外座標は状態を一切変更しない。

黒先手、置けない場合のみパス、双方が置けないと終局という基本は連盟のルールと整合させる。[S02]

### 2.3 パス・終局・数え方

次の手番に入る前に、黒白両方の合法手を調べる。

1. **双方0手なら即終局。** 空きマスがあっても終了する。終了のための架空の2回連続パスを棋譜に追加しない。
2. 現在手番だけ0手、相手は1手以上なら強制パス。表示700msを目安に、`PASS:F`を保存して手番を交代する。
3. 1手以上ならパスボタンは出さない。任意のパスはできない。
4. 終局後はどちらも置けない。石が多い色の勝ち、同数なら引き分け。

**本アプリは盤面上の実際の黒白枚数で比較し、残った空マスを勝者の石数へ加算しない。** 日本オセロ連盟の大会で用いる空所加算等をそのまま採用した公式競技ソフトではない。[S02] 6×6は本アプリの小型盤モードである。名称・美術は独自のREVERSIとして制作し、既存製品のロゴや素材は流用しない。

### 2.4 合法手が1つのとき

AIの合法手が一つならJevは呼ばず、その手を`F`（forced）として打つ。確率100%をJevが答えたと表示しない。人間の合法手が一つでも、本人が選択・「置く」で確定する。人間の置き手の出所は`H`である。

### 2.5 終了の全種類

| end_reason | 条件 | winner | 集計 |
|---|---|---|---|
| `completed` | 双方合法手0 | B / W / D（同数） | 盤面による対局結果 |
| `resigned` | 未終局で本人が投了確認 | 人間と反対の色 | 投了の勝敗。盤面枚数は参考値のまま |
| `aborted` | やめる、期限処理、新規開始、継続不能の無効終了 | null | 勝率の母数から除外 |

選んだマスは確定前なら変更・解除可能。確定後の待ったはv1にない。投了、局の破棄、新規上書きには確認画面を一回設ける。充電ケーブルを抜いた、Wi-Fiが切れた、カフェ画面へ戻っただけでは投了にしない。

---

## 3. データ・棋譜・不変条件

### 3.1 純粋コア

`src/reversi_core.hpp`の`Position`を使う。`n`は6/8だけ、石は0空・1黒・2白。64要素の固定配列の先頭`n*n`を使い、余りは0。添字は`row*n+col`、`row/col`は0起点。`side`は次に行動する色、`ply`は配置と強制パスを合わせた確定イベント数。

64マスの集合は`uint64_t`。`1<<63`ではなく`uint64_t(1)<<index`とする。6×6でも8を固定ストライドにしない。コアの失敗時には盤面・手番・plyを変更しない。

### 3.2 セッション

`src/reversi_session.hpp`が以下を保持する。

| フィールド | 定義 |
|---|---|
| id | 1局につき16byteの乱数。外部JSONは小文字32hex |
| pos | 検証済み盤面 |
| human | B/Wの一方 |
| mode | Jev0 / Pro1 / Casual2 / Local3 |
| closure | Active0 / Completed1 / Resigned2 / Aborted3 |
| localOnly | local開始、またはその局で端末AI継続を確定したらtrue |
| generation | 保存世代。初期1、確定処理ごとに増加。最大到達は新局へ誘導 |
| history | 最大128イベントの固定配列 |
| count | historyの有効件数、pos.plyと一致 |

IDは本番では予測しにくい乱数から生成。テストの固定ID・固定乱数種を本番へ使わない。`esp_fill_random`等を採用するときは、ESP32-S3で十分なエントロピーが供給される条件も確認する。[S13]

### 3.3 出所と通信上の棋譜

| 文字 | 出所 | 使用条件 |
|---|---|---|
| H | Human | 人間の合法な配置 |
| J | Jev | AIの合法手が2以上で、正常なJev応答から決定 |
| L | Local | AIの合法手が2以上で、端末AIが決定 |
| F | Forced | 強制パス、またはAIの唯一の合法配置 |

通信では`C2:H`、`D2:J`、`PASS:F`のような文字列配列にする。架空の例の座標を合法と仮定せず、必ず初期局面から再生して検証する。

`L`を一度含んだ棋譜の後へ`J`は追加できない。`local`モードの全局に`J`はない。`F`を人間の唯一の置き手に使わない。着手源は盤面の色を代用しない。

### 3.4 必須不変条件

- `count == ply`、石の総数は初期4＋配置イベント数。パスで枚数は変わらない。
- 行動後は手番を交代。反転分は相手から自分へ移るが、配置を除く総数は不変。
- completedと盤面終局は一致。resigned/abortedは未終局でのみ確定。
- 最大配置数は6×6で32、8×8で60。**AIの配置数が必ず半分とは限らない**（パスがある）。課金上限を16/30に決め打ちしない。
- イベントは128件以内。双方0手で終局するので、この範囲は本ルールで十分。ただし超過入力は必ず拒否する。
- 保存・通信・テストの正当な盤面は棋譜を再生して構築する。JSONの最終盤面だけを信じない。

---

## 4. 丸型UI・全画面

### 4.1 過去案からの寸法修正

直径480pxの円に内接する正方形は`480/√2 ≈339.4px`。以前の352〜368px角の盤面案では四隅が欠けるため撤回する。

**本仕様は312×312px、左上(84,84)。** 中心(240,240)から四隅まで約220.6pxで、半径232pxの設計上の安全域に入る。6×6は52px/マス、8×8は39px/マス。安全域は実ガラスの可視領域保証値ではなく、検証用の設計余白である。

| 部品 | x,y,w,h | 機能 |
|---|---|---|
| 題名 | 160,24,160,22 | 小さくJEV REVERSI |
| 得点／手番 | 132,50,216,28 | B/W枚数と交互の短い状態表示 |
| 盤面 | 84,84,312,312 | 全マス。プレイ中の回転なし |
| 操作 | 132,400,48,44 | 一時停止・メニュー。長い「メニュー」を詰め込まない |
| 置く | 188,402,104,52 | 選択した合法マスを確定 |
| 候補 | 300,400,48,44 | 大きい合法手一覧 |

細い盤枠・石・合法点・選択枠はLVGLの描画要素で作る。盤面は画像ファイルにしない。B/W両方に輪郭を付け、合法手を色だけで示さない。角や選択位置も形で分かるようにする。

### 4.2 タップの正確な挙動

1. human手番かつ保存・通信確定中でないときだけ盤面入力を有効化。
2. `84 ≤ x <396`かつ`84 ≤ y <396`でヒット判定。右端/下端396は盤外。境界を二つのマスで重複受理しない。
3. 合法マスを押して離すとそのマスを選択。選択枠と座標、返る石のプレビューを表示するが棋譜は変えない。
4. 同じマスの再選択でも石は置かない。他の合法マスなら選択変更。盤外は選択を維持する。不正マスは短い「ここには置けません」で、盤面を変更しない。
5. 別の「置く」の`LV_EVENT_CLICKED`で、現在plyと選択の合法性を再検証。入力を直ちにロックし、保存成功後に初めて確定表示。
6. 長押しリピート、押下中連続イベント、離した指が次画面の同座標ボタンを押す連鎖を加算に使わない。画面遷移後は一度全指が離れるまで新画面の入力を受けない。[S10]

### 4.3 大きい候補選択

8×8の39pxマスだけでは、実機の指で押しやすいとは断定できない。両サイズに「候補」を用意し、4候補/頁、100×78pxのカードで座標を選べるようにする。行優先順、前頁/次頁、戻る。選択後は盤面へ戻り、まだ「置く」を押す必要がある。

候補が多数でもページ上限は合法手数から計算し、4/8/16件などで切り捨てない。ページを開いた時のplyと現在plyが違えば一覧を破棄して再描画する。盤面をズームしてスクロールする機能はv1で不要。

### 4.4 画面一覧

| Screen ID | 表示と操作 | 次へ |
|---|---|---|
| ENTRY | 再開、始める、遊び方、カフェ | RESUME/SETUP/TUTORIAL/HOME |
| SETUP_SIZE | 6×6 / 8×8、戻る | SETUP_MODE |
| SETUP_MODE | JEV / JEV PRO / CASUAL / 端末AI。利用可否 | SETUP_COLOR |
| SETUP_COLOR | 黒・白・おまかせ、開始前確認 | START_SAVE |
| BOARD | 盤、枚数、手番、選択、操作 | 適切な状態へ |
| CHOICES | 合法座標4件/頁 | BOARD |
| MENU | 続ける、Jev評価、投了、やめる、カフェ | 確認/復帰 |
| DETAILS | 最後のJev入力盤面と選択、候補確率、モデル | MENU |
| NETWORK_CHOICE | もう一度状態確認、端末AIで続行、カフェ | WAIT/FREEZE_LOCAL/HOME |
| CONFIRM | 破棄・投了・端末AI切替などの確認 | 実行/取消 |
| PAUSED | 一時停止中、再開/カフェ | BOARD/HOME |
| RESULT | 勝敗、石数、盤サイズ、相手区分、再戦/カフェ | SETUP/HOME |
| SAVE_ERROR | 最後の確定盤面を維持、再読出し/終了案内 | 復旧またはABORT |
| TUTORIAL | 8ページ、前後、戻る | ENTRY |

文言105件とチュートリアル8ページは付録JSONを使用。状態コードや英語エラーをそのまま一般利用者へ出さない。文章カードは256px幅・本文24pxを基準に1頁最大7行。自動縮小で読めない文字にせず、必要なら明示ページ分割する。

### 4.5 Jev評価の表示

見せるのは実際の`probabilities`と`confidence`、選んだ座標、対象となった**着手前の盤面**である。現在の盤面へ、前の一手の確率を重ねない。上位3候補＋全候補のページ表示とする。

名称は「候補への予測配分」「モデルの自信指標」。**勝率・最善手率・人間の心を読んだ確率とは表記しない。** TypeSafeはconfidenceを回答分布由来の指標としている。[S05] Jevの非公開思考を見たような「角を狙うために考えました」という後付け文は生成しない。PROの計算済み特徴は「盤面から計算した特徴」と別表示できる。

CASUALで最大候補以外を選んだ場合は「確率から抽選した手」。Fは「置ける場所が一つなので自動着手」。Lは「端末AI」で、Jev確率やconfidenceを作らない。再起動で評価詳細のRAMが消えたら「この手の詳細は残っていません」と表示する。

---

## 5. 状態機械とコントローラー

### 5.1 状態一覧

`SETUP, START_SAVE, HUMAN_TURN, HUMAN_SELECTED, COMMITTING, FORCED_PASS, AI_REQUEST, AI_WAIT, AI_STAGED, NETWORK_CHOICE, ANIMATING, PAUSED, SUSPENDED, RESULT, SAVE_ERROR`。

UI状態とSession.closureは別。PAUSEDはActiveのまま。RESULTはCompleted/Resigned/Abortedのいずれかで、放置しても重複して結果保存しない。

### 5.2 手番へ入る共通処理

```text
enterTurn():
  if paused/suspended/closure != Active: return
  if both colors have no legal moves: persisted completion → RESULT
  if current legal count == 0:
      FORCED_PASS → 700ms後、FでパスをdurableCommit → enterTurn
  else if current side == human:
      HUMAN_TURN（合法手1つでも本人が確定）
  else if legal count == 1:
      Fで唯一の手をdurableCommit → ANIMATING → enterTurn
  else if mode == local or localOnly:
      localMoveを計算 → LでdurableCommit → ANIMATING → enterTurn
  else:
      prepare snapshot/hash/request → AI_REQUEST
```

この分岐はUIごとに複製せず一か所にまとめる。終局後にJevを呼ばない。パスで同じ人が連続して石を置く場合もあり、単純な人間/AI交互の画面遷移にしない。

### 5.3 入力は意図として渡す

LVGL callbackは`SELECT(square,expectedPly,uiEpoch)`、`CONFIRM(expectedPly,uiEpoch)`、`PAUSE`などの小さいイベントをキューへ渡すだけにする。HTTPやNVS書込みや大きな推論処理をcallbackに置かない。

参考`src/lvgl8_board_example.hpp`は盤面とボタンを作る接続例。`UiPort`を実装し、唯一のcontrollerにイベントを集める。**このヘッダーを貼るだけでGoogle接続や保存まで完成するものではない。** callbackが参照するBoardViewインスタンスは、画面が存在する間移動・破棄しない。destroy後の非同期イベントはuiEpochで無効にする。

### 5.4 保存を先にする

`Session next=current`へ`commit()`を実行し、成功したnextを保存して読出し検証する。保存成功後にcurrent=nextとし、反転アニメーションを180msを目安に実行する。失敗時はcurrentを維持し、入力を止める。

C++の`commit()`自体は**RAMのルール確定**であってNVSトランザクションではない。コード名だけで永続化済みと誤解しない。`durableCommit()`をcontroller/store層で追加する。

```cpp
// 実際のStore実装は第11章。エラーを無視しない。
Session next = current;
if (!ct_rev::commit(next, move, source, expectedPly)) {
    showRecoverableStateError();
    return;
}
if (!store.writeAndReadBack(next)) {
    enterSaveError();
    return;
}
current = next;
renderCommittedBoard(current);
```

`expectedPly`が同じ連打は最初の一回だけ通る。新しいゲームへ移った後のイベントはgame_idでも拒否する。二重送信防止を一定秒数の無条件待機だけに頼らない。

---

## 6. Jev契約

### 6.1 役割の境界

Jevは**合法手一覧から一手を評価・選択**する。座標の合法性、反転枚数、終局、保存、勝者はプログラムの責任。盤面画像は送らず、テキスト行列を送る。現行モデル資料はテキスト入力を指定している。[S04]

2026-09-22の公式一覧で`jev-1.13.0`を確認したため初期モデルIDとする。[S04] 起動条件は管理者が実キーでこのIDを呼べること。別モデルへ変えるときは設定、テスト、prompt/model記録を同時に更新する。`jev-latest`への無断追従は禁止。

### 6.2 HTTP形式

公式の`POST https://api.typesafe.ai/v1/systemone`、Bearer認証、JSONの`model/state/questions`を使う。Choiceは候補をキーとする`criteria`を持ち、応答は`answers.move`から取得する。[S03]

実際の送信本文は`CTReversi.buildJevRequest(snapshot,model)`で作る。付録に実装全文を収録した。架空のRESTエンドポイントやSDKのimportをGASへ置かない。

送るstateは以下だけ。

| キー | 意味 |
|---|---|
| game / rules_version | 本ゲームと版 |
| board_size | 6または8 |
| columns / rows | 左からの列文字、上からの行番号 |
| board_rows | 上から順にn文字の行をn本。B/W/. |
| legend | B黒、W白、.空き |
| side_to_move | Jevが今回指す絶対色 |
| counts | 黒・白・空きの実数 |
| legal_moves | 行優先の合法座標をすべて |

社員名、PIN、端末token、ゲームID、天気地点、じゃんけん履歴、コーヒー利用数はJevへ送らない。GASが検証のため受け取る棋譜も、盤面の再計算が終わった後はJev本文に入れない。

質問文は付録コードの英語固定文を使う。色・座標・8方向の反転・非連鎖・双方置けないと終局・空マス無得点を明示し、直近の反転枚数だけを最大化しないようにする。全合法手を渡し、コードが気に入った上位3手だけへ勝手に絞らない。

### 6.3 正常応答の検証

`parseJev()`は次をすべて確認する。

- 応答modelが要求した固定IDと一致。answers.moveがtype=choice。
- 確率のキー集合が全合法手と厳密に一致。欠落・余分・配列を拒否。
- 値はnumber、有限、0〜1。文字列数値、NaN、Infinityを許さない。
- 和が1±0.001。範囲内の丸め誤差だけ正規化し、それ以外は失敗。
- choiceが合法かつ最大値から1e-6以内。confidenceは0〜1の有限数値。
- 最大同率の正規化後の手は行優先で確定。APIが返したchoiceもapi_choiceとして残し、同率補正を隠さない。
- usageは非負整数のときだけ保存。欠落時nullを許容し、推測トークン数を作らない。

確率やconfidenceを信頼して合法性の再検査を省略しない。表示上の四捨五入は描画だけで行い、計算用に丸めない。

### 6.4 エラー

401/403は認証設定異常として管理者に通知し、Jevを利用不可にする。400/422は契約異常。429/529/5xxは一時停止を設ける。その他の非200・HTML・サイズ超過・JSON不正・タイムアウトは失敗。[S03] 本版の初期クールダウンは429/529/5xxで60秒とし、次の局面以降の新規予約を止める。401/403/400/422は管理者が設定を直して解除するまで利用不可。クールダウン終了後も同じfailed局面を再試行しない。

**同じ局面のJev呼出しは、アプリケーションから最大1回の予約・試行。** 同一局面の失敗後に再試行を何度も行う設計ではない。端末は状態を照会し、最終failedなら端末AIへ切替、または局をやめる。課金先内部の処理をexactly-onceと保証するものではない。

---

## 7. PRO特徴量、抽選、端末AI

### 7.1 PROの全特徴量

合法手を仮適用した盤面qを作り、以下を候補の説明に付ける。手番色をself、反対をopponentとする。

| 名前 | 厳密な定義 |
|---|---|
| flipped | その一手で反転する相手石の枚数。置いた石を含めない |
| corner | 置く位置が四隅 |
| edge | 外周。cornerもtrue |
| x_adjacent_to_empty_corner | qで空いている隅に、置いた位置が斜め隣接 |
| c_adjacent_to_empty_corner | qで空いている隅に、置いた位置が辺方向で隣接 |
| self_legal_count_on_resulting_board | qでselfが次に打つと仮定した合法手数 |
| opponent_legal_count_on_resulting_board | 同じqでopponentが打つと仮定した合法手数 |
| terminal | qの両色合法手が0 |
| terminal_disk_diff | terminalならself枚数−opponent枚数、非終局ならnull |

これは一手先の局面特徴であり、相手がさらに一手打った未来ではない。「確定石」「勝率」「数手先の読み」を計算したように表現しない。特徴量を使ってJevの選択を裏で端末エンジンの手へ差し替えない。

### 7.2 CASUALの抽選

正規化確率に1,000,000を掛けて床を取り、余った整数分を小数部分の大きい順へ1ずつ配る。同じ小数は行優先。同じ乱数roll∈[0,999999]に対して累積重みで選ぶ。これにより保存・再送で浮動小数の境界差を最小化する。

rollはGASの予約時に一度決め、レコードへ保存する。再送・再開・決定応答の再取得で引き直さない。秘密の32byte鍵を使い、`HMAC-SHA256(key, UTF8("REV_ROLL|1|"+decision_key+"|"+counter))`の先頭4byteをbig-endian符号なし整数uとして読む。

`u < 4,294,000,000`なら`u %1,000,000`を採用し、それ以外ならcounterを1増やす。counter初期0、100回を超えたら内部エラーで予約を止める。これはモジュロ偏りを避ける棄却法である。rollは強度や勝率を保証しない。

### 7.3 端末AIの完全定義

付録の`local_move/localMove`は深い探索を行わず、合法手を一つ仮適用してself視点で評価する。

```text
終局：石差d>0なら100000+d、d<0なら-100000+d、d=0なら0。
それ以外：
120×隅の占有差 + 8×合法手数差 − 4×frontier石数差
− 25×空き隅X隣接の石数差 − 10×空き隅C隣接の石数差
+ w×石数差
w = 空き>総マス/2なら−1、空き>総マス/4なら1、それ以外6。
```

frontier石は8近傍のどこかに空マスがある石。各石は一度だけ数える。X/Cリスクは空き隅ごとに該当位置を数える。差はすべてself−opponent。最高得点、同点は行優先。これは本書独自の軽量方針で、最善手や終盤完全読みに相当しない。

ネットワーク不調時でも盤面ロジックとこのAIだけで一局を終えられる。LOCALのゲームをJev戦績に混ぜず、途中切替は「Jev＋端末AI」とする。

---
## 8. Google連携と通信の構成

```text
ESP32：ルール、操作、棋譜、保存、表示、端末AI
    ↓ HTTPS / JSON
既存環境と共存するGoogle Apps Script Web App
    ├─ ゲーム用の非公開Googleスプレッドシート
    └─ UrlFetchApp → TypeSafe Jev
```

Googleスプレッドシートは保存先、GASは認証・検証・外部呼出しを担当する。専用VPSは不要。既存がGAS以外の経路なら、その方式を実コードで確認して適応し、現在の接続方式を推測で上書きしない。

### 8.1 秘密と認証

端末ごとの32byte以上の乱数tokenを使い、ESP32には端末tokenだけを設定。GASのScript PropertiesへtokenのSHA-256を保存し、検証する。Jevキーと抽選鍵はGAS側だけに置く。Script Propertiesは編集権限を持つ人から秘密を隔離する仕組みではないため、編集者を管理者に限定する。[S09]

端末tokenはHTTPSのJSON本文に入れる。URL、query、ログ、結果シートへ保存しない。AI DUEL等と共通の認証関数を使えるが、旧APIにないplayer_tokenを本APIへ勝手に追加しない。個人プロフィールは本ゲームに不要。

### 8.2 Apps Script固有の注意

`doPost(e)`では`e.postData.contents`を読む。任意Authorizationヘッダーがeventへ渡る前提は置かない。ルーターはnamespace=`jev_reversi`だけを新機能へ振り分け、他namespaceを元の実装へ渡す。[S06]

ContentServiceのTextOutputに架空の`setStatusCode()`を使わない。アプリケーション上の成否はJSONの`ok/error`で返す。HTTP200だけで成功と判定せず、ログインHTML、エラーページ、Content-Type、JSON型、namespace、versionを検査する。公開APIのパラメーターに予約名`c`や`sid`を用いない。[S06][S07]

### 8.3 リダイレクト

ContentServiceは返答を`script.googleusercontent.com`の一時URLへリダイレクトする。[S07] ESP32は設定済み`https://script.google.com/macros/s/.../exec`へPOSTし、302/303の返答取得先へ**GET、本文なし、tokenなし**で追従する。HTTPSかつ明示的に許可したGoogleホストだけ、最大3回。

unknown host、HTTPへの降格、ログイン要求、307/308での秘密本文再POSTは本版では拒否する。HTTPClientの「強制追従」を無条件で設定して終わりにせず、採用バージョンで送信内容を確認する。証明書検証を無効化しない。

### 8.4 タイムアウトと制限

GAS→Jevは`timeoutSeconds:8`。現行Google公式UrlFetchApp資料にこの指定がある。[S08] ESP32の接続は5秒、HTTP一連はリダイレクト込み15秒を初期上限とする。GAS起動・Sheets保存を含めて8秒以内に必ず返るという意味ではない。

応答待ちが長い場合も画面を止めない。経過表示の後、状態照会 / 端末AIへ切替 / カフェに戻る、を選べる。`decision.get`の自動照会は1秒・2秒・4秒間隔の最大3回、その後は手動。準備処理を再呼出ししてモデルを再抽選しない。

Google/TypeSafeのアカウント利用上限は変更されうるので、本番アカウントの最新値を確認する。[S04][S16] アプリ自身の保守的な初期制限は、端末ごとJev予約300回/日、一局60回まで、新規予約間隔1秒以上。6×6は配置数32も上限となる。強制手・パスでは予約を消費しない。予約後に失敗しても、その枠を安易に払い戻さない。

---

## 9. 自社APIの完全契約

### 9.1 共通リクエスト

全操作はPOST `/exec`、UTF-8 JSON。未知キー、型の取り違え、必須欠落を拒否。本文8KiBまで。IDは小文字32hex、hashは小文字64hex、時刻はUnix epoch msの非負安全整数。

```json
{
  "namespace": "jev_reversi",
  "api_version": 1,
  "action": "decision.prepare",
  "request_id": "11111111111111111111111111111111",
  "device_id": "22222222222222222222222222222222",
  "device_token": "<実環境で登録する秘密token>",
  "sent_at_ms": 1790000000000,
  "payload": {
    "snapshot": {
      "game_id": "33333333333333333333333333333333",
      "n": 6,
      "human": "W",
      "mode": "jev",
      "history": []
    },
    "ply": 0,
    "position_hash": "<下記identityから計算する64hex>"
  }
}
```

これは形式説明用で、時刻・秘密・hashは実呼出しにそのまま使えない。盤面は6×6初期、AIが黒のため、この局面は実際にAI判断が必要である。

`request_id`は一つの通信意図で固定して再送するが、モデルの二重呼出し防止はrequest_idではなく**decision_key**で行う。`sent_at_ms`は再送時に更新してよい。サーバー時刻と±5分以内を検査し、helloのみ0を許可する。TLSのための時計・信頼ストアの準備をhelloで省略できるわけではない。

### 9.2 棋譜の指紋

`CTReversi.identity(snapshot)`のASCII文字列をUTF-8化してSHA-256を取り、小文字hexにする。

```text
REV1|1.0.0|game_id|n|human|mode|ply|side|cells|historyをカンマ結合
```

空履歴でも最後の`|`は存在する。盤面cellsはn*n文字で改行なし。JSON文字列化のキー順序に依存させない。このidentity文字列とhashをGASで再計算し、両方を台帳へ保存する。

`decision_key = device_id + ":" + game_id + ":" + plyの10進整数`。

同じdecision_keyで盤面、モード、履歴のいずれかが違ったらSTATE_CONFLICT。同じ局面に別request_idを付けても再推論しない。別ゲームIDなら別局だが、日次上限と新規予約間隔で無制限呼出しを抑える。

### 9.3 全4操作

| action | payloadの全キー | 処理 |
|---|---|---|
| `device.hello` | `{}` | 端末認証、時刻、利用可否、固定モデル、schema/rules版、残枠、保守状態 |
| `decision.prepare` | snapshot, ply, position_hash | 棋譜再生・AI手番検証、既存照会または一回だけ予約してJevへ |
| `decision.get` | game_id, ply, position_hash | 同じ端末の既存判断を取得。未登録ならNOT_FOUND。Jevは呼ばない |
| `result.put` | snapshot, end_reason, client_ended_at_ms | 棋譜と勝敗を再検証し、一局の結果を冪等保存 |

snapshotはgame_id、n、human、mode、historyだけ。position/合法手/勝者の自己申告値を追加しない。`ply == history.length`も検査。強制手、終局、人間手番、local局はprepareにNO_DECISION_REQUIREDまたはLOCAL_ONLYを返す。unknown nは丸めず拒否。

### 9.4 共通レスポンス

```json
{
  "namespace": "jev_reversi",
  "api_version": 1,
  "request_id": "11111111111111111111111111111111",
  "server_time_ms": 1790000000123,
  "ok": true,
  "data": {},
  "error": null
}
```

失敗は`ok:false,data:null,error:{code,message_ja,retryable,retry_after_ms}`。retry_after_msは0以上。レスポンス16KiBまで。外部providerのrawレスポンス・stacktrace・秘密をerrorに入れない。

**hello data**：`server_time_ms,jev_available,model,modes,rules_version,schema_version,daily_calls_remaining,maintenance`。

**DecisionView data**：

```text
decision_key, game_id, ply, position_hash,
status: pending | ready | failed,
move: 座標またはnull,
inference: 正規化済みJev評価またはnull,
retry_after_ms: 非負整数,
error_code: nullまたは非秘密の失敗理由
```

- pendingはmove/inference=null、retry_after_ms=1000を初期値にする。
- readyは合法moveとinferenceが必須、retry_after_ms=0、error_code=null。
- failedはmove/inference=null、retry_after_ms=0、error_code必須。failedは終端状態であり再prepareしない。error_codeは`NO_KEY`, `PROVIDER_TOO_LARGE`, `PROVIDER_FETCH_OR_PARSE_FAILED`, `LEASE_EXPIRED`、または`PROVIDER_HTTP_<実HTTPコード>`（100〜599、200以外）のみ。例外本文は含めない。
- inferenceの全キーは`model,choice,api_choice,probabilities,confidence,normalization_applied,input_tokens,output_tokens`。CASUALのmoveはinference.choiceと異なってよいが、保存したrollから一致を検証する。

**result.put data**：`result_key,status,verification,provider_class,winner,black,white,empty`。statusは`stored`または`already_stored`。winnerはB/W/D/null。受信日時が異なっても、同じ局の内容を変更しない。

### 9.5 エラー全種類

| code | 意味・ユーザー動作 |
|---|---|
| BAD_REQUEST | 型・キー・サイズ・IDの不正。設定またはクライアントを修正 |
| AUTH_FAILED | 端末認証失敗。Jev/結果送信を止め、カフェと端末AIは維持 |
| CLOCK_SKEW | 時刻再同期後、同じ意図を再送 |
| RULE_VERSION_MISMATCH | ルール版不一致。自動変換せず更新確認 |
| MODE_UNAVAILABLE | Jevキー/モデル利用不可。本人が端末AIを選ぶ |
| BAD_SNAPSHOT / ILLEGAL_HISTORY | 棋譜不正。局を再検証。盤面を無理に修正しない |
| NO_DECISION_REQUIRED | 人間手番、強制手、終局。端末状態を再検証 |
| LOCAL_ONLY | 既に端末AI局。Jevへ戻さない |
| STATE_CONFLICT | 同じ局面キーに異なる棋譜。安全に停止し無効終了 |
| NOT_FOUND | 判断未登録。prepare未送信なら一度送る。送信結果不明なら保守状態も確認 |
| BUSY | ロック取得不可等。指定時間後に同じ意図の状態確認 |
| PROVIDER_FAILED | 判断failed。端末AI/終了を選ぶ |
| DAILY_LIMIT / STORAGE_LIMIT | 新規Jev予約停止。端末AIへ誘導 |
| STORAGE_UNCERTAIN | 保存結果が不明。管理者照合まで新しいオンライン更新を止める |
| MAINTENANCE | 保守中。破棄したことにせず端末AI/保存再開 |
| RESULT_CONFLICT | 同じ結果キーが異なる内容。上書き禁止 |
| INTEGRITY_ERROR | 棋譜のJ手と保存済みJev決定が不一致。結果を受理しない |

認証等の共通失敗はok=false。レコードとして終端failedが存在するときのgetはok=true,data.status=failedでもよい。端末は両階層を検査する。内部コードの`BAD_SOURCE`等は外部ILLEGAL_HISTORYへ明示マッピングする。

---

## 10. Google Sheetsの保存と再送

### 10.1 タブと全列

ゲーム関連は管理者だけが編集する非公開Workbookへ入れる。コーヒー集計が全社員公開なら別Workbookにする。全タブは同一Workbook・同一GAS writerで管理する。列順の正本は`data/sheets_schema.json`。

| タブ | 主キー | 用途 |
|---|---|---|
| ReversiMeta | key | schema、行割当、日次枠、保守、配備版 |
| ReversiDecisions | decision_key | 推論予約、同一局面、確定した手、確率 |
| ReversiResults | result_key | 匿名の一局結果、棋譜、検証区分 |

**ReversiMeta**の全列：`key,value_json,updated_at_ms`。

初期キー：`schema_version`, `rules_version`, `installed_at_ms`, `next_row:ReversiDecisions`, `next_row:ReversiResults`, `deployment_version`, `last_write_receipt`。日次キーは`budget:<device_id>:<YYYY-MM-DD>`、最短間隔は`last_reservation:<device_id>`。日付はAsia/Tokyo。秘密はMetaへ置かない。

**ReversiDecisions**の全列：

```text
decision_key,device_id,game_id,ply,position_hash,identity_text,snapshot_json,
mode,model_requested,prompt_version,features_version,status,generation,
created_at_ms,lease_until_ms,resolved_at_ms,roll,move,inference_json,
error_code,latency_ms,input_tokens,output_tokens
```

statusはpending/ready/failed。generationはworker世代のランダムIDで、ESP32保存generationとは別。snapshot_jsonは正規化した5フィールドだけ。rollは0〜999999の固定値（CASUAL以外はnullでもよい）。readyだけmove/inferenceが入る。未取得時刻・使用量はnull相当の空セル。lease期限は予約時刻＋20000ms、後から延長しない。

**ReversiResults**の全列：

```text
result_key,device_id,game_id,fingerprint,received_at_ms,client_ended_at_ms,
n,human,mode,end_reason,winner,black,white,empty,placements,passes,
jev_moves,local_moves,forced_ai_moves,provider_class,verification,history_json
```

result_keyはdevice_id:game_id。fingerprintは`UTF8("REV_RESULT|1|"+identity+"|"+end_reason)`のSHA-256。client_ended_at_msは参考時刻で指紋に含めず、再送時も端末では元値を維持する。最初に保存された値を正本とする。配置/パス/出所はサーバーで再計算し、人間の自己申告集計を保存しない。

### 10.2 provider_classとverification

適用されたAI配置だけ数える。人間の配置、強制パス、未適用のAPI応答はJev手数に含めない。

| provider_class | 条件 |
|---|---|
| jev | J>0かつL=0 |
| mixed | J>0かつL>0 |
| local | J=0かつL>0 |
| forced_only | J=0かつL=0。強制手のみ、または早い中断 |

verificationは以下。

- `verified_jev`：J>0、L=0、すべてのJ手が当時のready決定・局面hashと一致。
- `verified_mixed`：J>0、L>0、すべてのJ手が一致。
- `local_replay`：J=0、棋譜ルールが正常。強制手のみもここに入れる。
- `replay_only`：J手の過去レコードが保存期限経過等で参照できず、ルール再生のみ成功。一致未確認をJev実績としない。

既存レコードがあるのに不一致ならINTEGRITY_ERRORで拒否し、replay_onlyへ格下げして通さない。端末AI手Lは合法性と切替後の順序を検査するが、匿名利用の改造端末を完全に排除する認証対戦サービスではない。個人ランキングや賞金の根拠に使わない。

### 10.3 更新の原則

Sheets APIのbatchUpdateは同一リクエスト内の更新を原子的に適用できる。[S11] ただし、読み取ってから書く一連の処理が自動的にDBトランザクションになるわけではない。GASのScriptLockを使い、同じWorkbookを更新するすべてのゲーム/保守処理が同じ規約を守る。[S12]

- IDを確認した固定行にUpdateCellsで書く。新規行はMetaのnext_rowを割当て、その更新も同じbatchへ入れる。
- 日次枠の増加、予約作成、next_row更新は一つのbatch。
- 外部Jev HTTPはロックの外。ロック中に長いsleep・リトライループを置かない。
- 入力文字列はstringValue、数値はnumberValue、boolはboolValue。利用者文字列をformulaValueへ入れない。
- キャッシュはID→行等の高速化に限り、キャッシュ消失で重複予約・再課金しない。
- 元データ行を人がソート/挿入/手編集しない。別のレポート用タブを作る。
- ScriptLockだけでは別GASプロジェクトを排他できない。writerを一つに統一し、不可能なら共通の実排他経路を構築するまで稼働不可。

### 10.4 保存結果が不明な場合

各更新の前に、Script Propertiesの`REV_STORAGE_BARRIER`へreceipt_id、対象行、書込後データのhash、開始時刻だけを保存する。秘密本文を置かない。その後、固定行のUpdateCellsとMeta.last_write_receiptを同一batchで実行。

正常応答・読出し照合後にbarrierを消す。タイムアウト・実行中断・読出し不一致なら、barrierを残して**新規オンライン更新を停止**する。別のexecuteがbarrierを見た場合、更新がなかったと仮定して別の行を割り当てない。

管理者のrepairは、元workerが終了したことを確認し、last_write_receiptと全対象行のhashを照合。全部一致なら完了扱い、未適用を確実に確認できれば同じ固定行・同じ値の再適用、部分不一致ならバックアップ/監査で解決する。確認できないまま自動クリアしない。通常の通信再送と不確定な保存の復旧を混同しない。

既存DUEL等が共通のstorage barrierを持つなら、その機構へ統合し、片方が他方の不確定状態を無視しない。Reversiが止まっても、独立して安全な既存コーヒー＋1は止めない。なお、この永続化接続は付録の純粋状態モデルでは再現しきれず、実GAS受入試験で検証する。

### 10.5 一手の予約と確定

```text
認証・時刻・サイズ・型検査
→ snapshotを初期盤面から再生 / identity再計算
→ ScriptLockを取得（初期tryLock 2000ms、取れなければBUSY）
→ barrierがあればSTORAGE_UNCERTAIN
→ decision_key検索
   既存でhash違い: STATE_CONFLICT
   既存ready/failed: 同じレコードを返す
   既存pending: 期限内ならpending、期限超過ならfailedへ確定
→ 新規なら枠/間隔/容量を検査
→ pending, generation, lease, snapshot, model, rollを一括保存
→ ロック解除
→ この新規予約workerだけがJevを一度呼ぶ
→ ScriptLock再取得、barrierと同じ世代を照合
→ pendingかつ世代一致かつ期限内だけready/failedを一括保存
→ それ以外の遅い応答は破棄
```

期限と等しい時刻は期限内、超過で期限切れ。pendingのleaseが失効しても新workerでJevを呼ばず、failedへ終端化する。`decision_machine.js`はこの遷移を試験する純粋モデルであり、**実Lock/Sheets/Propertiesを代行しない**。

### 10.6 結果保存・保守

`result.put`は全棋譜を再生し、各J手の直前identityを再現して当時の記録と照合する。completedなら終局必須、resigned/abortedなら未終局必須。winner・石数等を再計算し、keyとfingerprint一致の再送なら前の結果を返す。不一致はRESULT_CONFLICT。

Decisions90日、Results180日を初期保持。上限はそれぞれ10000行/2000行（ヘッダー除外）。上限到達は新規予約や結果保存を停止し、管理者へ保守案内する。データを捨てて成功と返さない。

整理は保守モードでwriterを止め、バックアップ後に期限外行を除去して索引・next_row・キャッシュを更新。ゲーム中に物理行を詰めない。日次budgetは古い日付を保守時に整理。履歴を永久にフルスキャンして一手を判断しない。

---
## 11. 端末保存・電源断・再開

### 11.1 一局の保存形式

セッションは公開盤面なのでNVSへの保存を許可する。秘密役職をRAMだけへ置く人狼とは用途が異なる。保存するのは局ID、モード、色、出所つき棋譜、終了状態、localOnly、generation。盤面の重複コピーやJevの秘密キーは保存しない。

付録の`encode/decode`は明示バイト列を使う。構造体をそのまま`memcpy`して保存しない。パディング、エンディアン、コンパイラの差を避ける。

| オフセット | 長さ | 内容 |
|---:|---:|---|
| 0 | 4 | ASCII `REV1` |
| 4 | 1 | 保存形式version=1 |
| 5 | 1 | n=6/8 |
| 6 | 1 | human=1黒/2白 |
| 7 | 1 | mode=0Jev/1Pro/2Casual/3Local |
| 8 | 1 | closure=0Active/1Completed/2Resigned/3Aborted |
| 9 | 1 | localOnly=0/1 |
| 10 | 2 | 予約0 |
| 12 | 4 | generation、little-endian |
| 16 | 16 | 一局IDの生byte |
| 32 | 2 | history count、little-endian |
| 34 | 2×count | move0〜63または255PASS、source0H/1J/2L/3F |
| 最後 | 4 | それより前の全byteのCRC32、little-endian |

サイズは38+2×count、**最大294byte**。CRC32はIEEE反射型、poly0xEDB88320、init/xorout0xFFFFFFFF。CRCは偶発破損検出で、暗号署名ではない。

decodeは長さ・版・CRC・enumを検査し、初期盤面から全イベントを`commit`して復元する。違法手、違う手番の出所、Fの誤用、Jevへの戻り、終局後の追加手、終了状態の不一致を拒否する。失敗時に出力Sessionの一部だけを上書きしない。

### 11.2 NVS接続

namespaceは`ct_rev`。`slot0`と`slot1`の二世代を使う。`nvs_set_blob`のあと`nvs_commit`、読出し、decode、generation/棋譜照合まで成功して保存完了とする。既存namespaceは変更しない。NVSの耐電断特性があっても、書込み時点の新しい値が必ず残るとは限らない。[S14]

新局開始時は、旧局の終了処理後に新局generation=1を両slotへ保存するか、旧局を無効にした保存metadataと整合する手順にする。通常の更新はgenerationの低いslotへ書く。**局IDが異なる二つの有効slotを単にgenerationだけで比較しない。** 新局開始を識別する非秘密metadata（active_game_id）も二相で保存し、どの局が現在か確定できなければ選択確認または無効終了とする。

実装の簡素化を優先する場合の採用手順：

1. 旧局を閉じる。未送信結果を必要ならoutboxへ移す。
2. `ct_rev/start_pending`へ新局IDを書いてcommit。以降旧局へは自動復帰しない。
3. 新局の同一snapshotをslot0、slot1へ順に保存・検証。
4. active_game_idを新局IDに保存、start_pendingを消す。同じNVS commitで更新する。
5. 起動時start_pendingが残れば、そのIDで有効なsnapshotが両方同一か確認して開始処理を完了。片方しかなければもう片方へ同じsnapshotを補完。両方なければ「開始を完了できませんでした」とし、旧局を勝手に再開しない。

namespace/key名はNVSの制限に収める。[S14] 例の`active_game_id`は14文字、`start_pending`は13文字。

### 11.3 更新と読出しの失敗

最後の保存に失敗したら、画面は保存前の盤面へ留める。再タップを許す前に両slotを再読出しし、同一局でどこまで保存されたか確認する。書込み例外が出ても「絶対に未保存」と仮定しない。

起動では先にゲーム画面を出さず、metadataと両slotを検証する。両方有効なら同一局IDの高いgeneration。最新らしいslotが破損している場合は、古い盤面へ黙って戻らず「保存の一部を確認できません」と案内し、安全な破棄を基本とする。以前の局面を再開して同じplyへ別の手を生成しない。

リバーシだけの保存エラーで`nvs_flash_erase()`を呼ばない。既存Wi-Fi/カフェ/人狼/個人プロフィール関連のデータを巻き込まない。

### 11.4 再開できる範囲

同一端末の1局、最終保存から標準7日以内。非秘密metadataに保存時刻を置き、時刻が未同期なら「保存日時不明」として本人に再開/終了を選ばせる。NTP未取得を理由に棋譜を破壊しない。

再開したら常にPAUSEDを一度経由。現在手番を計算し、人間なら選択なしから、AIなら同じdecision_keyを状態照会して再開する。すでにLへ切り替え済みなら問い合わせない。AIの前回応答がRAMから消えていても、同じGASレコードをgetする。

画面遷移・HTTP応答未受信・電源断の直前の操作が失われる可能性はある。保証は「正常に保存され検証できた最新の確定状態へ戻る」。一度見えた未保存のアニメーションまで完全復元すると説明しない。

### 11.5 終了結果outbox

Googleへ結果を送れなくてもRESULT画面を表示し、端末には閉じたsnapshotとend_reason、client_ended_at_msを保存して後送する。outboxは最大4局。各項目にschema、局ID、CRCを付け、端末tokenやJevキーは入れない。

満杯なら「古い未送信結果を破棄して続ける / 今回は記録せず遊ぶ / 戻る」を明示し、勝手に成功扱いで捨てない。本人が破棄したときのみ削除。ゲーム中に新旧のresult_keyを取り違えない。

result.putがstored/already_storedかつkey/石数/勝者を検証できてから、その項目を消す。再送は同じsnapshot・end_reasonで行う。結果を2行追加したり勝数を二重加算したりしない。

---

## 12. 非同期・中断・遅延応答

### 12.1 ワーカーの分離

LVGLを触るのは既存UIタスク一つ。HTTPワーカーからウィジェットを直接更新しない。受信結果は固定上限のメッセージをキューへ渡す。LVGLは原則thread-safeではないため、既存portのmutexとtimerタスクに合わせる。[S10]

受信時は少なくとも`game_id, ply, position_hash, decision_key, waiting状態, localOnly,合法手`を照合する。付録`acceptsReply`はこの局面整合性を検査する。加えて、**PAUSED/SUSPENDEDでは適用せずstageする**条件をcontroller側で入れる。関数を通っただけで必ず打ってよいわけではない。

### 12.2 操作別の挙動

| 状況 | 処理 |
|---|---|
| Jev待ちでカフェへ | 選択解除、PAUSED→SUSPENDED、盤面保存。返答は同じ局面ならRAMにstageのみ |
| 終了後に古い返答 | 無視。新局へ適用しない。使用済みJ手として数えない |
| 端末AI切替後のJev返答 | 無視。GASにreadyが残っても採用しない |
| 人間が連続で「置く」 | 保存中は入力を止め、expectedPly一致の最初だけ受理 |
| API待ち中に別モード選択 | 同じ局では変更不可。いったん局を終了して新局 |
| 盤面選択後にカフェへ | 未確定の選択は破棄。再開時に自動確定しない |
| 応答がpendingのまま20秒超 | getでfailedへ期限処理。モデルを再実行しない |
| Wi-Fi復帰 | localOnly=trueならその局は端末AIのまま。次の新局からJevを選べる |

### 12.3 端末AI切替は不可逆

本人確認後、`freezeLocal()`の結果を先に保存してからオンライン待機権限を無効にする。AI手が一意ならその後はFでよい。まだLを一度も打っていなくてもlocalOnlyはtrueとして再起動後も維持する。

GASの棋譜だけではLがまだ現れていない切替を判別できない場合があるため、**端末controllerはfreeze後prepareしない**ことを独立した不変条件にする。レコードのunused readyが残ることは許すが、結果集計では適用済み棋譜だけを見る。

### 12.4 時間の扱い

UIの待機・演出・無操作は単調増加タイマーで計測する。NTP補正で思考時間が飛んだり負になったりしない。32bit millisの差を符号なし差分で処理するか、既存の64bitタイマーを使う。待機時間をループ内の長いdelayで実装しない。

無操作30秒で、文字が読める範囲に減光。120秒で一時停止。触れた最初の操作がゲームの置く操作にならないよう、復帰専用タップを一度挟む。共通のカフェアラーム・充電UIが割り込むときも同様に安全停止する。

---

## 13. BSP・LVGL・容量・電池

### 13.1 ハード初期化は触らない

2.8CのST7701 RGB、3線式SPIの初期化、GT911 I²C、I/O拡張P1/P2の制御を既存BSPに任せる。ESP32 GPIO2と拡張P2を混同しない。表示だけ成功してもタッチ成功とはしない。公式ボード定義に対応設定がある。[S15]

既存がLVGL8ならそのまま。付録のBoardView例はLVGL8用。LVGL9が既に正常稼働している場合はゲームコアをそのまま使い、UI APIだけ現行portへ適応する。参考例のために全体を8へ下げない。

新規独立環境が必要な場合に限り、過去の段階1設計書と同じ対応済みボード例を確認する。PSRAM OPI、Flash16MB、QIO80MHz、USB UART接続時CDC無効/native USB時有効という対応資料はあるが、使用中の既存環境へ無断適用しない。[S15]

### 13.2 初期メモリー予算

| 対象 | 設計上限・方針 |
|---|---|
| 盤面 | 固定64要素と小さい状態。毎手newしない |
| 棋譜 | 128件×2byte＋状態 |
| 保存snapshot | 最大294byte |
| HTTP request | 8KiB、response16KiB上限 |
| last Jev表示キャッシュ | 1件だけ。生HTTP全文を何局もRAMへ残さない |
| UI | 最大64cell/disc/dot＋少数control。画面破棄で全参照を解放 |
| 全画面画像 | 原則0。盤・石はベクター的描画 |
| フォント | 既存の日本語subsetを共有。ゲームごと巨大な全漢字フォントを複製しない |

RGB565の480×480全画面は460,800byte/面。これは計算値であり、既存portが実際に何面確保するかは設定次第。リバーシのために既存バッファをさらに二重三重へ増設しない。

ビルド後、Flash、PSRAM、内部RAM、最小free heap、最大連続空き、HTTP時のスタック、画面出入り100回後の増減を測る。収まらないときに最初からパーティション全書換えを選ばず、不要アセットや重複フォントを除く。

### 13.3 日本語・図柄

本文、ボタン、チュートリアル全文字を抽出してフォントのglyph不足を検査する。ニックネーム入力は不要。石の絵文字へ依存せず、円形描画と黒白表記を使う。小さい補助ボタンは「操作」「候補」の2字で統一する。

配色はlayout.jsonの提案値。カフェの暖色系背景と濃い盤、白黒石。文字や石が隣接背景と識別できるか実機で確認する。ブラウザで見えることを実ガラスのコントラスト確認の代用にしない。フォント本体はこの納品物に含めない。

### 13.4 バッテリー

1500mAhの駆動時間を本書では保証しない。輝度、RGB更新、Wi-Fi、HTTP待ちで変わる。ゲーム中の消費・カフェ待機・充電中を実測する。自動深いスリープはGT911による復帰と保存を実機検証してからで、本版の必須機能ではない。

低電池判定は既存の検証済み測定がある場合だけ使う。存在未確認のADC配線や残量%を捏造しない。充電中を理由にゲームを勝手に再起動しない。USB電流だけからLiPo側の正確な稼働時間を断定しない。

---

## 14. 設定・配備・既存機能

### 14.1 全Script Properties

| 名前 | 内容 |
|---|---|
| REV_SPREADSHEET_ID | ゲームWorkbookの実ID。未設定はオンライン停止 |
| JEV_API_KEY | 共通Jevキー。ソースに書かない |
| REV_JEV_MODEL | 初期jev-1.13.0、実接続で検証した版 |
| REV_ROLL_KEY_HEX | CASUAL抽選用32byte以上の秘密鍵 |
| REV_DEVICE_SHA256_<device_id> | 端末tokenのSHA-256。既存共通authへ明示的にマッピングしてもよい |
| REV_MAINTENANCE | trueなら新規予約停止 |
| REV_STORAGE_BARRIER | 不確定書込みの照合情報。平常時なし |
| REV_PROVIDER_DISABLED_REASON | 認証/契約異常による停止理由。平常時なし |
| REV_JEV_COOLDOWN_UNTIL_MS | 429等の全体クールダウン。初期0 |
| REV_DEPLOYMENT_VERSION | 本番に配備したコードのcommit等 |

共通Jevキーを別の関数で上書きしない。キー更新は停止→テスト→配備→再開。新しいモデルがあることを理由に既存対局中の要求modelを変えない。予約レコードにmodelを固定する。同じ局の最初の予約でmodel/prompt/features版を凍結し、以降のprepareはその局の既存レコードから継承する。設定変更後も既存局の版を提供できない場合はMODE_UNAVAILABLEとし、別モデルへ黙って切り替えない。管理者の破壊的な版更新は進行中局を安全に終了または端末AIへ移した後に行う。

### 14.2 配備手順

1. 既存ソース、GAS、Sheets、NVS保存仕様をバックアップ。第4ゲームはv2の3〜10人対応を保持。
2. 本Markdownを取り出してPC検査を再実行。問題があれば実機に進まない。
3. 端末AIだけでUI・パス・終局・保存・カフェ復帰を実装し、USB給電で試験。
4. 非公開のテストWorkbookを作る。GASはV8、タイムゾーンAsia/Tokyo、高度なGoogleサービスのSheets APIを有効にする。
5. `installReversiSchema()`は不足タブの作成とヘッダーの厳密照合だけ。既存タブのclearは禁止。版違いは明示migrationへ。
6. 共通doPostへnamespace分岐を追加。元のレスポンス形式を他ゲームまで変えない。
7. 管理者がProperties、端末tokenを設定する。サービス所有者実行を採用するときも端末認証を必須にする。
8. Workspaceの制限に反して匿名公開しない。ESP32が既存の承認済み経路で呼べるか確認。不可能なら端末AIだけで動き、オンライン機能は未接続として残す。
9. テスト用`/exec`でhello、mock provider、保存競合、再送、Googleリダイレクトを検証。`/dev`を製品設定にしない。[S06]
10. 実Jevキーで6×6/8×8、黒/白、全モードの基本局面を実送信し、modelと応答型を記録。動作証拠に秘密を載せない。
11. 本番Workbookへschemaを作り、テストと本番のIDを分離して配備。端末設定は必要な値だけ更新。
12. 既存5つの機能群（コーヒー＋1と4ゲーム）を回帰確認し、最後に電池・プレイ試験。

### 14.3 共通アプリへの接続

`registerGame("jev_reversi", slot=5, title="JEV REVERSI", entryCallback)`という役割の登録を、実際のアプリAPIへ適応する。存在しないこの関数名を既存にあると断定しない。

共通HOMEへ戻す前はpause/save、復帰はresume/再検証。全ゲームを同時にRAMへロードしない。ネットワークサービスは既存のコーヒー送信と共有し、ゲームのHTTPが無限に占有しない。カフェ更新を優先する小さいジョブキューとし、同じイベントIDを他ゲームへ再利用しない。

### 14.4 初期登録・匿名性

本ゲームは端末ID＋局IDだけ。個人戦績を勝手に収集しない。結果シートは「6×6/JEV/黒側で何局」という匿名の運用集計用。AI DUELのPlayers表へ自動登録しない。端末を次の人へ渡して再戦したら新しい局IDにする。

---

## 15. コードと実装フェーズ

### 15.1 収録したコードの役割

| ファイル | 稼働/検査範囲 |
|---|---|
| src/reversi_core.hpp | C++純粋ルール、軽量端末AI、ヒット判定、CRC。PCコンパイル試験済み |
| src/reversi_session.hpp | C++棋譜、出所、終了状態、binary snapshot。PC試験済み |
| src/lvgl8_board_example.hpp | LVGL8接続例。実LVGLコンパイル・実画面では未検証 |
| gas/reversi_shared.js | GAS/Node/ブラウザ共通のルール、Jev契約、評価・抽選。Node試験済み |
| gas/decision_machine.js | 永続化前提の予約/lease純粋モデル。実SheetLockを代行しない |
| gas/provider_adapter.gs | UrlFetchApp接続。VMモックでパラメーター試験済み、実APIは未接続 |
| preview.html | ローカルAIのみのブラウザ操作参考。GAS/Jev/ESP32とは未接続 |
| data/*.json | 全定数、文言、tutorial、layout、API、シート、独立oracleの局面例 |
| tests/* | C++、JS、Pythonoracle、ブラウザの各検査 |
| tools/run_all.py | 基本検査の再実行 |
| docs/acceptance.md | 実装後の受入試験表 |

参考コードを基に、エージェントは以下を**実プロジェクトへ実装する**：GameController、NVS Store、ネットワークキュー、全画面の生成、GASルーター/認証/台帳/管理関数、実環境設定。参考断片だけを書き込んで「完成」としない。

### 15.2 推奨インターフェース

```text
ReversiController
  enter(), select(square, ply, uiEpoch), confirm(ply, uiEpoch), pause(), resume()
  requestLocalSwitch(), confirmLocalSwitch(), resign(), abort()
  onNetworkResult(message), onSaveResult(message), tick(monotonicMs)
ReversiStore
  beginNewGame(snapshot), loadActive(), writeAndReadBack(snapshot)
  enqueueResult(snapshot,endReason,endTime), peekOutbox(), ackOutbox(resultKey)
ReversiNetwork
  hello(), prepare(snapshot,ply,hash), get(gameId,ply,hash), putResult(...)
GAS
  routeReversi(e), validateEnvelope(), authenticateDevice(), replaySnapshot()
  prepareDecision(), getDecision(), putResult(), installReversiSchema()
  repairReversiStorage(), compactReversiHistory(), smokeTestReversiProvider()
```

アプリ層の名前は適応可能だが、役割分離と契約は維持する。純粋コアへHTTPやLVGLを混ぜない。ゲーム画面のコードへAPIキーを置かない。テスト用固定乱数やmockの成功レスポンスを本番フラグなしで残さない。

### 15.3 フェーズと完了条件

| 段階 | 完了条件 |
|---|---|
| A：調査・保全 | 元の表示/タッチ/＋1、4ゲーム、接続経路が記録され、戻せる |
| B：純粋ロジック | 付録テストを再実行し、既存コンパイラへcoreを適応 |
| C：端末AI | 6/8、色選択、合法手、確認、パス、終局、投了を実機で完走 |
| D：保存・中断 | NVS読出し・CRC・棋譜再生・カフェ復帰・再起動試験 |
| E：Google | テスト用GASと台帳。mockで競合、重複、権限、redirect、保存不確定 |
| F：Jev | 実キーでschema、選択、PRO、CASUAL、固定モデル、例外を確認 |
| G：統合 | 全ゲーム回帰、メモリー、電池、体験評価、保守手順を確認 |

段階CまではJevが未開通でも作れる。Fの代わりに端末AIを使って「Jevと対戦できた」と報告してはいけない。

---

## 16. 検査と受入

### 16.1 実行方法

Python3、C++17のg++または適応した同等コンパイラ、Node.jsを用意する。標準検査はPython標準ライブラリのみ。ブラウザ追加試験だけPlaywrightとChromiumを使う。バージョンは実行ログに残す。

```bash
python tools/run_all.py
# 任意の追加検査。ツール導入済みの環境で行う。
python tests/browser_check.py
```

Windowsではg++が見つからない場合にMSYS2/WSL等の許可された環境へ適応する。コンパイラ未導入をテスト成功にしない。run_allは実行したコマンドの終了コードとJSONレポートを確認する。

### 16.2 自動検査の意味

独立Python oracleは、相手石を延ばす実装と同じコードを複製せず、自分の石の終端から中間列がすべて相手石かを確認する方式で作った。そこへC++とJSを照合している。同じバグを共有する可能性を減らすが、全局面の数学的正しさの証明ではない。

初期局面から深さ1〜5のperft（パスも一手、終局は一葉）を固定回帰値として持つ。全中終盤を網羅した探索ではない。ランダム対局、境界/強制パス/8方向反転/空きの残る終局、入力不正を別に試験する。

GAS保存モデルのNode検査は、実Googleサーバーの実行中断やSheets権限を再現したものではない。LVGL例もホストルールの成功だけではコンパイル確認済みと言えない。

### 16.3 受入試験の実施ルール

全項目は付録`docs/acceptance.md`。各行に実行日時、実行環境、担当、結果、証拠を付ける。状態は`未実施/合格/不合格/適用外`。適用外は理由を書き、Jev実接続・保存・6/8操作を適用外にして本番完成扱いにしない。

既存のゲーム仕様書のテストを無効化しない。今回の追加で第4ゲームが5人専用へ戻っていないか、第2のPIN/個人履歴を匿名ゲームに漏らしていないかも確認する。

### 16.4 面白さ・使いやすさの判定

少なくとも初見の参加者を含む5人に、6×6を各1局、8×8を各1局試してもらう。これは有意な強さ評価の標本数ではなく、操作のつまずき発見用。氏名を外部へ送らず、匿名メモで確認する。

「どこへ置けるか」「確定前に選び直せるか」「誰の番か」「相手がJevか端末AIか」「カフェへ戻って再開できるか」を説明なしで分かるか確認。8×8で押し間違える人がいれば、候補一覧を初期で開く設定や文字サイズを調整する。小さい文字へ押し込んで済ませない。

Jevの強さを比較する場合は盤サイズ・色・モデル・prompt・モード別に分け、端末AIやランダム相手と双方の色で複数局を行う。少数の勝ち負けだけで最強/高勝率を宣伝しない。明らかな違法手0件、未説明の切替0件、長時間の入力停止0件を優先する。

---

## 17. トラブル対応と納品判定

| 症状 | 最初に確認すること | 禁止する対処 |
|---|---|---|
| 画面が白い/タッチ不可 | 元のBSPが再現するか、ライブラリ/PSRAM/初期化 | 別ボードのピンへ総置換 |
| 四隅が欠ける | 312角と原点84、回転/スケール | 352角へ戻す |
| 1タップで2手進む | source、expectedPly、release gating、保存中ロック | 長いdelayで隠す |
| Jev返答で違うマス | A1/行列、absolute color、historyhash、legal再検証 | APIが正しいとして盤面を曲げる |
| パスで止まる | 双方合法手判定、F保存、次の手番 | 黒白が交互に配置する前提を維持 |
| 何回も課金 | 同じdecision_key、永続予約、lease、再送 | 毎回新game_idで自動再試行 |
| GASからHTML | デプロイ・Workspace設定・redirect | JSON成功とみなす/証明書無効 |
| 保存結果不明 | barrier/receiptと対象行照合 | barrierを即削除/新規append |
| 電源断で局面が戻る | metadata、二slot、CRC、棋譜再生 | 旧局へ黙って戻り同plyへ別手 |
| RAM不足 | 画像/フォント重複、HTTP容量、UI破棄 | Flash全消去から始める |

最終納品に必要なもの：変更した実ソース、固定バージョン、ビルドコマンド、書込み手順、実サイズmap、テスト結果、配備版、移行/戻し方、秘密を含まない環境設定例、不合格/未実施一覧。利用者向けには、始め方・置く・候補一覧・中断再開・端末AI表示を短い1頁にまとめる。

**完成判定**は「仕様とデータが揃った」「ホストで検査した」「実機で遊べた」「Googleに保存できた」「Jevへ実接続できた」「複数人が使って困らなかった」を別々に報告する。リンクを作っただけ、コードが存在するだけで全完了としない。

---

## 18. 根拠資料

以下は2026-09-22に確認した一次資料。仕様上の事実に[Sxx]を付けた。ルールのアプリ向け選択、UI寸法、軽量評価関数、保存方針、上限、テストは本書の設計であって、メーカーの保証ではない。各ライブラリの実導入版は既存プロジェクトで確認する。

| ID | 資料 | 確認した点 |
|---|---|---|
| S01 | [Waveshare ESP32-S3-Touch-LCD-2.8C](https://docs.waveshare.com/ESP32-S3-Touch-LCD-2.8C) | ボード、表示、メモリー、周辺機能 |
| S02 | [日本オセロ連盟・競技ルール](https://www.othello.gr.jp/rule) | 黒先手、合法手、パス、終局。競技の空所加算と本版の区別 |
| S03 | [TypeSafe API](https://docs.typesafe.ai/api) | HTTP endpoint、Choice、応答、エラー |
| S04 | [TypeSafe Models](https://docs.typesafe.ai/models) | 固定モデルID、テキスト入力、aliasの可変性 |
| S05 | [TypeSafe Confidence](https://docs.typesafe.ai/confidence) | 確率分布由来のconfidence |
| S06 | [Google Apps Script Web Apps](https://developers.google.com/apps-script/guides/web) | doPost、配備、実行権限 |
| S07 | [Apps Script Content Service](https://developers.google.com/apps-script/guides/content) | JSON応答とredirect |
| S08 | [UrlFetchApp](https://developers.google.com/apps-script/reference/url-fetch/url-fetch-app) | HTTP、証明書、redirect、timeoutSeconds |
| S09 | [Properties Service](https://developers.google.com/apps-script/guides/properties) | スクリプト設定の保存 |
| S10 | [LVGL8 Events](https://lvgl.io/docs/open/8.4/overview/event.html) / [OS and interrupts](https://lvgl.io/docs/open/8.4/porting/os) | クリックと排他、UIタスク |
| S11 | [Sheets batchUpdate](https://developers.google.com/workspace/sheets/api/reference/rest/v4/spreadsheets/batchUpdate) | 一括更新と原子性 |
| S12 | [LockService](https://developers.google.com/apps-script/reference/lock/lock-service) | GASの排他 |
| S13 | [ESP32-S3 Random Number Generation](https://docs.espressif.com/projects/esp-idf/en/stable/esp32s3/api-reference/system/random.html) | ハードウェア乱数と供給条件 |
| S14 | [ESP32-S3 NVS](https://docs.espressif.com/projects/esp-idf/en/stable/esp32s3/api-reference/storage/nvs_flash.html) | key制限、blob、commit、耐電断 |
| S15 | [Espressif Waveshare board configuration](https://raw.githubusercontent.com/esp-arduino-libs/ESP32_Display_Panel/master/docs/board/board_waveshare.md) | 2.8C対応とボード設定 |
| S16 | [Apps Script quotas](https://developers.google.com/apps-script/guides/services/quotas) | アカウント別制限の確認先 |

同会話で提供された`COFFEE_TIME_Stage1_Agent_Brief.md`、`COFFEE_TIME_AI_DUEL_Design_v1.0.md`、`COFFEE_TIME_CAFE_WEREWOLF_Design_v2.0.md`の関連章を読み、BSP保全・GAS接続・第4ゲームの3〜10人要件を照合した。本書はこれらの既存機能を削除する指示ではない。

公開資料だけでは、実ユーザーPC上の環境、共有設定、実キー権限、LCD可視域、ケースとタッチの干渉、消費電流は確認できない。これらは受入試験で実測・実接続する。

---
## 19. 作成時に実行した検査

以下はこの納品物の参考コードに対し、2026-09-22にPC環境で行った結果。詳細JSONは付録。Windows/ESP32/実GASへそのまま一般化しない。

| 検査 | 実行範囲・結果 |
|---|---|
| C++全局スモーク | **2,000局、93,013イベント、1,054パス**を完了。6×6/8×8それぞれ1,000局 |
| 独立oracle照合 | **1,301局面**の合法手・反転・エラー・次盤面・終局をC++/JS/Pythonで照合 |
| oracle局面生成 | 120局、5,572イベント、56パス。上の1,301局面を生成する検査であり別の性能評価ではない |
| 初期perft深さ1〜5 | 6×6：4,12,56,244,1364 / 8×8：4,12,56,244,1396 |
| JS契約・状態 | **29グループ合格**。確率不正、再生、lease、再送、遅い応答、接続パラメータのモック等 |
| CASUAL整数CDF | 1,000,000通りのrollで指定した3択の重み配分を照合 |
| 保存snapshot | バイト破損・切詰め計**84例を拒否**。一局完走後の再生と終了状態を確認 |
| Sanitizer | C++セッション検査をAddressSanitizer/UndefinedBehaviorSanitizer付きで実行し合格。全GAS/NVS/全局面の検査ではない |
| UIデータ | 16矩形の四隅が半径232px以内、全100セル中心、105文言・8説明頁・4API・3タブの整合を検査 |
| ブラウザ参考版 | 6/8の選択→確定、端末AI返信、一時停止、大きい候補、白側開始、JSエラーなしの7確認 |

環境はresults/host_run.jsonに記録。参考版をChromiumで表示し、盤面の四隅・下の操作が円内にあることを視覚確認した。ただし実機の指、ガラス、フォント、輝度、メモリーは別の試験である。

**実Jev呼出し0回、実Google呼出し0回、実機書込み0回。** 88項目の受入試験はすべて未実施から開始する。上表の自動検査を理由に受入欄へまとめて合格を記入しない。

---

## 付録の取り出し方

次のPythonを任意の作業フォルダーへ`extract_payload.py`として保存し、実行する。抽出するだけでコードを自動実行しない。SHA-256が合わない、同名の異なるファイルがある、不正なパスがある場合は停止する。

```bash
python extract_payload.py COFFEE_TIME_JEV_REVERSI_Design_v1.0.md ./jev_reversi_handoff
cd jev_reversi_handoff
python tools/run_all.py
```

抽出先にはソース・データ・検査・参考HTML・説明が揃う。以後、コードの挙動とJSON/本文を一緒に版管理し、変更したファイルだけを無検査で製品へコピーしない。

```python
#!/usr/bin/env python3
"""Safely extract text payloads from the handoff Markdown, verifying every SHA-256.
No extracted code is executed. Existing different files are never overwritten.
"""
from __future__ import annotations
import argparse,hashlib,json,pathlib,re
PATTERN=re.compile(r'^<!-- REV_FILE ([A-Za-z0-9_./-]+) sha256=([0-9a-f]{64}) -->\n^``````[^\n]*\n(.*?)^``````\n<!-- REV_END -->$',re.M|re.S)
def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('markdown',type=pathlib.Path)
    parser.add_argument('destination',type=pathlib.Path)
    args=parser.parse_args()
    # Normalize CRLF introduced by text editors; packaged payloads are LF UTF-8.
    text=args.markdown.read_text(encoding='utf-8').replace('\r\n','\n')
    found=PATTERN.findall(text)
    if not found:raise SystemExit('No payload markers found; refusing empty extraction.')
    root=args.destination.resolve();root.mkdir(parents=True,exist_ok=True)
    checked=[];seen=set()
    for name,digest,body in found:
        relative=pathlib.PurePosixPath(name)
        if relative.is_absolute() or any(x in ('..','.') for x in relative.parts) or name in seen:
            raise SystemExit('Unsafe or duplicate path: '+name)
        seen.add(name)
        target=(root/pathlib.Path(*relative.parts)).resolve()
        if root not in target.parents:raise SystemExit('Path escapes destination: '+name)
        data=body.encode('utf-8')
        if hashlib.sha256(data).hexdigest()!=digest:raise SystemExit('Checksum mismatch: '+name)
        if target.exists() and (not target.is_file() or target.read_bytes()!=data):
            raise SystemExit('Refusing to overwrite different existing path: '+name)
        checked.append((target,data))
    for target,data in checked:
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(data)
    print(json.dumps({'status':'verified','files':len(checked),'destination':str(root)},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
```

### 付録ファイル一覧（36ファイル）

| ファイル | byte | SHA-256先頭12桁 |
|---|---:|---|
| `AGENT_START.md` | 1,291 | `b728fa95c0f5` |
| `README.md` | 2,644 | `9b36ab335799` |
| `data/api_contract.json` | 2,408 | `5e040142b607` |
| `data/content.ja.json` | 5,558 | `817533efc13d` |
| `data/golden_positions.json` | 23,021 | `579895dfe287` |
| `data/layout.json` | 2,043 | `42cee4f3ffc0` |
| `data/rules.json` | 1,614 | `0cd39995bebf` |
| `data/sheets_schema.json` | 1,087 | `3604756782be` |
| `data/tutorial.ja.json` | 1,600 | `558426c44606` |
| `docs/acceptance.md` | 13,302 | `70de9156e7e7` |
| `gas/decision_machine.js` | 1,377 | `b519486854f2` |
| `gas/provider_adapter.gs` | 1,341 | `28efb909abad` |
| `gas/reversi_shared.js` | 10,647 | `6e2f8ad30ed6` |
| `manifest.json` | 5,615 | `6a37076414ee` |
| `preview.html` | 16,993 | `fa0dc43ca545` |
| `results/browser.json` | 276 | `098fb3626c07` |
| `results/contracts.json` | 119 | `cafede4d5925` |
| `results/core_verification.json` | 429 | `3929a8baf4a8` |
| `results/cpp_smoke.json` | 78 | `0dc9ef77e124` |
| `results/data.json` | 194 | `1bd7b315f643` |
| `results/host_run.json` | 289 | `00131dce487a` |
| `results/session.json` | 66 | `d73c8832b69e` |
| `results/session_sanitized.json` | 57 | `6412662df2a4` |
| `src/lvgl8_board_example.hpp` | 5,879 | `5bba2f20bf07` |
| `src/reversi_core.hpp` | 6,218 | `dd688307a43b` |
| `src/reversi_session.hpp` | 4,072 | `e52380f96909` |
| `tests/browser_check.py` | 1,977 | `c536700633ab` |
| `tests/core_cli.cpp` | 1,034 | `121ee71a02ac` |
| `tests/js_cli.js` | 524 | `d985e9e10b96` |
| `tests/session_test.cpp` | 1,618 | `14c5111e10c7` |
| `tests/smoke.cpp` | 1,157 | `451db9e51337` |
| `tests/test_contract.js` | 5,679 | `673cc9cc1ec2` |
| `tests/test_data.py` | 2,142 | `f51f9510e944` |
| `tests/verify_core.py` | 5,726 | `d1a00eb4b51b` |
| `tools/extract_payload.py` | 1,997 | `e67bf9c9231c` |
| `tools/run_all.py` | 1,822 | `ac9add0749ab` |

以下のブロック内を省略・省略記号に置き換えない。検査結果は作成時の記録であり、実装後の受入証跡は別に作成する。

### ファイル：`AGENT_START.md`

<!-- REV_FILE AGENT_START.md sha256=b728fa95c0f5c90fc9fb0cf2f75f61726f48d2a72bbf44925692d6bd2d66f41c -->
``````markdown
# エージェントへ渡す初期指示

COFFEE TIMEの第5ゲーム「JEV REVERSI」を、設計書v1.0.0を正本として実装してください。

6×6と8×8を同じ一つのアプリで提供します。312px角の盤面・選択後に「置く」で確定・大きい合法手一覧を使用してください。Jevは合法手から選ぶ役割で、ルール・反転・パス・勝敗を任せません。

既存LCD/GT911初期化、コーヒー＋1、AI ESPER、AI DUEL、CAFE DETECTIVE、3〜10人対応のCAFE WEREWOLF v2、Google連携を保全してください。

付録を取り出してPC検査を再実行し、端末AIで6/8を完走させ、保存・再開・カフェ復帰を実装します。その後GASの認証・冪等台帳・障害復旧、最後に実Jevを接続してください。

同じ局面の再送でモデルを再呼出しせず、端末AIへ切り替えた後にその局をJevへ戻さないでください。Jev不使用や混在をUIと結果で区別してください。

88項目の受入試験を実施し、コンパイル・ホスト試験・ESP32実機・実Google・実Jev・プレイ評価を分けて報告してください。未実施を成功に数えず、秘密情報を納品ファイルへ入れないでください。
``````
<!-- REV_END -->

### ファイル：`README.md`

<!-- REV_FILE README.md sha256=9b36ab335799b5dc8206682770438e9fd3cf8b6c6d42521701711c0b687ed2f2 -->
``````markdown
# COFFEE TIME / JEV REVERSI v1.0.0

本体設計書は `COFFEE_TIME_JEV_REVERSI_Design_v1.0.md`。この一式は完成仕様・参考実装・検査で、書込み済みファームではありません。

## 最初に

1. 設計書の0〜3章を読み、既存LCD/GT911/LVGL・コーヒー＋1・4ゲーム・Google連携を保存する。
2. `python tools/run_all.py` でホスト検査を再実行する（Python3・g++ C++17・Node.js）。
3. `preview.html` をPCブラウザで開き、6×6/8×8の二段階入力と大きい候補一覧を試す。これは端末AIだけの参考版。
4. C++のcore/sessionを既存ファームへ統合し、UI・NVS・非同期controllerを設計書に従って実装する。
5. GASルーター・認証・台帳・保存/再送を実装し、mock→実Google→実Jevの順に接続する。
6. `docs/acceptance.md` の88項目を実施し、未試験を残さず報告する。適用外には理由を書く。

`src/lvgl8_board_example.hpp`は接続例です。実LVGLビルドや実機では未確認です。`gas/decision_machine.js`は純粋な状態遷移モデルであり、ScriptLockやSheetsの実永続化機構ではありません。`provider_adapter.gs`も実キーへ接続していません。

## 保存とコード

core/sessionにはLVGLやHTTPの依存がありません。GASの `reversi_shared.js` とC++を独立したPython oracleと照合しています。

付録のgolden_positionsはテスト用の局面です。通常プレイで任意の盤面をロードする裏口は作りません。

Windowsでg++がない場合は、承認済みのWSL/MSYS2等へ検査コマンドを適応してください。コンパイラがない状態を合格にしないでください。

## 追加ブラウザ検査

`python tests/browser_check.py` はPlaywrightとChromiumが導入済みの環境で使用します。本作成環境では `/usr/bin/chromium` を使いました。他環境は実際の実行ファイルまたはPlaywright管理ブラウザへ適応してください。

## 不用意に変更しないもの

BSP、LVGL版、Flash区画、既存Google権限、旧4ゲームのID、個人認証の扱い。新ゲームのためにNVS全消去はしません。

フォント・メーカー画像・市販ゲームの素材は同梱しません。図柄は描画要素で構成し、日本語は既存の利用許諾済みフォントを共有します。

## 検査結果

`results/*.json`はこの設計書作成時のホスト実行結果です。ESP32実機、GAS本番、Jev実APIの成功証拠ではありません。再検査では上書きされます。
``````
<!-- REV_END -->

### ファイル：`data/api_contract.json`

<!-- REV_FILE data/api_contract.json sha256=5e040142b607c728748dc0a86b06ce71731e04035324f9ba9d45f3e6152e2ef7 -->
``````json
{
  "namespace": "jev_reversi",
  "api_version": 1,
  "envelope_required": [
    "namespace",
    "api_version",
    "action",
    "request_id",
    "device_id",
    "device_token",
    "sent_at_ms",
    "payload"
  ],
  "snapshot_required": [
    "game_id",
    "n",
    "human",
    "mode",
    "history"
  ],
  "actions": {
    "device.hello": {
      "payload": {},
      "response": [
        "server_time_ms",
        "jev_available",
        "model",
        "modes",
        "rules_version",
        "schema_version",
        "daily_calls_remaining",
        "maintenance"
      ]
    },
    "decision.prepare": {
      "payload": {
        "snapshot": "Snapshot",
        "ply": "integer 0..128",
        "position_hash": "lowercase SHA256 hex"
      },
      "response": "DecisionView"
    },
    "decision.get": {
      "payload": {
        "game_id": "32hex",
        "ply": "integer 0..128",
        "position_hash": "64hex"
      },
      "response": "DecisionView"
    },
    "result.put": {
      "payload": {
        "snapshot": "Snapshot",
        "end_reason": "completed|resigned|aborted",
        "client_ended_at_ms": "nonnegative integer|null"
      },
      "response": [
        "result_key",
        "status",
        "verification",
        "provider_class",
        "winner",
        "black",
        "white",
        "empty"
      ]
    }
  },
  "DecisionView_required": [
    "decision_key",
    "game_id",
    "ply",
    "position_hash",
    "status",
    "move",
    "inference",
    "retry_after_ms",
    "error_code"
  ],
  "DecisionView_status": [
    "pending",
    "ready",
    "failed"
  ],
  "errors": [
    "BAD_REQUEST",
    "AUTH_FAILED",
    "CLOCK_SKEW",
    "RULE_VERSION_MISMATCH",
    "MODE_UNAVAILABLE",
    "BAD_SNAPSHOT",
    "ILLEGAL_HISTORY",
    "NO_DECISION_REQUIRED",
    "LOCAL_ONLY",
    "STATE_CONFLICT",
    "NOT_FOUND",
    "BUSY",
    "PROVIDER_FAILED",
    "DAILY_LIMIT",
    "STORAGE_LIMIT",
    "STORAGE_UNCERTAIN",
    "MAINTENANCE",
    "RESULT_CONFLICT",
    "INTEGRITY_ERROR"
  ],
  "response_required": [
    "namespace",
    "api_version",
    "request_id",
    "server_time_ms",
    "ok",
    "data",
    "error"
  ],
  "DecisionView_error_codes": [
    "NO_KEY",
    "PROVIDER_TOO_LARGE",
    "PROVIDER_FETCH_OR_PARSE_FAILED",
    "LEASE_EXPIRED"
  ],
  "DecisionView_error_code_pattern": "PROVIDER_HTTP_[1-5][0-9]{2} (200 excluded)"
}
``````
<!-- REV_END -->

### ファイル：`data/content.ja.json`

<!-- REV_FILE data/content.ja.json sha256=817533efc13d9365d870c8deb37176dffd1ecee96588cdd3c645fe991fead813 -->
``````json
{
  "game.title": "JEV REVERSI",
  "game.subtitle": "一手ずつ、判断力で勝負。",
  "game.menu": "リバーシ",
  "start.quick": "QUICK 6×6",
  "start.classic": "CLASSIC 8×8",
  "start.quick.note": "大きなマスで、気軽に。",
  "start.classic.note": "8×8の盤で、じっくり。",
  "start.size": "盤面を選ぶ",
  "start.side": "あなたの石",
  "start.black": "黒・先手",
  "start.white": "白・後手",
  "start.random": "おまかせ",
  "start.opponent": "相手の選び方",
  "mode.jev": "JEV",
  "mode.pro": "JEV PRO",
  "mode.casual": "CASUAL",
  "mode.local": "端末AI",
  "mode.jev.note": "Jevの最大評価の手で対戦。",
  "mode.pro.note": "盤面の特徴もJevへ渡します。",
  "mode.casual.note": "Jevの評価分布から手を抽選。",
  "mode.local.note": "通信せず、端末内で対戦。",
  "mode.notice": "選び方の違いです。強さの順位ではありません。",
  "start.go": "始める",
  "start.resume": "つづきから",
  "start.new": "新しく遊ぶ",
  "start.confirm_new": "保存中の対局を終了して始めますか？",
  "start.no_online": "Jevに接続できません。端末AIで遊べます。",
  "start.no_key": "Jevの接続設定が未完了です。",
  "board.black": "黒",
  "board.white": "白",
  "board.you": "あなた",
  "board.ai": "相手",
  "board.place": "置く",
  "board.menu": "操作",
  "board.choices": "候補",
  "board.select": "置く場所を選んでください。",
  "board.selected": "{coord}を選択中",
  "board.illegal": "そこには置けません。",
  "board.occupied": "石のある場所には置けません。",
  "board.preview": "ここに置くと{count}枚返ります。",
  "board.your_turn": "あなたの番",
  "board.ai_turn": "相手の番",
  "board.saving": "保存中…",
  "board.thinking": "Jevが判断中…",
  "board.local_thinking": "端末AIが選んでいます。",
  "board.only_move": "置ける場所は一つです。",
  "board.forced": "ルールによる自動処理",
  "pass.you": "あなたは置けないため、パスです。",
  "pass.ai": "相手は置けないため、パスです。",
  "pass.no_manual": "置ける場所があるときはパスできません。",
  "result.win": "あなたの勝ち！",
  "result.loss": "相手の勝ち。また一局！",
  "result.draw": "引き分け。いい勝負でした。",
  "result.empty": "空きマスは、どちらの点にも加えません。",
  "result.reason": "両方とも置ける場所がなくなりました。",
  "result.resigned": "投了しました。",
  "result.aborted": "対局を終了しました。勝敗には数えません。",
  "result.jev": "Jevと対戦",
  "result.mixed": "一部、端末AIで対戦",
  "result.local": "端末AIと対戦",
  "result.forced_only": "Jevの選択が発生しなかった対局です。",
  "result.again": "もう一局",
  "result.home": "カフェへ",
  "result.sync_ok": "記録を保存しました。",
  "result.sync_wait": "記録は端末に保存。後で送信します。",
  "result.sync_failed": "記録を送れませんでした。対局結果は変わりません。",
  "menu.continue": "対局へ戻る",
  "menu.pause": "保存してカフェへ",
  "menu.resign": "投了する",
  "menu.end": "対局を終了",
  "menu.rules": "遊び方",
  "menu.decision": "Jevの評価を見る",
  "menu.sound": "操作音",
  "menu.resign.confirm": "この対局を負けとして終えますか？",
  "menu.end.confirm": "勝敗を付けずに対局を終了しますか？",
  "detail.title": "直前のJevの評価",
  "detail.notice": "候補間の相対評価です。勝率ではありません。",
  "detail.not_reason": "選択分布を表示しています。Jevの内部思考ではありません。",
  "detail.none": "表示できるJevの評価はありません。",
  "detail.sampled": "CASUALでは評価分布から抽選しました。",
  "detail.forced": "この手は一択のため、Jevを呼んでいません。",
  "net.slow": "通信に時間がかかっています。",
  "net.wait": "もう少し待つ",
  "net.retry": "同じ手の結果を確認",
  "net.local": "端末AIへ切り替える",
  "net.local.confirm": "この対局の残りは端末AIが担当します。Jevへは戻しません。",
  "net.pause": "保存して後で続ける",
  "net.conflict": "記録が一致しません。安全のため対局を止めました。",
  "net.quota": "今日のJev利用枠に達しました。",
  "net.bad_response": "Jevの応答を検証できませんでした。",
  "net.stale": "古い局面への応答は適用しません。",
  "net.tls": "安全な通信を確認できません。接続設定を確認してください。",
  "save.resume": "前回の保存時点から再開します。",
  "save.corrupt": "保存データを確認できません。新しい対局を始めてください。",
  "save.failure": "保存できません。盤面を進めずに停止しました。",
  "save.full": "未送信の記録が4件あります。",
  "save.drop_old": "最も古い未送信記録を削除",
  "save.without_record": "今回は追加の記録を残さず遊ぶ",
  "common.yes": "はい",
  "common.no": "いいえ",
  "common.back": "戻る",
  "common.next": "次へ",
  "common.ok": "確認",
  "pause.idle": "しばらく操作がないため、一時停止しました。",
  "pause.not_running": "カフェ表示中は対局を進めません。"
}
``````
<!-- REV_END -->

### ファイル：`data/golden_positions.json`

<!-- REV_FILE data/golden_positions.json sha256=579895dfe287d09650c3ea2bcf739ce6f661ea6b43fd50a41b27425376474202 -->
``````json
[
  {
    "input": {
      "n": 6,
      "side": "B",
      "cells": "..............WB....BW..............",
      "ply": 0,
      "move": 22
    },
    "expected": {
      "legal": [
        8,
        13,
        22,
        27
      ],
      "flips": [
        21
      ],
      "next": {
        "n": 6,
        "cells": "..............WB....BBB.............",
        "side": "W",
        "ply": 1
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 6,
      "side": "W",
      "cells": "..............WB....BB.....B........",
      "ply": 1,
      "move": 26
    },
    "expected": {
      "legal": [
        16,
        26,
        28
      ],
      "flips": [
        20
      ],
      "next": {
        "n": 6,
        "cells": "..............WB....WB....WB........",
        "side": "B",
        "ply": 2
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 6,
      "side": "B",
      "cells": "....B....B.W.BBBW...BW....WWWW.WB..B",
      "ply": 12,
      "move": 22
    },
    "expected": {
      "legal": [
        17,
        22,
        23,
        30,
        33,
        34
      ],
      "flips": [
        21,
        27
      ],
      "next": {
        "n": 6,
        "cells": "....B....B.W.BBBW...BBB...WBWW.WB..B",
        "side": "W",
        "ply": 13
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 6,
      "side": "W",
      "cells": ".BWWB.W.WW...WWWBWBBWWBB.BBBBBWBB..W",
      "ply": 23,
      "move": 0
    },
    "expected": {
      "legal": [
        0,
        5,
        11,
        24,
        33,
        34
      ],
      "flips": [
        1
      ],
      "next": {
        "n": 6,
        "cells": "WWWWB.W.WW...WWWBWBBWWBB.BBBBBWBB..W",
        "side": "B",
        "ply": 24
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 6,
      "side": "W",
      "cells": "WWWWW.BWBWWW.BWWB.BBBB.B..B.W......W",
      "ply": 19,
      "move": 25
    },
    "expected": {
      "legal": [
        12,
        17,
        22,
        24,
        25,
        27,
        31,
        32
      ],
      "flips": [
        13,
        19,
        20
      ],
      "next": {
        "n": 6,
        "cells": "WWWWW.BWBWWW.WWWB.BWWB.B.WB.W......W",
        "side": "B",
        "ply": 20
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 6,
      "side": "B",
      "cells": "....WB..W.WB..WWBB.WWBWBWWBBBB.BBW.B",
      "ply": 20,
      "move": 9
    },
    "expected": {
      "legal": [
        1,
        2,
        3,
        7,
        9,
        12,
        13,
        18,
        30,
        34
      ],
      "flips": [
        10,
        15
      ],
      "next": {
        "n": 6,
        "cells": "....WB..WBBB..WBBB.WWBWBWWBBBB.BBW.B",
        "side": "W",
        "ply": 21
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 6,
      "side": "W",
      "cells": "..............WB....BBB.............",
      "ply": 1,
      "move": 16
    },
    "expected": {
      "legal": [
        16,
        26,
        28
      ],
      "flips": [
        15
      ],
      "next": {
        "n": 6,
        "cells": "..............WWW...BBB.............",
        "side": "B",
        "ply": 2
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 6,
      "side": "B",
      "cells": ".WB.....W....BWBB...WBWW..WWW....BW.",
      "ply": 12,
      "move": 31
    },
    "expected": {
      "legal": [
        0,
        3,
        7,
        19,
        25,
        29,
        31,
        32,
        35
      ],
      "flips": [
        26
      ],
      "next": {
        "n": 6,
        "cells": ".WB.....W....BWBB...WBWW..BWW..B.BW.",
        "side": "W",
        "ply": 13
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 6,
      "side": "W",
      "cells": ".W......WBBB..BWB..WBBW...B.B..B.W.B",
      "ply": 13,
      "move": 4
    },
    "expected": {
      "legal": [
        3,
        4,
        5,
        13,
        17,
        23,
        25,
        27,
        32,
        34
      ],
      "flips": [
        9,
        10,
        14,
        16
      ],
      "next": {
        "n": 6,
        "cells": ".W..W...WWWB..WWW..WBBW...B.B..B.W.B",
        "side": "B",
        "ply": 14
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 6,
      "side": "B",
      "cells": "WBBBBBWWBBBBWWBBBBWWWBBWWWWWWWWWWWWW",
      "ply": 32,
      "move": -1
    },
    "expected": {
      "legal": [],
      "flips": [],
      "next": {
        "n": 6,
        "cells": "WBBBBBWWBBBBWWBBBBWWWBBWWWWWWWWWWWWW",
        "side": "B",
        "ply": 32
      },
      "error": "FINISHED",
      "terminal": true,
      "winner": "W"
    }
  },
  {
    "input": {
      "n": 6,
      "side": "B",
      "cells": "........B.....BBW...BWBW..WWWW....BW",
      "ply": 10,
      "move": 33
    },
    "expected": {
      "legal": [
        10,
        17,
        32,
        33
      ],
      "flips": [
        21,
        27
      ],
      "next": {
        "n": 6,
        "cells": "........B.....BBW...BBBW..WBWW...BBW",
        "side": "W",
        "ply": 11
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 6,
      "side": "B",
      "cells": "WWWWW..WBW..WBWWW.WWBWW.WBBBWWBBBBBB",
      "ply": 26,
      "move": 10
    },
    "expected": {
      "legal": [
        6,
        10,
        11,
        17,
        23
      ],
      "flips": [
        9,
        15,
        16,
        22,
        28
      ],
      "next": {
        "n": 6,
        "cells": "WWWWW..WBBB.WBWBB.WWBWB.WBBBBWBBBBBB",
        "side": "W",
        "ply": 27
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 6,
      "side": "W",
      "cells": "...WB.WW.W..BWBBB.BWBB..BBBBB.B..W..",
      "ply": 17,
      "move": 5
    },
    "expected": {
      "legal": [
        5,
        17,
        22,
        23,
        31,
        34,
        35
      ],
      "flips": [
        4
      ],
      "next": {
        "n": 6,
        "cells": "...WWWWW.W..BWBBB.BWBB..BBBBB.B..W..",
        "side": "B",
        "ply": 18
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 6,
      "side": "B",
      "cells": "..BBB....WWW.BBWW.BBBWWW.B.BB...B.BW",
      "ply": 18,
      "move": 17
    },
    "expected": {
      "legal": [
        5,
        17
      ],
      "flips": [
        10,
        15,
        16,
        22
      ],
      "next": {
        "n": 6,
        "cells": "..BBB....WBW.BBBBBBBBWBW.B.BB...B.BW",
        "side": "W",
        "ply": 19
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 6,
      "side": "W",
      "cells": "BW.....B.WWWWWBWW.WBWB..WBBBB.WBW...",
      "ply": 19,
      "move": 22
    },
    "expected": {
      "legal": [
        2,
        8,
        22,
        29,
        33,
        34
      ],
      "flips": [
        21,
        27
      ],
      "next": {
        "n": 6,
        "cells": "BW.....B.WWWWWBWW.WBWWW.WBBWB.WBW...",
        "side": "B",
        "ply": 20
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 6,
      "side": "B",
      "cells": "..............WB....BW..............",
      "ply": 0,
      "move": 37
    },
    "expected": {
      "legal": [
        8,
        13,
        22,
        27
      ],
      "flips": [],
      "next": {
        "n": 6,
        "cells": "..............WB....BW..............",
        "side": "B",
        "ply": 0
      },
      "error": "OUT_OF_RANGE",
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 8,
      "side": "W",
      "cells": "..................WB.......WB......BBB..........................",
      "ply": 3,
      "move": 20
    },
    "expected": {
      "legal": [
        11,
        20,
        29,
        43,
        45
      ],
      "flips": [
        19
      ],
      "next": {
        "n": 8,
        "cells": "..................WWW......WB......BBB..........................",
        "side": "B",
        "ply": 4
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 8,
      "side": "B",
      "cells": "....W.......WWW....WBW..WWWWWWWWBWBBBWW...WWWWBW..W.......W.....",
      "ply": 26,
      "move": 10
    },
    "expected": {
      "legal": [
        6,
        7,
        10,
        11,
        16,
        17,
        18,
        22,
        39,
        41,
        49,
        51,
        52,
        53,
        54,
        57
      ],
      "flips": [
        19,
        28,
        37
      ],
      "next": {
        "n": 8,
        "cells": "....W.....B.WWW....BBW..WWWWBWWWBWBBBBW...WWWWBW..W.......W.....",
        "side": "W",
        "ply": 27
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 8,
      "side": "B",
      "cells": "BWWWW.WBBBBWWWW.BBBWWWWBBBWWWWWBBBBWBWWBBBBWWWWBW.BWBBBB..WWW.WB",
      "ply": 54,
      "move": 15
    },
    "expected": {
      "legal": [
        5,
        15,
        56,
        61
      ],
      "flips": [
        11,
        12,
        13,
        14,
        22,
        29
      ],
      "next": {
        "n": 8,
        "cells": "BWWWW.WBBBBBBBBBBBBWWWBBBBWWWBWBBBBWBWWBBBBWWWWBW.BWBBBB..WWW.WB",
        "side": "W",
        "ply": 55
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 8,
      "side": "W",
      "cells": ".........WB.......W.......BWB......BW.....BBWW.....BBW..........",
      "ply": 11,
      "move": 2
    },
    "expected": {
      "legal": [
        2,
        11,
        17,
        20,
        25,
        29,
        34,
        41,
        50,
        58,
        59,
        60
      ],
      "flips": [
        10
      ],
      "next": {
        "n": 8,
        "cells": "..W......WW.......W.......BWB......BW.....BBWW.....BBW..........",
        "side": "B",
        "ply": 12
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 8,
      "side": "B",
      "cells": "...BW.B..BBB.W.W.BBBWWWWWBWWBWWWBBWBBWWW.WBBWBWW...WBBBW..W.WBBB",
      "ply": 44,
      "move": 50
    },
    "expected": {
      "legal": [
        5,
        7,
        12,
        14,
        16,
        40,
        48,
        49,
        50,
        59
      ],
      "flips": [
        41,
        51
      ],
      "next": {
        "n": 8,
        "cells": "...BW.B..BBB.W.W.BBBWWWWWBWWBWWWBBWBBWWW.BBBWBWW..BBBBBW..W.WBBB",
        "side": "W",
        "ply": 45
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 8,
      "side": "W",
      "cells": "BBBBBBBBBBBBBBWBWBWBBWWBWWBBWBWBWBWWBWWBWBWBBBWBWWWWWWWBWWWWWWWB",
      "ply": 61,
      "move": -1
    },
    "expected": {
      "legal": [],
      "flips": [],
      "next": {
        "n": 8,
        "cells": "BBBBBBBBBBBBBBWBWBWBBWWBWWBBWBWBWBWWBWWBWBWBBBWBWWWWWWWBWWWWWWWB",
        "side": "W",
        "ply": 61
      },
      "error": "FINISHED",
      "terminal": true,
      "winner": "B"
    }
  },
  {
    "input": {
      "n": 8,
      "side": "B",
      "cells": "..........W........WBB.....BWWW....BBW....BWWBW..B....B.........",
      "ply": 14,
      "move": 31
    },
    "expected": {
      "legal": [
        11,
        18,
        22,
        31,
        38,
        39,
        47,
        50,
        51,
        52,
        53
      ],
      "flips": [
        28,
        29,
        30
      ],
      "next": {
        "n": 8,
        "cells": "..........W........WBB.....BBBBB...BBW....BWWBW..B....B.........",
        "side": "W",
        "ply": 15
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 8,
      "side": "B",
      "cells": "W.W...B.BWWWBB...BBBBBBB.BWWWWBB.BWWBBBB.WBWBB.WW..WBBB....WBBBB",
      "ply": 42,
      "move": 40
    },
    "expected": {
      "legal": [
        1,
        3,
        4,
        40,
        49,
        50,
        55,
        58
      ],
      "flips": [
        41
      ],
      "next": {
        "n": 8,
        "cells": "W.W...B.BWWWBB...BBBBBBB.BWWWWBB.BWWBBBBBBBWBB.WW..WBBB....WBBBB",
        "side": "W",
        "ply": 43
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 8,
      "side": "W",
      "cells": "..........................BWWW....WBWW......BB.....WB.B.........",
      "ply": 9,
      "move": 53
    },
    "expected": {
      "legal": [
        18,
        25,
        42,
        43,
        53,
        60,
        63
      ],
      "flips": [
        45,
        52
      ],
      "next": {
        "n": 8,
        "cells": "..........................BWWW....WBWW......BW.....WWWB.........",
        "side": "B",
        "ply": 10
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 8,
      "side": "W",
      "cells": "...B.W....B.WB.WWWWWBWW..WWBWWB.BBBBWWBW.BWWB.W.BWWB.B..W.WB..B.",
      "ply": 37,
      "move": 4
    },
    "expected": {
      "legal": [
        1,
        2,
        4,
        11,
        14,
        23,
        24,
        31,
        40,
        45,
        47,
        52,
        60
      ],
      "flips": [
        13
      ],
      "next": {
        "n": 8,
        "cells": "...BWW....B.WW.WWWWWBWW..WWBWWB.BBBBWWBW.BWWB.W.BWWB.B..W.WB..B.",
        "side": "B",
        "ply": 38
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 8,
      "side": "B",
      "cells": "..BWWWB..WWWWW...WWWBWBWB.WBBWBWBWWWWWBWBWBBWWB.BBBBBBBBBBBBBB.W",
      "ply": 50,
      "move": 1
    },
    "expected": {
      "legal": [
        0,
        1,
        8,
        14,
        16,
        25
      ],
      "flips": [
        10,
        19
      ],
      "next": {
        "n": 8,
        "cells": ".BBWWWB..WBWWW...WWBBWBWB.WBBWBWBWWWWWBWBWBBWWB.BBBBBBBBBBBBBB.W",
        "side": "W",
        "ply": 51
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 8,
      "side": "W",
      "cells": "....................W.....BBW......BWB....BB.W.....B............",
      "ply": 7,
      "move": 25
    },
    "expected": {
      "legal": [
        18,
        25,
        29,
        34,
        38,
        46,
        49,
        50
      ],
      "flips": [
        26,
        27
      ],
      "next": {
        "n": 8,
        "cells": "....................W....WWWW......BWB....BB.W.....B............",
        "side": "B",
        "ply": 8
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 8,
      "side": "B",
      "cells": ".............B...W..WBBBWWWWWBBW...WWBBW..WWBWB..WWBWW.B..BBBW..",
      "ply": 30,
      "move": 47
    },
    "expected": {
      "legal": [
        8,
        11,
        12,
        19,
        33,
        34,
        40,
        41,
        47,
        48,
        54,
        56,
        57,
        62
      ],
      "flips": [
        31,
        39
      ],
      "next": {
        "n": 8,
        "cells": ".............B...W..WBBBWWWWWBBB...WWBBB..WWBWBB.WWBWW.B..BBBW..",
        "side": "W",
        "ply": 31
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 8,
      "side": "B",
      "cells": "BWWWWWWBBBWBWWWWBBBWBBBBBBWBBBBBBBBWBBBBBBWBWBBBBBBWWBBBBBBBBBBB",
      "ply": 60,
      "move": -1
    },
    "expected": {
      "legal": [],
      "flips": [],
      "next": {
        "n": 8,
        "cells": "BWWWWWWBBBWBWWWWBBBWBBBBBBWBBBBBBBBWBBBBBBWBWBBBBBBWWBBBBBBBBBBB",
        "side": "B",
        "ply": 60
      },
      "error": "FINISHED",
      "terminal": true,
      "winner": "B"
    }
  },
  {
    "input": {
      "n": 8,
      "side": "W",
      "cells": ".........WB.BW....W.W...BWBWB.B.WBBBBB....BBBBBB...BWB....BW....",
      "ply": 25,
      "move": 41
    },
    "expected": {
      "legal": [
        2,
        4,
        11,
        16,
        29,
        38,
        41,
        50,
        54,
        57
      ],
      "flips": [
        33,
        34
      ],
      "next": {
        "n": 8,
        "cells": ".........WB.BW....W.W...BWBWB.B.WWWBBB...WBBBBBB...BWB....BW....",
        "side": "B",
        "ply": 26
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 8,
      "side": "W",
      "cells": "BBWWWWWWBWWWWBBWBBWWWWWWBBWBBWWWBWBBBWWWBBBWWWWWBBBBBW.WBBBBWW..",
      "ply": 57,
      "move": -1
    },
    "expected": {
      "legal": [],
      "flips": [],
      "next": {
        "n": 8,
        "cells": "BBWWWWWWBWWWWBBWBBWWWWWWBBWBBWWWBWBBBWWWBBBWWWWWBBBBBW.WBBBBWW..",
        "side": "B",
        "ply": 58
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 8,
      "side": "B",
      "cells": "...........................WB......BW...........................",
      "ply": 0,
      "move": 19
    },
    "expected": {
      "legal": [
        19,
        26,
        37,
        44
      ],
      "flips": [
        27
      ],
      "next": {
        "n": 8,
        "cells": "...................B.......BB......BW...........................",
        "side": "W",
        "ply": 1
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 8,
      "side": "W",
      "cells": "BBB.....BWB..W..BBBBBB..BBBBBBW.BBBBWWW..BBWWW.....WWBW....W....",
      "ply": 33,
      "move": 62
    },
    "expected": {
      "legal": [
        11,
        12,
        22,
        40,
        48,
        49,
        61,
        62
      ],
      "flips": [
        53
      ],
      "next": {
        "n": 8,
        "cells": "BBB.....BWB..W..BBBBBB..BBBBBBW.BBBBWWW..BBWWW.....WWWW....W..W.",
        "side": "B",
        "ply": 34
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 8,
      "side": "B",
      "cells": "BBBBBWW.BBBBWWW.BBBWWWWWBBWWBWW.BWWBBBWB.WBWBWBBWBWBBBBBBBBBBBBB",
      "ply": 56,
      "move": 7
    },
    "expected": {
      "legal": [
        7,
        15,
        31,
        40
      ],
      "flips": [
        5,
        6,
        14,
        21
      ],
      "next": {
        "n": 8,
        "cells": "BBBBBBBBBBBBWWB.BBBWWBWWBBWWBWW.BWWBBBWB.WBWBWBBWBWBBBBBBBBBBBBB",
        "side": "W",
        "ply": 57
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 8,
      "side": "B",
      "cells": "..........B.......B.B.....BWBW.....BWW.......WW.................",
      "ply": 8,
      "move": 34
    },
    "expected": {
      "legal": [
        19,
        30,
        34,
        38,
        44,
        54,
        55
      ],
      "flips": [
        27
      ],
      "next": {
        "n": 8,
        "cells": "..........B.......B.B.....BBBW....BBWW.......WW.................",
        "side": "W",
        "ply": 9
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 8,
      "side": "B",
      "cells": ".BW.......B.WB.B..BWWWBBWWBWWBW..WBWBBWB.WW.BBW..WBB.WBW..B...WB",
      "ply": 36,
      "move": 61
    },
    "expected": {
      "legal": [
        3,
        4,
        5,
        11,
        16,
        31,
        32,
        40,
        47,
        48,
        52,
        60,
        61
      ],
      "flips": [
        53,
        62
      ],
      "next": {
        "n": 8,
        "cells": ".BW.......B.WB.B..BWWWBBWWBWWBW..WBWBBWB.WW.BBW..WBB.BBW..B..BBB",
        "side": "W",
        "ply": 37
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 8,
      "side": "W",
      "cells": "WWWWWWWBBWBBWWBWBWWBWBBWBBBWBWWWBWBBWWBWBWBWWWBWBWWWWBBWBW.WWWBW",
      "ply": 59,
      "move": -1
    },
    "expected": {
      "legal": [],
      "flips": [],
      "next": {
        "n": 8,
        "cells": "WWWWWWWBBWBBWWBWBWWBWBBWBBBWBWWWBWBBWWBWBWBWWWBWBWWWWBBWBW.WWWBW",
        "side": "B",
        "ply": 60
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 8,
      "side": "B",
      "cells": "B........B.W.B....WWWW...WWBW.....WWBB...WB..BB.................",
      "ply": 16,
      "move": 3
    },
    "expected": {
      "legal": [
        3,
        10,
        12,
        14,
        24,
        29,
        33,
        40,
        43,
        48
      ],
      "flips": [
        11,
        19
      ],
      "next": {
        "n": 8,
        "cells": "B..B.....B.B.B....WBWW...WWBW.....WWBB...WB..BB.................",
        "side": "W",
        "ply": 17
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 8,
      "side": "W",
      "cells": "WWWWWWWWWWWWWWWWWBWWWWWWWBBBBBBBWBBWBWBWWWWWWBB.W.W...B.WB.W....",
      "ply": 49,
      "move": 58
    },
    "expected": {
      "legal": [
        47,
        53,
        55,
        58,
        62,
        63
      ],
      "flips": [
        57
      ],
      "next": {
        "n": 8,
        "cells": "WWWWWWWWWWWWWWWWWBWWWWWWWBBBBBBBWBBWBWBWWWWWWBB.W.W...B.WWWW....",
        "side": "B",
        "ply": 50
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  },
  {
    "input": {
      "n": 8,
      "side": "W",
      "cells": ".............W....B.BW.W...BBWW....BBW.B....B........B..........",
      "ply": 11,
      "move": 26
    },
    "expected": {
      "legal": [
        11,
        19,
        26,
        34,
        42,
        43,
        51
      ],
      "flips": [
        27,
        28
      ],
      "next": {
        "n": 8,
        "cells": ".............W....B.BW.W..WWWWW....BBW.B....B........B..........",
        "side": "B",
        "ply": 12
      },
      "error": null,
      "terminal": false,
      "winner": "-"
    }
  }
]
``````
<!-- REV_END -->

### ファイル：`data/layout.json`

<!-- REV_FILE data/layout.json sha256=42cee4f3ffc0c6b89e12c2ad7914437db5329c8fde7d819d7a25d75548da3837 -->
``````json
{
  "size": [
    480,
    480
  ],
  "center": [
    240,
    240
  ],
  "safe_radius": 232,
  "board": {
    "x": 84,
    "y": 84,
    "w": 312,
    "h": 312,
    "cell6": 52,
    "cell8": 39
  },
  "board_controls": [
    {
      "id": "title",
      "x": 160,
      "y": 24,
      "w": 160,
      "h": 22,
      "font": 16
    },
    {
      "id": "score",
      "x": 132,
      "y": 50,
      "w": 216,
      "h": 28,
      "font": 20
    },
    {
      "id": "menu",
      "x": 132,
      "y": 400,
      "w": 48,
      "h": 44,
      "font": 16
    },
    {
      "id": "place",
      "x": 188,
      "y": 402,
      "w": 104,
      "h": 52,
      "font": 20
    },
    {
      "id": "choices",
      "x": 300,
      "y": 400,
      "w": 48,
      "h": 44,
      "font": 16
    }
  ],
  "card_page": {
    "text": {
      "x": 112,
      "y": 100,
      "w": 256,
      "h": 224,
      "font": 24,
      "line_height": 32
    },
    "left": {
      "x": 130,
      "y": 350,
      "w": 100,
      "h": 64
    },
    "right": {
      "x": 250,
      "y": 350,
      "w": 100,
      "h": 64
    }
  },
  "list_page": {
    "choices": [
      {
        "x": 130,
        "y": 140,
        "w": 100,
        "h": 78
      },
      {
        "x": 250,
        "y": 140,
        "w": 100,
        "h": 78
      },
      {
        "x": 130,
        "y": 230,
        "w": 100,
        "h": 78
      },
      {
        "x": 250,
        "y": 230,
        "w": 100,
        "h": 78
      }
    ],
    "prev": {
      "x": 138,
      "y": 334,
      "w": 88,
      "h": 60
    },
    "next": {
      "x": 254,
      "y": 334,
      "w": 88,
      "h": 60
    },
    "back": {
      "x": 190,
      "y": 400,
      "w": 100,
      "h": 48
    }
  },
  "colors": {
    "background": "#F2EADF",
    "board": "#245548",
    "grid": "#C7D3C8",
    "black": "#17201C",
    "white": "#F9F5EB",
    "accent": "#D7A94C"
  },
  "auto_rotate": false,
  "coordinate_origin": "top-left A1",
  "cell_boundaries": "left/top inclusive, right/bottom exclusive"
}
``````
<!-- REV_END -->

### ファイル：`data/rules.json`

<!-- REV_FILE data/rules.json sha256=0cd39995bebfba7481ae5b6098f1c0077688b724373a2d3bac81e1b5d5218987 -->
``````json
{
  "schema_version": "1.0.0",
  "rules_version": "1.0.0",
  "game_id": "jev_reversi",
  "menu_slot": 5,
  "sizes": [
    6,
    8
  ],
  "default_size": 6,
  "default_human": "B",
  "default_mode": "jev",
  "mode_ids": [
    "jev",
    "jev_pro",
    "casual",
    "local"
  ],
  "piece_ids": {
    "empty": 0,
    "black": 1,
    "white": 2
  },
  "move_sources": {
    "H": 0,
    "J": 1,
    "L": 2,
    "F": 3
  },
  "max_events": 128,
  "automatic_pass_ms": 700,
  "ai_animation_ms": 180,
  "idle_pause_ms": 120000,
  "screen_dim_ms": 30000,
  "api_connect_timeout_ms": 5000,
  "api_total_timeout_ms": 15000,
  "provider_timeout_seconds": 8,
  "lease_ms": 20000,
  "poll_intervals_ms": [
    1000,
    2000,
    4000
  ],
  "max_polls": 3,
  "probability_sum_tolerance": 0.001,
  "argmax_tolerance": 1e-06,
  "sampling_total": 1000000,
  "request_bytes_limit": 8192,
  "response_bytes_limit": 16384,
  "provider_chars_limit": 32768,
  "game_decision_limit": 60,
  "device_daily_call_limit": 300,
  "device_min_reservation_interval_ms": 1000,
  "decision_retention_days": 90,
  "result_retention_days": 180,
  "decision_rows_cap": 10000,
  "result_rows_cap": 2000,
  "pending_outbox_limit": 4,
  "resume_slots": 1,
  "active_game_retention_days": 7,
  "default_model": "jev-1.13.0",
  "prompt_version": "rev-prompt-1.0.0",
  "features_version": "rev-features-1.0.0",
  "local_policy_version": "rev-local-1ply-1.0.0",
  "out_of_scope": [
    "two_human_players",
    "live_spectator_arena",
    "ranked_personal_profile",
    "undo_after_commit",
    "win_probability_display",
    "multi_device_resume"
  ]
}
``````
<!-- REV_END -->

### ファイル：`data/sheets_schema.json`

<!-- REV_FILE data/sheets_schema.json sha256=3604756782beef2a2ebd3f203e00232a4e04d418fb04f2d4aa2835924c0b59b3 -->
``````json
{
  "schema_version": "1.0.0",
  "sheets": {
    "ReversiMeta": [
      "key",
      "value_json",
      "updated_at_ms"
    ],
    "ReversiDecisions": [
      "decision_key",
      "device_id",
      "game_id",
      "ply",
      "position_hash",
      "identity_text",
      "snapshot_json",
      "mode",
      "model_requested",
      "prompt_version",
      "features_version",
      "status",
      "generation",
      "created_at_ms",
      "lease_until_ms",
      "resolved_at_ms",
      "roll",
      "move",
      "inference_json",
      "error_code",
      "latency_ms",
      "input_tokens",
      "output_tokens"
    ],
    "ReversiResults": [
      "result_key",
      "device_id",
      "game_id",
      "fingerprint",
      "received_at_ms",
      "client_ended_at_ms",
      "n",
      "human",
      "mode",
      "end_reason",
      "winner",
      "black",
      "white",
      "empty",
      "placements",
      "passes",
      "jev_moves",
      "local_moves",
      "forced_ai_moves",
      "provider_class",
      "verification",
      "history_json"
    ]
  }
}
``````
<!-- REV_END -->

### ファイル：`data/tutorial.ja.json`

<!-- REV_FILE data/tutorial.ja.json sha256=558426c4460612f7a3d48be282c50363668ba4922dc714c4462866865749b718 -->
``````json
[
  {
    "title": "一枚置いて、はさむ",
    "body": "自分の石と新しく置く石で、相手の石を一直線にはさみます。はさんだ石が自分の色に変わります。"
  },
  {
    "title": "八つの方向を確認",
    "body": "縦・横・斜めが対象です。一度の着手で複数の方向をはさめたら、そのすべてを返します。"
  },
  {
    "title": "点のある場所が候補",
    "body": "一枚以上返せる空きマスだけに置けます。マスを選び「置く」で確定します。候補一覧からも選べます。"
  },
  {
    "title": "置けないときはパス",
    "body": "置ける場所がなければ、自動的に相手の番になります。置ける場所があるときはパスできません。"
  },
  {
    "title": "最後に多い方の勝ち",
    "body": "二人とも置けなくなったら終了です。盤上の石が多い方が勝ち。同じ枚数なら引き分けです。"
  },
  {
    "title": "角だけでは決まらない",
    "body": "一度取った角は返されません。でも、今たくさん返す手が、最後に勝つ手とは限りません。"
  },
  {
    "title": "Jevの判断と対戦",
    "body": "盤面のルールは端末が管理し、Jevは合法な候補から選びます。表示する評価は、この一局の勝率ではありません。"
  },
  {
    "title": "途中でコーヒーを",
    "body": "メニューから保存してカフェに戻れます。盤面は停止するので、戻ってから続きを楽しめます。"
  }
]
``````
<!-- REV_END -->

### ファイル：`docs/acceptance.md`

<!-- REV_FILE docs/acceptance.md sha256=70de9156e7e70c6e9370b4f6ce087aa5cdceb1900e91a54c6548eebe6b744dee -->
``````markdown
# JEV REVERSI v1.0 受入試験

ホスト自動検査とは別に、実装担当が実施する。初期状態はすべて未実施。各行の証拠へ環境・日時・担当を記入する。

| ID | 分類 | 試験 | 合格条件 | 状態 | 証拠 |
|---|---|---|---|---|---|
| RV-001 | 既存環境・導入 | 変更前保存 | 実ソース・GAS・設定の版と戻し方を記録し、原本を復元できる。 | 未実施 | — |
| RV-002 | 既存環境・導入 | BSP保全 | 元のLCD・タッチの起動、座標と色が変更前と同じ。 | 未実施 | — |
| RV-003 | 既存環境・導入 | コーヒー＋1 | 素早い2回操作が2杯として記録され、ゲーム追加で重複しない。 | 未実施 | — |
| RV-004 | 既存環境・導入 | 既存4ゲーム | AI ESPER・AI DUEL・CAFE DETECTIVE・人狼v2が起動する。 | 未実施 | — |
| RV-005 | 既存環境・導入 | 人狼の人数 | 第4ゲームが一つのアプリで3〜10人を選べるまま。 | 未実施 | — |
| RV-006 | 既存環境・導入 | 第5メニュー | jev_reversiを一つだけ追加。IDや保存領域が衝突しない。 | 未実施 | — |
| RV-007 | 既存環境・導入 | 導入失敗 | 設定不足でも既存カフェを利用でき、Flash全消去を要求しない。 | 未実施 | — |
| RV-008 | 既存環境・導入 | テストと本番 | Workbookと/exec URLが分離され、テストが本番履歴を変更しない。 | 未実施 | — |
| RV-009 | ルールとゲーム進行 | 6×6初期 | 白C3/D4、黒D3/C4、黒先手、合法手C2/B3/E4/D5。 | 未実施 | — |
| RV-010 | ルールとゲーム進行 | 8×8初期 | 白D4/E5、黒E4/D5、合法手D3/C4/F5/E6。 | 未実施 | — |
| RV-011 | ルールとゲーム進行 | 色選択 | 人間白でAI黒が先手。おまかせは局開始時に一度だけ決まり再開不変。 | 未実施 | — |
| RV-012 | ルールとゲーム進行 | 全8方向 | 一本でも複数でも、成立する線だけ全反転する。 | 未実施 | — |
| RV-013 | ルールとゲーム進行 | 非連鎖 | 今回返った石を根拠に追加の石を連鎖反転しない。 | 未実施 | — |
| RV-014 | ルールとゲーム進行 | 盤端 | A/H端またはA/F端から隣の行へ誤ってつながらない。 | 未実施 | — |
| RV-015 | ルールとゲーム進行 | 不正配置 | 埋まった場所、捕獲なし、範囲外で盤面/手番/plyが変わらない。 | 未実施 | — |
| RV-016 | ルールとゲーム進行 | 唯一の人間手 | 合法手が一つでも人間の選択・確定を待ちsource=H。 | 未実施 | — |
| RV-017 | ルールとゲーム進行 | 唯一のAI手 | APIを呼ばずsource=Fで唯一の手を置く。 | 未実施 | — |
| RV-018 | ルールとゲーム進行 | 強制パス | 自分だけ合法手0の時だけPASS:F、枚数不変で交代。 | 未実施 | — |
| RV-019 | ルールとゲーム進行 | パス禁止 | 合法手があれば手動/不正APIのPASSを拒否。 | 未実施 | — |
| RV-020 | ルールとゲーム進行 | 空きあり終局 | 両者合法手0で、空マスが残っていても終局。 | 未実施 | — |
| RV-021 | ルールとゲーム進行 | 満盤終局 | 最後の配置後、余分な手やJev呼出しをしない。 | 未実施 | — |
| RV-022 | ルールとゲーム進行 | 石数と引分 | 空マスを勝者へ足さず、同数は引き分け。 | 未実施 | — |
| RV-023 | ルールとゲーム進行 | 投了 | 確認後のみ相手色勝利。盤面石数は改変しない。 | 未実施 | — |
| RV-024 | ルールとゲーム進行 | 中止 | abortedを勝率へ加算しない。通信切断だけでは中止にしない。 | 未実施 | — |
| RV-025 | 丸型UIと操作 | 四隅表示 | 312px角盤と全操作部が実LCDの可視円内。 | 未実施 | — |
| RV-026 | 丸型UIと操作 | 6×6ヒット | 52pxセルの全中心と境界の選択が正しい。 | 未実施 | — |
| RV-027 | 丸型UIと操作 | 8×8ヒット | 39pxセルの全中心と境界、外側396pxの判定が正しい。 | 未実施 | — |
| RV-028 | 丸型UIと操作 | 二段階入力 | マス選択だけでは盤面が変わらず、別の置くで確定。 | 未実施 | — |
| RV-029 | 丸型UIと操作 | 選び直し | 確定前に別合法マスを選べる。確定後の待ったはできない。 | 未実施 | — |
| RV-030 | 丸型UIと操作 | 候補一覧 | 4候補/頁、大きいカード、全合法手に到達し、選択後も確定が必要。 | 未実施 | — |
| RV-031 | 丸型UIと操作 | 一覧の世代 | 古いplyの候補カードが新局面に適用されない。 | 未実施 | — |
| RV-032 | 丸型UIと操作 | 長押し連打 | 押しっぱなしと素早い複数クリックで二重着手しない。 | 未実施 | — |
| RV-033 | 丸型UIと操作 | 指を離す | 画面遷移後、前画面で押していた指が新画面の確定を起動しない。 | 未実施 | — |
| RV-034 | 丸型UIと操作 | 文字切れ | 105文言と8説明頁に欠け/重なり/不足glyphがない。 | 未実施 | — |
| RV-035 | 丸型UIと操作 | 色非依存 | 黒白・合法手・選択が色だけに頼らず分かる。 | 未実施 | — |
| RV-036 | 丸型UIと操作 | 詳細画面 | Jev評価は対応する着手前盤面と実数値。勝率と表記しない。 | 未実施 | — |
| RV-037 | Jevと端末AI | 実Jev6×6 | 実キーで合法な一手が返り、modelと選択を記録。 | 未実施 | — |
| RV-038 | Jevと端末AI | 実Jev8×8 | 実キーで8×8の座標と色を誤らず選択。 | 未実施 | — |
| RV-039 | Jevと端末AI | 白黒両方 | Jevが黒でも白でもabsolute colorが正しい。 | 未実施 | — |
| RV-040 | Jevと端末AI | 全合法手 | criteriaが全合法手と完全一致。上位手だけに切り捨てない。 | 未実施 | — |
| RV-041 | Jevと端末AI | PRO特徴 | 全特徴量をC++/JS等の計算値と照合し、後続返信盤と誤認しない。 | 未実施 | — |
| RV-042 | Jevと端末AI | CASUAL | 同じ決定キーの再取得で抽選手が変わらない。 | 未実施 | — |
| RV-043 | Jevと端末AI | 最大同率 | 1e-6以内の最大同率を行優先に処理しapi_choiceを保持。 | 未実施 | — |
| RV-044 | Jevと端末AI | 確率検査 | 欠落/余分/負数/NaN/文字列/和不正/非法choiceを拒否。 | 未実施 | — |
| RV-045 | Jevと端末AI | 固定モデル | 要求と応答modelを一致させ、aliasへ無断変更しない。 | 未実施 | — |
| RV-046 | Jevと端末AI | 端末AI一致 | ローカル方針が参考コアと同じ、合法手以外を出さない。 | 未実施 | — |
| RV-047 | Jevと端末AI | 障害後継続 | 明示確認でlocalOnlyを保存。以後その局はJevへ戻らない。 | 未実施 | — |
| RV-048 | Jevと端末AI | 出所表示 | J/L/F、人間手を混同せず、Jev不使用局をJev勝利と呼ばない。 | 未実施 | — |
| RV-049 | HTTP・Google・永続決定 | 端末認証 | 無効tokenで情報を取得/更新できず、ログにtokenを出さない。 | 未実施 | — |
| RV-050 | HTTP・Google・永続決定 | TLS | 証明書検証有効。時計不足時もsetInsecure等で回避しない。 | 未実施 | — |
| RV-051 | HTTP・Google・永続決定 | redirect | 302/303は許可GoogleホストへGET、秘密本文の再送なし。 | 未実施 | — |
| RV-052 | HTTP・Google・永続決定 | HTML応答 | 200ログインHTML/JSON不正を成功扱いにしない。 | 未実施 | — |
| RV-053 | HTTP・Google・永続決定 | schema上限 | 未知キー、8KiB超要求、16KiB超返答を拒否。 | 未実施 | — |
| RV-054 | HTTP・Google・永続決定 | GAS共存 | 既存doPost namespaceを変更せず第5のみ追加。 | 未実施 | — |
| RV-055 | HTTP・Google・永続決定 | 二重prepare | 同一局面へ同時2要求でも永続予約と外部試行は最大一度。 | 未実施 | — |
| RV-056 | HTTP・Google・永続決定 | 別request ID再送 | request_idが違っても同decision_keyは同じ確定手。 | 未実施 | — |
| RV-057 | HTTP・Google・永続決定 | 局面衝突 | 同keyで違う棋譜/hashならSTATE_CONFLICT、上書きなし。 | 未実施 | — |
| RV-058 | HTTP・Google・永続決定 | 長いJev通信 | Jev待ち中はScriptLockを保持せず他の安全な処理を止めない。 | 未実施 | — |
| RV-059 | HTTP・Google・永続決定 | 期限切れ | 20秒lease切れはfailed。古いworkerが戻ってもreadyにしない。 | 未実施 | — |
| RV-060 | HTTP・Google・永続決定 | 遅延応答 | 別局/別ply/別hash/切替済み/破棄済みなら適用しない。 | 未実施 | — |
| RV-061 | HTTP・Google・永続決定 | 通信timeout | 15秒でUIは操作可能、状態照会3回後に選択できる。 | 未実施 | — |
| RV-062 | HTTP・Google・永続決定 | Jevエラー | 401/422/429/529/5xx/8秒timeoutで無限再試行しない。 | 未実施 | — |
| RV-063 | HTTP・Google・永続決定 | 割当上限 | 300予約/日、60/局、最短間隔、行上限を一括更新で検査。 | 未実施 | — |
| RV-064 | HTTP・Google・永続決定 | 保存不確定 | batch応答消失・worker中断でbarrierが残り新規更新を安全停止。 | 未実施 | — |
| RV-065 | HTTP・Google・永続決定 | repair | 管理者がreceipt/hashを照合し、無条件クリアや別行appendをしない。 | 未実施 | — |
| RV-066 | HTTP・Google・永続決定 | 結果再送 | 同result_key・同内容は一行だけ。別内容はRESULT_CONFLICT。 | 未実施 | — |
| RV-067 | HTTP・Google・永続決定 | 棋譜検証 | result.putで全手を再生し、終了条件とJ手の確定記録を照合。 | 未実施 | — |
| RV-068 | HTTP・Google・永続決定 | 保持期限 | 90/180日整理は保守モードで索引とnext_rowを整合、枠を勝手に増やさない。 | 未実施 | — |
| RV-069 | 保存・中断・電源 | snapshot | CRCと全棋譜再生を検査、壊れたデータを部分復元しない。 | 未実施 | — |
| RV-070 | 保存・中断・電源 | 通常再開 | 人間/AI手番、黒/白、6/8の途中を保存して同一状態へ再開。 | 未実施 | — |
| RV-071 | 保存・中断・電源 | 新局途中の電断 | start_pendingと両slotの各書込点で停止して旧局へ誤復帰しない。 | 未実施 | — |
| RV-072 | 保存・中断・電源 | 着手保存中電断 | 最後の確定状態を検出し、未確認の盤面を表示しない。 | 未実施 | — |
| RV-073 | 保存・中断・電源 | 古い世代 | 別局のgenerationを比較して古い局を選ばない。 | 未実施 | — |
| RV-074 | 保存・中断・電源 | NVS満杯 | 既存namespaceを消さず安全停止。カフェ設定が残る。 | 未実施 | — |
| RV-075 | 保存・中断・電源 | 切替保存 | L未着手でもlocalOnlyが再開後に保持される。 | 未実施 | — |
| RV-076 | 保存・中断・電源 | カフェ復帰 | 選択解除・一時停止・保存、カフェ＋1後にゲームを再開。 | 未実施 | — |
| RV-077 | 保存・中断・電源 | 一時停止中応答 | Jevの返答を受けても停止画面中に自動着手しない。 | 未実施 | — |
| RV-078 | 保存・中断・電源 | outbox | 4局の未送信結果を再送して各一行。満杯は明示選択。 | 未実施 | — |
| RV-079 | 保存・中断・電源 | 終局応答消失 | 結果保存の返答が消えても二重集計しない。 | 未実施 | — |
| RV-080 | 保存・中断・電源 | 時計補正 | NTP前後やmillis wrapで待機/減光/一時停止の時間が破綻しない。 | 未実施 | — |
| RV-081 | 性能と遊び心地 | 内部RAM | 実ビルドサイズと最小heap・stack余裕を測定、未計測値を記載しない。 | 未実施 | — |
| RV-082 | 性能と遊び心地 | 画面出入り100回 | ゲームとカフェを100回往復し継続的なRAM減少/クラッシュなし。 | 未実施 | — |
| RV-083 | 性能と遊び心地 | 長時間通信 | HTTP待ち・失敗を繰り返してWDT/画面フリーズなし。 | 未実施 | — |
| RV-084 | 性能と遊び心地 | 電池と充電 | 1500mAh実機で操作/待機/充電中を測定、接続解除で不正終了なし。 | 未実施 | — |
| RV-085 | 性能と遊び心地 | 初見5人の6×6 | 各1局、選択/確定/パス/結果/カフェへ戻るが理解できる。 | 未実施 | — |
| RV-086 | 性能と遊び心地 | 初見5人の8×8 | 各1局、大きい候補一覧を含めて誤操作・読みづらさを記録して修正。 | 未実施 | — |
| RV-087 | 性能と遊び心地 | 相手の表示 | Jev・端末AI・途中混在の違いを参加者が区別できる。 | 未実施 | — |
| RV-088 | 性能と遊び心地 | 回帰と納品 | 元4ゲーム/カフェの回帰、未実施一覧、配備版、戻し方を提出。 | 未実施 | — |

**合計：88項目。**

実API/実Google/ESP32実機の項目は、PC参考版が動いたことでは合格にしない。スコープ外のため適用外とする場合も理由と制限を完成報告へ残す。
``````
<!-- REV_END -->

### ファイル：`gas/decision_machine.js`

<!-- REV_FILE gas/decision_machine.js sha256=b519486854f24636a9c1c0235b0ca18a9a5215329ebc0282fa6ed628325a6be9 -->
``````javascript
/* Pure lease/idempotency reference. The caller MUST persist each transition under a real
 * ScriptLock + atomic Sheets batch. This module is not itself a lock or database. */
var CTDecision = (()=>{
  'use strict';
  const LEASE_MS=20000;
  function reserve(existing,input,now,generation) {
    if(existing) {
      if(existing.position_hash!==input.position_hash||existing.identity!==input.identity)throw Error('STATE_CONFLICT');
      return {record:existing,call_provider:false};
    }
    return {record:{...input,status:'pending',generation,lease_until_ms:now+LEASE_MS,
      call_reserved:true,created_at_ms:now,answer:null,error:null},call_provider:true};
  }
  function finalize(record,generation,now,answer,error=null) {
    if(record.status!=='pending'||record.generation!==generation)return {record,accepted:false};
    if(now>record.lease_until_ms)return {record:{...record,status:'failed',error:'LEASE_EXPIRED',answer:null},accepted:false};
    return {record:{...record,status:error?'failed':'ready',answer:error?null:answer,error},accepted:true};
  }
  function expire(record,now) {
    if(record.status==='pending'&&now>record.lease_until_ms)return {...record,status:'failed',answer:null,error:'LEASE_EXPIRED'};
    return record;
  }
  return {reserve,finalize,expire,LEASE_MS};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=CTDecision;
``````
<!-- REV_END -->

### ファイル：`gas/provider_adapter.gs`

<!-- REV_FILE gas/provider_adapter.gs sha256=28efb909abad7dbfca23fc08c552e7ce7a4b6fccb69cee755b37909b459a97a3 -->
``````javascript
/** Reference connector. CTReversi must be loaded as an Apps Script .gs module.
 * Call only AFTER a durable reservation; never while holding ScriptLock.
 * No API keys, request bodies or response bodies are logged here.
 */
function revCallProvider(snapshot, model, apiKey) {
  if (typeof apiKey !== 'string' || !apiKey) return {ok:false,error:'NO_KEY'};
  var p = CTReversi.replay(snapshot);
  var body = CTReversi.buildJevRequest(snapshot, model);
  var start = Date.now();
  try {
    var response = UrlFetchApp.fetch('https://api.typesafe.ai/v1/systemone', {
      method:'post', contentType:'application/json',
      headers:{Authorization:'Bearer '+apiKey}, payload:JSON.stringify(body),
      muteHttpExceptions:true, followRedirects:false,
      validateHttpsCertificates:true, timeoutSeconds:8
    });
    var code = response.getResponseCode();
    if (code !== 200) return {ok:false,error:'PROVIDER_HTTP_'+code,latency_ms:Date.now()-start};
    var text = response.getContentText();
    if (text.length > 32768) return {ok:false,error:'PROVIDER_TOO_LARGE',latency_ms:Date.now()-start};
    var parsed = CTReversi.parseJev(JSON.parse(text),p,model);
    return {ok:true,inference:parsed,latency_ms:Date.now()-start};
  } catch (err) {
    return {ok:false,error:'PROVIDER_FETCH_OR_PARSE_FAILED',latency_ms:Date.now()-start};
  }
}
``````
<!-- REV_END -->

### ファイル：`gas/reversi_shared.js`

<!-- REV_FILE gas/reversi_shared.js sha256=6e2f8ad30ed62055a1eef9bc54904674eb4c3f67ef56fd894d521c507e40d080 -->
``````javascript
/* Pure JavaScript reference module; shared by Apps Script V8, Node and browser preview.
 * Google persistence/authorization is a separate adapter; this file never calls an API.
 */
var CTReversi = (() => {
  'use strict';
  const MODES = ['jev','jev_pro','casual','local'];
  const fail = c => { throw new Error(c); };
  const other = c => c === 'B' ? 'W' : 'B';
  function check(p) {
    if (!p || ![6,8].includes(p.n) || !['B','W'].includes(p.side) ||
        typeof p.cells !== 'string' || p.cells.length !== p.n*p.n || /[^.BW]/.test(p.cells) ||
        !Number.isInteger(p.ply) || p.ply<0 || p.ply>128) fail('BAD_STATE');
  }
  function initial(n) {
    if (![6,8].includes(n)) fail('BAD_SIZE');
    let b=Array(n*n).fill('.'), a=n/2-1, c=n/2;
    b[a*n+a]=b[c*n+c]='W'; b[a*n+c]=b[c*n+a]='B';
    return {n,cells:b.join(''),side:'B',ply:0};
  }
  function coord(n,i) { return i===-1?'PASS':String.fromCharCode(65+i%n)+(1+Math.floor(i/n)); }
  function square(n,s) {
    if(s==='PASS') return -1;
    if(typeof s!=='string'||! /^[A-H][1-8]$/.test(s)) fail('BAD_MOVE');
    const c=s.charCodeAt(0)-65,r=Number(s[1])-1;
    if(r>=n||c>=n) fail('BAD_MOVE');
    return r*n+c;
  }
  function flips(p,i,color=p.side) {
    check(p);
    if(!['B','W'].includes(color)) fail('BAD_COLOR');
    if(!Number.isInteger(i)||i<0||i>=p.n*p.n||p.cells[i]!=='.') return [];
    let out=[];
    for(let dy=-1;dy<=1;dy++) for(let dx=-1;dx<=1;dx++) {
      if(!dy&&!dx) continue;
      let r=Math.floor(i/p.n)+dy,c=i%p.n+dx,ray=[];
      while(r>=0&&r<p.n&&c>=0&&c<p.n&&p.cells[r*p.n+c]===other(color)) {
        ray.push(r*p.n+c);r+=dy;c+=dx;
      }
      if(ray.length&&r>=0&&r<p.n&&c>=0&&c<p.n&&p.cells[r*p.n+c]===color) out.push(...ray);
    }
    return out.sort((a,b)=>a-b);
  }
  function legal(p,color=p.side) {
    let out=[];for(let i=0;i<p.n*p.n;i++) if(flips(p,i,color).length) out.push(i);return out;
  }
  function terminal(p) {return legal(p,'B').length===0&&legal(p,'W').length===0;}
  function counts(p) {
    check(p);return {black:[...p.cells].filter(x=>x==='B').length,white:[...p.cells].filter(x=>x==='W').length,empty:[...p.cells].filter(x=>x==='.').length};
  }
  function winner(p) {if(!terminal(p)) return '-';let c=counts(p);return c.black>c.white?'B':c.white>c.black?'W':'D';}
  function step(p,i) {
    check(p);if(p.ply>=128) fail('BAD_STATE');if(terminal(p)) fail('FINISHED');
    let b=[...p.cells];
    if(i===-1) {if(legal(p).length) fail('PASS_FORBIDDEN');}
    else {
      if(!Number.isInteger(i)||i<0||i>=p.n*p.n) fail('OUT_OF_RANGE');
      if(p.cells[i]!=='.') fail('OCCUPIED');
      let f=flips(p,i);if(!f.length) fail('NO_CAPTURE');
      b[i]=p.side;for(const j of f) b[j]=p.side;
    }
    return {n:p.n,cells:b.join(''),side:other(p.side),ply:p.ply+1};
  }
  function frontier(p,color) {
    let total=0;
    for(let i=0;i<p.n*p.n;i++) if(p.cells[i]===color) {
      let near=false;
      for(let dy=-1;dy<=1;dy++) for(let dx=-1;dx<=1;dx++) {
        let r=Math.floor(i/p.n)+dy,c=i%p.n+dx;
        if((dy||dx)&&r>=0&&r<p.n&&c>=0&&c<p.n&&p.cells[r*p.n+c]==='.') near=true;
      }
      if(near) total++;
    }
    return total;
  }
  function risk(p,color,diagonal) {
    let v=0,n=p.n;
    for(const r of [0,n-1]) for(const c of [0,n-1]) if(p.cells[r*n+c]==='.') {
      let ir=r===0?1:n-2,ic=c===0?1:n-2;
      if(diagonal) v+=Number(p.cells[ir*n+ic]===color);
      else v+=Number(p.cells[ir*n+c]===color)+Number(p.cells[r*n+ic]===color);
    }
    return v;
  }
  function evaluate(p,root) {
    const opp=other(root),c=counts(p),d=root==='B'?c.black-c.white:c.white-c.black;
    if(terminal(p)) return d===0?0:(d>0?100000:-100000)+d;
    let corner=0;
    for(const r of [0,p.n-1]) for(const col of [0,p.n-1]) {
      let x=p.cells[r*p.n+col];corner+=Number(x===root)-Number(x===opp);
    }
    let w=c.empty>Math.floor(p.n*p.n/2)?-1:c.empty>Math.floor(p.n*p.n/4)?1:6;
    return 120*corner+8*(legal(p,root).length-legal(p,opp).length)-4*(frontier(p,root)-frontier(p,opp))
      -25*(risk(p,root,true)-risk(p,opp,true))-10*(risk(p,root,false)-risk(p,opp,false))+w*d;
  }
  function localMove(p) {
    const l=legal(p);if(!l.length)return -1;
    let best=l[0],score=-200000;
    for(const i of l) {let v=evaluate(step(p,i),p.side);if(v>score){score=v;best=i;}}
    return best;
  }
  function replay(s) {
    if(!s||!/^[0-9a-f]{32}$/.test(s.game_id)||!['B','W'].includes(s.human)||!MODES.includes(s.mode)||
       !Array.isArray(s.history)||s.history.length>128) fail('BAD_SNAPSHOT');
    let p=initial(s.n),localOnly=s.mode==='local';
    for(const token of s.history) {
      if(typeof token!=='string'||! /^(?:[A-H][1-8]|PASS):[HJLF]$/.test(token))fail('BAD_HISTORY');
      let [name,source]=token.split(':'),i=square(p.n,name),l=legal(p);
      if(i===-1) {if(source!=='F')fail('BAD_SOURCE');}
      else if(p.side===s.human) {if(source!=='H')fail('BAD_SOURCE');}
      else if(l.length===1) {if(source!=='F')fail('BAD_SOURCE');}
      else {
        if(!['J','L'].includes(source))fail('BAD_SOURCE');
        if(source==='J'&&localOnly)fail('PROVIDER_SWITCH_BACK');
        if(source==='L')localOnly=true;
      }
      p=step(p,i);
    }
    return p;
  }
  function identity(s) {
    let p=replay(s);
    return ['REV1','1.0.0',s.game_id,s.n,s.human,s.mode,p.ply,p.side,p.cells,s.history.join(',')].join('|');
  }
  function features(p,i) {
    let q=step(p,i),r=Math.floor(i/p.n),c=i%p.n,done=terminal(q),k=counts(q);
    let x=false,adj=false;
    for(let cr of [0,p.n-1])for(let cc of [0,p.n-1])if(q.cells[cr*p.n+cc]==='.'){
      x=x||(Math.abs(r-cr)===1&&Math.abs(c-cc)===1);
      adj=adj||(Math.abs(r-cr)+Math.abs(c-cc)===1);
    }
    return {flipped:flips(p,i).length,corner:(r===0||r===p.n-1)&&(c===0||c===p.n-1),
      edge:r===0||r===p.n-1||c===0||c===p.n-1,x_adjacent_to_empty_corner:x,c_adjacent_to_empty_corner:adj,
      self_legal_count_on_resulting_board:legal(q,p.side).length,
      opponent_legal_count_on_resulting_board:legal(q,other(p.side)).length,
      terminal:done,terminal_disk_diff:done?(p.side==='B'?k.black-k.white:k.white-k.black):null};
  }
  function buildJevRequest(s,model) {
    const p=replay(s),l=legal(p);
    if(s.mode==='local'||s.history.some(x=>x.endsWith(':L')))fail('LOCAL_ONLY');
    if(p.side===s.human||terminal(p)||l.length<2)fail('NO_DECISION_REQUIRED');
    if(typeof model!=='string'||!/^jev-[A-Za-z0-9.-]+$/.test(model))fail('BAD_MODEL');
    const criteria={};
    for(const i of l)criteria[coord(p.n,i)]=s.mode==='jev_pro'?features(p,i):'Place one '+(p.side==='B'?'black':'white')+' disk at '+coord(p.n,i)+'.';
    return {model,state:{game:'COFFEE TIME Reversi',rules_version:'1.0.0',board_size:p.n,
      columns:'ABCDEFGH'.slice(0,p.n).split(''),rows:Array.from({length:p.n},(_,i)=>i+1),
      board_rows:Array.from({length:p.n},(_,r)=>p.cells.slice(r*p.n,(r+1)*p.n)),
      legend:{B:'black',W:'white','.':'empty'},side_to_move:p.side,counts:counts(p),
      legal_moves:l.map(i=>coord(p.n,i))},questions:{move:{type:'choice',
      instructions:'Choose exactly one legal move for the side_to_move in Reversi. Maximize the chance of finishing with more disks than the opponent under good opposing play. B and W are absolute colors, not player names. A1 is the top-left; columns go right and rows go down. A legal placement brackets one or more adjacent enemy disks with a friendly disk in a straight line in any of eight directions; all such lines flip simultaneously, without chain reactions. If neither side has a legal move the game ends, even with empty cells. Empty cells score for neither side; ties are draws. Do not optimize immediate flips alone. All choices supplied are legal; do not invent a move or pass. In PRO, mobility counts refer to the SAME resulting board for each hypothetical color, not to a later reply.',criteria}}};
  }
  function parseJev(response,p,model) {
    if(!response||response.model!==model||!response.answers)fail('MODEL_OR_RESPONSE_INVALID');
    const a=response.answers.move,l=legal(p).map(i=>coord(p.n,i));
    if(!a||a.type!=='choice'||!a.probabilities||Array.isArray(a.probabilities)||
      Object.keys(a.probabilities).length!==l.length||!l.includes(a.choice)||
      typeof a.confidence!=='number'||!Number.isFinite(a.confidence)||a.confidence<0||a.confidence>1)fail('PROVIDER_INVALID');
    const values=l.map(x=>a.probabilities[x]);
    if(values.some(x=>typeof x!=='number'||!Number.isFinite(x)||x<0||x>1))fail('PROVIDER_INVALID');
    let sum=values.reduce((a,b)=>a+b,0);
    if(Math.abs(sum-1)>0.001||sum<=0)fail('PROVIDER_INVALID');
    const maximum=Math.max(...values);
    if(maximum-a.probabilities[a.choice]>1e-6)fail('PROVIDER_INVALID');
    const probabilities={};l.forEach((x,i)=>probabilities[x]=values[i]/sum);
    // Canonical tie-breaking: lowest row-major position within tolerance of the true maximum.
    const selected=l.find(x=>Math.max(...Object.values(probabilities))-probabilities[x]<=1e-6);
    const usage=response.usage||{};
    const safeInt=x=>Number.isInteger(x)&&x>=0?x:null;
    return {model,choice:selected,api_choice:a.choice,probabilities,confidence:a.confidence,
      normalization_applied:sum!==1,input_tokens:safeInt(usage.input_tokens),output_tokens:safeInt(usage.output_tokens)};
  }
  function probabilityWeights(probabilities,orderedKeys) {
    const raw=orderedKeys.map(k=>probabilities[k]*1000000),w=raw.map(Math.floor);
    let left=1000000-w.reduce((a,b)=>a+b,0);
    if(left<0||left>orderedKeys.length)fail('BAD_PROBABILITY');
    const ranked=raw.map((v,i)=>({i,remainder:v-w[i]})).sort((a,b)=>b.remainder-a.remainder||a.i-b.i);
    for(let j=0;j<left;j++)w[ranked[j].i]++;
    return w;
  }
  function sample(probabilities,orderedKeys,roll) {
    if(!Number.isInteger(roll)||roll<0||roll>=1000000)fail('BAD_ROLL');
    const w=probabilityWeights(probabilities,orderedKeys);let sum=0;
    for(let i=0;i<w.length;i++){sum+=w[i];if(roll<sum)return orderedKeys[i];}
    fail('BAD_PROBABILITY');
  }
  function acceptsReply(active,reply) {
    return !!active && !active.local_only && active.waiting && reply && reply.status==='ready' &&
      reply.game_id===active.game_id && reply.ply===active.ply &&
      reply.position_hash===active.position_hash && reply.decision_key===active.decision_key &&
      active.legal_moves.includes(reply.move);
  }
  return {MODES,other,check,initial,coord,square,flips,legal,terminal,counts,winner,step,frontier,risk,
    evaluate,localMove,replay,identity,features,buildJevRequest,parseJev,probabilityWeights,sample,acceptsReply};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=CTReversi;
``````
<!-- REV_END -->

### ファイル：`manifest.json`

<!-- REV_FILE manifest.json sha256=6a37076414eedf3fb92d6baeae906b0a1790d74460d5753b27380df7aeeb8226 -->
``````json
{
  "version": "1.0.0",
  "format": "UTF-8 LF",
  "note": "Manifest lists payload files except itself. Every Markdown block, including this manifest, has its own SHA-256.",
  "files": [
    {
      "path": "AGENT_START.md",
      "bytes": 1291,
      "sha256": "b728fa95c0f5c90fc9fb0cf2f75f61726f48d2a72bbf44925692d6bd2d66f41c"
    },
    {
      "path": "README.md",
      "bytes": 2644,
      "sha256": "9b36ab335799b5dc8206682770438e9fd3cf8b6c6d42521701711c0b687ed2f2"
    },
    {
      "path": "data/api_contract.json",
      "bytes": 2408,
      "sha256": "5e040142b607c728748dc0a86b06ce71731e04035324f9ba9d45f3e6152e2ef7"
    },
    {
      "path": "data/content.ja.json",
      "bytes": 5558,
      "sha256": "817533efc13d9365d870c8deb37176dffd1ecee96588cdd3c645fe991fead813"
    },
    {
      "path": "data/golden_positions.json",
      "bytes": 23021,
      "sha256": "579895dfe287d09650c3ea2bcf739ce6f661ea6b43fd50a41b27425376474202"
    },
    {
      "path": "data/layout.json",
      "bytes": 2043,
      "sha256": "42cee4f3ffc0c6b89e12c2ad7914437db5329c8fde7d819d7a25d75548da3837"
    },
    {
      "path": "data/rules.json",
      "bytes": 1614,
      "sha256": "0cd39995bebfba7481ae5b6098f1c0077688b724373a2d3bac81e1b5d5218987"
    },
    {
      "path": "data/sheets_schema.json",
      "bytes": 1087,
      "sha256": "3604756782beef2a2ebd3f203e00232a4e04d418fb04f2d4aa2835924c0b59b3"
    },
    {
      "path": "data/tutorial.ja.json",
      "bytes": 1600,
      "sha256": "558426c4460612f7a3d48be282c50363668ba4922dc714c4462866865749b718"
    },
    {
      "path": "docs/acceptance.md",
      "bytes": 13302,
      "sha256": "70de9156e7e70c6e9370b4f6ce087aa5cdceb1900e91a54c6548eebe6b744dee"
    },
    {
      "path": "gas/decision_machine.js",
      "bytes": 1377,
      "sha256": "b519486854f24636a9c1c0235b0ca18a9a5215329ebc0282fa6ed628325a6be9"
    },
    {
      "path": "gas/provider_adapter.gs",
      "bytes": 1341,
      "sha256": "28efb909abad7dbfca23fc08c552e7ce7a4b6fccb69cee755b37909b459a97a3"
    },
    {
      "path": "gas/reversi_shared.js",
      "bytes": 10647,
      "sha256": "6e2f8ad30ed62055a1eef9bc54904674eb4c3f67ef56fd894d521c507e40d080"
    },
    {
      "path": "preview.html",
      "bytes": 16993,
      "sha256": "fa0dc43ca545165a6394756e29f94a4e0f731f3785387c4ccf9335253a54002f"
    },
    {
      "path": "results/browser.json",
      "bytes": 276,
      "sha256": "098fb3626c075454d4b913480f380490f07d949328f508a33cf8cf6f2dbdde72"
    },
    {
      "path": "results/contracts.json",
      "bytes": 119,
      "sha256": "cafede4d592555b566e2da00fbaf9ca81d0cf1df119a4b4b3a67f8c69d04d601"
    },
    {
      "path": "results/core_verification.json",
      "bytes": 429,
      "sha256": "3929a8baf4a80448a25381f15f99b1b9072dee779ec2dc60daae7d900c25ea72"
    },
    {
      "path": "results/cpp_smoke.json",
      "bytes": 78,
      "sha256": "0dc9ef77e124f585557cb884c8255e8438526e42e29a0c41809be5d517b2e68d"
    },
    {
      "path": "results/data.json",
      "bytes": 194,
      "sha256": "1bd7b315f64388bcb6c22deb8c86ccada500d01b5c468b85d3f8f8b98c5fdb47"
    },
    {
      "path": "results/host_run.json",
      "bytes": 289,
      "sha256": "00131dce487ab464053586f3e806ac4f91f169d3fc947eb1a8df16cad0032017"
    },
    {
      "path": "results/session.json",
      "bytes": 66,
      "sha256": "d73c8832b69eed9d4491c7bffc4e51f2c56d0a024fc956c9ef5f48e6d70cb888"
    },
    {
      "path": "results/session_sanitized.json",
      "bytes": 57,
      "sha256": "6412662df2a4ac16f07caf76e530454ef346ad1836301b4911f560cbeb0d403a"
    },
    {
      "path": "src/lvgl8_board_example.hpp",
      "bytes": 5879,
      "sha256": "5bba2f20bf07108852a9c50635df41141c04b83e00eb3eeb4e2e69f989aed2a9"
    },
    {
      "path": "src/reversi_core.hpp",
      "bytes": 6218,
      "sha256": "dd688307a43b50a45e0a1c9a2f1bfad1da23be8f1dd7a39b32ef5bbd86f141a9"
    },
    {
      "path": "src/reversi_session.hpp",
      "bytes": 4072,
      "sha256": "e52380f9690963b6157678117a844298c26079e34ba33f80f04e8acf8226798b"
    },
    {
      "path": "tests/browser_check.py",
      "bytes": 1977,
      "sha256": "c536700633abe2fc9eaac1a5f8db7ac812c6db4fab494522ad767c67298f4065"
    },
    {
      "path": "tests/core_cli.cpp",
      "bytes": 1034,
      "sha256": "121ee71a02acc9b5737639ba1d142cf8e697f908683fb4459d1d5fcf31c7dd4c"
    },
    {
      "path": "tests/js_cli.js",
      "bytes": 524,
      "sha256": "d985e9e10b96225b64e8e8ec64a4c6bafa2a7f822594aba61b1e1b9281e71f02"
    },
    {
      "path": "tests/session_test.cpp",
      "bytes": 1618,
      "sha256": "14c5111e10c795143eecebd77eeff472732e50dbbde03e7363fb7bda104c30b4"
    },
    {
      "path": "tests/smoke.cpp",
      "bytes": 1157,
      "sha256": "451db9e51337b2554d37cac55c78ffb2b684ce3dc4532e6505f06384c3854d07"
    },
    {
      "path": "tests/test_contract.js",
      "bytes": 5679,
      "sha256": "673cc9cc1ec2d9463cd42a93c76412ebd5228ad7b452ffb1268c866fedb0224d"
    },
    {
      "path": "tests/test_data.py",
      "bytes": 2142,
      "sha256": "f51f9510e944dd310bcd99a24723aba15d61c12740db9749b572bc6606c69c57"
    },
    {
      "path": "tests/verify_core.py",
      "bytes": 5726,
      "sha256": "d1a00eb4b51bec03c948e163b663d525fd83ad3a4873947334a5269f130adbb9"
    },
    {
      "path": "tools/extract_payload.py",
      "bytes": 1997,
      "sha256": "e67bf9c9231c9f8fdbf4b878ae70e73d15db497ec4b54b1582b7babc0f5bec91"
    },
    {
      "path": "tools/run_all.py",
      "bytes": 1822,
      "sha256": "ac9add0749ab3f727f4d067a882b3f76336f59e9bc4b803cd1a07928d162b34c"
    }
  ]
}
``````
<!-- REV_END -->

### ファイル：`preview.html`

<!-- REV_FILE preview.html sha256=fa0dc43ca545165a6394756e29f94a4e0f731f3785387c4ccf9335253a54002f -->
``````html
<!doctype html><html lang="ja"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>COFFEE TIME — REVERSI ローカル参考版</title>
<style>body{background:#f2eadf;color:#17201c;font-family:system-ui,sans-serif;text-align:center;margin:22px}h1{font-size:24px;letter-spacing:.07em}p{line-height:1.7;max-width:680px;margin:12px auto}.bar{margin:16px;display:flex;justify-content:center;gap:12px;flex-wrap:wrap}select,button{font:inherit;border:1px solid #768b80;border-radius:10px;padding:10px;background:white}canvas{width:min(90vw,480px);height:auto;touch-action:none;box-shadow:0 12px 34px #192d2430;border-radius:50%;background:#f2eadf}.note{font-size:14px}#status{min-height:50px;font-weight:600}</style>
<h1>COFFEE TIME / REVERSI</h1><p>丸型画面の操作確認用・端末AIとのローカル対戦です。<br>Jev／Google／ESP32には接続しません。</p>
<div class="bar"><label>盤面 <select id="size"><option value="6">6×6</option><option value="8">8×8</option></select></label><label>自分の色 <select id="human"><option value="B">黒・先手</option><option value="W">白・後手</option></select></label><button id="new">新しい対局</button></div>
<canvas id="screen" width="480" height="480" aria-label="リバーシ盤。マスを選んで置くを押す"></canvas>
<p id="status" aria-live="polite"></p><p class="note">マスを選択 → 中央下の「置く」で確定。右下「候補」で大きな候補一覧を開けます。<br>左下「休止」で停止・再開。PC参考版は再読込すると対局が消えます。</p>
<script>/* Pure JavaScript reference module; shared by Apps Script V8, Node and browser preview.
 * Google persistence/authorization is a separate adapter; this file never calls an API.
 */
var CTReversi = (() => {
  'use strict';
  const MODES = ['jev','jev_pro','casual','local'];
  const fail = c => { throw new Error(c); };
  const other = c => c === 'B' ? 'W' : 'B';
  function check(p) {
    if (!p || ![6,8].includes(p.n) || !['B','W'].includes(p.side) ||
        typeof p.cells !== 'string' || p.cells.length !== p.n*p.n || /[^.BW]/.test(p.cells) ||
        !Number.isInteger(p.ply) || p.ply<0 || p.ply>128) fail('BAD_STATE');
  }
  function initial(n) {
    if (![6,8].includes(n)) fail('BAD_SIZE');
    let b=Array(n*n).fill('.'), a=n/2-1, c=n/2;
    b[a*n+a]=b[c*n+c]='W'; b[a*n+c]=b[c*n+a]='B';
    return {n,cells:b.join(''),side:'B',ply:0};
  }
  function coord(n,i) { return i===-1?'PASS':String.fromCharCode(65+i%n)+(1+Math.floor(i/n)); }
  function square(n,s) {
    if(s==='PASS') return -1;
    if(typeof s!=='string'||! /^[A-H][1-8]$/.test(s)) fail('BAD_MOVE');
    const c=s.charCodeAt(0)-65,r=Number(s[1])-1;
    if(r>=n||c>=n) fail('BAD_MOVE');
    return r*n+c;
  }
  function flips(p,i,color=p.side) {
    check(p);
    if(!['B','W'].includes(color)) fail('BAD_COLOR');
    if(!Number.isInteger(i)||i<0||i>=p.n*p.n||p.cells[i]!=='.') return [];
    let out=[];
    for(let dy=-1;dy<=1;dy++) for(let dx=-1;dx<=1;dx++) {
      if(!dy&&!dx) continue;
      let r=Math.floor(i/p.n)+dy,c=i%p.n+dx,ray=[];
      while(r>=0&&r<p.n&&c>=0&&c<p.n&&p.cells[r*p.n+c]===other(color)) {
        ray.push(r*p.n+c);r+=dy;c+=dx;
      }
      if(ray.length&&r>=0&&r<p.n&&c>=0&&c<p.n&&p.cells[r*p.n+c]===color) out.push(...ray);
    }
    return out.sort((a,b)=>a-b);
  }
  function legal(p,color=p.side) {
    let out=[];for(let i=0;i<p.n*p.n;i++) if(flips(p,i,color).length) out.push(i);return out;
  }
  function terminal(p) {return legal(p,'B').length===0&&legal(p,'W').length===0;}
  function counts(p) {
    check(p);return {black:[...p.cells].filter(x=>x==='B').length,white:[...p.cells].filter(x=>x==='W').length,empty:[...p.cells].filter(x=>x==='.').length};
  }
  function winner(p) {if(!terminal(p)) return '-';let c=counts(p);return c.black>c.white?'B':c.white>c.black?'W':'D';}
  function step(p,i) {
    check(p);if(p.ply>=128) fail('BAD_STATE');if(terminal(p)) fail('FINISHED');
    let b=[...p.cells];
    if(i===-1) {if(legal(p).length) fail('PASS_FORBIDDEN');}
    else {
      if(!Number.isInteger(i)||i<0||i>=p.n*p.n) fail('OUT_OF_RANGE');
      if(p.cells[i]!=='.') fail('OCCUPIED');
      let f=flips(p,i);if(!f.length) fail('NO_CAPTURE');
      b[i]=p.side;for(const j of f) b[j]=p.side;
    }
    return {n:p.n,cells:b.join(''),side:other(p.side),ply:p.ply+1};
  }
  function frontier(p,color) {
    let total=0;
    for(let i=0;i<p.n*p.n;i++) if(p.cells[i]===color) {
      let near=false;
      for(let dy=-1;dy<=1;dy++) for(let dx=-1;dx<=1;dx++) {
        let r=Math.floor(i/p.n)+dy,c=i%p.n+dx;
        if((dy||dx)&&r>=0&&r<p.n&&c>=0&&c<p.n&&p.cells[r*p.n+c]==='.') near=true;
      }
      if(near) total++;
    }
    return total;
  }
  function risk(p,color,diagonal) {
    let v=0,n=p.n;
    for(const r of [0,n-1]) for(const c of [0,n-1]) if(p.cells[r*n+c]==='.') {
      let ir=r===0?1:n-2,ic=c===0?1:n-2;
      if(diagonal) v+=Number(p.cells[ir*n+ic]===color);
      else v+=Number(p.cells[ir*n+c]===color)+Number(p.cells[r*n+ic]===color);
    }
    return v;
  }
  function evaluate(p,root) {
    const opp=other(root),c=counts(p),d=root==='B'?c.black-c.white:c.white-c.black;
    if(terminal(p)) return d===0?0:(d>0?100000:-100000)+d;
    let corner=0;
    for(const r of [0,p.n-1]) for(const col of [0,p.n-1]) {
      let x=p.cells[r*p.n+col];corner+=Number(x===root)-Number(x===opp);
    }
    let w=c.empty>Math.floor(p.n*p.n/2)?-1:c.empty>Math.floor(p.n*p.n/4)?1:6;
    return 120*corner+8*(legal(p,root).length-legal(p,opp).length)-4*(frontier(p,root)-frontier(p,opp))
      -25*(risk(p,root,true)-risk(p,opp,true))-10*(risk(p,root,false)-risk(p,opp,false))+w*d;
  }
  function localMove(p) {
    const l=legal(p);if(!l.length)return -1;
    let best=l[0],score=-200000;
    for(const i of l) {let v=evaluate(step(p,i),p.side);if(v>score){score=v;best=i;}}
    return best;
  }
  function replay(s) {
    if(!s||!/^[0-9a-f]{32}$/.test(s.game_id)||!['B','W'].includes(s.human)||!MODES.includes(s.mode)||
       !Array.isArray(s.history)||s.history.length>128) fail('BAD_SNAPSHOT');
    let p=initial(s.n),localOnly=s.mode==='local';
    for(const token of s.history) {
      if(typeof token!=='string'||! /^(?:[A-H][1-8]|PASS):[HJLF]$/.test(token))fail('BAD_HISTORY');
      let [name,source]=token.split(':'),i=square(p.n,name),l=legal(p);
      if(i===-1) {if(source!=='F')fail('BAD_SOURCE');}
      else if(p.side===s.human) {if(source!=='H')fail('BAD_SOURCE');}
      else if(l.length===1) {if(source!=='F')fail('BAD_SOURCE');}
      else {
        if(!['J','L'].includes(source))fail('BAD_SOURCE');
        if(source==='J'&&localOnly)fail('PROVIDER_SWITCH_BACK');
        if(source==='L')localOnly=true;
      }
      p=step(p,i);
    }
    return p;
  }
  function identity(s) {
    let p=replay(s);
    return ['REV1','1.0.0',s.game_id,s.n,s.human,s.mode,p.ply,p.side,p.cells,s.history.join(',')].join('|');
  }
  function features(p,i) {
    let q=step(p,i),r=Math.floor(i/p.n),c=i%p.n,done=terminal(q),k=counts(q);
    let x=false,adj=false;
    for(let cr of [0,p.n-1])for(let cc of [0,p.n-1])if(q.cells[cr*p.n+cc]==='.'){
      x=x||(Math.abs(r-cr)===1&&Math.abs(c-cc)===1);
      adj=adj||(Math.abs(r-cr)+Math.abs(c-cc)===1);
    }
    return {flipped:flips(p,i).length,corner:(r===0||r===p.n-1)&&(c===0||c===p.n-1),
      edge:r===0||r===p.n-1||c===0||c===p.n-1,x_adjacent_to_empty_corner:x,c_adjacent_to_empty_corner:adj,
      self_legal_count_on_resulting_board:legal(q,p.side).length,
      opponent_legal_count_on_resulting_board:legal(q,other(p.side)).length,
      terminal:done,terminal_disk_diff:done?(p.side==='B'?k.black-k.white:k.white-k.black):null};
  }
  function buildJevRequest(s,model) {
    const p=replay(s),l=legal(p);
    if(s.mode==='local'||s.history.some(x=>x.endsWith(':L')))fail('LOCAL_ONLY');
    if(p.side===s.human||terminal(p)||l.length<2)fail('NO_DECISION_REQUIRED');
    if(typeof model!=='string'||!/^jev-[A-Za-z0-9.-]+$/.test(model))fail('BAD_MODEL');
    const criteria={};
    for(const i of l)criteria[coord(p.n,i)]=s.mode==='jev_pro'?features(p,i):'Place one '+(p.side==='B'?'black':'white')+' disk at '+coord(p.n,i)+'.';
    return {model,state:{game:'COFFEE TIME Reversi',rules_version:'1.0.0',board_size:p.n,
      columns:'ABCDEFGH'.slice(0,p.n).split(''),rows:Array.from({length:p.n},(_,i)=>i+1),
      board_rows:Array.from({length:p.n},(_,r)=>p.cells.slice(r*p.n,(r+1)*p.n)),
      legend:{B:'black',W:'white','.':'empty'},side_to_move:p.side,counts:counts(p),
      legal_moves:l.map(i=>coord(p.n,i))},questions:{move:{type:'choice',
      instructions:'Choose exactly one legal move for the side_to_move in Reversi. Maximize the chance of finishing with more disks than the opponent under good opposing play. B and W are absolute colors, not player names. A1 is the top-left; columns go right and rows go down. A legal placement brackets one or more adjacent enemy disks with a friendly disk in a straight line in any of eight directions; all such lines flip simultaneously, without chain reactions. If neither side has a legal move the game ends, even with empty cells. Empty cells score for neither side; ties are draws. Do not optimize immediate flips alone. All choices supplied are legal; do not invent a move or pass. In PRO, mobility counts refer to the SAME resulting board for each hypothetical color, not to a later reply.',criteria}}};
  }
  function parseJev(response,p,model) {
    if(!response||response.model!==model||!response.answers)fail('MODEL_OR_RESPONSE_INVALID');
    const a=response.answers.move,l=legal(p).map(i=>coord(p.n,i));
    if(!a||a.type!=='choice'||!a.probabilities||Array.isArray(a.probabilities)||
      Object.keys(a.probabilities).length!==l.length||!l.includes(a.choice)||
      typeof a.confidence!=='number'||!Number.isFinite(a.confidence)||a.confidence<0||a.confidence>1)fail('PROVIDER_INVALID');
    const values=l.map(x=>a.probabilities[x]);
    if(values.some(x=>typeof x!=='number'||!Number.isFinite(x)||x<0||x>1))fail('PROVIDER_INVALID');
    let sum=values.reduce((a,b)=>a+b,0);
    if(Math.abs(sum-1)>0.001||sum<=0)fail('PROVIDER_INVALID');
    const maximum=Math.max(...values);
    if(maximum-a.probabilities[a.choice]>1e-6)fail('PROVIDER_INVALID');
    const probabilities={};l.forEach((x,i)=>probabilities[x]=values[i]/sum);
    // Canonical tie-breaking: lowest row-major position within tolerance of the true maximum.
    const selected=l.find(x=>Math.max(...Object.values(probabilities))-probabilities[x]<=1e-6);
    const usage=response.usage||{};
    const safeInt=x=>Number.isInteger(x)&&x>=0?x:null;
    return {model,choice:selected,api_choice:a.choice,probabilities,confidence:a.confidence,
      normalization_applied:sum!==1,input_tokens:safeInt(usage.input_tokens),output_tokens:safeInt(usage.output_tokens)};
  }
  function probabilityWeights(probabilities,orderedKeys) {
    const raw=orderedKeys.map(k=>probabilities[k]*1000000),w=raw.map(Math.floor);
    let left=1000000-w.reduce((a,b)=>a+b,0);
    if(left<0||left>orderedKeys.length)fail('BAD_PROBABILITY');
    const ranked=raw.map((v,i)=>({i,remainder:v-w[i]})).sort((a,b)=>b.remainder-a.remainder||a.i-b.i);
    for(let j=0;j<left;j++)w[ranked[j].i]++;
    return w;
  }
  function sample(probabilities,orderedKeys,roll) {
    if(!Number.isInteger(roll)||roll<0||roll>=1000000)fail('BAD_ROLL');
    const w=probabilityWeights(probabilities,orderedKeys);let sum=0;
    for(let i=0;i<w.length;i++){sum+=w[i];if(roll<sum)return orderedKeys[i];}
    fail('BAD_PROBABILITY');
  }
  function acceptsReply(active,reply) {
    return !!active && !active.local_only && active.waiting && reply && reply.status==='ready' &&
      reply.game_id===active.game_id && reply.ply===active.ply &&
      reply.position_hash===active.position_hash && reply.decision_key===active.decision_key &&
      active.legal_moves.includes(reply.move);
  }
  return {MODES,other,check,initial,coord,square,flips,legal,terminal,counts,winner,step,frontier,risk,
    evaluate,localMove,replay,identity,features,buildJevRequest,parseJev,probabilityWeights,sample,acceptsReply};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=CTReversi;
</script><script>
const R=CTReversi,canvas=document.querySelector('#screen'),ctx=canvas.getContext('2d');
let p,human='B',selected=-1,paused=false,gen=0,list=false,page=0,history=[],message='';
const rect=(x,y,w,h,fill)=>{ctx.fillStyle=fill;ctx.fillRect(x,y,w,h);};
const text=(s,x,y,size=20,fill='#17201c')=>{ctx.fillStyle=fill;ctx.font=size+'px system-ui';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(s,x,y);};
function button(x,y,w,h,label,on=true){ctx.fillStyle=on?'#245548':'#9ca99e';ctx.beginPath();ctx.roundRect(x,y,w,h,8);ctx.fill();text(label,x+w/2,y+h/2,16,'#fff');}
function draw(){
 ctx.clearRect(0,0,480,480);ctx.save();ctx.beginPath();ctx.arc(240,240,240,0,Math.PI*2);ctx.clip();rect(0,0,480,480,'#f2eadf');
 text(`REVERSI ${p.n}×${p.n}`,240,35,16);let c=R.counts(p);text(`黒 ${c.black} / 白 ${c.white}`,240,64,20);
 if(list){let ls=R.legal(p);text('置く場所を選ぶ',240,112,22);let a=ls.slice(page*4,page*4+4);
 a.forEach((v,i)=>button(i%2?250:130,i>=2?230:140,100,78,R.coord(p.n,v)));
 button(138,334,88,60,'前',page>0);button(254,334,88,60,'次',(page+1)*4<ls.length);button(190,400,100,48,'戻る');ctx.restore();return;}
 rect(84,84,312,312,'#245548');let cell=312/p.n;
 for(let i=0;i<p.n*p.n;i++){let x=84+(i%p.n)*cell,y=84+Math.floor(i/p.n)*cell;
  ctx.strokeStyle='#C7D3C8';ctx.lineWidth=1;ctx.strokeRect(x+.5,y+.5,cell,cell);
  if(p.cells[i]!=='.'){ctx.fillStyle=p.cells[i]==='B'?'#17201c':'#f9f5eb';ctx.beginPath();ctx.arc(x+cell/2,y+cell/2,cell*.37,0,Math.PI*2);ctx.fill();}
 }
 if(p.side===human&&!R.terminal(p)&&!paused)for(let i of R.legal(p)){let x=84+(i%p.n)*cell+cell/2,y=84+Math.floor(i/p.n)*cell+cell/2;ctx.fillStyle='#d7a94c';ctx.beginPath();ctx.arc(x,y,3,0,Math.PI*2);ctx.fill();}
 if(selected>=0){ctx.strokeStyle='#ffd46b';ctx.lineWidth=3;ctx.strokeRect(84+(selected%p.n)*cell+3,84+Math.floor(selected/p.n)*cell+3,cell-6,cell-6);}
 button(132,400,48,44,paused?'再開':'休止');button(188,402,104,52,'置く',selected>=0&&!paused);button(300,400,48,44,'候補',p.side===human&&!paused);
 if(paused){rect(126,184,228,100,'#f2eadf');text('一時停止',240,220,26);text('左下の再開で戻ります',240,255,16);}
 document.querySelector('#status').textContent=message;ctx.restore();
}
function apply(i,source){p=R.step(p,i);history.push(R.coord(p.n,i)+':'+source);selected=-1;draw();schedule();}
function schedule(){
 if(paused)return;
 if(R.terminal(p)){let win=R.winner(p);message=win==='D'?'引き分けです。':win===human?'あなたの勝ち！':'端末AIの勝ち。もう一局どうぞ。';draw();return;}
 let l=R.legal(p),ticket=gen,seq=p.ply;
 if(!l.length){message=(p.side===human?'あなた':'端末AI')+'はパスです。';draw();setTimeout(()=>{if(gen===ticket&&!paused&&p.ply===seq)apply(-1,'F');},700);return;}
 if(p.side!==human){message='端末AIが選んでいます。';draw();setTimeout(()=>{if(gen!==ticket||paused||p.ply!==seq)return;let q=R.legal(p);apply(q.length===1?q[0]:R.localMove(p),q.length===1?'F':'L');},250);}
 else{message='あなたは'+(human==='B'?'黒':'白')+'です。場所を選んで「置く」。';draw();}
}
function reset(){gen++;p=R.initial(Number(document.querySelector('#size').value));human=document.querySelector('#human').value;selected=-1;paused=false;list=false;page=0;history=[];schedule();}
function inside(x,y,r){return x>=r[0]&&x<r[0]+r[2]&&y>=r[1]&&y<r[1]+r[3];}
canvas.addEventListener('click',e=>{let b=canvas.getBoundingClientRect(),x=(e.clientX-b.left)*480/b.width,y=(e.clientY-b.top)*480/b.height;
 if(list){let ls=R.legal(p);for(let i=0;i<4;i++)if(inside(x,y,[i%2?250:130,i>=2?230:140,100,78])&&ls[page*4+i]!==undefined){selected=ls[page*4+i];list=false;message=R.coord(p.n,selected)+'を選択。「置く」で確定。';draw();return;}
 if(inside(x,y,[138,334,88,60])&&page>0)page--;
 if(inside(x,y,[254,334,88,60])&&(page+1)*4<ls.length)page++;
 if(inside(x,y,[190,400,100,48]))list=false;draw();return;}
 if(inside(x,y,[132,400,48,44])){gen++;paused=!paused;selected=-1;if(!paused)schedule();else draw();return;}
 if(paused||R.terminal(p)||p.side!==human)return;
 if(inside(x,y,[300,400,48,44])){list=true;page=0;draw();return;}
 if(inside(x,y,[188,402,104,52])&&selected>=0){apply(selected,'H');return;}
 if(x>=84&&x<396&&y>=84&&y<396){let i=Math.floor((y-84)/(312/p.n))*p.n+Math.floor((x-84)/(312/p.n));if(R.legal(p).includes(i)){selected=i;message=R.coord(p.n,i)+'を選択。'+R.flips(p,i).length+'枚返ります。';}else{selected=-1;message='そこには置けません。';}draw();}
});
document.querySelector('#new').addEventListener('click',reset);reset();
window.previewState=()=>({position:p,human,selected,paused,list,history:[...history]});
</script></html>
``````
<!-- REV_END -->

### ファイル：`results/browser.json`

<!-- REV_FILE results/browser.json sha256=098fb3626c075454d4b913480f380490f07d949328f508a33cf8cf6f2dbdde72 -->
``````json
{
  "status": "passed",
  "checks": [
    "6x6 select/confirm",
    "AI local reply",
    "pause",
    "8x8 candidate picker",
    "8x8 commit",
    "human white/AI opening",
    "no console page errors"
  ],
  "live_jev": false,
  "live_google": false,
  "hardware": false
}
``````
<!-- REV_END -->

### ファイル：`results/contracts.json`

<!-- REV_FILE results/contracts.json sha256=cafede4d592555b566e2da00fbaf9ca81d0cf1df119a4b4b3a67f8c69d04d601 -->
``````json
{
  "status": "passed",
  "test_groups": 29,
  "cdf_rolls": 1000000,
  "real_google_calls": 0,
  "real_jev_calls": 0
}
``````
<!-- REV_END -->

### ファイル：`results/core_verification.json`

<!-- REV_FILE results/core_verification.json sha256=3929a8baf4a80448a25381f15f99b1b9072dee779ec2dc60daae7d900c25ea72 -->
``````json
{
  "status": "passed",
  "cross_language_positions": 1301,
  "oracle_simulation": {
    "games": 120,
    "turns": 5572,
    "passes": 56
  },
  "perft_depth_1_to_5": {
    "6": [
      4,
      12,
      56,
      244,
      1364
    ],
    "8": [
      4,
      12,
      56,
      244,
      1396
    ]
  },
  "scope": "bounded regression / independent oracle, not exhaustive all Reversi positions, no hardware or Jev API"
}
``````
<!-- REV_END -->

### ファイル：`results/cpp_smoke.json`

<!-- REV_FILE results/cpp_smoke.json sha256=0dc9ef77e124f585557cb884c8255e8438526e42e29a0c41809be5d517b2e68d -->
``````json
{
  "games": 2000,
  "turns": 93013,
  "passes": 1054,
  "status": "passed"
}
``````
<!-- REV_END -->

### ファイル：`results/data.json`

<!-- REV_FILE results/data.json sha256=1bd7b315f64388bcb6c22deb8c86ccada500d01b5c468b85d3f8f8b98c5fdb47 -->
``````json
{
  "status": "passed",
  "safe_rectangles": 16,
  "ui_strings": 105,
  "tutorial_pages": 8,
  "api_actions": 4,
  "sheet_types": 3,
  "cell_centers_checked": 100,
  "physical_display": false
}
``````
<!-- REV_END -->

### ファイル：`results/host_run.json`

<!-- REV_FILE results/host_run.json sha256=00131dce487ab464053586f3e806ac4f91f169d3fc947eb1a8df16cad0032017 -->
``````json
{
  "status": "passed",
  "versions": {
    "python": "3.13.5",
    "g++": "g++ (Debian 14.2.0-19) 14.2.0",
    "node": "v22.16.0",
    "platform": "Linux-6.18.44-x86_64-with-glibc2.41"
  },
  "real_hardware": false,
  "real_google": false,
  "real_jev": false,
  "lvgl_compiled": false
}
``````
<!-- REV_END -->

### ファイル：`results/session.json`

<!-- REV_FILE results/session.json sha256=d73c8832b69eed9d4491c7bffc4e51f2c56d0a024fc956c9ef5f48e6d70cb888 -->
``````json
{
  "status": "passed",
  "corruption_and_truncation_tests": 84
}
``````
<!-- REV_END -->

### ファイル：`results/session_sanitized.json`

<!-- REV_FILE results/session_sanitized.json sha256=6412662df2a4ac16f07caf76e530454ef346ad1836301b4911f560cbeb0d403a -->
``````json
{"status":"passed","corruption_and_truncation_tests":84}
``````
<!-- REV_END -->

### ファイル：`src/lvgl8_board_example.hpp`

<!-- REV_FILE src/lvgl8_board_example.hpp sha256=5bba2f20bf07108852a9c50635df41141c04b83e00eb3eeb4e2e69f989aed2a9 -->
``````cpp
#pragma once
// LVGL 8 integration example. Not compiled against the user's LVGL/BSP here.
// All calls must be made on the existing LVGL thread or under its existing mutex.
#include <lvgl.h>
#include <array>
#include <cstdio>
#include "reversi_session.hpp"
namespace ct_rev {
struct UiPort {
    virtual ~UiPort()=default;
    virtual void select(int square,uint16_t expectedPly)=0;
    virtual void confirm(uint16_t expectedPly)=0;
    virtual void menu()=0;
    virtual void choices()=0;
};
class BoardView {
    struct Tag {BoardView* owner=nullptr;int value=0;};
    lv_obj_t* root_=nullptr;lv_obj_t* title_=nullptr;lv_obj_t* score_=nullptr;
    lv_obj_t* place_=nullptr;lv_obj_t* choices_=nullptr;
    std::array<lv_obj_t*,64> cells_{};std::array<lv_obj_t*,64> disks_{};
    std::array<lv_obj_t*,64> dots_{};std::array<Tag,67> tags_{};
    UiPort* port_=nullptr;uint8_t n_=6;uint16_t ply_=0;bool canPlay_=false;
    static void event(lv_event_t* e){
        auto* tag=static_cast<Tag*>(lv_event_get_user_data(e));
        if(!tag||!tag->owner||lv_event_get_code(e)!=LV_EVENT_CLICKED)return;
        auto* s=tag->owner;
        if(!s->port_)return;
        if(tag->value==64){s->port_->menu();return;}
        if(!s->canPlay_)return;
        if(tag->value==65)s->port_->confirm(s->ply_);
        else if(tag->value==66)s->port_->choices();
        else s->port_->select(tag->value,s->ply_);
    }
    static void flat(lv_obj_t* p){lv_obj_set_style_pad_all(p,0,0);lv_obj_set_style_border_width(p,0,0);lv_obj_set_style_radius(p,0,0);lv_obj_clear_flag(p,LV_OBJ_FLAG_SCROLLABLE);}
    lv_obj_t* control(int tag,int x,int y,int w,int h,const char* text,const lv_font_t* font){
        auto* b=lv_btn_create(root_);lv_obj_set_pos(b,x,y);lv_obj_set_size(b,w,h);
        lv_obj_set_style_bg_color(b,lv_color_hex(0x245548),0);lv_obj_clear_flag(b,LV_OBJ_FLAG_SCROLLABLE);
        tags_[tag]={this,tag};lv_obj_add_event_cb(b,event,LV_EVENT_CLICKED,&tags_[tag]);
        auto* l=lv_label_create(b);lv_label_set_text(l,text);lv_obj_set_style_text_font(l,font,0);lv_obj_center(l);
        lv_obj_clear_flag(l,LV_OBJ_FLAG_CLICKABLE);return b;
    }
public:
    // Do not copy an object whose callback user_data points into its member arrays.
    BoardView()=default;BoardView(const BoardView&)=delete;BoardView& operator=(const BoardView&)=delete;
    void destroy(){canPlay_=false;port_=nullptr;if(root_){lv_obj_del(root_);root_=nullptr;}}
    void create(lv_obj_t* parent,uint8_t n,UiPort& port,const lv_font_t* textFont=LV_FONT_DEFAULT){
        destroy();n_=n;port_=&port;
        if(n!=6&&n!=8){port_=nullptr;return;}
        root_=lv_obj_create(parent);flat(root_);lv_obj_set_pos(root_,0,0);lv_obj_set_size(root_,480,480);
        lv_obj_set_style_bg_color(root_,lv_color_hex(0xF2EADF),0);
        title_=lv_label_create(root_);lv_obj_set_pos(title_,160,24);lv_obj_set_size(title_,160,22);
        lv_obj_set_style_text_align(title_,LV_TEXT_ALIGN_CENTER,0);
        score_=lv_label_create(root_);lv_obj_set_pos(score_,132,50);lv_obj_set_size(score_,216,28);
        lv_obj_set_style_text_font(score_,textFont,0);lv_obj_set_style_text_align(score_,LV_TEXT_ALIGN_CENTER,0);
        const int u=312/n;
        for(int i=0;i<n*n;i++){
            cells_[i]=lv_btn_create(root_);flat(cells_[i]);lv_obj_set_pos(cells_[i],84+(i%n)*u,84+(i/n)*u);lv_obj_set_size(cells_[i],u,u);
            lv_obj_set_style_bg_color(cells_[i],lv_color_hex(0x245548),0);
            lv_obj_set_style_border_width(cells_[i],1,0);lv_obj_set_style_border_color(cells_[i],lv_color_hex(0xC7D3C8),0);
            tags_[i]={this,i};lv_obj_add_event_cb(cells_[i],event,LV_EVENT_CLICKED,&tags_[i]);
            disks_[i]=lv_obj_create(cells_[i]);flat(disks_[i]);lv_obj_set_size(disks_[i],u*3/4,u*3/4);
            lv_obj_set_style_radius(disks_[i],LV_RADIUS_CIRCLE,0);lv_obj_center(disks_[i]);lv_obj_clear_flag(disks_[i],LV_OBJ_FLAG_CLICKABLE);
            dots_[i]=lv_obj_create(cells_[i]);flat(dots_[i]);lv_obj_set_size(dots_[i],6,6);lv_obj_set_style_radius(dots_[i],LV_RADIUS_CIRCLE,0);
            lv_obj_set_style_bg_color(dots_[i],lv_color_hex(0xD7A94C),0);lv_obj_center(dots_[i]);lv_obj_clear_flag(dots_[i],LV_OBJ_FLAG_CLICKABLE);
        }
        control(64,132,400,48,44,"操作",textFont);
        place_=control(65,188,402,104,52,"置く",textFont);
        choices_=control(66,300,400,48,44,"候補",textFont);
    }
    void render(const Session& s,int selected,bool enabled){
        if(!root_||s.pos.n!=n_)return;
        ply_=s.pos.ply;canPlay_=enabled&&s.closure==Closure::Active&&s.pos.side==s.human;
        char line[80];std::snprintf(line,sizeof(line),"REVERSI %ux%u",unsigned(n_),unsigned(n_));lv_label_set_text(title_,line);
        auto count=counts(s.pos);std::snprintf(line,sizeof(line),"B %d / W %d",count.black,count.white);lv_label_set_text(score_,line);
        for(int i=0;i<n_*n_;i++){
            bool empty=s.pos.board[i]==Cell::Empty,legalCell=captures(s.pos,i,s.pos.side)!=0;
            if(empty)lv_obj_add_flag(disks_[i],LV_OBJ_FLAG_HIDDEN);else{
                lv_obj_clear_flag(disks_[i],LV_OBJ_FLAG_HIDDEN);
                lv_obj_set_style_bg_color(disks_[i],lv_color_hex(s.pos.board[i]==Cell::Black?0x17201C:0xF9F5EB),0);
            }
            if(canPlay_&&legalCell)lv_obj_clear_flag(dots_[i],LV_OBJ_FLAG_HIDDEN);else lv_obj_add_flag(dots_[i],LV_OBJ_FLAG_HIDDEN);
            lv_obj_set_style_border_width(cells_[i],selected==i?3:1,0);
            lv_obj_set_style_border_color(cells_[i],lv_color_hex(selected==i?0xD7A94C:0xC7D3C8),0);
        }
        if(canPlay_&&selected>=0&&captures(s.pos,selected,s.pos.side))lv_obj_clear_state(place_,LV_STATE_DISABLED);
        else lv_obj_add_state(place_,LV_STATE_DISABLED);
        if(canPlay_)lv_obj_clear_state(choices_,LV_STATE_DISABLED);else lv_obj_add_state(choices_,LV_STATE_DISABLED);
    }
};
} // namespace ct_rev
``````
<!-- REV_END -->

### ファイル：`src/reversi_core.hpp`

<!-- REV_FILE src/reversi_core.hpp sha256=dd688307a43b50a45e0a1c9a2f1bfad1da23be8f1dd7a39b32ef5bbd86f141a9 -->
``````cpp
#pragma once
// COFFEE TIME reference core. No LVGL, network, global mutable state or heap allocation.
#include <array>
#include <cstdint>
#include <cstddef>
#include <cstring>

namespace ct_rev {
constexpr int PASS = -1;
enum class Cell : uint8_t { Empty=0, Black=1, White=2 };
enum class Error : uint8_t { Ok, BadState, OutOfRange, Occupied, NoCapture, PassForbidden, Finished };
inline Cell other(Cell c) { return c==Cell::Black ? Cell::White : Cell::Black; }
inline char symbol(Cell c) { return c==Cell::Black?'B':c==Cell::White?'W':'.'; }
struct Position {
    uint8_t n=6;
    Cell side=Cell::Black;
    uint16_t ply=0;
    std::array<Cell,64> board{};
};
struct MoveList { std::array<uint8_t,64> cells{}; uint8_t count=0; };
struct Transition { Error error=Error::Ok; uint64_t flips=0; uint8_t flipped=0; bool passed=false; bool terminal=false; };
struct Counts { int black=0, white=0, empty=0; };
inline bool valid(const Position& p) {
    if ((p.n!=6 && p.n!=8) || (p.side!=Cell::Black && p.side!=Cell::White) || p.ply>128) return false;
    for (int i=0;i<64;i++) {
        if (static_cast<unsigned>(p.board[i])>2) return false;
        if (i>=p.n*p.n && p.board[i]!=Cell::Empty) return false;
    }
    return true; // Reachability must be checked by replay, not this structural check.
}
inline bool initial(uint8_t n, Position& out) {
    if(n!=6 && n!=8) return false;
    Position p; p.n=n;
    const int a=n/2-1,b=n/2;
    p.board[a*n+a]=Cell::White; p.board[b*n+b]=Cell::White;
    p.board[a*n+b]=Cell::Black; p.board[b*n+a]=Cell::Black;
    out=p; return true;
}
inline uint64_t captures(const Position& p,int square,Cell color) {
    if(!valid(p) || (color!=Cell::Black && color!=Cell::White) || square<0 || square>=p.n*p.n || p.board[square]!=Cell::Empty) return 0;
    uint64_t total=0;
    for(int dy=-1;dy<=1;dy++) for(int dx=-1;dx<=1;dx++) {
        if(!dx&&!dy) continue;
        int r=square/p.n+dy, c=square%p.n+dx;
        uint64_t ray=0;
        while(r>=0 && r<p.n && c>=0 && c<p.n && p.board[r*p.n+c]==other(color)) {
            ray |= uint64_t(1) << (r*p.n+c); r+=dy; c+=dx;
        }
        if(ray && r>=0 && r<p.n && c>=0 && c<p.n && p.board[r*p.n+c]==color) total|=ray;
    }
    return total;
}
inline MoveList legal(const Position& p,Cell color) {
    MoveList out;
    if(!valid(p)) return out;
    for(int i=0;i<p.n*p.n;i++) if(captures(p,i,color)) out.cells[out.count++]=static_cast<uint8_t>(i);
    return out;
}
inline bool terminal(const Position& p) {
    return valid(p) && legal(p,Cell::Black).count==0 && legal(p,Cell::White).count==0;
}
inline Counts counts(const Position& p) {
    Counts out;
    if(!valid(p)) return out;
    for(int i=0;i<p.n*p.n;i++) {
        if(p.board[i]==Cell::Black) ++out.black;
        else if(p.board[i]==Cell::White) ++out.white;
        else ++out.empty;
    }
    return out;
}
inline char winner(const Position& p) {
    if(!terminal(p)) return '-';
    const auto x=counts(p); return x.black>x.white?'B':x.white>x.black?'W':'D';
}
inline Transition apply(Position& p,int move) {
    Transition t;
    if(!valid(p) || p.ply>=128) {t.error=Error::BadState;return t;}
    if(terminal(p)) {t.error=Error::Finished;return t;}
    Position next=p;
    if(move==PASS) {
        if(legal(p,p.side).count) {t.error=Error::PassForbidden;return t;}
        t.passed=true;
    } else {
        if(move<0 || move>=p.n*p.n) {t.error=Error::OutOfRange;return t;}
        if(p.board[move]!=Cell::Empty) {t.error=Error::Occupied;return t;}
        t.flips=captures(p,move,p.side);
        if(!t.flips) {t.error=Error::NoCapture;return t;}
        next.board[move]=p.side;
        for(int i=0;i<p.n*p.n;i++) if(t.flips & (uint64_t(1)<<i)) {next.board[i]=p.side;++t.flipped;}
    }
    next.side=other(p.side); ++next.ply;
    t.terminal=terminal(next); p=next; return t;
}
inline int frontier(const Position& p,Cell color) {
    int count=0;
    for(int r=0;r<p.n;r++) for(int c=0;c<p.n;c++) if(p.board[r*p.n+c]==color) {
        bool near=false;
        for(int dy=-1;dy<=1;dy++) for(int dx=-1;dx<=1;dx++) {
            int y=r+dy,x=c+dx;
            if((dx||dy)&&y>=0&&y<p.n&&x>=0&&x<p.n&&p.board[y*p.n+x]==Cell::Empty) near=true;
        }
        if(near) ++count;
    }
    return count;
}
inline int risk(const Position& p,Cell color,bool diagonal) {
    int total=0, n=p.n;
    for(int r : {0,n-1}) for(int c : {0,n-1}) if(p.board[r*n+c]==Cell::Empty) {
        int ir=r==0?1:n-2, ic=c==0?1:n-2;
        if(diagonal) total+=(p.board[ir*n+ic]==color);
        else total+=(p.board[ir*n+c]==color)+(p.board[r*n+ic]==color);
    }
    return total;
}
inline int evaluate(const Position& p,Cell root) {
    const Cell opp=other(root); const auto x=counts(p);
    int diff=(root==Cell::Black?x.black-x.white:x.white-x.black);
    if(terminal(p)) return diff==0?0:(diff>0?100000:-100000)+diff;
    int corners=0;
    for(int r : {0,int(p.n)-1}) for(int c : {0,int(p.n)-1}) {
        corners+=(p.board[r*p.n+c]==root); corners-=(p.board[r*p.n+c]==opp);
    }
    int w= x.empty>p.n*p.n/2 ? -1 : x.empty>p.n*p.n/4 ? 1 : 6;
    return 120*corners+8*(int(legal(p,root).count)-int(legal(p,opp).count))
        -4*(frontier(p,root)-frontier(p,opp))
        -25*(risk(p,root,true)-risk(p,opp,true))
        -10*(risk(p,root,false)-risk(p,opp,false))+w*diff;
}
inline int local_move(const Position& p) {
    const auto moves=legal(p,p.side);
    if(!moves.count) return PASS;
    int best=moves.cells[0], score=-200000;
    for(int k=0;k<moves.count;k++) {
        Position child=p;
        if(apply(child,moves.cells[k]).error!=Error::Ok) return PASS;
        int s=evaluate(child,p.side);
        if(s>score) {score=s;best=moves.cells[k];}
    }
    return best; // Equal evaluations: ascending row-major square index.
}
inline int hit_test(int x,int y,uint8_t n) {
    if((n!=6&&n!=8)||x<84||x>=396||y<84||y>=396) return -1;
    int unit=312/n; return ((y-84)/unit)*n+(x-84)/unit;
}
inline uint32_t crc32(const uint8_t* data,size_t size) {
    uint32_t crc=0xffffffffu;
    for(size_t i=0;i<size;i++) {
        crc^=data[i];
        for(int j=0;j<8;j++) crc=(crc>>1)^(0xedb88320u & (0u-(crc&1u)));
    }
    return crc^0xffffffffu;
}
} // namespace ct_rev
``````
<!-- REV_END -->

### ファイル：`src/reversi_session.hpp`

<!-- REV_FILE src/reversi_session.hpp sha256=e52380f9690963b6157678117a844298c26079e34ba33f80f04e8acf8226798b -->
``````cpp
#pragma once
#include "reversi_core.hpp"
namespace ct_rev {
enum class Mode:uint8_t {Jev=0,Pro=1,Casual=2,Local=3};
enum class Source:uint8_t {Human=0,Jev=1,Local=2,Forced=3};
enum class Closure:uint8_t {Active=0,Completed=1,Resigned=2,Aborted=3};
struct Event {uint8_t move=255; Source source=Source::Forced;};
struct Session {
    Position pos;
    Cell human=Cell::Black;
    Mode mode=Mode::Jev;
    Closure closure=Closure::Active;
    bool localOnly=false;
    uint32_t generation=1;
    std::array<uint8_t,16> id{};
    std::array<Event,128> history{};
    uint16_t count=0;
};
inline bool start(Session& s,uint8_t n,Cell human,Mode mode,const std::array<uint8_t,16>& id) {
    if((human!=Cell::Black&&human!=Cell::White)||unsigned(mode)>3) return false;
    Session v; if(!initial(n,v.pos))return false;
    v.human=human;v.mode=mode;v.localOnly=mode==Mode::Local;v.id=id;s=v;return true;
}
inline bool commit(Session& s,int move,Source source,uint16_t expectedPly) {
    if(s.closure!=Closure::Active||s.count>=128||s.generation==0xffffffffu||s.pos.ply!=expectedPly||s.count!=expectedPly) return false;
    const auto lm=legal(s.pos,s.pos.side);
    if(move==PASS) {if(source!=Source::Forced)return false;}
    else if(s.pos.side==s.human) {if(source!=Source::Human)return false;}
    else if(lm.count==1) {if(source!=Source::Forced)return false;}
    else {
        if(source!=Source::Jev&&source!=Source::Local)return false;
        if(source==Source::Jev&&s.localOnly)return false;
    }
    Session next=s;
    if(apply(next.pos,move).error!=Error::Ok)return false;
    next.history[next.count++]={uint8_t(move==PASS?255:move),source};
    if(source==Source::Local)next.localOnly=true;
    if(terminal(next.pos))next.closure=Closure::Completed;
    ++next.generation;s=next;return true;
}
inline bool freezeLocal(Session& s) {
    if(s.closure!=Closure::Active||s.generation==0xffffffffu)return false;
    if(!s.localOnly){s.localOnly=true;++s.generation;}return true;
}
inline bool close(Session& s,Closure reason) {
    if(s.closure!=Closure::Active||s.generation==0xffffffffu||
       (reason!=Closure::Resigned&&reason!=Closure::Aborted))return false;
    s.closure=reason;++s.generation;return true;
}
constexpr size_t SNAPSHOT_MAX=294;
inline void put32(uint8_t* p,uint32_t v){for(int i=0;i<4;i++)p[i]=uint8_t(v>>(8*i));}
inline uint32_t get32(const uint8_t* p){uint32_t v=0;for(int i=0;i<4;i++)v|=uint32_t(p[i])<<(8*i);return v;}
inline size_t encode(const Session& s,std::array<uint8_t,SNAPSHOT_MAX>& out) {
    if(s.count>128)return 0;
    out.fill(0);out[0]='R';out[1]='E';out[2]='V';out[3]='1';out[4]=1;
    out[5]=s.pos.n;out[6]=uint8_t(s.human);out[7]=uint8_t(s.mode);out[8]=uint8_t(s.closure);out[9]=s.localOnly?1:0;
    put32(out.data()+12,s.generation);
    std::memcpy(out.data()+16,s.id.data(),16);out[32]=uint8_t(s.count);out[33]=uint8_t(s.count>>8);
    for(int i=0;i<s.count;i++){out[34+2*i]=s.history[i].move;out[35+2*i]=uint8_t(s.history[i].source);}
    size_t bytes=38+2*s.count;put32(out.data()+bytes-4,crc32(out.data(),bytes-4));return bytes;
}
inline bool decode(const uint8_t* p,size_t bytes,Session& out) {
    if(!p||bytes<38||bytes>SNAPSHOT_MAX||std::memcmp(p,"REV1",4)||p[4]!=1||p[9]>1||p[10]||p[11])return false;
    if(get32(p+bytes-4)!=crc32(p,bytes-4)||get32(p+12)==0||p[8]>3)return false;
    uint16_t count=uint16_t(p[32])|(uint16_t(p[33])<<8);if(count>128||bytes!=size_t(38+2*count))return false;
    std::array<uint8_t,16> id;std::memcpy(id.data(),p+16,16);
    Session s;if(!start(s,p[5],Cell(p[6]),Mode(p[7]),id))return false;
    for(int i=0;i<count;i++){
        uint8_t m=p[34+2*i],source=p[35+2*i];if(source>3)return false;
        if(!commit(s,m==255?PASS:int(m),Source(source),s.pos.ply))return false;
    }
    const auto closure=Closure(p[8]);
    if(terminal(s.pos)!=(closure==Closure::Completed))return false;
    if(s.localOnly&&!p[9])return false;
    if(get32(p+12)<s.generation)return false;
    s.closure=closure;s.localOnly=p[9]!=0;s.generation=get32(p+12);out=s;return true;
}
} // namespace ct_rev
``````
<!-- REV_END -->

### ファイル：`tests/browser_check.py`

<!-- REV_FILE tests/browser_check.py sha256=c536700633abe2fc9eaac1a5f8db7ac812c6db4fab494522ad767c67298f4065 -->
``````python
from playwright.sync_api import sync_playwright
from pathlib import Path
import json,shutil
root=Path(__file__).resolve().parents[1]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path=shutil.which('chromium'),args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1000,'height':900})
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content((root/'preview.html').read_text(),wait_until='load');page.wait_for_timeout(300)
 box=page.locator('canvas').bounding_box()
 def click(x,y):page.mouse.click(box['x']+x*box['width']/480,box['y']+y*box['height']/480)
 click(84+2*52+26,84+1*52+26)
 assert page.evaluate('previewState().selected')==8
 assert page.evaluate('previewState().position.ply')==0
 click(240,428);page.wait_for_timeout(600)
 assert page.evaluate('previewState().position.ply')==2
 click(156,422);assert page.evaluate('previewState().paused')
 page.screenshot(path=str(root/'results/preview_6x6.png'),full_page=True)
 page.select_option('#size','8');page.click('#new');page.wait_for_timeout(100)
 assert page.evaluate('previewState().position.n')==8
 click(324,422);assert page.evaluate('previewState().list')
 click(180,179);assert page.evaluate('previewState().selected')==19
 click(240,428);page.wait_for_timeout(600)
 assert page.evaluate('previewState().position.ply')==2
 page.screenshot(path=str(root/'results/preview_8x8.png'),full_page=True)
 page.select_option('#human','W');page.click('#new');page.wait_for_timeout(650)
 assert page.evaluate('previewState().position.ply')==1
 assert page.evaluate('previewState().position.side')=='W'
 assert not errors,errors
 browser.close()
(root/'results/browser.json').write_text(json.dumps({'status':'passed','checks':['6x6 select/confirm','AI local reply','pause','8x8 candidate picker','8x8 commit','human white/AI opening','no console page errors'],'live_jev':False,'live_google':False,'hardware':False},indent=2)+'\n')
print('browser passed')
``````
<!-- REV_END -->

### ファイル：`tests/core_cli.cpp`

<!-- REV_FILE tests/core_cli.cpp sha256=121ee71a02acc9b5737639ba1d142cf8e697f908683fb4459d1d5fcf31c7dd4c -->
``````cpp
#include "../src/reversi_core.hpp"
#include <iostream>
#include <string>
using namespace ct_rev;
int main() {
    int n=0,side=0,ply=0,m=0; std::string text;
    while(std::cin>>n>>side>>ply>>text>>m) {
        Position p; p.n=uint8_t(n);p.side=Cell(side);p.ply=uint16_t(ply);
        if(n!=6&&n!=8) return 3;
        if(text.size()!=size_t(n*n)) return 4;
        for(int i=0;i<n*n;i++) {if(text[i]!='.'&&text[i]!='B'&&text[i]!='W') return 5; p.board[i]=text[i]=='B'?Cell::Black:text[i]=='W'?Cell::White:Cell::Empty;}
        auto lm=legal(p,p.side); uint64_t mask=0;
        for(int k=0;k<lm.count;k++) mask |= uint64_t(1)<<lm.cells[k];
        int local=local_move(p); uint64_t flip=captures(p,m,p.side);
        auto t=apply(p,m); auto cnt=counts(p);
        std::cout<<mask<<' '<<flip<<' '<<local<<' '<<int(t.error)<<' '<<int(p.side)<<' '<<p.ply<<' ';
        for(int i=0;i<n*n;i++) std::cout<<symbol(p.board[i]);
        std::cout<<' '<<terminal(p)<<' '<<winner(p)<<' '<<cnt.black<<' '<<cnt.white<<' '<<cnt.empty<<'\n';
    }
}
``````
<!-- REV_END -->

### ファイル：`tests/js_cli.js`

<!-- REV_FILE tests/js_cli.js sha256=d985e9e10b96225b64e8e8ec64a4c6bafa2a7f822594aba61b1e1b9281e71f02 -->
``````javascript
const R=require('../gas/reversi_shared.js');
const fs=require('fs');
const lines=fs.readFileSync(0,'utf8').trim().split('\n');
for(const line of lines) {
  if(!line)continue;
  const {n,side,cells,ply,move}=JSON.parse(line),p={n,side,cells,ply};
  let next=null,error=null;
  try{next=R.step(p,move);}catch(e){error=e.message;}
  console.log(JSON.stringify({legal:R.legal(p),flips:R.flips(p,move),local:R.localMove(p),next,error,
    terminal:next?R.terminal(next):R.terminal(p),winner:next?R.winner(next):R.winner(p)}));
}
``````
<!-- REV_END -->

### ファイル：`tests/session_test.cpp`

<!-- REV_FILE tests/session_test.cpp sha256=14c5111e10c795143eecebd77eeff472732e50dbbde03e7363fb7bda104c30b4 -->
``````cpp
#include "../src/reversi_session.hpp"
#include <cassert>
#include <iostream>
using namespace ct_rev;
int main(){
    std::array<uint8_t,16> id{};id[0]=1;Session s;assert(start(s,6,Cell::Black,Mode::Jev,id));
     assert(!commit(s,8,Source::Jev,0));assert(s.count==0);
    assert(commit(s,8,Source::Human,0));assert(!commit(s,8,Source::Human,0));
    auto l=legal(s.pos,s.pos.side);assert(l.count>1);
    assert(commit(s,l.cells[0],Source::Jev,1));
    std::array<uint8_t,SNAPSHOT_MAX> bytes;size_t len=encode(s,bytes);Session copy;
    assert(decode(bytes.data(),len,copy));assert(copy.pos.board==s.pos.board&&copy.pos.side==s.pos.side);
    size_t corruption=0;
    for(size_t j=0;j<len;j++){auto b=bytes;b[j]^=1;assert(!decode(b.data(),len,copy));++corruption;}
    for(size_t j=0;j<len;j++){assert(!decode(bytes.data(),j,copy));++corruption;}
    assert(freezeLocal(s));assert(s.localOnly);
    while(!terminal(s.pos)){
        l=legal(s.pos,s.pos.side);int m=l.count?local_move(s.pos):PASS;
        Source source=m==PASS?Source::Forced:s.pos.side==s.human?Source::Human:l.count==1?Source::Forced:Source::Local;
        assert(commit(s,m,source,s.count));
    }
    assert(s.closure==Closure::Completed);len=encode(s,bytes);assert(decode(bytes.data(),len,copy));
    assert(!close(s,Closure::Resigned));
    assert(start(s,8,Cell::White,Mode::Local,id));assert(s.localOnly);
    assert(close(s,Closure::Aborted));len=encode(s,bytes);assert(decode(bytes.data(),len,copy));
    assert(copy.closure==Closure::Aborted);
    std::cout<<"{\"status\":\"passed\",\"corruption_and_truncation_tests\":"<<corruption<<"}\n";
}
``````
<!-- REV_END -->

### ファイル：`tests/smoke.cpp`

<!-- REV_FILE tests/smoke.cpp sha256=451db9e51337b2554d37cac55c78ffb2b684ce3dc4532e6505f06384c3854d07 -->
``````cpp
#include "../src/reversi_core.hpp"
#include <cassert>
#include <iostream>
#include <cstdint>
using namespace ct_rev;
int main() {
    uint32_t rng=1234567; uint64_t turns=0, passes=0;
    for(int n : {6,8}) {
        for(int g=0;g<1000;g++) {
            Position p; assert(initial(uint8_t(n),p));
            int moves=0;
            while(!terminal(p)) {
                auto l=legal(p,p.side); rng=rng*1664525u+1013904223u;
                int m=l.count?l.cells[rng%l.count]:PASS;
                auto before=counts(p); auto t=apply(p,m); assert(t.error==Error::Ok);
                auto after=counts(p); assert(before.empty-after.empty==(m==PASS?0:1));
                assert(++moves<=128); ++turns; if(m==PASS) ++passes;
            }
            auto q=p; assert(apply(q,PASS).error==Error::Finished);
        }
    }
    assert(crc32(reinterpret_cast<const uint8_t*>("123456789"),9)==0xcbf43926u);
    for(int n:{6,8}) for(int r=0;r<n;r++) for(int c=0;c<n;c++)
        assert(hit_test(84+c*(312/n)+(312/n)/2,84+r*(312/n)+(312/n)/2,n)==r*n+c);
    std::cout<<"{\"games\":2000,\"turns\":"<<turns<<",\"passes\":"<<passes<<",\"status\":\"passed\"}\n";
}
``````
<!-- REV_END -->

### ファイル：`tests/test_contract.js`

<!-- REV_FILE tests/test_contract.js sha256=673cc9cc1ec2d9463cd42a93c76412ebd5228ad7b452ffb1268c866fedb0224d -->
``````javascript
'use strict';
const R=require('../gas/reversi_shared.js'),D=require('../gas/decision_machine.js');
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
let groups=0;const test=(name,f)=>{f();groups++;};
const config={game_id:'a'.repeat(32),n:6,human:'W',mode:'jev',history:[]};
const p=R.replay(config),keys=R.legal(p).map(i=>R.coord(6,i)),model='jev-1.13.0';
const good=()=>({model,answers:{move:{type:'choice',choice:keys[0],probabilities:Object.fromEntries(keys.map(k=>[k,.25])),confidence:0}},usage:{input_tokens:101,output_tokens:0}});
test('initial legal sets',()=>assert.deepEqual(keys,['C2','B3','E4','D5']));
test('request contains only legal choices',()=>assert.deepEqual(Object.keys(R.buildJevRequest(config,model).questions.move.criteria),keys));
test('no device/user/secret in state',()=>{
 const text=JSON.stringify(R.buildJevRequest(config,model));
 for(const bad of ['api_key','player_id','game_id','device_id','history'])assert(!text.includes(bad));
});
test('pro exact feature schema',()=>{
 let q=R.buildJevRequest({...config,mode:'jev_pro'},model);
 assert.equal(typeof q.questions.move.criteria.C2.flipped,'number');
 assert.equal(q.questions.move.criteria.C2.flipped,1);
});
test('local no request',()=>assert.throws(()=>R.buildJevRequest({...config,mode:'local'},model),/LOCAL_ONLY/));
test('human turn no request',()=>assert.throws(()=>R.buildJevRequest({...config,human:'B'},model),/NO_DECISION_REQUIRED/));
test('valid probability',()=>assert.equal(R.parseJev(good(),p,model).choice,keys[0]));
test('wrong model',()=>assert.throws(()=>R.parseJev({...good(),model:'jev-other'},p,model)));
for(const [name,mutate] of [
 ['missing',x=>delete x.answers.move.probabilities[keys[0]]],
 ['extra',x=>x.answers.move.probabilities.A1=0],
 ['negative',x=>x.answers.move.probabilities[keys[0]]=-1],
 ['nan',x=>x.answers.move.probabilities[keys[0]]=NaN],
 ['infinity',x=>x.answers.move.probabilities[keys[0]]=Infinity],
 ['string',x=>x.answers.move.probabilities[keys[0]]='0.25'],
 ['bad sum',x=>x.answers.move.probabilities[keys[0]]=.9],
 ['bad choice',x=>x.answers.move.choice='PASS'],
 ['bad confidence',x=>x.answers.move.confidence=1.1],
 ['nonargmax',x=>{x.answers.move.probabilities[keys[0]]=.1;x.answers.move.probabilities[keys[1]]=.4;}]
])test(name,()=>{const x=good();mutate(x);assert.throws(()=>R.parseJev(x,p,model));});
test('rounding only normalization',()=>{let x=good();x.answers.move.probabilities[keys[0]]+=.0001;assert(R.parseJev(x,p,model).normalization_applied);});
test('CDF exact weights',()=>{
 const w=R.probabilityWeights({a:.5,b:.3,c:.2},['a','b','c']);assert.deepEqual(w,[500000,300000,200000]);
 const observed={a:0,b:0,c:0};for(let r=0;r<1000000;r++)observed[R.sample({a:.5,b:.3,c:.2},['a','b','c'],r)]++;
 assert.deepEqual(observed,{a:500000,b:300000,c:200000});
});
test('CDF zero mass',()=>assert.equal(R.sample({a:0,b:1},['a','b'],0),'b'));
test('identity no timestamp',()=>assert.equal(R.identity(config),R.identity({...config,time:555})));
test('role/source validation',()=>assert.throws(()=>R.replay({...config,history:['C2:H']}),/BAD_SOURCE/));
test('no provider return after fallback',()=>{
 let c={...config,history:['C2:L']};let p=R.replay(c),humanMove=R.coord(6,R.legal(p)[0]);
 c.history.push(humanMove+':H');p=R.replay(c);
 c.history.push(R.coord(6,R.legal(p)[0])+':J');assert.throws(()=>R.replay(c),/PROVIDER_SWITCH_BACK/);
});
test('immutable lease',()=>{
 let a=D.reserve(null,{position_hash:'h',identity:'i'},100,'g');assert(a.call_provider);
 let b=D.reserve(a.record,{position_hash:'h',identity:'i'},101,'g2');assert(!b.call_provider);
 assert.throws(()=>D.reserve(a.record,{position_hash:'x',identity:'i'},101,'g2'),/STATE_CONFLICT/);
});
test('late answer rejected',()=>{
 let a=D.reserve(null,{position_hash:'h',identity:'i'},0,'g').record;
 assert(!D.finalize(a,'g',20001,{move:'C2'}).accepted);
 assert(!D.finalize(a,'bad',1,{move:'C2'}).accepted);
});
test('no reroll after ready',()=>{
 let a=D.reserve(null,{position_hash:'h',identity:'i'},0,'g').record;
 let b=D.finalize(a,'g',10,{move:'C2'}).record;
 assert(!D.finalize(b,'g',11,{move:'D5'}).accepted);
 assert.equal(D.reserve(b,{position_hash:'h',identity:'i'},12,'g2').record.answer.move,'C2');
});
test('reply fencing',()=>{
 let active={local_only:false,waiting:true,game_id:'g',ply:1,position_hash:'h',decision_key:'d',legal_moves:['C2']};
 let reply={status:'ready',game_id:'g',ply:1,position_hash:'h',decision_key:'d',move:'C2'};
 assert(R.acceptsReply(active,reply));
 for(const change of [{game_id:'old'},{ply:2},{position_hash:'x'},{move:'A1'},{decision_key:'other'}])assert(!R.acceptsReply(active,{...reply,...change}));
 assert(!R.acceptsReply({...active,local_only:true},reply));
});
test('GAS connector mocked only',()=>{
 let called=0,opts=null;
 let ctx={CTReversi:R,Date,JSON,UrlFetchApp:{fetch:(url,o)=>{called++;opts=o;assert(url==='https://api.typesafe.ai/v1/systemone');return{getResponseCode:()=>200,getContentText:()=>JSON.stringify(good())};}}};
 vm.createContext(ctx);vm.runInContext(fs.readFileSync(__dirname+'/../gas/provider_adapter.gs','utf8'),ctx);
 let answer=ctx.revCallProvider(config,model,'TEST-NOT-A-KEY');assert(answer.ok);assert.equal(called,1);
 assert.equal(opts.timeoutSeconds,8);assert.equal(opts.followRedirects,false);assert.equal(opts.validateHttpsCertificates,true);
 assert.equal(ctx.revCallProvider(config,model,'').ok,false);assert.equal(called,1);
});
const report={status:'passed',test_groups:groups,cdf_rolls:1000000,real_google_calls:0,real_jev_calls:0};
fs.writeFileSync(__dirname+'/../results/contracts.json',JSON.stringify(report,null,2)+'\n');console.log(report);
``````
<!-- REV_END -->

### ファイル：`tests/test_data.py`

<!-- REV_FILE tests/test_data.py sha256=f51f9510e944dd310bcd99a24723aba15d61c12740db9749b572bc6606c69c57 -->
``````python
"""Data/schema/layout consistency. Does not verify physical glass or real font glyphs."""
from pathlib import Path
import json,math
root=Path(__file__).resolve().parents[1]
load=lambda n:json.loads((root/'data'/n).read_text())
rules=load('rules.json');layout=load('layout.json');content=load('content.ja.json');api=load('api_contract.json');sheets=load('sheets_schema.json');tutorial=load('tutorial.ja.json')
assert rules['sizes']==[6,8] and rules['menu_slot']==5
assert rules['max_events']==128 and rules['game_id']=='jev_reversi'
assert set(api['actions'])=={'device.hello','decision.prepare','decision.get','result.put'}
assert len(api['errors'])==len(set(api['errors']))
# Recursive rectangle validation: every x/y/w/h rectangle lives inside design safe circle.
rects=[]
def walk(x,path=''):
 if isinstance(x,dict):
  if all(k in x for k in ['x','y','w','h']):
   for dx in [0,x['w']]:
    for dy in [0,x['h']]:
     d=math.hypot(x['x']+dx-240,x['y']+dy-240)
     assert d<=232+1e-6,(path,d)
   rects.append(path)
  for k,v in x.items():walk(v,path+'.'+k)
 elif isinstance(x,list):
  for i,v in enumerate(x):walk(v,path+f'[{i}]')
walk(layout)
# The format has raw root-size metadata but no rectangular full-screen object to exempt.
assert len(rects)>=10
assert (312/6,312/8)==(52,39)
for n in [6,8]:
 for row in range(n):
  for col in range(n):
   x=84+(col+.5)*312/n;y=84+(row+.5)*312/n
   assert int((x-84)/(312/n))==col and int((y-84)/(312/n))==row
assert len(content)>=100
assert all(isinstance(k,str) and isinstance(v,str) and v for k,v in content.items())
assert len(tutorial)==8
for name,cols in sheets['sheets'].items():
 assert len(cols)==len(set(cols)) and cols and all(isinstance(x,str) for x in cols)
assert 'device_token' not in ','.join(str(x) for x in sheets['sheets'].values())
report={'status':'passed','safe_rectangles':len(rects),'ui_strings':len(content),'tutorial_pages':len(tutorial),
 'api_actions':len(api['actions']),'sheet_types':len(sheets['sheets']),'cell_centers_checked':100,'physical_display':False}
(root/'results/data.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
``````
<!-- REV_END -->

### ファイル：`tests/verify_core.py`

<!-- REV_FILE tests/verify_core.py sha256=d1a00eb4b51bec03c948e163b663d525fd83ad3a4873947334a5269f130adbb9 -->
``````python
#!/usr/bin/env python3
"""Independent line-endpoint oracle vs C++ and JS. Python stdlib only."""
from __future__ import annotations
import json, pathlib, random, subprocess
ROOT=pathlib.Path(__file__).resolve().parents[1]

def initial(n):
    b=['.']*(n*n);a=n//2-1;c=n//2
    b[a*n+a]=b[c*n+c]='W';b[a*n+c]=b[c*n+a]='B'
    return ''.join(b)

def flip(n,b,side,i):
    if i<0 or i>=n*n or b[i]!='.':return []
    row,col=divmod(i,n);other='W' if side=='B' else 'B';out=set()
    # An independently formulated test: enumerate FRIENDLY endpoints, not ray scan loops.
    for j,x in enumerate(b):
        if x!=side:continue
        r,c=divmod(j,n);dy=r-row;dx=c-col
        if not (dy==0 or dx==0 or abs(dy)==abs(dx)):continue
        distance=max(abs(dx),abs(dy))
        if distance<2:continue
        sy=(dy>0)-(dy<0);sx=(dx>0)-(dx<0)
        between=[(row+k*sy)*n+col+k*sx for k in range(1,distance)]
        if all(b[k]==other for k in between):out.update(between)
    return sorted(out)

def legal(n,b,s):return [i for i in range(n*n) if flip(n,b,s,i)]
def ended(n,b):return not legal(n,b,'B') and not legal(n,b,'W')
def play(n,b,s,m):
    out=list(b)
    if m>=0:
        out[m]=s
        for i in flip(n,b,s,m):out[i]=s
    return ''.join(out),'W' if s=='B' else 'B'

def make_cases():
    rng=random.Random(20260922);cases=[];games=0;turns=0;passes=0
    for n in (6,8):
        for g in range(60):
            b=initial(n);s='B';ply=0
            while not ended(n,b):
                lm=legal(n,b,s);m=rng.choice(lm) if lm else -1
                if (ply+g)%5==0 or not lm:
                    cases.append(dict(n=n,side=s,cells=b,ply=ply,move=m))
                b,s=play(n,b,s,m);ply+=1;turns+=1;passes+=m==-1
                assert ply<=128
            cases.append(dict(n=n,side=s,cells=b,ply=ply,move=-1));games+=1
        for m in [-2,-1,0,n*n,n*n+1]:cases.append(dict(n=n,side='B',cells=initial(n),ply=0,move=m))
        # All eight rays flip into the center, no chain reaction.
        board=['.']*(n*n);center=2*n+2
        for dy in (-1,0,1):
            for dx in (-1,0,1):
                if not dx and not dy:continue
                board[(2+dy)*n+2+dx]='W';board[(2+2*dy)*n+2+2*dx]='B'
        cases.append(dict(n=n,side='B',cells=''.join(board),ply=0,move=center))
        # A sole forced pass, and a terminal board with empty cells.
        for b,s,m in [('WB.'+'W'*(n*n-3),'B',-1),('WB.'+'W'*(n*n-3),'W',2),
                      ('B'+'.'*(n*n-1),'W',-1),('B'*(n*n//2)+'W'*(n*n//2),'B',-1)]:
            cases.append(dict(n=n,side=s,cells=b,ply=0,move=m))
    return cases,dict(games=games,turns=turns,passes=passes)

def oracle(case):
    n,b,s,ply,m=(case[k] for k in ('n','cells','side','ply','move'))
    lm=legal(n,b,s);f=flip(n,b,s,m);done=ended(n,b)
    err='FINISHED' if done else 'PASS_FORBIDDEN' if m==-1 and lm else 'OUT_OF_RANGE' if m < -1 or m>=n*n else 'OCCUPIED' if m>=0 and b[m]!='.' else 'NO_CAPTURE' if m>=0 and not f else None
    nb,ns=(b,s) if err else play(n,b,s,m)
    np=ply+(err is None);bc=nb.count('B');wc=nb.count('W')
    end=ended(n,nb);win='-' if not end else 'B' if bc>wc else 'W' if wc>bc else 'D'
    return dict(legal=lm,flips=f,next=dict(n=n,cells=nb,side=ns,ply=np),error=err,terminal=end,winner=win)

def perft(n,b,s,depth):
    if depth==0 or ended(n,b):return 1
    return sum(perft(n,*play(n,b,s,m),depth-1) for m in (legal(n,b,s) or [-1]))

def main():
    subprocess.run(['g++','-std=c++17','-O2','-Wall','-Wextra','-Werror',str(ROOT/'tests/core_cli.cpp'),'-o',str(ROOT/'tests/core_cli')],check=True)
    cases,info=make_cases()
    cp='\n'.join(f"{c['n']} {1 if c['side']=='B' else 2} {c['ply']} {c['cells']} {c['move']}" for c in cases)+'\n'
    crows=subprocess.run([str(ROOT/'tests/core_cli')],input=cp,text=True,capture_output=True,check=True).stdout.splitlines()
    jrows=subprocess.run(['node',str(ROOT/'tests/js_cli.js')],input='\n'.join(map(json.dumps,cases))+'\n',text=True,capture_output=True,check=True).stdout.splitlines()
    assert len(crows)==len(jrows)==len(cases)
    errors={None:0,'BAD_STATE':1,'OUT_OF_RANGE':2,'OCCUPIED':3,'NO_CAPTURE':4,'PASS_FORBIDDEN':5,'FINISHED':6}
    for idx,(c,cl,jl) in enumerate(zip(cases,crows,jrows)):
        want=oracle(c);x=cl.split();j=json.loads(jl)
        lm=[i for i in range(c['n']**2) if int(x[0])>>i&1];f=[i for i in range(c['n']**2) if int(x[1])>>i&1]
        assert lm==want['legal']==j['legal'],(idx,'legal')
        assert f==want['flips']==j['flips'],(idx,'flips')
        assert int(x[3])==errors[want['error']] and j['error']==want['error'],(idx,'error')
        assert x[6]==want['next']['cells'] and int(x[5])==want['next']['ply'],(idx,'next')
        assert x[4]==('1' if want['next']['side']=='B' else '2')
        assert int(x[7])==int(want['terminal']) and x[8]==want['winner']
        assert int(x[2])==j['local'],(idx,'local evaluation parity')
        if j['next'] is not None:assert j['next']==want['next']
    tree={str(n):[perft(n,initial(n),'B',d) for d in range(1,6)] for n in (6,8)}
    report={'status':'passed','cross_language_positions':len(cases),'oracle_simulation':info,'perft_depth_1_to_5':tree,
            'scope':'bounded regression / independent oracle, not exhaustive all Reversi positions, no hardware or Jev API'}
    (ROOT/'results/core_verification.json').write_text(json.dumps(report,indent=2)+'\n')
    # Curated reachable positions for the coding agent, not golden values from the implementation under test.
    fixture=[dict(input=c,expected=oracle(c)) for c in cases[::max(1,len(cases)//40)]]
    (ROOT/'data/golden_positions.json').write_text(json.dumps(fixture,indent=2)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
``````
<!-- REV_END -->

### ファイル：`tools/extract_payload.py`

<!-- REV_FILE tools/extract_payload.py sha256=e67bf9c9231c9f8fdbf4b878ae70e73d15db497ec4b54b1582b7babc0f5bec91 -->
``````python
#!/usr/bin/env python3
"""Safely extract text payloads from the handoff Markdown, verifying every SHA-256.
No extracted code is executed. Existing different files are never overwritten.
"""
from __future__ import annotations
import argparse,hashlib,json,pathlib,re
PATTERN=re.compile(r'^<!-- REV_FILE ([A-Za-z0-9_./-]+) sha256=([0-9a-f]{64}) -->\n^``````[^\n]*\n(.*?)^``````\n<!-- REV_END -->$',re.M|re.S)
def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('markdown',type=pathlib.Path)
    parser.add_argument('destination',type=pathlib.Path)
    args=parser.parse_args()
    # Normalize CRLF introduced by text editors; packaged payloads are LF UTF-8.
    text=args.markdown.read_text(encoding='utf-8').replace('\r\n','\n')
    found=PATTERN.findall(text)
    if not found:raise SystemExit('No payload markers found; refusing empty extraction.')
    root=args.destination.resolve();root.mkdir(parents=True,exist_ok=True)
    checked=[];seen=set()
    for name,digest,body in found:
        relative=pathlib.PurePosixPath(name)
        if relative.is_absolute() or any(x in ('..','.') for x in relative.parts) or name in seen:
            raise SystemExit('Unsafe or duplicate path: '+name)
        seen.add(name)
        target=(root/pathlib.Path(*relative.parts)).resolve()
        if root not in target.parents:raise SystemExit('Path escapes destination: '+name)
        data=body.encode('utf-8')
        if hashlib.sha256(data).hexdigest()!=digest:raise SystemExit('Checksum mismatch: '+name)
        if target.exists() and (not target.is_file() or target.read_bytes()!=data):
            raise SystemExit('Refusing to overwrite different existing path: '+name)
        checked.append((target,data))
    for target,data in checked:
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(data)
    print(json.dumps({'status':'verified','files':len(checked),'destination':str(root)},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
``````
<!-- REV_END -->

### ファイル：`tools/run_all.py`

<!-- REV_FILE tools/run_all.py sha256=ac9add0749ab3f727f4d067a882b3f76336f59e9bc4b803cd1a07928d162b34c -->
``````python
#!/usr/bin/env python3
"""Rebuild and execute host reference tests; no real cloud/hardware calls."""
from pathlib import Path
import json,platform,shutil,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
def run(args,timeout=180):
    p=subprocess.run(args,cwd=ROOT,text=True,capture_output=True,timeout=timeout)
    if p.returncode:
        print(p.stdout);print(p.stderr,file=sys.stderr)
        raise SystemExit(p.returncode)
    print(p.stdout,end='')
    return p.stdout

def main():
    for tool in ['g++','node']:
        if not shutil.which(tool):raise SystemExit(f'Required tool missing: {tool}. No tests passed.')
    (ROOT/'results').mkdir(exist_ok=True)
    versions={'python':platform.python_version(),'g++':run(['g++','--version']).splitlines()[0],
              'node':run(['node','--version']).strip(),'platform':platform.platform()}
    for name in ['smoke','session_test']:
        output=ROOT/'tests'/(name+('.exe' if sys.platform=='win32' else ''))
        run(['g++','-std=c++17','-O2','-Wall','-Wextra','-Werror',str(ROOT/'tests'/f'{name}.cpp'),'-o',str(output)])
        result=run([str(output)])
        obj=json.loads(result);assert obj['status']=='passed'
        (ROOT/'results'/('cpp_smoke.json' if name=='smoke' else 'session.json')).write_text(json.dumps(obj,indent=2)+'\n')
    run([sys.executable,str(ROOT/'tests/verify_core.py')])
    run(['node',str(ROOT/'tests/test_contract.js')])
    run([sys.executable,str(ROOT/'tests/test_data.py')])
    (ROOT/'results/host_run.json').write_text(json.dumps({'status':'passed','versions':versions,
      'real_hardware':False,'real_google':False,'real_jev':False,'lvgl_compiled':False},ensure_ascii=False,indent=2)+'\n')
    print('HOST TESTS PASSED. Real ESP32 / LVGL integration / GAS / Jev remain untested.')
if __name__=='__main__':main()
``````
<!-- REV_END -->

