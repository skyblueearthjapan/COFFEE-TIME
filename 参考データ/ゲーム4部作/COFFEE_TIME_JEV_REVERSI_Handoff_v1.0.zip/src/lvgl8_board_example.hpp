#pragma once
// LVGL 8 integration example. Not compiled against the user's LVGL/BSP here.
// All calls must be made on the existing LVGL thread or under its existing mutex.
#include <lvgl.h>
#include <array>
#include <cstdio>
#include "reversi_session.hpp"
namespace ct_rev {
struct UiPort {
    virtual ~UiPort()=default;
    virtual void select(int square,uint16_t expectedPly)=0;
    virtual void confirm(uint16_t expectedPly)=0;
    virtual void menu()=0;
    virtual void choices()=0;
};
class BoardView {
    struct Tag {BoardView* owner=nullptr;int value=0;};
    lv_obj_t* root_=nullptr;lv_obj_t* title_=nullptr;lv_obj_t* score_=nullptr;
    lv_obj_t* place_=nullptr;lv_obj_t* choices_=nullptr;
    std::array<lv_obj_t*,64> cells_{};std::array<lv_obj_t*,64> disks_{};
    std::array<lv_obj_t*,64> dots_{};std::array<Tag,67> tags_{};
    UiPort* port_=nullptr;uint8_t n_=6;uint16_t ply_=0;bool canPlay_=false;
    static void event(lv_event_t* e){
        auto* tag=static_cast<Tag*>(lv_event_get_user_data(e));
        if(!tag||!tag->owner||lv_event_get_code(e)!=LV_EVENT_CLICKED)return;
        auto* s=tag->owner;
        if(!s->port_)return;
        if(tag->value==64){s->port_->menu();return;}
        if(!s->canPlay_)return;
        if(tag->value==65)s->port_->confirm(s->ply_);
        else if(tag->value==66)s->port_->choices();
        else s->port_->select(tag->value,s->ply_);
    }
    static void flat(lv_obj_t* p){lv_obj_set_style_pad_all(p,0,0);lv_obj_set_style_border_width(p,0,0);lv_obj_set_style_radius(p,0,0);lv_obj_clear_flag(p,LV_OBJ_FLAG_SCROLLABLE);}
    lv_obj_t* control(int tag,int x,int y,int w,int h,const char* text,const lv_font_t* font){
        auto* b=lv_btn_create(root_);lv_obj_set_pos(b,x,y);lv_obj_set_size(b,w,h);
        lv_obj_set_style_bg_color(b,lv_color_hex(0x245548),0);lv_obj_clear_flag(b,LV_OBJ_FLAG_SCROLLABLE);
        tags_[tag]={this,tag};lv_obj_add_event_cb(b,event,LV_EVENT_CLICKED,&tags_[tag]);
        auto* l=lv_label_create(b);lv_label_set_text(l,text);lv_obj_set_style_text_font(l,font,0);lv_obj_center(l);
        lv_obj_clear_flag(l,LV_OBJ_FLAG_CLICKABLE);return b;
    }
public:
    // Do not copy an object whose callback user_data points into its member arrays.
    BoardView()=default;BoardView(const BoardView&)=delete;BoardView& operator=(const BoardView&)=delete;
    void destroy(){canPlay_=false;port_=nullptr;if(root_){lv_obj_del(root_);root_=nullptr;}}
    void create(lv_obj_t* parent,uint8_t n,UiPort& port,const lv_font_t* textFont=LV_FONT_DEFAULT){
        destroy();n_=n;port_=&port;
        if(n!=6&&n!=8){port_=nullptr;return;}
        root_=lv_obj_create(parent);flat(root_);lv_obj_set_pos(root_,0,0);lv_obj_set_size(root_,480,480);
        lv_obj_set_style_bg_color(root_,lv_color_hex(0xF2EADF),0);
        title_=lv_label_create(root_);lv_obj_set_pos(title_,160,24);lv_obj_set_size(title_,160,22);
        lv_obj_set_style_text_align(title_,LV_TEXT_ALIGN_CENTER,0);
        score_=lv_label_create(root_);lv_obj_set_pos(score_,132,50);lv_obj_set_size(score_,216,28);
        lv_obj_set_style_text_font(score_,textFont,0);lv_obj_set_style_text_align(score_,LV_TEXT_ALIGN_CENTER,0);
        const int u=312/n;
        for(int i=0;i<n*n;i++){
            cells_[i]=lv_btn_create(root_);flat(cells_[i]);lv_obj_set_pos(cells_[i],84+(i%n)*u,84+(i/n)*u);lv_obj_set_size(cells_[i],u,u);
            lv_obj_set_style_bg_color(cells_[i],lv_color_hex(0x245548),0);
            lv_obj_set_style_border_width(cells_[i],1,0);lv_obj_set_style_border_color(cells_[i],lv_color_hex(0xC7D3C8),0);
            tags_[i]={this,i};lv_obj_add_event_cb(cells_[i],event,LV_EVENT_CLICKED,&tags_[i]);
            disks_[i]=lv_obj_create(cells_[i]);flat(disks_[i]);lv_obj_set_size(disks_[i],u*3/4,u*3/4);
            lv_obj_set_style_radius(disks_[i],LV_RADIUS_CIRCLE,0);lv_obj_center(disks_[i]);lv_obj_clear_flag(disks_[i],LV_OBJ_FLAG_CLICKABLE);
            dots_[i]=lv_obj_create(cells_[i]);flat(dots_[i]);lv_obj_set_size(dots_[i],6,6);lv_obj_set_style_radius(dots_[i],LV_RADIUS_CIRCLE,0);
            lv_obj_set_style_bg_color(dots_[i],lv_color_hex(0xD7A94C),0);lv_obj_center(dots_[i]);lv_obj_clear_flag(dots_[i],LV_OBJ_FLAG_CLICKABLE);
        }
        control(64,132,400,48,44,"操作",textFont);
        place_=control(65,188,402,104,52,"置く",textFont);
        choices_=control(66,300,400,48,44,"候補",textFont);
    }
    void render(const Session& s,int selected,bool enabled){
        if(!root_||s.pos.n!=n_)return;
        ply_=s.pos.ply;canPlay_=enabled&&s.closure==Closure::Active&&s.pos.side==s.human;
        char line[80];std::snprintf(line,sizeof(line),"REVERSI %ux%u",unsigned(n_),unsigned(n_));lv_label_set_text(title_,line);
        auto count=counts(s.pos);std::snprintf(line,sizeof(line),"B %d / W %d",count.black,count.white);lv_label_set_text(score_,line);
        for(int i=0;i<n_*n_;i++){
            bool empty=s.pos.board[i]==Cell::Empty,legalCell=captures(s.pos,i,s.pos.side)!=0;
            if(empty)lv_obj_add_flag(disks_[i],LV_OBJ_FLAG_HIDDEN);else{
                lv_obj_clear_flag(disks_[i],LV_OBJ_FLAG_HIDDEN);
                lv_obj_set_style_bg_color(disks_[i],lv_color_hex(s.pos.board[i]==Cell::Black?0x17201C:0xF9F5EB),0);
            }
            if(canPlay_&&legalCell)lv_obj_clear_flag(dots_[i],LV_OBJ_FLAG_HIDDEN);else lv_obj_add_flag(dots_[i],LV_OBJ_FLAG_HIDDEN);
            lv_obj_set_style_border_width(cells_[i],selected==i?3:1,0);
            lv_obj_set_style_border_color(cells_[i],lv_color_hex(selected==i?0xD7A94C:0xC7D3C8),0);
        }
        if(canPlay_&&selected>=0&&captures(s.pos,selected,s.pos.side))lv_obj_clear_state(place_,LV_STATE_DISABLED);
        else lv_obj_add_state(place_,LV_STATE_DISABLED);
        if(canPlay_)lv_obj_clear_state(choices_,LV_STATE_DISABLED);else lv_obj_add_state(choices_,LV_STATE_DISABLED);
    }
};
} // namespace ct_rev
