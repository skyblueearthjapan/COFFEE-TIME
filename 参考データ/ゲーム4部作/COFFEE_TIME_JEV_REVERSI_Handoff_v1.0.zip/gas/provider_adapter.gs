/** Reference connector. CTReversi must be loaded as an Apps Script .gs module.
 * Call only AFTER a durable reservation; never while holding ScriptLock.
 * No API keys, request bodies or response bodies are logged here.
 */
function revCallProvider(snapshot, model, apiKey) {
  if (typeof apiKey !== 'string' || !apiKey) return {ok:false,error:'NO_KEY'};
  var p = CTReversi.replay(snapshot);
  var body = CTReversi.buildJevRequest(snapshot, model);
  var start = Date.now();
  try {
    var response = UrlFetchApp.fetch('https://api.typesafe.ai/v1/systemone', {
      method:'post', contentType:'application/json',
      headers:{Authorization:'Bearer '+apiKey}, payload:JSON.stringify(body),
      muteHttpExceptions:true, followRedirects:false,
      validateHttpsCertificates:true, timeoutSeconds:8
    });
    var code = response.getResponseCode();
    if (code !== 200) return {ok:false,error:'PROVIDER_HTTP_'+code,latency_ms:Date.now()-start};
    var text = response.getContentText();
    if (text.length > 32768) return {ok:false,error:'PROVIDER_TOO_LARGE',latency_ms:Date.now()-start};
    var parsed = CTReversi.parseJev(JSON.parse(text),p,model);
    return {ok:true,inference:parsed,latency_ms:Date.now()-start};
  } catch (err) {
    return {ok:false,error:'PROVIDER_FETCH_OR_PARSE_FAILED',latency_ms:Date.now()-start};
  }
}
