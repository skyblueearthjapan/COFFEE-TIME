/* Pure lease/idempotency reference. The caller MUST persist each transition under a real
 * ScriptLock + atomic Sheets batch. This module is not itself a lock or database. */
var CTDecision = (()=>{
  'use strict';
  const LEASE_MS=20000;
  function reserve(existing,input,now,generation) {
    if(existing) {
      if(existing.position_hash!==input.position_hash||existing.identity!==input.identity)throw Error('STATE_CONFLICT');
      return {record:existing,call_provider:false};
    }
    return {record:{...input,status:'pending',generation,lease_until_ms:now+LEASE_MS,
      call_reserved:true,created_at_ms:now,answer:null,error:null},call_provider:true};
  }
  function finalize(record,generation,now,answer,error=null) {
    if(record.status!=='pending'||record.generation!==generation)return {record,accepted:false};
    if(now>record.lease_until_ms)return {record:{...record,status:'failed',error:'LEASE_EXPIRED',answer:null},accepted:false};
    return {record:{...record,status:error?'failed':'ready',answer:error?null:answer,error},accepted:true};
  }
  function expire(record,now) {
    if(record.status==='pending'&&now>record.lease_until_ms)return {...record,status:'failed',answer:null,error:'LEASE_EXPIRED'};
    return record;
  }
  return {reserve,finalize,expire,LEASE_MS};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=CTDecision;
