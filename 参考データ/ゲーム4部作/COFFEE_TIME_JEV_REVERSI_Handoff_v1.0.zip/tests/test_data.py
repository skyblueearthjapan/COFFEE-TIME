"""Data/schema/layout consistency. Does not verify physical glass or real font glyphs."""
from pathlib import Path
import json,math
root=Path(__file__).resolve().parents[1]
load=lambda n:json.loads((root/'data'/n).read_text())
rules=load('rules.json');layout=load('layout.json');content=load('content.ja.json');api=load('api_contract.json');sheets=load('sheets_schema.json');tutorial=load('tutorial.ja.json')
assert rules['sizes']==[6,8] and rules['menu_slot']==5
assert rules['max_events']==128 and rules['game_id']=='jev_reversi'
assert set(api['actions'])=={'device.hello','decision.prepare','decision.get','result.put'}
assert len(api['errors'])==len(set(api['errors']))
# Recursive rectangle validation: every x/y/w/h rectangle lives inside design safe circle.
rects=[]
def walk(x,path=''):
 if isinstance(x,dict):
  if all(k in x for k in ['x','y','w','h']):
   for dx in [0,x['w']]:
    for dy in [0,x['h']]:
     d=math.hypot(x['x']+dx-240,x['y']+dy-240)
     assert d<=232+1e-6,(path,d)
   rects.append(path)
  for k,v in x.items():walk(v,path+'.'+k)
 elif isinstance(x,list):
  for i,v in enumerate(x):walk(v,path+f'[{i}]')
walk(layout)
# The format has raw root-size metadata but no rectangular full-screen object to exempt.
assert len(rects)>=10
assert (312/6,312/8)==(52,39)
for n in [6,8]:
 for row in range(n):
  for col in range(n):
   x=84+(col+.5)*312/n;y=84+(row+.5)*312/n
   assert int((x-84)/(312/n))==col and int((y-84)/(312/n))==row
assert len(content)>=100
assert all(isinstance(k,str) and isinstance(v,str) and v for k,v in content.items())
assert len(tutorial)==8
for name,cols in sheets['sheets'].items():
 assert len(cols)==len(set(cols)) and cols and all(isinstance(x,str) for x in cols)
assert 'device_token' not in ','.join(str(x) for x in sheets['sheets'].values())
report={'status':'passed','safe_rectangles':len(rects),'ui_strings':len(content),'tutorial_pages':len(tutorial),
 'api_actions':len(api['actions']),'sheet_types':len(sheets['sheets']),'cell_centers_checked':100,'physical_display':False}
(root/'results/data.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
