from playwright.sync_api import sync_playwright
from pathlib import Path
import json,shutil
root=Path(__file__).resolve().parents[1]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path=shutil.which('chromium'),args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1000,'height':900})
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content((root/'preview.html').read_text(),wait_until='load');page.wait_for_timeout(300)
 box=page.locator('canvas').bounding_box()
 def click(x,y):page.mouse.click(box['x']+x*box['width']/480,box['y']+y*box['height']/480)
 click(84+2*52+26,84+1*52+26)
 assert page.evaluate('previewState().selected')==8
 assert page.evaluate('previewState().position.ply')==0
 click(240,428);page.wait_for_timeout(600)
 assert page.evaluate('previewState().position.ply')==2
 click(156,422);assert page.evaluate('previewState().paused')
 page.screenshot(path=str(root/'results/preview_6x6.png'),full_page=True)
 page.select_option('#size','8');page.click('#new');page.wait_for_timeout(100)
 assert page.evaluate('previewState().position.n')==8
 click(324,422);assert page.evaluate('previewState().list')
 click(180,179);assert page.evaluate('previewState().selected')==19
 click(240,428);page.wait_for_timeout(600)
 assert page.evaluate('previewState().position.ply')==2
 page.screenshot(path=str(root/'results/preview_8x8.png'),full_page=True)
 page.select_option('#human','W');page.click('#new');page.wait_for_timeout(650)
 assert page.evaluate('previewState().position.ply')==1
 assert page.evaluate('previewState().position.side')=='W'
 assert not errors,errors
 browser.close()
(root/'results/browser.json').write_text(json.dumps({'status':'passed','checks':['6x6 select/confirm','AI local reply','pause','8x8 candidate picker','8x8 commit','human white/AI opening','no console page errors'],'live_jev':False,'live_google':False,'hardware':False},indent=2)+'\n')
print('browser passed')
