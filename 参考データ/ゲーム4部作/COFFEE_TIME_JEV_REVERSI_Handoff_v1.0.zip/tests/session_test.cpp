#include "../src/reversi_session.hpp"
#include <cassert>
#include <iostream>
using namespace ct_rev;
int main(){
    std::array<uint8_t,16> id{};id[0]=1;Session s;assert(start(s,6,Cell::Black,Mode::Jev,id));
     assert(!commit(s,8,Source::Jev,0));assert(s.count==0);
    assert(commit(s,8,Source::Human,0));assert(!commit(s,8,Source::Human,0));
    auto l=legal(s.pos,s.pos.side);assert(l.count>1);
    assert(commit(s,l.cells[0],Source::Jev,1));
    std::array<uint8_t,SNAPSHOT_MAX> bytes;size_t len=encode(s,bytes);Session copy;
    assert(decode(bytes.data(),len,copy));assert(copy.pos.board==s.pos.board&&copy.pos.side==s.pos.side);
    size_t corruption=0;
    for(size_t j=0;j<len;j++){auto b=bytes;b[j]^=1;assert(!decode(b.data(),len,copy));++corruption;}
    for(size_t j=0;j<len;j++){assert(!decode(bytes.data(),j,copy));++corruption;}
    assert(freezeLocal(s));assert(s.localOnly);
    while(!terminal(s.pos)){
        l=legal(s.pos,s.pos.side);int m=l.count?local_move(s.pos):PASS;
        Source source=m==PASS?Source::Forced:s.pos.side==s.human?Source::Human:l.count==1?Source::Forced:Source::Local;
        assert(commit(s,m,source,s.count));
    }
    assert(s.closure==Closure::Completed);len=encode(s,bytes);assert(decode(bytes.data(),len,copy));
    assert(!close(s,Closure::Resigned));
    assert(start(s,8,Cell::White,Mode::Local,id));assert(s.localOnly);
    assert(close(s,Closure::Aborted));len=encode(s,bytes);assert(decode(bytes.data(),len,copy));
    assert(copy.closure==Closure::Aborted);
    std::cout<<"{\"status\":\"passed\",\"corruption_and_truncation_tests\":"<<corruption<<"}\n";
}
