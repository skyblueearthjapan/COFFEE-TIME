#include "../src/reversi_core.hpp"
#include <iostream>
#include <string>
using namespace ct_rev;
int main() {
    int n=0,side=0,ply=0,m=0; std::string text;
    while(std::cin>>n>>side>>ply>>text>>m) {
        Position p; p.n=uint8_t(n);p.side=Cell(side);p.ply=uint16_t(ply);
        if(n!=6&&n!=8) return 3;
        if(text.size()!=size_t(n*n)) return 4;
        for(int i=0;i<n*n;i++) {if(text[i]!='.'&&text[i]!='B'&&text[i]!='W') return 5; p.board[i]=text[i]=='B'?Cell::Black:text[i]=='W'?Cell::White:Cell::Empty;}
        auto lm=legal(p,p.side); uint64_t mask=0;
        for(int k=0;k<lm.count;k++) mask |= uint64_t(1)<<lm.cells[k];
        int local=local_move(p); uint64_t flip=captures(p,m,p.side);
        auto t=apply(p,m); auto cnt=counts(p);
        std::cout<<mask<<' '<<flip<<' '<<local<<' '<<int(t.error)<<' '<<int(p.side)<<' '<<p.ply<<' ';
        for(int i=0;i<n*n;i++) std::cout<<symbol(p.board[i]);
        std::cout<<' '<<terminal(p)<<' '<<winner(p)<<' '<<cnt.black<<' '<<cnt.white<<' '<<cnt.empty<<'\n';
    }
}
