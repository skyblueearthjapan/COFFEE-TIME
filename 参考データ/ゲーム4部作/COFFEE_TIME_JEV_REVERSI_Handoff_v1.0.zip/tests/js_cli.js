const R=require('../gas/reversi_shared.js');
const fs=require('fs');
const lines=fs.readFileSync(0,'utf8').trim().split('\n');
for(const line of lines) {
  if(!line)continue;
  const {n,side,cells,ply,move}=JSON.parse(line),p={n,side,cells,ply};
  let next=null,error=null;
  try{next=R.step(p,move);}catch(e){error=e.message;}
  console.log(JSON.stringify({legal:R.legal(p),flips:R.flips(p,move),local:R.localMove(p),next,error,
    terminal:next?R.terminal(next):R.terminal(p),winner:next?R.winner(next):R.winner(p)}));
}
