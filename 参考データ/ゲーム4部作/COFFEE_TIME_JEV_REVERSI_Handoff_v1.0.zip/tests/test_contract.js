'use strict';
const R=require('../gas/reversi_shared.js'),D=require('../gas/decision_machine.js');
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
let groups=0;const test=(name,f)=>{f();groups++;};
const config={game_id:'a'.repeat(32),n:6,human:'W',mode:'jev',history:[]};
const p=R.replay(config),keys=R.legal(p).map(i=>R.coord(6,i)),model='jev-1.13.0';
const good=()=>({model,answers:{move:{type:'choice',choice:keys[0],probabilities:Object.fromEntries(keys.map(k=>[k,.25])),confidence:0}},usage:{input_tokens:101,output_tokens:0}});
test('initial legal sets',()=>assert.deepEqual(keys,['C2','B3','E4','D5']));
test('request contains only legal choices',()=>assert.deepEqual(Object.keys(R.buildJevRequest(config,model).questions.move.criteria),keys));
test('no device/user/secret in state',()=>{
 const text=JSON.stringify(R.buildJevRequest(config,model));
 for(const bad of ['api_key','player_id','game_id','device_id','history'])assert(!text.includes(bad));
});
test('pro exact feature schema',()=>{
 let q=R.buildJevRequest({...config,mode:'jev_pro'},model);
 assert.equal(typeof q.questions.move.criteria.C2.flipped,'number');
 assert.equal(q.questions.move.criteria.C2.flipped,1);
});
test('local no request',()=>assert.throws(()=>R.buildJevRequest({...config,mode:'local'},model),/LOCAL_ONLY/));
test('human turn no request',()=>assert.throws(()=>R.buildJevRequest({...config,human:'B'},model),/NO_DECISION_REQUIRED/));
test('valid probability',()=>assert.equal(R.parseJev(good(),p,model).choice,keys[0]));
test('wrong model',()=>assert.throws(()=>R.parseJev({...good(),model:'jev-other'},p,model)));
for(const [name,mutate] of [
 ['missing',x=>delete x.answers.move.probabilities[keys[0]]],
 ['extra',x=>x.answers.move.probabilities.A1=0],
 ['negative',x=>x.answers.move.probabilities[keys[0]]=-1],
 ['nan',x=>x.answers.move.probabilities[keys[0]]=NaN],
 ['infinity',x=>x.answers.move.probabilities[keys[0]]=Infinity],
 ['string',x=>x.answers.move.probabilities[keys[0]]='0.25'],
 ['bad sum',x=>x.answers.move.probabilities[keys[0]]=.9],
 ['bad choice',x=>x.answers.move.choice='PASS'],
 ['bad confidence',x=>x.answers.move.confidence=1.1],
 ['nonargmax',x=>{x.answers.move.probabilities[keys[0]]=.1;x.answers.move.probabilities[keys[1]]=.4;}]
])test(name,()=>{const x=good();mutate(x);assert.throws(()=>R.parseJev(x,p,model));});
test('rounding only normalization',()=>{let x=good();x.answers.move.probabilities[keys[0]]+=.0001;assert(R.parseJev(x,p,model).normalization_applied);});
test('CDF exact weights',()=>{
 const w=R.probabilityWeights({a:.5,b:.3,c:.2},['a','b','c']);assert.deepEqual(w,[500000,300000,200000]);
 const observed={a:0,b:0,c:0};for(let r=0;r<1000000;r++)observed[R.sample({a:.5,b:.3,c:.2},['a','b','c'],r)]++;
 assert.deepEqual(observed,{a:500000,b:300000,c:200000});
});
test('CDF zero mass',()=>assert.equal(R.sample({a:0,b:1},['a','b'],0),'b'));
test('identity no timestamp',()=>assert.equal(R.identity(config),R.identity({...config,time:555})));
test('role/source validation',()=>assert.throws(()=>R.replay({...config,history:['C2:H']}),/BAD_SOURCE/));
test('no provider return after fallback',()=>{
 let c={...config,history:['C2:L']};let p=R.replay(c),humanMove=R.coord(6,R.legal(p)[0]);
 c.history.push(humanMove+':H');p=R.replay(c);
 c.history.push(R.coord(6,R.legal(p)[0])+':J');assert.throws(()=>R.replay(c),/PROVIDER_SWITCH_BACK/);
});
test('immutable lease',()=>{
 let a=D.reserve(null,{position_hash:'h',identity:'i'},100,'g');assert(a.call_provider);
 let b=D.reserve(a.record,{position_hash:'h',identity:'i'},101,'g2');assert(!b.call_provider);
 assert.throws(()=>D.reserve(a.record,{position_hash:'x',identity:'i'},101,'g2'),/STATE_CONFLICT/);
});
test('late answer rejected',()=>{
 let a=D.reserve(null,{position_hash:'h',identity:'i'},0,'g').record;
 assert(!D.finalize(a,'g',20001,{move:'C2'}).accepted);
 assert(!D.finalize(a,'bad',1,{move:'C2'}).accepted);
});
test('no reroll after ready',()=>{
 let a=D.reserve(null,{position_hash:'h',identity:'i'},0,'g').record;
 let b=D.finalize(a,'g',10,{move:'C2'}).record;
 assert(!D.finalize(b,'g',11,{move:'D5'}).accepted);
 assert.equal(D.reserve(b,{position_hash:'h',identity:'i'},12,'g2').record.answer.move,'C2');
});
test('reply fencing',()=>{
 let active={local_only:false,waiting:true,game_id:'g',ply:1,position_hash:'h',decision_key:'d',legal_moves:['C2']};
 let reply={status:'ready',game_id:'g',ply:1,position_hash:'h',decision_key:'d',move:'C2'};
 assert(R.acceptsReply(active,reply));
 for(const change of [{game_id:'old'},{ply:2},{position_hash:'x'},{move:'A1'},{decision_key:'other'}])assert(!R.acceptsReply(active,{...reply,...change}));
 assert(!R.acceptsReply({...active,local_only:true},reply));
});
test('GAS connector mocked only',()=>{
 let called=0,opts=null;
 let ctx={CTReversi:R,Date,JSON,UrlFetchApp:{fetch:(url,o)=>{called++;opts=o;assert(url==='https://api.typesafe.ai/v1/systemone');return{getResponseCode:()=>200,getContentText:()=>JSON.stringify(good())};}}};
 vm.createContext(ctx);vm.runInContext(fs.readFileSync(__dirname+'/../gas/provider_adapter.gs','utf8'),ctx);
 let answer=ctx.revCallProvider(config,model,'TEST-NOT-A-KEY');assert(answer.ok);assert.equal(called,1);
 assert.equal(opts.timeoutSeconds,8);assert.equal(opts.followRedirects,false);assert.equal(opts.validateHttpsCertificates,true);
 assert.equal(ctx.revCallProvider(config,model,'').ok,false);assert.equal(called,1);
});
const report={status:'passed',test_groups:groups,cdf_rolls:1000000,real_google_calls:0,real_jev_calls:0};
fs.writeFileSync(__dirname+'/../results/contracts.json',JSON.stringify(report,null,2)+'\n');console.log(report);
