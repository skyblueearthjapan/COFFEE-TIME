#include "../src/reversi_core.hpp"
#include <cassert>
#include <iostream>
#include <cstdint>
using namespace ct_rev;
int main() {
    uint32_t rng=1234567; uint64_t turns=0, passes=0;
    for(int n : {6,8}) {
        for(int g=0;g<1000;g++) {
            Position p; assert(initial(uint8_t(n),p));
            int moves=0;
            while(!terminal(p)) {
                auto l=legal(p,p.side); rng=rng*1664525u+1013904223u;
                int m=l.count?l.cells[rng%l.count]:PASS;
                auto before=counts(p); auto t=apply(p,m); assert(t.error==Error::Ok);
                auto after=counts(p); assert(before.empty-after.empty==(m==PASS?0:1));
                assert(++moves<=128); ++turns; if(m==PASS) ++passes;
            }
            auto q=p; assert(apply(q,PASS).error==Error::Finished);
        }
    }
    assert(crc32(reinterpret_cast<const uint8_t*>("123456789"),9)==0xcbf43926u);
    for(int n:{6,8}) for(int r=0;r<n;r++) for(int c=0;c<n;c++)
        assert(hit_test(84+c*(312/n)+(312/n)/2,84+r*(312/n)+(312/n)/2,n)==r*n+c);
    std::cout<<"{\"games\":2000,\"turns\":"<<turns<<",\"passes\":"<<passes<<",\"status\":\"passed\"}\n";
}
