#!/usr/bin/env python3
"""Independent line-endpoint oracle vs C++ and JS. Python stdlib only."""
from __future__ import annotations
import json, pathlib, random, subprocess
ROOT=pathlib.Path(__file__).resolve().parents[1]

def initial(n):
    b=['.']*(n*n);a=n//2-1;c=n//2
    b[a*n+a]=b[c*n+c]='W';b[a*n+c]=b[c*n+a]='B'
    return ''.join(b)

def flip(n,b,side,i):
    if i<0 or i>=n*n or b[i]!='.':return []
    row,col=divmod(i,n);other='W' if side=='B' else 'B';out=set()
    # An independently formulated test: enumerate FRIENDLY endpoints, not ray scan loops.
    for j,x in enumerate(b):
        if x!=side:continue
        r,c=divmod(j,n);dy=r-row;dx=c-col
        if not (dy==0 or dx==0 or abs(dy)==abs(dx)):continue
        distance=max(abs(dx),abs(dy))
        if distance<2:continue
        sy=(dy>0)-(dy<0);sx=(dx>0)-(dx<0)
        between=[(row+k*sy)*n+col+k*sx for k in range(1,distance)]
        if all(b[k]==other for k in between):out.update(between)
    return sorted(out)

def legal(n,b,s):return [i for i in range(n*n) if flip(n,b,s,i)]
def ended(n,b):return not legal(n,b,'B') and not legal(n,b,'W')
def play(n,b,s,m):
    out=list(b)
    if m>=0:
        out[m]=s
        for i in flip(n,b,s,m):out[i]=s
    return ''.join(out),'W' if s=='B' else 'B'

def make_cases():
    rng=random.Random(20260922);cases=[];games=0;turns=0;passes=0
    for n in (6,8):
        for g in range(60):
            b=initial(n);s='B';ply=0
            while not ended(n,b):
                lm=legal(n,b,s);m=rng.choice(lm) if lm else -1
                if (ply+g)%5==0 or not lm:
                    cases.append(dict(n=n,side=s,cells=b,ply=ply,move=m))
                b,s=play(n,b,s,m);ply+=1;turns+=1;passes+=m==-1
                assert ply<=128
            cases.append(dict(n=n,side=s,cells=b,ply=ply,move=-1));games+=1
        for m in [-2,-1,0,n*n,n*n+1]:cases.append(dict(n=n,side='B',cells=initial(n),ply=0,move=m))
        # All eight rays flip into the center, no chain reaction.
        board=['.']*(n*n);center=2*n+2
        for dy in (-1,0,1):
            for dx in (-1,0,1):
                if not dx and not dy:continue
                board[(2+dy)*n+2+dx]='W';board[(2+2*dy)*n+2+2*dx]='B'
        cases.append(dict(n=n,side='B',cells=''.join(board),ply=0,move=center))
        # A sole forced pass, and a terminal board with empty cells.
        for b,s,m in [('WB.'+'W'*(n*n-3),'B',-1),('WB.'+'W'*(n*n-3),'W',2),
                      ('B'+'.'*(n*n-1),'W',-1),('B'*(n*n//2)+'W'*(n*n//2),'B',-1)]:
            cases.append(dict(n=n,side=s,cells=b,ply=0,move=m))
    return cases,dict(games=games,turns=turns,passes=passes)

def oracle(case):
    n,b,s,ply,m=(case[k] for k in ('n','cells','side','ply','move'))
    lm=legal(n,b,s);f=flip(n,b,s,m);done=ended(n,b)
    err='FINISHED' if done else 'PASS_FORBIDDEN' if m==-1 and lm else 'OUT_OF_RANGE' if m < -1 or m>=n*n else 'OCCUPIED' if m>=0 and b[m]!='.' else 'NO_CAPTURE' if m>=0 and not f else None
    nb,ns=(b,s) if err else play(n,b,s,m)
    np=ply+(err is None);bc=nb.count('B');wc=nb.count('W')
    end=ended(n,nb);win='-' if not end else 'B' if bc>wc else 'W' if wc>bc else 'D'
    return dict(legal=lm,flips=f,next=dict(n=n,cells=nb,side=ns,ply=np),error=err,terminal=end,winner=win)

def perft(n,b,s,depth):
    if depth==0 or ended(n,b):return 1
    return sum(perft(n,*play(n,b,s,m),depth-1) for m in (legal(n,b,s) or [-1]))

def main():
    subprocess.run(['g++','-std=c++17','-O2','-Wall','-Wextra','-Werror',str(ROOT/'tests/core_cli.cpp'),'-o',str(ROOT/'tests/core_cli')],check=True)
    cases,info=make_cases()
    cp='\n'.join(f"{c['n']} {1 if c['side']=='B' else 2} {c['ply']} {c['cells']} {c['move']}" for c in cases)+'\n'
    crows=subprocess.run([str(ROOT/'tests/core_cli')],input=cp,text=True,capture_output=True,check=True).stdout.splitlines()
    jrows=subprocess.run(['node',str(ROOT/'tests/js_cli.js')],input='\n'.join(map(json.dumps,cases))+'\n',text=True,capture_output=True,check=True).stdout.splitlines()
    assert len(crows)==len(jrows)==len(cases)
    errors={None:0,'BAD_STATE':1,'OUT_OF_RANGE':2,'OCCUPIED':3,'NO_CAPTURE':4,'PASS_FORBIDDEN':5,'FINISHED':6}
    for idx,(c,cl,jl) in enumerate(zip(cases,crows,jrows)):
        want=oracle(c);x=cl.split();j=json.loads(jl)
        lm=[i for i in range(c['n']**2) if int(x[0])>>i&1];f=[i for i in range(c['n']**2) if int(x[1])>>i&1]
        assert lm==want['legal']==j['legal'],(idx,'legal')
        assert f==want['flips']==j['flips'],(idx,'flips')
        assert int(x[3])==errors[want['error']] and j['error']==want['error'],(idx,'error')
        assert x[6]==want['next']['cells'] and int(x[5])==want['next']['ply'],(idx,'next')
        assert x[4]==('1' if want['next']['side']=='B' else '2')
        assert int(x[7])==int(want['terminal']) and x[8]==want['winner']
        assert int(x[2])==j['local'],(idx,'local evaluation parity')
        if j['next'] is not None:assert j['next']==want['next']
    tree={str(n):[perft(n,initial(n),'B',d) for d in range(1,6)] for n in (6,8)}
    report={'status':'passed','cross_language_positions':len(cases),'oracle_simulation':info,'perft_depth_1_to_5':tree,
            'scope':'bounded regression / independent oracle, not exhaustive all Reversi positions, no hardware or Jev API'}
    (ROOT/'results/core_verification.json').write_text(json.dumps(report,indent=2)+'\n')
    # Curated reachable positions for the coding agent, not golden values from the implementation under test.
    fixture=[dict(input=c,expected=oracle(c)) for c in cases[::max(1,len(cases)//40)]]
    (ROOT/'data/golden_positions.json').write_text(json.dumps(fixture,indent=2)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
