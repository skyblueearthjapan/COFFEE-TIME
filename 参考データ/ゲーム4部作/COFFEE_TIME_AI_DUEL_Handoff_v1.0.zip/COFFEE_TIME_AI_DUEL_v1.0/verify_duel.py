"""Run: python verify_duel.py. No API credentials and no network access needed."""
from __future__ import annotations
import concurrent.futures
import copy
import json
import math
import pathlib
import unittest
from duel_reference import *

ROOT=pathlib.Path(__file__).resolve().parent
COUNTS={'outcome_pairs':0,'probability_grid_points':0,'duplicate_submit_calls':0,'long_history_rounds':0}

def rec(i, match='a'*32, number=None, hand='ROCK', ai='SCISSORS'):
    return {'round_id':f'{i:032x}','match_id':match,'round_no':number or (i-1)%10+1,
            'player_hand':hand,'ai_hand':ai,'player_result':result(hand,ai),
            'provider_used':'stats','probabilities':dict(zip(HANDS,[1/3]*3))}

def committed():
    e=TestEngine(); mid='a'*32; e.open('p1',mid)
    r=e.reserve(mid,1,0)
    pub=e.commit(r['round_id'],r['generation_id'],dict(zip(HANDS,[.4,.35,.25])),1)
    return e,r['round_id'],pub

class DuelTests(unittest.TestCase):
    def test_all_outcomes(self):
        expected=[['draw','human_win','ai_win'],['ai_win','draw','human_win'],['human_win','ai_win','draw']]
        for i,h in enumerate(HANDS):
            for j,a in enumerate(HANDS):
                self.assertEqual(result(h,a),expected[i][j]); COUNTS['outcome_pairs']+=1
    def test_invalid_hand(self):
        with self.assertRaises(RuleError): result('rock','ROCK')
    def test_probability_grid(self):
        for a in range(101):
            for b in range(101-a):
                p=dict(zip(HANDS,[a/100,b/100,(100-a-b)/100]))
                u=expected_margins(p)
                self.assertAlmostEqual(sum(u.values()),0)
                self.assertGreaterEqual(max(u.values()),-1e-12)
                for h in optimal_actions(p): self.assertAlmostEqual(u[h],max(u.values()))
                COUNTS['probability_grid_points']+=1
    def test_greedy_counterexample(self):
        self.assertEqual(optimal_actions(dict(zip(HANDS,[.4,.35,.25]))),['ROCK'])
    def test_uniform_tie(self):
        self.assertEqual(optimal_actions(dict(zip(HANDS,[1/3]*3))),list(HANDS))
    def test_invalid_probabilities(self):
        bad=[{},dict(zip(HANDS,[.1,.1,.1])),dict(zip(HANDS,[1,-.1,.1])),
             dict(zip(HANDS,[True,0,0])),dict(zip(HANDS,[math.nan,.5,.5])),
             dict(zip(HANDS,[math.inf,0,0])),{'ROCK':1,'SCISSORS':0,'PAPER':0,'OTHER':0}]
        for p in bad:
            with self.assertRaises(RuleError):normalize_probabilities(p)
    def test_rounding_tolerance(self):
        p=normalize_probabilities(dict(zip(HANDS,[.3333,.3333,.3333])))
        self.assertAlmostEqual(sum(p.values()),1)
    def test_hash_tampering(self):
        args=['a'*32,'b'*32,1,'ROCK','c'*64]; original=commitment(*args)
        for i,x in enumerate(['d'*32,'e'*32,2,'PAPER','f'*64]):
            changed=args.copy(); changed[i]=x; self.assertNotEqual(original,commitment(*changed))
    def test_pin_domain_salt(self):
        k=b'x'*32
        self.assertNotEqual(pin_digest(k,'p1','a'*32,'123456'),pin_digest(k,'p2','a'*32,'123456'))
        self.assertNotEqual(pin_digest(k,'p1','a'*32,'123456'),pin_digest(k,'p1','b'*32,'123456'))
        self.assertNotEqual(pin_digest(k,'p1','a'*32,'123456'),pin_digest(b'y'*32,'p1','a'*32,'123456'))
    def test_no_cross_match_transition(self):
        s=append_resolved(zero_stats(),rec(1))
        s=append_resolved(s,rec(2,match='b'*32,number=1,hand='PAPER'))
        self.assertEqual(sum(map(sum,s['transition_by_hand'])),0)
        self.assertEqual(sum(s['first_hand_counts']),2)
    def test_within_match_transition(self):
        s=append_resolved(zero_stats(),rec(1));s=append_resolved(s,rec(2,hand='PAPER'))
        self.assertEqual(s['transition_by_hand'][0][2],1)
        self.assertEqual(s['repeat_after_result'][0],[0,1])
    def test_stats_cold_start(self):
        p=stats_prediction(zero_stats(),'a'*32,1)
        for v in p.values():self.assertAlmostEqual(v,1/3)
    def test_tail_bounded_long_history(self):
        s=zero_stats()
        for i in range(1,1001):
            s=append_resolved(s,rec(i,match=f'{(i-1)//10:032x}',hand=HANDS[i%3]))
        COUNTS['long_history_rounds']=1000
        self.assertEqual(s['rounds'],1000);self.assertEqual(len(s['tail']),50)
        self.assertEqual(sum(s['hand_counts']),1000)
        self.assertEqual(sum(map(sum,s['transition_by_hand'])),900)
        self.assertEqual(sum(s['first_hand_counts']),100)
        self.assertAlmostEqual(sum(stats_prediction(s,'f'*32,1).values()),1)
    def test_duplicate_stats_guard(self):
        r=rec(1); s=append_resolved(zero_stats(),r)
        with self.assertRaises(RuleError):append_resolved(s,r)
    def test_no_hidden_fields_before_submit(self):
        _,_,p=committed()
        for k in ['ai_hand','nonce','probabilities','prediction','generation_id']:
            self.assertNotIn(k,p)
    def test_concurrent_duplicates(self):
        e,rid,p=committed()
        def send(_):return e.submit(rid,'ROCK',p['commit_hash'],2)
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            rows=list(pool.map(send,range(32)))
        COUNTS['duplicate_submit_calls']=len(rows)
        self.assertEqual(e.players['p1']['rounds'],1)
        self.assertEqual(e.matches['a'*32]['resolved'],1)
        self.assertTrue(all(r==rows[0] for r in rows))
    def test_changed_hand_rejected(self):
        e,rid,p=committed();e.submit(rid,'ROCK',p['commit_hash'],2)
        with self.assertRaisesRegex(RuleError,'HAND_ALREADY_SUBMITTED'):
            e.submit(rid,'PAPER',p['commit_hash'],3)
    def test_submit_before_commit_rejected(self):
        e=TestEngine();e.open('p1','a'*32);r=e.reserve('a'*32,1,0)
        with self.assertRaises(RuleError):e.submit(r['round_id'],'ROCK','0'*64,1)
    def test_stale_generation(self):
        e=TestEngine();e.open('p1','a'*32);a=e.reserve('a'*32,1,0);b=e.reserve('a'*32,1,31)
        with self.assertRaisesRegex(RuleError,'STALE_GENERATION'):
            e.commit(a['round_id'],a['generation_id'],dict(zip(HANDS,[1/3]*3)),32)
        e.commit(b['round_id'],b['generation_id'],dict(zip(HANDS,[1/3]*3)),32)
    def test_expired_submit(self):
        e,rid,p=committed()
        with self.assertRaisesRegex(RuleError,'ROUND_EXPIRED'):e.submit(rid,'ROCK',p['commit_hash'],302)
    def test_commit_mismatch(self):
        e,rid,p=committed()
        with self.assertRaisesRegex(RuleError,'COMMIT_MISMATCH'):e.submit(rid,'ROCK','0'*64,2)
    def test_ten_rounds_completion_and_retention(self):
        e=TestEngine();mid='a'*32;e.open('p1',mid)
        for n in range(1,11):
            r=e.reserve(mid,n,n*5)
            pub=e.commit(r['round_id'],r['generation_id'],dict(zip(HANDS,[1/3]*3)),n*5+1)
            e.submit(r['round_id'],HANDS[n%3],pub['commit_hash'],n*5+2)
        m=e.matches[mid];s=e.players['p1']
        self.assertEqual(m['status'],'completed');self.assertEqual(sum(m['score'].values()),10)
        self.assertEqual(s['match_counts']['completed'],1)
        e.open('p1','b'*32)
        self.assertEqual(e.players['p1']['rounds'],10)
        e.open('p2','c'*32)
        self.assertEqual(e.players['p2']['rounds'],0)
    def test_active_player_collision(self):
        e=TestEngine();e.open('p1','a'*32)
        with self.assertRaisesRegex(RuleError,'MATCH_ACTIVE'):e.open('p1','b'*32)
    def test_contract_schema(self):
        c=json.loads((ROOT/'duel_config.json').read_text());a=json.loads((ROOT/'api_actions.json').read_text())
        sh=json.loads((ROOT/'sheet_headers.json').read_text())
        self.assertEqual(c['hands'],list(HANDS));self.assertEqual(c['beats'],BEATS)
        self.assertEqual(len(a),11);self.assertEqual(len(sh),9)
        self.assertEqual(c['match']['rounds'],10)
        self.assertEqual(set(a['round.submit']['payload']['player_hand']['enum']),set(HANDS))
        for cols in sh.values():self.assertEqual(len(cols),len(set(cols)))
    def test_hand_geometry(self):
        c=json.loads((ROOT/'duel_config.json').read_text())['display'];r=c['hand_button_radius']
        centers=c['hand_button_centers']
        for x,y in centers:self.assertLessEqual(math.hypot(x-240,y-240)+r,c['safe_radius'])
        for a,b in zip(centers,centers[1:]):self.assertGreaterEqual(math.dist(a,b),2*r+8)

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(DuelTests)
    runner=unittest.TextTestRunner(verbosity=2)
    out=runner.run(suite)
    vectors={'commit':{'match_id':'a'*32,'round_id':'b'*32,'round_no':1,'ai_hand':'ROCK','nonce':'c'*64,
                        'expected_sha256':commitment('a'*32,'b'*32,1,'ROCK','c'*64)},
             'pin':{'pepper_hex':(b'x'*32).hex(),'player_id':'p1','salt_hex':'a'*32,'pin':'123456',
                    'expected_hmac_sha256':pin_digest(b'x'*32,'p1','a'*32,'123456')},
             'greedy_counterexample':{'probabilities':dict(zip(HANDS,[.4,.35,.25])),
                                      'expected_margins':expected_margins(dict(zip(HANDS,[.4,.35,.25]))),'best':'ROCK'}}
    report={'scope':'reference_python_only','tests_run':out.testsRun,'failures':len(out.failures),
            'errors':len(out.errors),'passed':out.wasSuccessful(),'checks':COUNTS,
            'not_tested':['ESP32 compile/flash/touch','Apps Script deployment','real Google Sheets atomicity','real Jev API','real power and latency']}
    (ROOT/'test_vectors.json').write_text(json.dumps(vectors,ensure_ascii=False,indent=2)+'\n')
    (ROOT/'validation_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    raise SystemExit(0 if out.wasSuccessful() else 1)
