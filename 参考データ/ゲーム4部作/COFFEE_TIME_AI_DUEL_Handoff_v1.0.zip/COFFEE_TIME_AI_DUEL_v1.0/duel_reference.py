"""AI DUEL v1: executable reference logic, NOT ESP32 firmware or a GAS backend.
Python 3.10+, standard library only. The in-memory lock is a test double, not
proof of real Sheets concurrency. Production must use the specified GAS lock
and atomic Sheets batches. Randomness here is supplied by secrets.
"""
from __future__ import annotations
import copy
import hashlib
import hmac
import math
import secrets
import threading
from dataclasses import dataclass
from typing import Any

HANDS = ('ROCK', 'SCISSORS', 'PAPER')
BEATS = {'ROCK': 'SCISSORS', 'SCISSORS': 'PAPER', 'PAPER': 'ROCK'}
RESULTS = ('human_win', 'ai_win', 'draw')

class RuleError(ValueError):
    pass

def result(human: str, ai: str) -> str:
    if human not in HANDS or ai not in HANDS:
        raise RuleError('BAD_REQUEST')
    return 'draw' if human == ai else ('human_win' if BEATS[human] == ai else 'ai_win')

def normalize_probabilities(raw: dict[str, float]) -> dict[str, float]:
    if not isinstance(raw, dict) or set(raw) != set(HANDS):
        raise RuleError('INVALID_PROBABILITIES')
    if any(isinstance(x, bool) or not isinstance(x, (int, float))
           or not math.isfinite(x) or x < 0 or x > 1 for x in raw.values()):
        raise RuleError('INVALID_PROBABILITIES')
    s = sum(raw.values())
    if s <= 0 or abs(s - 1.0) > .001 + 1e-12:
        raise RuleError('INVALID_PROBABILITIES')
    return {h: raw[h] / s for h in HANDS}

def expected_margins(p: dict[str, float]) -> dict[str, float]:
    p = normalize_probabilities(p)
    return {a: sum((1 if BEATS[a] == h else -1 if BEATS[h] == a else 0) * p[h]
                   for h in HANDS) for a in HANDS}

def optimal_actions(p: dict[str, float]) -> list[str]:
    u = expected_margins(p)
    best = max(u.values())
    return [h for h in HANDS if abs(u[h] - best) <= 1e-9]

def choose_ai(p: dict[str, float]) -> str:
    return secrets.choice(optimal_actions(p))

def commitment(match_id: str, round_id: str, round_no: int, ai_hand: str, nonce: str) -> str:
    if ai_hand not in HANDS or not 1 <= round_no <= 10:
        raise RuleError('BAD_REQUEST')
    if any(len(x) != 32 or any(c not in '0123456789abcdef' for c in x) for x in (match_id, round_id)):
        raise RuleError('BAD_REQUEST')
    if len(nonce) != 64 or any(c not in '0123456789abcdef' for c in nonce):
        raise RuleError('BAD_REQUEST')
    text = f'AI_DUEL|1|{match_id}|{round_id}|{round_no}|{ai_hand}|{nonce}'
    return hashlib.sha256(text.encode('ascii')).hexdigest()

def pin_digest(pepper: bytes, player_id: str, salt_hex: str, pin: str) -> str:
    if len(pepper) < 32 or len(pin) != 6 or not pin.isascii() or not pin.isdigit():
        raise RuleError('BAD_PIN')
    msg = f'AI_DUEL_PIN|1|{player_id}|{salt_hex}|{pin}'.encode('utf-8')
    return hmac.new(pepper, msg, hashlib.sha256).hexdigest()

def zero_stats() -> dict[str, Any]:
    return {
        'stats_version':'duel-stats-1', 'rounds':0, 'hand_counts':[0,0,0],
        'outcome_counts':[0,0,0], 'first_hand_counts':[0,0,0],
        'transition_by_hand':[[0]*3 for _ in range(3)],
        'transition_by_hand_result':[[[0]*3 for _ in range(3)] for _ in range(3)],
        'repeat_after_result':[[0,0] for _ in range(3)],
        'tail':[], 'last_round_id':None,
        'prediction':{provider:{'n':0,'hits':0,'brier_sum':0.0,'nll_sum':0.0}
                      for provider in ('jev','stats')},
        'match_counts':{'completed':0,'human_win':0,'ai_win':0,'draw':0,'aborted':0},
    }

def append_resolved(stats: dict[str, Any], r: dict[str, Any]) -> dict[str, Any]:
    """Caller must enforce round idempotency BEFORE invoking this function."""
    s = copy.deepcopy(stats)
    if r['round_id'] == s['last_round_id']:
        raise RuleError('DUPLICATE_STATS_UPDATE')
    hi, ri = HANDS.index(r['player_hand']), RESULTS.index(r['player_result'])
    if result(r['player_hand'], r['ai_hand']) != r['player_result']:
        raise RuleError('RESULT_MISMATCH')
    previous = s['tail'][-1] if s['tail'] else None
    s['rounds'] += 1
    s['hand_counts'][hi] += 1
    s['outcome_counts'][ri] += 1
    if r['round_no'] == 1:
        s['first_hand_counts'][hi] += 1
    if previous and previous['match_id'] == r['match_id'] and previous['round_no'] + 1 == r['round_no']:
        pi = HANDS.index(previous['player_hand'])
        pri = RESULTS.index(previous['player_result'])
        s['transition_by_hand'][pi][hi] += 1
        s['transition_by_hand_result'][pi][pri][hi] += 1
        s['repeat_after_result'][pri][0 if hi == pi else 1] += 1
    provider = r['provider_used']
    p = normalize_probabilities(r['probabilities'])
    m = s['prediction'][provider]
    m['n'] += 1
    predicted = next(h for h in HANDS if p[h] == max(p.values()))
    m['hits'] += int(predicted == r['player_hand'])
    m['brier_sum'] += sum((p[h] - int(h == r['player_hand']))**2 for h in HANDS)
    m['nll_sum'] += -math.log(max(p[r['player_hand']], 1e-6))
    s['tail'].append({k:r[k] for k in ('round_id','match_id','round_no','player_hand','ai_hand','player_result')})
    s['tail'] = s['tail'][-50:]
    s['last_round_id'] = r['round_id']
    return s

def smooth(counts: list[int]) -> dict[str, float]:
    return {h:(counts[i]+1)/(sum(counts)+3) for i,h in enumerate(HANDS)}

def stats_prediction(s: dict[str, Any], match_id: str, round_no: int) -> dict[str, float]:
    components:list[tuple[float,dict[str,float]]] = [(0.15, smooth(s['hand_counts']))]
    recent = s['tail'][-20:]
    if recent:
        counts = [sum(r['player_hand'] == h for r in recent) for h in HANDS]
        components.append((0.25,smooth(counts)))
    previous = s['tail'][-1] if s['tail'] else None
    if round_no > 1 and previous and previous['match_id'] == match_id and previous['round_no'] == round_no-1:
        hi, ri = HANDS.index(previous['player_hand']), RESULTS.index(previous['player_result'])
        hcounts = s['transition_by_hand'][hi]
        rcounts = s['transition_by_hand_result'][hi][ri]
        if sum(hcounts) >= 5:
            components.append((0.30,smooth(hcounts)))
        if sum(rcounts) >= 8:
            components.append((0.30,smooth(rcounts)))
    ws = sum(w for w,_ in components)
    q = {h:sum(w*p[h] for w,p in components)/ws for h in HANDS}
    if round_no == 1 and sum(s['first_hand_counts']) >= 5:
        f = smooth(s['first_hand_counts'])
        q = {h:0.5*q[h]+0.5*f[h] for h in HANDS}
    return normalize_probabilities(q)

@dataclass
class TestEngine:
    """Reference state machine with an in-memory atomic critical section."""
    def __init__(self):
        self.lock=threading.RLock()
        self.players:dict[str,dict[str,Any]]={}
        self.matches:dict[str,dict[str,Any]]={}
        self.rounds:dict[str,dict[str,Any]]={}

    def open(self, player: str, match_id: str) -> dict[str,Any]:
        with self.lock:
            if match_id in self.matches:
                if self.matches[match_id]['player_id'] != player:
                    raise RuleError('FORBIDDEN')
                return copy.deepcopy(self.matches[match_id])
            if any(m['player_id']==player and m['status']=='active' for m in self.matches.values()):
                raise RuleError('MATCH_ACTIVE')
            self.players.setdefault(player,zero_stats())
            self.matches[match_id]={'player_id':player,'status':'active','resolved':0,'round_ids':[],
                                    'score':{'human_win':0,'ai_win':0,'draw':0}}
            return copy.deepcopy(self.matches[match_id])

    def reserve(self, match_id: str, round_no: int, now: int) -> dict[str,Any]:
        with self.lock:
            m=self.matches[match_id]
            # Natural-key replay also works after completion.
            if round_no <= len(m['round_ids']):
                r=self.rounds[m['round_ids'][round_no-1]]
                if r['status'] != 'preparing' or now < r['lease_until']:
                    return copy.deepcopy(r)
                r['generation_id']=secrets.token_hex(16)
                r['lease_until']=now+30
                return copy.deepcopy(r)
            if m['status']!='active':
                raise RuleError('MATCH_CLOSED')
            if round_no != m['resolved']+1 or round_no != len(m['round_ids'])+1:
                raise RuleError('ROUND_ORDER')
            rid=secrets.token_hex(16)
            r={'round_id':rid,'match_id':match_id,'round_no':round_no,'status':'preparing',
               'generation_id':secrets.token_hex(16),'lease_until':now+30,'player_id':m['player_id'],
               'history_count_before':self.players[m['player_id']]['rounds']}
            self.rounds[rid]=r
            m['round_ids'].append(rid)
            return copy.deepcopy(r)

    def commit(self, rid: str, gen: str, p: dict[str,float], now: int, provider: str='stats') -> dict[str,Any]:
        p=normalize_probabilities(p)
        with self.lock:
            r=self.rounds[rid]
            if r['status']!='preparing' or gen!=r['generation_id']:
                raise RuleError('STALE_GENERATION')
            if self.matches[r['match_id']]['status']!='active':
                raise RuleError('MATCH_CLOSED')
            if now >= r['lease_until']:
                raise RuleError('LEASE_EXPIRED')
            r.update(status='committed',ai_hand=choose_ai(p),probabilities=p,provider_used=provider,
                     nonce=secrets.token_hex(32),expires=now+300)
            r['commit_hash']=commitment(r['match_id'],rid,r['round_no'],r['ai_hand'],r['nonce'])
            return self.public(r)

    @staticmethod
    def public(r: dict[str,Any]) -> dict[str,Any]:
        allowed=('round_id','match_id','round_no','status','commit_hash','provider_used','expires')
        return {k:r[k] for k in allowed if k in r}

    def submit(self, rid: str, hand: str, commit_hash: str, now: int) -> dict[str,Any]:
        with self.lock:
            r=self.rounds[rid]
            if hand not in HANDS:
                raise RuleError('BAD_REQUEST')
            if not hmac.compare_digest(r.get('commit_hash',''),commit_hash):
                raise RuleError('COMMIT_MISMATCH')
            if r['status']=='resolved':
                if r['player_hand'] != hand:
                    raise RuleError('HAND_ALREADY_SUBMITTED')
                return copy.deepcopy(r)
            if r['status']!='committed':
                raise RuleError('ROUND_NOT_READY')
            if now > r['expires']:
                raise RuleError('ROUND_EXPIRED')
            r2=copy.deepcopy(r)
            r2.update(status='resolved',player_hand=hand,player_result=result(hand,r['ai_hand']))
            m2=copy.deepcopy(self.matches[r['match_id']])
            s2=append_resolved(self.players[r['player_id']],r2)
            m2['resolved']+=1
            m2['score'][r2['player_result']]+=1
            if m2['resolved']==10:
                m2['status']='completed'
                winner=('human_win' if m2['score']['human_win']>m2['score']['ai_win'] else
                        'ai_win' if m2['score']['human_win']<m2['score']['ai_win'] else 'draw')
                s2['match_counts']['completed']+=1
                s2['match_counts'][winner]+=1
            # Three assignments under one lock model one Sheets atomic batch.
            self.rounds[rid]=r2
            self.matches[r['match_id']]=m2
            self.players[r['player_id']]=s2
            return copy.deepcopy(r2)
