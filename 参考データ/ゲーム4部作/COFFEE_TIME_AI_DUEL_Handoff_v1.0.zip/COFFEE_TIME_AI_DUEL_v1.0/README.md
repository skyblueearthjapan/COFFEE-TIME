# COFFEE TIME / AI DUEL — 開発エージェント引継ぎ一式

正本：`COFFEE_TIME_AI_DUEL_Design_v1.0.md`

個人別履歴をGoogleスプレッドシートに保存し、Apps ScriptからJevを呼ぶ
ESP32-S3-Touch-LCD-2.8C向けじゃんけんゲームの設計資料です。
完成ファームウェアでも、本番デプロイ済みGASでもありません。

## 開始

1. 設計書の第0章を読み、既存のLCD・タッチ・コーヒー＋1・Google連携を保全。
2. Python 3.10以上で `python verify_duel.py` を実行。
3. 第18章の順で統計AI→個人履歴/GAS→Jev→実機UIへ実装。
4. `TEST_RECORD.md`の48項目を実試験し、結果と証拠を記録。

## 同梱内容

- 正本Markdown：ルール、全列定義、11操作、29エラー、UI、削除と復旧、API等。
- 4つの定義JSON：duel_config/api_actions/errors/sheet_headers。
- duel_reference.py：ロジックとメモリー上の状態機械の参考コード。
- verify_duel.py：25項目の標準ライブラリだけのテスト。
- test_vectors.json：他言語のhash/PIN計算等を照合する既知の試験値。
- validation_report.json / test_output.txt：実行済みPython検査の記録。
- extract_bundle.py：Markdownだけから8ファイルを抽出する任意の補助。
- TEST_RECORD.md：Google・Jev・ESP32の本番受入記録。初期値は全件NOT_RUN。
- SHA256SUMS.txt：一式内のファイル照合用。

## 注意

PIN/pepperの試験値は公開された固定値です。本番へ流用しないでください。
Jev/APIキー、端末token、実Spreadsheet ID、Wi-Fi情報、フォントファイルは含みません。
Pythonのテスト成功を、ESP32/GAS/実Google Sheets/Jev接続の成功と同一視しないでください。
公開候補へ最適な手を選ぶ参考ロジックがあっても、Jevが人間を高精度で読める保証ではありません。
