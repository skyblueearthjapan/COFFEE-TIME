"""Extract the eight embedded implementation-design files, without executing them.
Usage: python extract_bundle.py DESIGN.md DESTINATION
Existing files are not overwritten. Python 3.10+, standard library only.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import re

ALLOWED = (
    'duel_config.json', 'api_actions.json', 'errors.json', 'sheet_headers.json',
    'duel_reference.py', 'verify_duel.py', 'test_vectors.json', 'validation_report.json',
)

def extract(markdown: Path, destination: Path) -> list[Path]:
    text = markdown.read_text(encoding='utf-8')
    pattern = r'^### File: ([A-Za-z0-9_.]+)\n\n```[A-Za-z0-9_]*\n(.*?)^```[ \t]*$'
    blocks = re.findall(pattern, text, flags=re.MULTILINE | re.DOTALL)
    names = [name for name, _ in blocks]
    if len(names) != len(set(names)) or set(names) != set(ALLOWED):
        raise ValueError('Embedded file set is missing, duplicated, or unexpected.')
    destination.mkdir(parents=True, exist_ok=True)
    for name in ALLOWED:
        if (destination / name).exists():
            raise FileExistsError(f'Will not overwrite: {destination / name}')
    written: list[Path] = []
    for name, contents in blocks:
        target = destination / name
        with target.open('x', encoding='utf-8', newline='\n') as handle:
            handle.write(contents)
        written.append(target)
    return written

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('markdown', type=Path)
    parser.add_argument('destination', type=Path)
    args = parser.parse_args()
    for target in extract(args.markdown, args.destination):
        print(target.name)
