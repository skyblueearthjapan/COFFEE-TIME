'use strict';
const fs=require('node:fs'); const path=require('node:path'); const root=path.join(__dirname,'..');
const safeScript=s=>s.replace(/<\/script/gi,'<\\/script');
let t=fs.readFileSync(path.join(root,'prototype/template.html'),'utf8');
const core=fs.readFileSync(path.join(root,'reference/detective_core.js'),'utf8');
const pack=JSON.parse(fs.readFileSync(path.join(root,'data/catalog.author.json'),'utf8'));
t=t.replace('/*__CORE__*/',()=>safeScript(core)).replace('/*__PACK__*/',()=>safeScript(JSON.stringify(pack)));
fs.writeFileSync(path.join(root,'prototype/prototype.html'),t,'utf8');
console.log('Built standalone story prototype:',Buffer.byteLength(t),'bytes');
