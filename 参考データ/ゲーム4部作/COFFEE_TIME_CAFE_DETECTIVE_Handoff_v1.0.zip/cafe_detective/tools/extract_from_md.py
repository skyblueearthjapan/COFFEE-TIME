"""Extract the embedded source files from the specification. No code is executed.
Usage: python extract_from_md.py specification.md new_empty_output_dir
"""
from __future__ import annotations
import hashlib
import re
import sys
from pathlib import Path, PurePosixPath

PATTERN = re.compile(r'^<!-- BEGIN_FILE path="([A-Za-z0-9_./-]+)" sha256="([a-f0-9]{64})" -->\n````[a-zA-Z0-9]*\n(.*?)^````\n<!-- END_FILE -->$', re.M | re.S)

def extract(source: Path, destination: Path) -> int:
    # read_bytes preserves the exact LF endings protected by the block digest.
    raw = source.read_bytes().decode('utf-8')
    blocks = PATTERN.findall(raw)
    if not blocks:
        raise ValueError('No embedded file blocks found. Do not use a reformatted copy.')
    if destination.exists() and (destination.is_symlink() or any(destination.iterdir())):
        raise ValueError('Use a new or empty output directory; existing work will not be overwritten.')
    seen = set()
    verified = []
    for relative, digest, body in blocks:
        p = PurePosixPath(relative)
        if p.is_absolute() or any(x in ('', '.', '..') for x in p.parts) or relative in seen:
            raise ValueError('Unsafe or duplicate relative path: ' + relative)
        seen.add(relative)
        data = body.encode('utf-8')
        if hashlib.sha256(data).hexdigest() != digest:
            raise ValueError('Digest mismatch (possibly altered line endings): ' + relative)
        verified.append((p, data))
    destination.mkdir(parents=True, exist_ok=True)
    base = destination.resolve()
    for p, data in verified:
        target = destination.joinpath(*p.parts)
        if not target.resolve().is_relative_to(base):
            raise ValueError('Path escapes destination: ' + str(p))
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    return len(verified)

if __name__ == '__main__':
    if len(sys.argv) != 3:
        raise SystemExit('Usage: python extract_from_md.py specification.md new_empty_output_dir')
    try:
        count = extract(Path(sys.argv[1]), Path(sys.argv[2]))
    except (ValueError, OSError, UnicodeError) as e:
        raise SystemExit('Extraction stopped: ' + str(e)) from e
    print(f'Extracted and SHA-256-verified {count} files. No code was executed.')
