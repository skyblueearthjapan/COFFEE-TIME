#include "../reference/DetectiveGate.hpp"
#include <cassert>
#include <iostream>
int main(){
 cd::Gate g;assert(!g.choose(0));g.enableChoices();assert(!g.choose(3));assert(g.choose(1));assert(!g.choose(2));assert(g.change());
 assert(g.choose(2));assert(!g.submit(0));assert(g.submit(71));assert(!g.submit(72));auto epoch=g.epoch();
 assert(!g.receive(epoch,72,true));assert(g.receive(epoch,71,false));assert(g.stage()==cd::Gate::Stage::Pending);
 assert(g.receive(epoch,71,true));assert(g.stage()==cd::Gate::Stage::Result);assert(!g.receive(epoch,71,true));
 g.newScreen();g.enableChoices();assert(g.choose(0));assert(g.submit(73));epoch=g.epoch();g.detach();
 assert(!g.receive(epoch,73,true));std::cout<<"18 UI gate assertions passed\n";
}
