"""Optional Playwright smoke test. Requires installed Playwright + Chromium.
This tests the PC solo preview, not ESP32/GAS/Jev. No Internet is used.
"""
import json, os, shutil
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
report={"scope":"offline_PC_story_preview", "cases":[], "browser_errors":[], "paths":[],"hardware_tested":False}
with sync_playwright() as pw:
    exe=os.environ.get("CHROMIUM_EXECUTABLE") or shutil.which("chromium")
    browser=pw.chromium.launch(headless=True,**({"executable_path":exe} if exe else {}))
    page=browser.new_page(viewport={"width":900,"height":950})
    page.on("pageerror",lambda e:report["browser_errors"].append(str(e)))
    page.set_content((ROOT/'prototype/prototype.html').read_text(encoding='utf8'),wait_until='load')
    page.wait_for_selector('#screen button')
    def state(): return page.evaluate('CafePreview.getState()')
    def advance():
        steps=0
        while state()['screen']=='page':
            bs=page.locator('#screen button');bs.last.click();steps+=1
            assert steps<60,'Unexpected page loop'
        return steps
    for idx,answer in enumerate(['チャイ','ラテ','モカ']):
        page.get_by_role('button',name='作品一覧へ',exact=True).first.click()
        page.locator('#screen button').nth(idx).click()
        page.get_by_role('button',name='はじめる',exact=True).click()
        pages=advance();assert state()['screen']=='hub'
        if idx==0:
            page.get_by_role('button',name='店の様子',exact=True).click();advance()
        for ci in range(3):
            page.locator('#screen button').nth(ci).click();pages+=advance()
        page.get_by_role('button',name='手帳まとめ',exact=True).click();advance()
        page.get_by_role('button',name='推理する',exact=True).click()
        page.get_by_role('button',name=answer,exact=True).click()
        page.get_by_role('button',name='決定',exact=True).click()
        assert '謎がつながりました' in page.locator('#screen').inner_text()
        page.get_by_role('button',name='理由と物語へ',exact=True).click();pages+=advance()
        assert state()['screen']=='collect'
        assert 'undefined' not in page.locator('#screen').inner_text()
        report['cases'].append({'id':'CD00'+str(idx+1),'result':'PASS','pages_read':pages})
        page.locator('#screen').get_by_role('button',name='作品一覧へ',exact=True).click()
    # Hint + wrong answer, then all narrative endings still available.
    page.locator('#screen button').first.click();page.get_by_role('button',name='読み直す',exact=True).click();advance()
    page.get_by_role('button',name='ヒント',exact=True).click();advance()
    for ci in range(3):page.locator('#screen button').nth(ci).click();advance()
    page.get_by_role('button',name='推理する',exact=True).click();page.get_by_role('button',name='ラテ',exact=True).click();page.get_by_role('button',name='決定',exact=True).click()
    assert 'もう一度' in page.locator('#screen').inner_text()
    page.get_by_role('button',name='理由と物語へ',exact=True).click();advance();assert state()['screen']=='collect'
    report['paths'].append('hint_wrong_answer_full_ending_PASS')
    page.locator('#screen').get_by_role('button',name='作品一覧へ',exact=True).click()
    page.locator('#screen button').nth(2).click();page.get_by_role('button',name='読み直す',exact=True).click();advance()
    page.get_by_role('button',name='答えを見て物語を続ける',exact=True).click();advance();assert state()['screen']=='result'
    page.get_by_role('button',name='理由と物語へ',exact=True).click();advance();assert state()['screen']=='collect'
    report['paths'].append('give_up_full_ending_PASS')
    page.get_by_role('button',name='コーヒー ＋1（デモ）',exact=True).click();assert state()['coffee']==1
    report['paths'].append('separate_coffee_demo_PASS')
    # Reading width is consistent at narrow phone viewport as well.
    page.set_viewport_size({'width':390,'height':850})
    box=page.locator('#holder').bounding_box();assert box['width']<=358.1
    report['paths'].append('responsive_390px_PASS')
    assert not report['browser_errors'],report['browser_errors']
    page.screenshot(path=str(ROOT/'docs/preview_check.png'))
    browser.close()
report['status']='PASS'
(ROOT/'docs/browser_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(report,ensure_ascii=False,indent=2))
