'use strict';
const assert=require('node:assert/strict'),crypto=require('node:crypto');
const P=require('../reference/sheets_plan.js'),C=require('../reference/detective_core.js');
const hash=o=>crypto.createHash('sha256').update(C.canonical(o)).digest('hex');
assert.equal(P.cell('=IMPORTDATA("x")').userEnteredValue.stringValue,'=IMPORTDATA("x")');
assert.equal(P.cell(true).userEnteredValue.boolValue,true);assert.equal(P.cell(4).userEnteredValue.numberValue,4);
assert.throws(()=>P.cell(NaN));assert.throws(()=>P.row(1,0,['x']));
assert.throws(()=>P.plan([{sheet_id:1,row_index0:1,values:['x']},{sheet_id:1,row_index0:1,values:['y']}]));
assert.equal(P.plan([{sheet_id:1,row_index0:1,values:['x']}]).requests[0].updateCells.fields,'userEnteredValue');
// Serial mock durable store. Validates application-level replay semantics, NOT Google's concurrency behavior.
class Store {
 constructor(){this.receipts=new Map();this.result=null;this.count=0;this.lock=Promise.resolve();}
 request(id,choice){const job=this.lock.then(()=>{
  const fp=hash({choice});if(this.receipts.has(id)){const r=this.receipts.get(id);if(r.fp!==fp)throw Error('REQUEST_CONFLICT');return r.response;}
  if(this.result && this.result.choice!==choice)throw Error('ANSWER_ALREADY_LOCKED');
  const r=this.result||{choice,seq:1};if(!this.result){this.result=r;this.count++;}
  this.receipts.set(id,{fp,response:r});return r;
 });this.lock=job.catch(()=>{});return job;}
}
(async()=>{const s=new Store();const all=await Promise.all(Array.from({length:64},()=>s.request('same','CHAI')));
 assert.equal(s.count,1);assert(all.every(x=>x===all[0]));
 await assert.rejects(()=>s.request('same','LATTE'),/REQUEST_CONFLICT/);
 await assert.rejects(()=>s.request('different','LATTE'),/ANSWER_ALREADY_LOCKED/);
 assert.equal((await s.request('new-id-same-choice','CHAI')).choice,'CHAI');assert.equal(s.count,1);
 console.log('Storage plan checks and 64 parallel mock replays passed');
})().catch(e=>{console.error(e);process.exitCode=1;});
