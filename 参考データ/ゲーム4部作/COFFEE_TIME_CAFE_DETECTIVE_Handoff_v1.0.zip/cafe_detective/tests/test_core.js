'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');const path=require('node:path');const crypto=require('node:crypto');
const C=require('../reference/detective_core.js');
const pack=JSON.parse(fs.readFileSync(path.join(__dirname,'../data/catalog.author.json'),'utf8'));
const sha=x=>crypto.createHash('sha256').update(x,'utf8').digest('hex');
const tests=[];function test(name,fn){tests.push({name,fn});}
function throws(code,fn){assert.throws(fn,e=>e.code===code);}
const ep=pack.episodes[0], ids=ep.public.options.map(x=>x.id);
const raw={model:'jev-test-fixture',answers:{answer:{type:'choice',choice:'CHAI',probabilities:{LATTE:0.1,MOCHA:0.2,CHAI:0.7},confidence:0.6}},usage:{input_tokens:1,output_tokens:1}};
const pred=C.normalizePrediction(raw,ids);
const meta={attempt_id:'1'.repeat(32),actor_id:'2'.repeat(32),device_id:'3'.repeat(32),public_hash:sha(C.canonical(C.publicCase(ep))),mode:'jev',now_ms:1000,practice:false};
function allRead(mode='jev'){let a=C.begin(ep,{...meta,mode});return C.progress(a,ep,['E1','E2','E3'],1001);}
function ready(){let a=C.prepare(allRead(),ep,1002);return C.commit(a,pred,a.generation,1003,'a'.repeat(64),sha).state;}
for(const e of pack.episodes){
 test(e.case_id+' single correct answer',()=>{const r=C.solve(e);assert.equal(r.legal_count,e.private.solver.expected_legal_worlds);assert.equal(r.solutions.length,1);assert.deepEqual(r.answer_ids,[e.private.answer_id]);});
 test(e.case_id+' all display IDs unique and reachable',()=>{assert.equal(new Set(e.public.clues.map(c=>c.id)).size,3);assert.equal(e.public.options.length,3);assert.equal(new Set(e.public.options.map(x=>x.id)).size,3);for(const c of e.public.clues){assert(c.pages.length);assert(c.summary.length);}});
 test(e.case_id+' all wrong choices have feedback',()=>{const wrong=e.public.options.filter(x=>x.id!==e.private.answer_id).map(x=>x.id).sort();assert.deepEqual(Object.keys(e.private.wrong_feedback).sort(),wrong);});
 test(e.case_id+' no spoiler keys in public projection',()=>{const s=JSON.stringify(C.publicCase({...e, private:{...e.private,canary:'TOP_SECRET_CANARY'}}));for(const k of ['TOP_SECRET_CANARY','answer_id','solver','wrong_feedback','epilogue','collectible'])assert(!s.includes(k));});
 test(e.case_id+' model request only sees pre-answer human text',()=>{const s=JSON.stringify(C.modelRequest(e,'jev-fixture'));for(const k of ['answer_id','solver','epilogue','hint','player_id','COCOA'])assert(!s.includes(k));assert.equal(Object.keys(C.modelRequest(e,'x').questions).length,1);});
 test(e.case_id+' choice order invariant in solver',()=>{for(const p of [[0,1,2],[0,2,1],[1,0,2],[1,2,0],[2,0,1],[2,1,0]]){const clone=structuredClone(e);clone.public.options=p.map(i=>e.public.options[i]);assert.deepEqual(C.solve(clone).answer_ids,[e.private.answer_id]);}});
}
for(const e of pack.episodes.slice(0,2)) for(const id of ['E1','E2','E3'])test(e.case_id+' removal of '+id+' makes answer ambiguous',()=>assert(C.solve(e,id).answer_ids.length>1));
test('CD003 full truth table',()=>{const e=pack.episodes[2],s=e.private.solver;assert.deepEqual(C.enumerate(s).worlds.map(w=>({name:w.giver,wrong:s.statements.filter(t=>!C.evalExpr(t.expr,w)).length})),[{name:'LATTE',wrong:2},{name:'MOCHA',wrong:1},{name:'CHAI',wrong:2}]);});
test('canonical stable key order',()=>assert.equal(C.canonical({b:[2,1],a:3}),C.canonical({a:3,b:[2,1]})));
test('nonfinite refused',()=>throws('NON_FINITE',()=>C.canonical({a:NaN})));
test('unknown operator rejected',()=>throws('UNKNOWN_OP',()=>C.evalExpr({op:'eval',code:'process.exit()'},{})));
test('missing world variable refused',()=>throws('BAD_VAR',()=>C.evalExpr({var:'x'},{})));
test('huge domain refused',()=>throws('DOMAIN_TOO_LARGE',()=>C.enumerate({domains:{a:Array.from({length:100001},(_,i)=>i)},all_different:[]})));
test('prediction normal',()=>assert.equal(pred.choice,'CHAI'));
for(const [name,edit] of [
 ['extra option',x=>x.answers.answer.probabilities.OTHER=0],['missing option',x=>delete x.answers.answer.probabilities.LATTE],
 ['negative',x=>x.answers.answer.probabilities.LATTE=-1],['sum off',x=>x.answers.answer.probabilities.LATTE=0.8],
 ['probability string',x=>x.answers.answer.probabilities.LATTE='0.1'],['confidence NaN',x=>x.answers.answer.confidence=NaN],
 ['wrong max',x=>x.answers.answer.choice='LATTE'],['missing model',x=>delete x.model],['negative tokens',x=>x.usage.input_tokens=-1],
 ['unrecognized choice',x=>x.answers.answer.choice='X']])test('reject '+name,()=>{let x=structuredClone(raw);edit(x);throws('PROVIDER_INVALID',()=>C.normalizePrediction(x,ids));});
test('all evidence required',()=>throws('EVIDENCE_REQUIRED',()=>C.prepare(C.begin(ep,meta),ep,1002)));
test('invalid clue rejected',()=>throws('BAD_EVIDENCE_ID',()=>C.progress(allRead(),ep,['E9'],1002)));
test('progress sets do not duplicate',()=>assert.equal(C.progress(allRead(),ep,['E1'],1002).seen_ids.length,3));
test('hint order enforced',()=>throws('HINT_ORDER',()=>C.hint(allRead(),2,1002)));
test('hint level latches',()=>{const a=C.hint(C.hint(allRead(),1,1002),2,1003);assert.equal(C.hint(a,1,1004).hint_level,2);});
test('prepare retried preserves generation',()=>{const a=C.prepare(allRead(),ep,1002);assert.deepEqual(C.prepare(a,ep,1003),a);});
test('commit before deadline',()=>assert.equal(ready().mode_effective,'jev'));
test('late commit ignored',()=>{const a=C.prepare(allRead(),ep,1002);assert.equal(C.commit(a,pred,a.generation,21002,'a'.repeat(64),sha).applied,false);});
test('wrong generation ignored',()=>{const a=C.prepare(allRead(),ep,1002);assert.equal(C.commit(a,pred,999,1003,'a'.repeat(64),sha).applied,false);});
test('fallback late result ignored',()=>{let a=C.prepare(allRead(),ep,1002);const g=a.generation;a=C.fallback(a,1003,'timeout');assert.equal(C.commit(a,pred,g,1004,'a'.repeat(64),sha).applied,false);});
test('committed cannot change to solo',()=>throws('COMMIT_FROZEN',()=>C.fallback(ready(),1004,'error')));
test('hidden AI choice until resolution',()=>{const s=JSON.stringify(C.publicAttempt(ready()));assert(!s.includes('probabilities'));assert(!s.includes('nonce_hex'));assert(!s.includes('CHAI'));});
test('commit hash agrees before reveal',()=>{const a=ready();assert.equal(sha(C.commitText(a)),a.commit_hash);});
test('tampering changes commit',()=>{const a=ready(),b=structuredClone(a);b.prediction.probabilities.CHAI=.6;assert.notEqual(sha(C.commitText(b)),a.commit_hash);});
test('submit only when ready',()=>throws('NOT_READY',()=>C.resolve(allRead(),ep,'CHAI',1002)));
test('first resolution',()=>{const a=C.resolve(ready(),ep,'CHAI',1004);assert.equal(a.phase,'resolved');assert.equal(a.result.comparison,'both_correct');});
test('same answer replay stable',()=>{const a=C.resolve(ready(),ep,'CHAI',1004);assert.deepEqual(C.resolve(a,ep,'CHAI',999999999),a);});
test('different answer replay blocked',()=>{const a=C.resolve(ready(),ep,'CHAI',1004);throws('ANSWER_ALREADY_LOCKED',()=>C.resolve(a,ep,'MOCHA',1005));});
test('give up while investigating allowed',()=>{const a=C.resolve(C.begin(ep,meta),ep,null,1003);assert(a.result.gave_up);assert.equal(a.result.comparison,'not_compared');});
test('hint excludes duel',()=>{let a=C.hint(ready(),1,1004);assert.equal(C.resolve(a,ep,'CHAI',1005).result.comparison,'not_compared');});
test('practice excludes duel',()=>{let a=ready();a.practice=true;assert.equal(C.resolve(a,ep,'CHAI',1005).result.comparison,'not_compared');});
test('solo has no fake AI',()=>{const a=C.resolve(C.prepare(allRead('solo'),ep,1003),ep,'CHAI',1004);assert.equal(a.result.ai_correct,null);assert.equal(a.result.comparison,'not_compared');});
test('all four honest comparison results',()=>{for(const h of ids)for(const ai of ids){const r=C.outcome(ep,h,{...pred,choice:ai},{practice:false,hint_level:0});const hc=h==='CHAI',ac=ai==='CHAI';assert.equal(r.comparison,hc?(ac?'both_correct':'human_win'):(ac?'ai_win':'both_incorrect'));}});
test('pause refuses mutations',()=>throws('ATTEMPT_PAUSED',()=>C.progress(C.pause(allRead(),1003),ep,['E1'],1004)));
test('resume preserved clue history',()=>assert.deepEqual(C.resume(C.pause(allRead(),1003),1004).seen_ids,allRead().seen_ids));
test('abandoned late commit ignored',()=>{let a=C.prepare(allRead(),ep,1002);const g=a.generation;a=C.abandon(a,1003);assert.equal(C.commit(a,pred,g,1004,'a'.repeat(64),sha).applied,false);});
test('expiry boundary is exclusive',()=>{const a=allRead();throws('ATTEMPT_EXPIRED',()=>C.hint(a,1,a.expires_at_ms));});
test('reveal generation validates original commit',()=>{const a=C.resolve(ready(),ep,'CHAI',1004),p=C.publicAttempt(a);const restore={...a,generation:p.ai_reveal.committed_generation,prediction:p.ai_reveal.prediction,nonce_hex:p.ai_reveal.nonce_hex};assert.equal(sha(C.commitText(restore)),a.commit_hash);});
test('exact commitment bytes verify after resolve',()=>{const b=ready();const a=C.resolve(b,ep,'CHAI',1004),p=C.publicAttempt(a);assert.equal(sha(p.ai_reveal.commit_payload),b.commit_hash);const wire=JSON.parse(p.ai_reveal.commit_payload.split('\n')[1]);assert.equal(wire.attempt_id,a.attempt_id);assert.equal(wire.choice,p.ai_reveal.prediction.choice);assert.equal(wire.public_hash,a.public_hash);});
test('exact commitment bytes are hidden before answer',()=>{assert(!Object.hasOwn(C.publicAttempt(ready()),'commit_payload'));assert(!JSON.stringify(C.publicAttempt(ready())).includes('CAFE_DETECTIVE_COMMIT_V1'));});
let passed=0;const details=[];
for(const t of tests){try{t.fn();passed++;details.push({name:t.name,status:'PASS'});}catch(e){details.push({name:t.name,status:'FAIL',error:String(e)});console.error('FAIL',t.name,e);}}
const report={suite:'cafe_detective_reference_core',node:process.version,passed,total:tests.length,failed:tests.length-passed,details,
  cases:pack.episodes.map(e=>({id:e.case_id,...C.solve(e)})),limitations:['No live Jev calls','No Google Apps Script/Sheets execution','No ESP32 firmware build or device test','Japanese prose-to-logic correspondence needs editorial review beyond these structural checks']};
fs.writeFileSync(path.join(__dirname,'../docs/verification_report.json'),JSON.stringify(report,null,2)+'\n');
console.log(`${passed}/${tests.length} tests passed`);if(passed!==tests.length)process.exit(1);
