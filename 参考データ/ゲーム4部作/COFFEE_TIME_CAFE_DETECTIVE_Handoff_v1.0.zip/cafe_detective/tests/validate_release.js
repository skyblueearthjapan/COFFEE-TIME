'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const R=path.resolve(__dirname,'..');const load=p=>JSON.parse(fs.readFileSync(path.join(R,p),'utf8'));
const pack=load('data/catalog.author.json'),cfg=load('data/config.json'),api=load('data/api_contract.json');
const cids=new Set(pack.characters.map(c=>c.id)),emotions=new Set(['neutral','puzzled','soft','smile']);
let pages=0;let maxPageChars=0;let maximumConservativeLines=0;
function textpage(p){
 assert(cids.has(p.speaker));assert(emotions.has(p.emotion));assert(typeof p.text==='string'&&p.text.length>0);
 assert(!/TODO|TBD|あとで追加|未記入/.test(p.text));
 const chars=[...p.text];maxPageChars=Math.max(maxPageChars,chars.length);
 // Conservative Japanese full-width estimate; real font measurement is a hardware acceptance test.
 const lines=p.text.split('\n').reduce((n,line)=>n+Math.ceil([...line].reduce((v,c)=>v+(c.charCodeAt(0)<128?.55:1),0)/(300/22)),0);
 maximumConservativeLines=Math.max(maximumConservativeLines,lines);assert(lines<=6,'oversized page: '+p.text);pages++;
}
for(const e of pack.episodes){
 for(const ps of [e.public.intro,e.public.premises,e.private.explanation,e.private.epilogue,e.private.recap])ps.forEach(textpage);
 e.public.clues.forEach(c=>c.pages.forEach(textpage));e.public.hints.forEach(h=>h.pages.forEach(textpage));e.public.ambient.forEach(a=>a.pages.forEach(textpage));
 assert.deepEqual(e.public.hints.map(h=>h.level),[1,2]);
 assert.equal(e.public.options.filter(o=>o.id==='COCOA').length,0);
}
assert.equal(api.operations.length,15);assert.equal(new Set(api.operations.map(x=>x.action)).size,15);
assert.equal(api.operations.filter(x=>x.auth==='device').length,2);
assert.equal(Object.keys(load('data/sheets_schema.json').sheets).length,6);
const boxes=[[140,48,200,32],[78,96,74,48],[160,98,160,36],[90,154,300,184],[92,342,64,52],[180,348,120,52],[324,342,64,52],[144,410,192,24],...[0,1,2].map(i=>[96,148+68*i,288,56])];
for(const [x,y,w,h]of boxes)for(const a of [x,x+w])for(const b of [y,y+h])assert(Math.hypot(a-240,b-240)<=cfg.display.safe_radius,'out of safe circle '+[x,y,w,h]);
assert.equal(cfg.namespace,'cafe_detective');assert.equal(cfg.attempt_ttl_ms,86400000);assert.equal(cfg.prepare_lease_ms,20000);
const report={pages,maxPageChars,maximumConservativeLines,layout_boxes:boxes.length,api_operations:api.operations.length,sheets:6,characters:pack.characters.length,episodes:pack.episodes.length,reference_only:true};
fs.writeFileSync(path.join(R,'docs/content_validation.json'),JSON.stringify(report,null,2)+'\n');
console.log(report);
