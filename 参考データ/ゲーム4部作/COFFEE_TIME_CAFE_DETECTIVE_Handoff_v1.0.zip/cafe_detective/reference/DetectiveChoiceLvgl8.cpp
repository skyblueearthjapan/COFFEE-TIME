// Reference screen fragment for an EXISTING LVGL 8 port. Not a complete sketch.
#include <lvgl.h>
#include <stdint.h>
struct CdChoiceContext {
  uint32_t epoch;
  bool enabled;
  const lv_font_t* jp_font; // supplied by application; no font file is bundled
  bool (*enqueue)(uint32_t epoch, uint8_t choice_index); // nonblocking queue
};
struct CdButtonContext { CdChoiceContext* app; uint8_t index; };
// Single shared screen instance; stored contexts outlive their LVGL buttons.
static CdButtonContext cd_buttons[3];
static void cd_choice_clicked(lv_event_t* event) {
  if(lv_event_get_code(event)!=LV_EVENT_CLICKED)return;
  auto* b=static_cast<CdButtonContext*>(lv_event_get_user_data(event));
  if(!b||!b->app||!b->app->enabled)return;
  // Controller opens a separate confirmation page. This is NOT submit to GAS.
  b->app->enabled=false;
  if(!b->app->enqueue(b->app->epoch,b->index))b->app->enabled=true;
}
lv_obj_t* cd_make_choices(lv_obj_t* parent,CdChoiceContext* ctx,const char* names[3]) {
  if(!parent||!ctx||!ctx->jp_font||!ctx->enqueue)return nullptr;
  lv_obj_t* root=lv_obj_create(parent);
  lv_obj_set_size(root,480,480);lv_obj_set_pos(root,0,0);
  lv_obj_clear_flag(root,LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_set_style_pad_all(root,0,0);lv_obj_set_style_border_width(root,0,0);
  lv_obj_set_style_bg_color(root,lv_color_hex(0xF4EEE3),0);
  lv_obj_t* title=lv_label_create(root);
  lv_obj_set_style_text_font(title,ctx->jp_font,0);lv_label_set_text(title,"誰だと思う？");
  lv_obj_set_width(title,280);lv_obj_set_pos(title,100,90);
  lv_obj_set_style_text_align(title,LV_TEXT_ALIGN_CENTER,0);
  for(uint8_t i=0;i<3;i++){
    auto* button=lv_btn_create(root);lv_obj_set_pos(button,96,148+i*68);lv_obj_set_size(button,288,56);
    lv_obj_set_style_radius(button,16,0);lv_obj_set_style_bg_color(button,lv_color_hex(0x5B6554),0);
    auto* label=lv_label_create(button);lv_obj_set_style_text_font(label,ctx->jp_font,0);
    lv_label_set_text(label,names[i]);lv_obj_center(label);
    cd_buttons[i]={ctx,i};lv_obj_add_event_cb(button,cd_choice_clicked,LV_EVENT_CLICKED,&cd_buttons[i]);
  }
  ctx->enabled=true;return root;
}
// Call only on UI task (or under the existing LVGL mutex). Delete root before
// reusing cd_buttons. Never free ctx while callbacks can still reference it.
