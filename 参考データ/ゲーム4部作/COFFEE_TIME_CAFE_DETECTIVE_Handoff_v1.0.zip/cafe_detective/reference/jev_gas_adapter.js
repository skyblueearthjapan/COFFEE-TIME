/* GAS V8 reference. Install DetectiveCore first. Live Google/Jev execution is untested here. */
function CD_sha256(text) {
  return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,text,Utilities.Charset.UTF_8)
    .map(function(b){return ('0'+(b&255).toString(16)).slice(-2);}).join('');
}
function CD_jevOnce(episode, model) {
  var key=PropertiesService.getScriptProperties().getProperty('JEV_API_KEY');
  if(!key)return {ok:false,reason:'NO_KEY'};
  var request=DetectiveCore.modelRequest(episode,model);
  // No user ID, answer key, hints, recap, story ending or prior history is in request.
  try {
    var r=UrlFetchApp.fetch('https://api.typesafe.ai/v1/systemone',{
      method:'post',contentType:'application/json',headers:{Authorization:'Bearer '+key},
      payload:JSON.stringify(request),muteHttpExceptions:true,followRedirects:false,
      validateHttpsCertificates:true,timeoutSeconds:8
    });
    var status=r.getResponseCode();
    if(status!==200)return {ok:false,reason:'PROVIDER_HTTP_'+status};
    var text=r.getContentText('UTF-8');
    if(Utilities.newBlob(text).getBytes().length>32768)return {ok:false,reason:'PROVIDER_TOO_LARGE'};
    var p=DetectiveCore.normalizePrediction(JSON.parse(text),episode.public.options.map(function(o){return o.id;}));
    if(p.model!==model)return {ok:false,reason:'MODEL_MISMATCH'};
    return {ok:true,prediction:p};
  } catch(e) {
    // Do not log request body, API key or raw provider error. Record a short category.
    return {ok:false,reason:e&&e.code==='PROVIDER_INVALID'?'PROVIDER_INVALID':'PROVIDER_TRANSPORT'};
  }
}
function CD_jsonResponse(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
// Existing doPost should route namespace=cafe_detective to its authenticated router.
// This file deliberately has no doPost: adding a second global doPost would break the existing app.
