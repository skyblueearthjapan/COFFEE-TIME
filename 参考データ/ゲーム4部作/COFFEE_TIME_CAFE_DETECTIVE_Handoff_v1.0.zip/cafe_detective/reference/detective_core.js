/* Original reference domain core. Pure JS: usable in Node tests or GAS V8.
 * Does NOT provide network authentication, durable transactions or a board driver. */
var DetectiveCore = (function () {
  'use strict';
  class DomainError extends Error { constructor(code) { super(code); this.code = code; } }
  const fail = c => { throw new DomainError(c); };
  const copy = x => JSON.parse(JSON.stringify(x));
  function require_(ok, code) { if (!ok) fail(code); }
  function canonical(x) {
    if (x === null || typeof x === 'boolean' || typeof x === 'string') return JSON.stringify(x);
    if (typeof x === 'number') { require_(Number.isFinite(x), 'NON_FINITE'); return JSON.stringify(x); }
    if (Array.isArray(x)) return '[' + x.map(canonical).join(',') + ']';
    require_(typeof x === 'object' && (Object.getPrototypeOf(x) === Object.prototype || Object.getPrototypeOf(x) === null), 'BAD_OBJECT');
    return '{' + Object.keys(x).sort().map(k => JSON.stringify(k) + ':' + canonical(x[k])).join(',') + '}';
  }
  function evalExpr(e, world, depth = 0) {
    require_(e && typeof e === 'object' && depth <= 32, 'BAD_EXPR');
    if (Object.prototype.hasOwnProperty.call(e, 'lit')) return e.lit;
    if (Object.prototype.hasOwnProperty.call(e, 'var')) { require_(Object.prototype.hasOwnProperty.call(world, e.var), 'BAD_VAR'); return world[e.var]; }
    const rec = v => evalExpr(v, world, depth + 1);
    switch (e.op) {
      case 'eq': return rec(e.a) === rec(e.b);
      case 'lt': { const a=rec(e.a), b=rec(e.b); require_(typeof a==='number'&&typeof b==='number', 'BAD_LT'); return a < b; }
      case 'not': { const b=rec(e.x); require_(typeof b==='boolean','BAD_BOOL'); return !b; }
      case 'and': require_(Array.isArray(e.xs)&&e.xs.length>0,'BAD_AND'); return e.xs.every(v => { const b=rec(v); require_(typeof b==='boolean','BAD_BOOL'); return b; });
      case 'exactly_false': require_(Array.isArray(e.xs)&&Number.isInteger(e.n)&&e.n>=0,'BAD_COUNT'); return e.xs.filter(v=>{const b=rec(v);require_(typeof b==='boolean','BAD_BOOL');return !b;}).length === e.n;
      default: fail('UNKNOWN_OP');
    }
  }
  function enumerate(spec) {
    const keys = Object.keys(spec.domains); let total = 1;
    for (const k of keys) { const d=spec.domains[k]; require_(Array.isArray(d)&&d.length>0&&new Set(d).size===d.length,'BAD_DOMAIN'); total*=d.length; }
    require_(total<=100000,'DOMAIN_TOO_LARGE');
    const out=[];
    function walk(i,w) {
      if(i===keys.length) {
        const legal=spec.all_different.every(group => new Set(group.map(k => {require_(k in w,'BAD_VAR');return w[k];})).size===group.length);
        if(legal) out.push(copy(w)); return;
      }
      for(const v of spec.domains[keys[i]]) {w[keys[i]]=v;walk(i+1,w);}
    }
    walk(0,{}); return {raw_count:total,worlds:out};
  }
  function answerFor(spec,w) {
    if(spec.answer.kind==='variable') {require_(spec.answer.var in w,'BAD_VAR');return w[spec.answer.var];}
    require_(spec.answer.kind==='owner_of_value','BAD_ANSWER_KIND');
    const target=evalExpr(spec.answer.target,w);
    const owners=Object.entries(spec.answer.vars).filter(([id,k])=>w[k]===target).map(([id])=>id);
    require_(owners.length===1,'BAD_OWNER');return owners[0];
  }
  function solve(ep, omitClue = null) {
    const spec=ep.private.solver, all=enumerate(spec), cs=spec.constraints.filter(c=>c.clue_id!==omitClue);
    const solutions=all.worlds.filter(w=>cs.every(c=>evalExpr(c.expr,w)===true));
    return {raw_count:all.raw_count,legal_count:all.worlds.length,solutions,answer_ids:[...new Set(solutions.map(w=>answerFor(spec,w)))].sort()};
  }
  function publicCase(ep) {
    const p=ep.public;
    // Allowlist, not deletion of a few known secret fields.
    return copy({case_id:ep.case_id,question_version:ep.question_version,order:ep.order,
      title:p.title,short_title:p.short_title,chapter:p.chapter,difficulty:p.difficulty,estimated_minutes:p.estimated_minutes,
      intro:p.intro,premises:p.premises,question:p.question,options:p.options,clues:p.clues,ambient:p.ambient,menu_teaser:p.menu_teaser});
  }
  function modelRequest(ep, model) {
    require_(typeof model==='string'&&model.length>0,'BAD_MODEL');
    const p=publicCase(ep);
    return {
      model,
      state:{game:'cafe_detective',language:'ja-JP',title:p.title,
        intro:p.intro.map(x=>({speaker:x.speaker,text:x.text})),
        rules:p.premises.map(x=>x.text),
        evidence:p.clues.map(x=>({label:x.label,speaker:x.speaker,pages:x.pages.map(y=>y.text),summary:x.summary})),
        question:p.question},
      questions:{answer:{type:'choice',
        instructions:'Solve the short fictional mystery using ONLY the supplied rules and evidence. Select the single character who satisfies the conditions. Do not infer guilt from names, personality, tone, or previous stories. Some statements may be false ONLY when the stated puzzle rule allows it. Ignore motives revealed after the solution; they are not part of this question.',
        criteria:Object.fromEntries(p.options.map(o=>[o.id,o.label+' is the character asked for in the question.']))}}
    };
  }
  function normalizePrediction(raw, ids) {
    const a=raw && raw.answers && raw.answers.answer;
    require_(a&&a.type==='choice'&&typeof raw.model==='string','PROVIDER_INVALID');
    require_(a.probabilities&&typeof a.probabilities==='object'&&!Array.isArray(a.probabilities),'PROVIDER_INVALID');
    require_(canonical(Object.keys(a.probabilities).sort())===canonical(ids.slice().sort()),'PROVIDER_INVALID');
    require_(ids.includes(a.choice),'PROVIDER_INVALID');
    let sum=0;for(const id of ids) {const p=a.probabilities[id];require_(typeof p==='number'&&Number.isFinite(p)&&p>=0&&p<=1,'PROVIDER_INVALID');sum+=p;}
    require_(Math.abs(sum-1)<=0.001 && sum>0,'PROVIDER_INVALID');
    require_(typeof a.confidence==='number'&&Number.isFinite(a.confidence)&&a.confidence>=0&&a.confidence<=1,'PROVIDER_INVALID');
    const probs=Object.fromEntries(ids.map(id=>[id,a.probabilities[id]/sum]));
    require_(Math.max(...Object.values(probs))-probs[a.choice]<=1e-6,'PROVIDER_INVALID');
    const usage={input_tokens:null,output_tokens:null};
    for(const k of Object.keys(usage)) {const n=raw.usage && raw.usage[k];if(n!==undefined){require_(Number.isInteger(n)&&n>=0,'PROVIDER_INVALID');usage[k]=n;}}
    return {choice:a.choice,probabilities:probs,confidence:a.confidence,model:raw.model,usage};
  }
  function begin(ep, meta) {
    require_(['jev','solo'].includes(meta.mode),'BAD_MODE');
    return {attempt_id:meta.attempt_id,actor_id:meta.actor_id,device_id:meta.device_id,case_id:ep.case_id,question_version:ep.question_version,
      public_hash:meta.public_hash,phase:'investigating',paused:false,revision:0,seen_ids:[],hint_level:0,
      practice:Boolean(meta.practice),mode_requested:meta.mode,mode_effective:null,prediction:null,
      generation:0,lease_until_ms:null,commit_hash:null,nonce_hex:null,prepared_at_ms:null,
      started_at_ms:meta.now_ms,expires_at_ms:meta.now_ms+86400000,result:null};
  }
  function check(a,now){require_(!['resolved','abandoned','expired'].includes(a.phase),'ATTEMPT_CLOSED');require_(now<a.expires_at_ms,'ATTEMPT_EXPIRED');}
  function progress(a,ep,ids,now) {
    check(a,now);require_(!a.paused,'ATTEMPT_PAUSED');
    const valid=ep.public.clues.map(c=>c.id);require_(Array.isArray(ids)&&ids.every(id=>valid.includes(id)),'BAD_EVIDENCE_ID');
    const n=copy(a);n.seen_ids=[...new Set([...a.seen_ids,...ids])].sort();n.revision++;return n;
  }
  function hint(a,level,now) {
    check(a,now);require_(!a.paused,'ATTEMPT_PAUSED');require_([1,2].includes(level),'BAD_HINT');
    require_(level<=a.hint_level+1,'HINT_ORDER');const n=copy(a);n.hint_level=Math.max(a.hint_level,level);n.revision++;return n;
  }
  function prepare(a,ep,now) {
    check(a,now);require_(!a.paused,'ATTEMPT_PAUSED');
    if(['ready','preparing'].includes(a.phase)) return copy(a);
    require_(a.phase==='investigating','BAD_PHASE');
    require_(ep.public.clues.every(c=>a.seen_ids.includes(c.id)),'EVIDENCE_REQUIRED');
    const n=copy(a);n.revision++;n.generation++;
    if(n.mode_requested==='solo') {n.phase='ready';n.mode_effective='solo';n.prepared_at_ms=now;}
    else {n.phase='preparing';n.lease_until_ms=now+20000;}
    return n;
  }
  function commit(a,prediction,generation,now,nonce,hashFn) {
    if(a.phase!=='preparing'||a.generation!==generation||now>=a.lease_until_ms||now>=a.expires_at_ms) return {state:copy(a),applied:false};
    require_(/^[a-f0-9]{64}$/.test(nonce),'BAD_NONCE');
    const n=copy(a);n.phase='ready';n.mode_effective='jev';n.prediction=copy(prediction);n.prepared_at_ms=now;n.nonce_hex=nonce;n.revision++;
    n.commit_payload=commitText(n);n.commit_hash=hashFn(n.commit_payload);return {state:n,applied:true};
  }
  function commitText(a) {
    require_(a.prediction&&a.nonce_hex,'COMMIT_NOT_READY');
    // ASCII IDs + canonical UTF-8 JSON, one single LF separator, no trailing LF.
    return 'CAFE_DETECTIVE_COMMIT_V1\n'+canonical({attempt_id:a.attempt_id,case_id:a.case_id,question_version:a.question_version,
      public_hash:a.public_hash,generation:a.generation,model:a.prediction.model,choice:a.prediction.choice,
      probabilities:a.prediction.probabilities,confidence:a.prediction.confidence,nonce_hex:a.nonce_hex});
  }
  function fallback(a,now,reason) {
    check(a,now);require_(['investigating','preparing','ready'].includes(a.phase),'BAD_PHASE');
    if(a.phase==='ready'&&a.mode_effective==='jev')fail('COMMIT_FROZEN');
    const n=copy(a);n.generation++;n.phase='ready';n.mode_effective='solo';n.prediction=null;n.prepared_at_ms=now;n.commit_hash=null;n.nonce_hex=null;n.fallback_reason=reason;n.revision++;return n;
  }
  function outcome(ep,chosen,pred,ctx) {
    require_(chosen===null||ep.public.options.some(o=>o.id===chosen),'BAD_CHOICE');
    const correct=chosen===ep.private.answer_id;
    const aiCorrect=pred ? pred.choice===ep.private.answer_id : null;
    let comparison='not_compared';
    if(pred && chosen!==null && !ctx.practice && ctx.hint_level===0) {
      comparison=correct?(aiCorrect?'both_correct':'human_win'):(aiCorrect?'ai_win':'both_incorrect');
    }
    return {human_choice:chosen,correct_answer:ep.private.answer_id,human_correct:correct,ai_correct:aiCorrect,
      comparison,points:correct?(ctx.hint_level?1:2):0,assisted:ctx.hint_level>0,practice:ctx.practice,gave_up:chosen===null};
  }
  function resolve(a,ep,chosen,now) {
    if(a.phase==='resolved'){require_(a.result.human_choice===chosen,'ANSWER_ALREADY_LOCKED');return copy(a);}
    check(a,now);require_(!a.paused,'ATTEMPT_PAUSED');
    if(chosen!==null){require_(a.phase==='ready','NOT_READY');require_(ep.public.clues.every(c=>a.seen_ids.includes(c.id)),'EVIDENCE_REQUIRED');}
    const n=copy(a);n.result=outcome(ep,chosen,a.prediction,{practice:a.practice,hint_level:a.hint_level});
    n.phase='resolved';n.resolved_at_ms=now;n.revision++;n.generation++;return n;
  }
  function pause(a,now) {check(a,now);const n=copy(a);n.paused=true;n.revision++;return n;}
  function resume(a,now) {check(a,now);const n=copy(a);n.paused=false;n.revision++;return n;}
  function abandon(a,now) {if(a.phase==='abandoned')return copy(a);check(a,now);const n=copy(a);n.phase='abandoned';n.generation++;n.revision++;return n;}
  function publicAttempt(a) {
    const out={attempt_id:a.attempt_id,case_id:a.case_id,question_version:a.question_version,public_hash:a.public_hash,phase:a.phase,paused:a.paused,
      revision:a.revision,seen_ids:a.seen_ids,hint_level:a.hint_level,practice:a.practice,mode_requested:a.mode_requested,mode_effective:a.mode_effective,
      commit_hash:a.commit_hash,expires_at_ms:a.expires_at_ms};
    if(a.phase==='resolved') {out.result=a.result;out.ai_reveal=a.prediction?{prediction:a.prediction,nonce_hex:a.nonce_hex,committed_generation:a.generation-1,commit_payload:a.commit_payload}:null;}
    return copy(out);
  }
  function glyphs(pack,uiStrings) {
    const set=new Set();
    const add=t=>{for(const c of t)if(c!=='\n'&&c!=='\r'&&c!=='\t')set.add(c);};
    function rec(x){if(typeof x==='string')add(x);else if(Array.isArray(x))x.forEach(rec);else if(x&&typeof x==='object')Object.values(x).forEach(rec);}
    rec(pack);rec(uiStrings);return [...set].sort().join('');
  }
  return {DomainError,canonical,evalExpr,enumerate,answerFor,solve,publicCase,modelRequest,normalizePrediction,begin,progress,hint,prepare,commit,commitText,fallback,outcome,resolve,pause,resume,abandon,publicAttempt,glyphs};
})();
if (typeof module !== 'undefined' && module.exports) module.exports = DetectiveCore;
