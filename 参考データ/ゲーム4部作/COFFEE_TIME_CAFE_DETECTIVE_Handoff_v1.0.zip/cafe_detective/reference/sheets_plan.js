/* Original deterministic write-plan helpers; transport/recovery is specified in the MD. */
var DetectiveSheetsPlan=(function(){
  'use strict';
  function cell(x){
    if(x===null)return {userEnteredValue:{}};
    if(typeof x==='string')return {userEnteredValue:{stringValue:x}};
    if(typeof x==='boolean')return {userEnteredValue:{boolValue:x}};
    if(typeof x==='number'&&Number.isFinite(x))return {userEnteredValue:{numberValue:x}};
    throw new Error('INVALID_CELL');
  }
  function row(sheetId,rowIndex0,values){
    if(!Number.isInteger(sheetId)||sheetId<0||!Number.isInteger(rowIndex0)||rowIndex0<1||!Array.isArray(values)||!values.length)throw new Error('INVALID_ROW');
    return {updateCells:{range:{sheetId,startRowIndex:rowIndex0,endRowIndex:rowIndex0+1,startColumnIndex:0,endColumnIndex:values.length},rows:[{values:values.map(cell)}],fields:'userEnteredValue'}};
  }
  function plan(writes){
    if(!Array.isArray(writes)||writes.length<1)throw new Error('EMPTY_PLAN');
    const seen=new Set();const requests=writes.map(w=>{const k=w.sheet_id+':'+w.row_index0;if(seen.has(k))throw new Error('DUPLICATE_ROW');seen.add(k);return row(w.sheet_id,w.row_index0,w.values);});
    return {requests,includeSpreadsheetInResponse:false};
  }
  return {cell,row,plan};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=DetectiveSheetsPlan;
