# CAFE DETECTIVE — COFFEE TIME 実装引継ぎ

対象：Waveshare ESP32-S3-Touch-LCD-2.8C / 折りたたみBケース / 803450・1500mAh。

正本は `COFFEE_TIME_CAFE_DETECTIVE_Design_v1.0.md`。第一章3話の全脚本と、ゲーム・Google連携・Jevの責任分担を収録しています。

## 最初の検査

Node.js 20以降（検査環境22.16.0）で、外部npmパッケージなしに実行できます。

```sh
node tests/test_core.js
node tests/test_storage.js
node tests/validate_release.js
node tools/build_package.js
node tools/build_preview.js
```

任意のホストC++17検査（Linux/macOSの例。Windowsは出力名を.exe等に合わせる）：

```sh
g++ -std=c++17 -Wall -Wextra -Werror tests/test_gate.cpp -o /tmp/cafe_detective_gate
/tmp/cafe_detective_gate
```

PC参考版は `prototype/prototype.html` をブラウザーで開きます。3話・全結末を収録したsoloモードです。Jev、Google、本人認証、永続的な戦績は実装していません。ファイルの実行が会社のブラウザー方針で禁止される場合は管理者が認めた開発環境で使用してください。画面デザインは物語と操作確認用であり、最終ESP32レイアウトは仕様書第5章が正本です。

任意のブラウザー自動試験にはPlaywrightとChromiumの準備が別途必要です。外部依存はこの試験だけです。既にインストールされている環境では：

```sh
python tests/test_browser.py
```

`CHROMIUM_EXECUTABLE` 環境変数で既存Chromiumの場所を指定できます。テストはHTMLをメモリーからロードし、ネットワークやGoogle/Jevへ接続しません。

## 役割

- `data/catalog.author.json`：作者用の全脚本・正解・solver。端末APIへ丸ごと返さない。
- `data/catalog.public.json`：公開部分。build_package.jsで再生成。
- `data/api_contract.json` / `api_responses.json`：自社GAS APIの全要求/成功返答。
- `data/sheets_schema.json`：追加6タブの列順。
- `data/acceptance_tests.json`：実装後に行う72項目。初期値NOT_RUNは正常。
- `reference/detective_core.js`：Node/GAS向けの純粋ロジック。認証・実保存・ボード制御は含まない。
- `reference/jev_gas_adapter.js`：実Jev HTTP契約の参考接続。実API未試験。
- `reference/sheets_plan.js`：Sheets更新内容の作成。実保存・排他・barrierは仕様に沿って接続する。
- `reference/DetectiveGate.hpp`：C++入力ラッチの参考部品。実機バイナリーではない。
- `reference/DetectiveChoiceLvgl8.cpp`：LVGL8の参考画面断片。実LVGL/ESP32コンパイル未確認。
- `docs/*validation*.json` / `verification_report.json`：この引継ぎ作成時に実行した参考検査の結果。
- `data/required_glyphs.txt`：必要な**文字の一覧だけ**。フォントファイルではない。

## 完成の区別

この納品は「脚本・仕様・参考実装・参考検査」です。書込み可能な完成ファームやデプロイ済みGASではありません。既存コードへの組込み、実Google/Jev、実機の字形・タッチ・電力・電断を実装担当が確認します。APIキーや接続先、実機の状態を架空の値で成功扱いしないでください。
