'use strict';
const {screens}=UI_DATA;
const byId=Object.fromEntries(screens.map(s=>[s.id,s]));
const clone=v=>JSON.parse(JSON.stringify(v));
let current=clone(byId.lobby), lastTable='poker_bet_open', returnScene='lobby', suspended=null, generation=1;
let highContrast=false, reduced=false, modal=null, confirmations=0, pointer=null, drafts={};
let eventLog=[];let gate=new CafeUi.ConfirmGate();
const svgNS='http://www.w3.org/2000/svg';
const escapeXml=s=>String(s).replace(/[<>&"']/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;',"'":'&apos;'}[c]));
const color=k=>(highContrast?({...THEME.colors,felt:'#081E17',felt_top:'#081E17',muted:'#F7EFDF',gold:'#F2CF84'}):THEME.colors)[k]||k;
function stamp(){return {matchId:'ui-fixture-'+current.id,revision:current.revision,generation};}
function log(type,detail={}){eventLog.push({n:eventLog.length+1,type,detail});if(eventLog.length>120)eventLog.shift();document.getElementById('log').textContent=eventLog.slice(-9).map(x=>`${x.n}  ${x.type}  ${JSON.stringify(x.detail)}`).join('\n');}
function openScene(id,record=true){if(!byId[id])throw Error('Unknown scene '+id);current=clone(byId[id]);generation++;current.ui_generation=generation;modal=null;drafts={};pointer=null;gate=new CafeUi.ConfirmGate();gate.uncover(stamp());if(current.covered)gate.cover();if(current.game!=='common'&&!['HELP','HAND_RESULT','ROUND_RESULT'].includes(current.phase))lastTable=id;if(record)log('fixture.open',{id});document.getElementById('scene-select').value=id;render();}
function frame(){return `<defs>
 <radialGradient id="room"><stop stop-color="#253B2D"/><stop offset="1" stop-color="${color('backdrop')}"/></radialGradient>
 <linearGradient id="wood" x2="0" y2="1"><stop stop-color="${color('walnut_light')}"/><stop offset=".48" stop-color="${color('walnut_dark')}"/><stop offset="1" stop-color="#38261A"/></linearGradient>
 <linearGradient id="felt" x2="0" y2="1"><stop stop-color="${color('felt_top')}"/><stop offset="1" stop-color="${color('felt_dark')}"/></linearGradient>
 <linearGradient id="paper" x2=".3" y2="1"><stop stop-color="#FFF9EF"/><stop offset="1" stop-color="${color('paper')}"/></linearGradient>
 <pattern id="backpattern" width="12" height="12" patternUnits="userSpaceOnUse"><path d="M6 1L11 6L6 11L1 6Z" fill="none" stroke="#6A8070" stroke-width=".6"/></pattern>
 <clipPath id="roundclip"><circle cx="240" cy="240" r="239"/></clipPath></defs>
 <g clip-path="url(#roundclip)"><circle cx="240" cy="240" r="240" fill="url(#room)"/>
 <circle cx="240" cy="240" r="231" fill="none" stroke="${color('brass')}" stroke-opacity=".28"/>
 <rect x="26" y="98" width="428" height="296" rx="148" fill="url(#wood)" stroke="#0A100C" stroke-width="3"/>
 <rect x="33" y="105" width="414" height="282" rx="141" fill="none" stroke="${color('brass')}" stroke-opacity=".56"/>
 <rect x="40" y="112" width="400" height="268" rx="134" fill="url(#felt)" stroke="#0A1813" stroke-width="3"/>
 <rect x="50" y="122" width="380" height="248" rx="124" fill="none" stroke="${color('brass')}" stroke-opacity=".32" stroke-dasharray="2 4"/>
 <text x="240" y="385" text-anchor="middle" fill="${color('brass')}" font-size="9" letter-spacing="3" opacity=".5">COFFEE TIME</text></g>`;}
function textSvg(e,override){const [x,y,w,h]=e.rect,fs=e.font_px||18, lines=String(override??e.text).split('\n'), lh=fs*1.2,baseline=y+(h-lines.length*lh)/2+fs*.9;return `<g class="textblock" data-element="${escapeXml(e.id)}" data-rect="${e.rect.join(',')}"><text x="${x+w/2}" y="${baseline}" fill="${color(e.color||'text')}" font-size="${fs}" font-weight="${e.id==='title'||fs>=28?600:450}" text-anchor="middle">${lines.map((s,i)=>`<tspan x="${x+w/2}" dy="${i?lh:0}">${escapeXml(s)}</tspan>`).join('')}</text></g>`;}
function suitSvg(suit,x,y,size,fill){const paths={S:'M16 1C12 7 2 12 2 19C2 27 11 30 16 23C21 30 30 27 30 19C30 12 20 7 16 1ZM14 22L10 32H22L18 22Z',H:'M16 30C10 24 1 18 1 10C1 1 12 -1 16 7C20 -1 31 1 31 10C31 18 22 24 16 30Z',D:'M16 0L31 16L16 32L1 16Z',C:'M16 1A8 8 0 1 0 16 17A8 8 0 1 0 25 27A8 8 0 1 0 16 17A8 8 0 1 0 7 27A8 8 0 1 0 16 17M14 21L10 32H22L18 21Z'};return `<path d="${paths[suit]||paths.D}" transform="translate(${x} ${y}) scale(${size/32})" fill="${fill}"/>`;}
function buttonSvg(e){const[x,y,w,h]=e.rect, enabled=e.enabled!==false;
 const fill=!enabled?color('disabled'):e.style==='primary'?color('gold'):e.style==='danger'?color('danger'):e.style==='quiet'?color('backdrop'):color('button');
 const fg=!enabled?color('disabled_text'):e.style==='primary'?color('gold_ink'):color('text');
 let inner=`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="13" fill="${fill}" stroke="${enabled?color('brass'):color('divider')}" stroke-width="${enabled?1.5:1}"/>`;
 if(e.action==='ENTER_TABLE')inner+=`<path d="M${x+26} ${y+18}H${x+w-26}" stroke="${color('gold')}" stroke-opacity=".65"/>`;
 inner+=textSvg({...e,color:fg});
 return `<g class="hit ${enabled?'enabled':''}" data-hit="${e.id}" data-action="${e.action}" data-enabled="${enabled}" role="button" tabindex="${enabled?0:-1}" aria-label="${escapeXml(e.text.replace(/\n/g,' '))}" aria-disabled="${!enabled}">${inner}</g>`;}
function cardSvg(e){if(e.face==='absent')return '';let[x,y,w,h]=e.rect;if(e.selected)y-=THEME.touch.card_lift;
 let svg=`<rect x="${x+1}" y="${y+3}" width="${w}" height="${h}" rx="7" fill="#000" opacity=".3"/>`;
 if(e.face==='back')svg+=`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="6" fill="#17352D" stroke="${color('brass')}" stroke-width="1"/><rect x="${x+4}" y="${y+4}" width="${w-8}" height="${h-8}" rx="3" fill="url(#backpattern)"/><path d="M${x+w/2} ${y+h*.32}l${w*.14} ${h*.18}l-${w*.14} ${h*.18}l-${w*.14} -${h*.18}Z" fill="${color('brass')}"/>`;
 else{svg+=`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="7" fill="url(#paper)" stroke="${e.selected?color('gold'):color('ink')}" stroke-width="${e.selected?3:1}"/>`;
  if(e.value!==null&&e.value!==undefined){svg+=textSvg({id:e.id+'_rank',rect:[x,y+8,w,h-16],font_px:38,text:String(e.value),color:'ink'});}
  else{const ink=['H','D'].includes(e.suit)?color('red'):color('ink');svg+=`<text x="${x+8}" y="${y+29}" fill="${ink}" font-size="${THEME.fonts.rank}" font-weight="650">${escapeXml(e.rank)}</text>`;svg+=suitSvg(e.suit,x+w-22,y+9,14,ink);svg+=suitSvg(e.suit,x+w/2-13,y+h-33,26,ink);}
  if(e.selected)svg+=`<circle cx="${x+w-9}" cy="${y+9}" r="9" fill="${color('gold')}"/><path d="M${x+w-14} ${y+9}l3 3l6 -7" fill="none" stroke="${color('ink')}" stroke-width="2"/>`;
 }
 const sel=e.select_group&&e.enabled;
 return `<g class="card ${sel?'hit enabled':''}" data-card="${e.id}" data-private="${!!e.private}" ${sel?`data-hit="${e.id}" data-enabled="true" role="button" tabindex="0" aria-pressed="${!!e.selected}" aria-label="${escapeXml(e.value??((e.rank||'')+' '+(e.suit||'')))}"`:''}>${svg}</g>`;
}
function displayElements(){let els=clone(current.elements);
 if(current.game==='gops'&&Array.isArray(current.remaining)){
  els=els.filter(e=>!e.id.startsWith('bid_'));
  const p=CafeUi.gopsPage(current.remaining,current.page||0);
  p.values.forEach((v,i)=>els.push({id:'bid_'+v,kind:'card',rect:[96+76*i,254,68,82],face:'face',value:v,rank:null,suit:null,private:false,select_group:'gops',selected:drafts.bid===v,enabled:true}));
  const a=els.find(e=>e.id==='prev'),b=els.find(e=>e.id==='next');if(a)a.enabled=p.page>0;if(b)b.enabled=p.page+1<p.pages;
  const t=els.find(e=>e.id==='selection_info');if(t)t.text=(drafts.bid?`${drafts.bid}を選択`:'札を選択')+`  /  ${p.page+1}・${p.pages}ページ`;
  const confirm=els.find(e=>e.id==='action_right');if(confirm)confirm.enabled=!!drafts.bid&&current.ai_ready;
 }
 if(current.game==='poker'&&current.phase.startsWith('DRAW')){
  const who=els.find(e=>e.id==='opponent');if(who)who.text=current.ai_ready?'JEV  交換選択済み':'JEV  選択を準備中';
  let mask=drafts.drawMask||0,n=0;els.forEach(e=>{if(e.id.startsWith('hand_')){e.selected=!!(mask&(1<<Number(e.id.split('_')[1])));if(e.selected)n++;}});
  els.find(e=>e.id==='pot').text=n+' 枚';els.find(e=>e.id==='action_right').text=n?`${n}枚交換`:'交換しない';
 }
 if(current.game==='thirty_one'&&['TURN','LAST_REPLY'].includes(current.phase)){
  els.forEach(e=>{if(e.select_group==='market')e.selected=e.id===drafts.market;if(e.select_group==='thirty_hand')e.selected=e.id===drafts.hand;});
  els.find(e=>e.id==='action_left').enabled=!!drafts.market&&!!drafts.hand;
 }
 const committing=['CHECK','BET','CALL','RAISE','FOLD','DRAW_CONFIRM','BID_CONFIRM','SWAP_CONFIRM','KNOCK','STAND','PREDICT_PLAYER','PREDICT_BANKER','PREDICT_TIE'];
 if(gate.busy)els.forEach(e=>{if(e.select_group||committing.includes(e.action)||['PAGE_NEXT','PAGE_PREV','CLEAR_SELECTION'].includes(e.action))e.enabled=false;});
 return els;
}
function modalSvg(){if(!modal)return '';const msg=modal.message,accepted=modal.accepted;return `<g id="modal"><circle cx="240" cy="240" r="240" fill="${color('backdrop')}"/><rect x="72" y="118" width="336" height="222" rx="22" fill="${color('felt_dark')}" stroke="${color('brass')}"/>${textSvg({id:'modal_title',rect:[108,138,264,32],font_px:24,text:accepted?'受付済み（見本）':modal.title||'内容を確認',color:'gold'})}${textSvg({id:'modal_body',rect:[98,184,284,134],font_px:20,text:msg,color:'text'})}${buttonSvg({id:'modal_cancel',rect:[108,350,124,52],text:accepted?'閉じる':'選び直す',font_px:20,style:'secondary',enabled:true,action:'CANCEL_MODAL'})}${buttonSvg({id:'modal_accept',rect:[248,350,124,52],text:'決定',font_px:20,style:'primary',enabled:!accepted&&!modal.info,action:'ACCEPT_MODAL'})}</g>`;}
function getSvg(){const els=displayElements();return `<svg id="screen" viewBox="0 0 480 480" width="480" height="480" xmlns="${svgNS}" aria-label="CAFE CARDS UIモック" style="font-family:'Noto Sans CJK JP','Yu Gothic','Hiragino Kaku Gothic ProN',sans-serif">${frame()}${current.game==='poker'&&els.some(e=>e.id==='pot')?`<g aria-hidden="true">${[0,5,10].map(d=>`<ellipse cx="116" cy="${197-d}" rx="15" ry="7" fill="#314F3C" stroke="${color('brass')}" stroke-width="1.5"/>`).join('')}</g>`:''}<g clip-path="url(#roundclip)" id="content">${els.map(e=>e.kind==='label'?textSvg(e):e.kind==='card'?cardSvg(e):buttonSvg(e)).join('')}</g>${modalSvg()}</svg>`;}
function render(){document.getElementById('device').innerHTML=getSvg();document.getElementById('scene-name').textContent=current.name_ja;document.getElementById('phase').textContent=`${current.phase} / UI gen ${generation}`;document.getElementById('confirm-count').textContent=confirmations;document.body.classList.toggle('reduced',reduced);}
function info(text,title='UI仕様の説明'){modal={message:text,title,info:true,accepted:false};render();}
function proposal(action,message){const legal=current.legal_actions||[action];const required=current.game==='gops'||current.game==='baccarat'||current.phase.startsWith('DRAW');gate.bind(stamp());if(!gate.propose(stamp(),action,legal,required,current.ai_ready)){log('blocked',{action});return;}
 modal={action,message,legal,required,origin:{...stamp()},accepted:false};log('confirm.open',{action});render();}
function selectCard(e){if(gate.busy||current.covered)return;if(e.select_group==='poker_draw'){const i=Number(e.id.split('_')[1]);drafts.drawMask=(drafts.drawMask||0)^(1<<i);}
 else if(e.select_group==='gops')drafts.bid=e.value;
 else if(e.select_group==='market')drafts.market=e.id;
 else if(e.select_group==='thirty_hand')drafts.hand=e.id;
 log('draft.changed',{group:e.select_group});render();}
function doAction(id){const el=displayElements().find(x=>x.id===id);if(modal){if(id==='modal_cancel'){gate.cancel();modal=null;render();return;}if(id!=='modal_accept'||modal.info||modal.accepted)return;const out=gate.confirm(modal.origin,modal.legal,modal.required,current.ai_ready);if(!out){log('confirm.rejected');return;}confirmations++;modal.accepted=true;modal.message='実装側に操作を送る位置です。\nこの見本はカードを配らず、\n実API・戦績を変更しません。';log('controller.command',out);render();return;}
 if(!el||el.enabled===false)return;if(el.kind==='card')return selectCard(el);
 const a=el.action;
 if(a==='ENTER_TABLE')return openScene(el.args.scene);
 if(['LOBBY','LEAVE_DEMO'].includes(a))return openScene('lobby');
 if(a==='PAUSE'){suspended={scene:clone(current),drafts:clone(drafts),busy:gate.busy};gate.cover();openScene('paused');return;}
 if(a==='RESUME_DEMO'){if(suspended){const ss=suspended;current=clone(ss.scene);generation++;drafts=current.game==='thirty_one'?{}:clone(ss.drafts);gate.uncover(stamp());gate.busy=ss.busy;suspended=null;modal=null;log('resume.fixture_only');render();}else openScene(lastTable);return;}
 if(a==='CLEAR_SELECTION'){drafts.drawMask=0;render();return;}
 if(a==='PAGE_NEXT'||a==='PAGE_PREV'){const p=CafeUi.gopsPage(current.remaining,current.page||0),next=p.page+(a==='PAGE_NEXT'?1:-1);if(next>=0&&next<p.pages){current.page=next;generation++;gate.bind(stamp());render();}return;}
 if(['CHECK','BET','FOLD','CALL','RAISE'].includes(a)){const amount=current.amounts?.[a]||0;return proposal(a,a==='FOLD'?'このハンドを降ります。\n場の点数は相手が獲得し、\n双方の札は公開しません。':`${a==='CHECK'?'追加せず続けます。':a==='BET'?'点数を出して勝負します。':a==='CALL'?'相手と同額にそろえます。':'相手に合わせ、上乗せします。'}\n今回、追加する点数：${amount}点\n確定後の変更はできません。`);}
 if(a==='DRAW_CONFIRM'){const mask=drafts.drawMask||0,n=mask.toString(2).replace(/0/g,'').length;return proposal('DRAW:'+mask,n?`${n}枚を一度だけ交換します。\n捨てた札は今回戻りません。\n確定後は選び直せません。`:'今の5枚をすべて残します。\nカードは交換しません。');}
 if(a==='BID_CONFIRM')return proposal('PLAY:'+drafts.bid,`${drafts.bid}の札を出します。\nこの札は今回で使い切りです。\n相手の札は変更されません。`);
 if(a==='SWAP_CONFIRM'){const i=Number(drafts.hand?.split('_')[1]),j=Number(drafts.market?.split('_')[1]);if(!Number.isInteger(i)||!Number.isInteger(j))return;const h=displayElements().find(x=>x.id===drafts.hand),m=displayElements().find(x=>x.id===drafts.market);return proposal(`SWAP:${i}:${j}`,`自分の ${h.rank}${h.suit}\n場の ${m.rank}${m.suit}\nこの2枚を交換します。`);}
 if(a==='KNOCK')return proposal(a,'交換せずに勝負を宣言します。\n相手に最後の1手を渡した後、\n手札を比べます。');
 if(a==='STAND')return proposal(a,'交換せず、この手札のまま\n相手と得点を比べます。');
 if(a.startsWith('PREDICT_')){const side=a.slice(8);return proposal(side,`${side==='TIE'?'引き分け':side+'勝ち'}と予想します。\nPLAYER・BANKERは\n手札の側の名前です。\n人間・Jevとは別です。`);}
 if(a==='SHOW_REMAINING'){returnScene=current.id;return openScene('gops_remaining');}
 if(a==='RETURN_SCENE')return openScene(returnScene==='lobby'?lastTable:returnScene);
 if(a==='SHOW_DECISION'){if(!current.decision_visible)return info('この場面では公開できません。');returnScene=current.id;openScene('decision_detail');if(returnScene.startsWith('baccarat')){current.elements.find(x=>x.id==='values').text='PLAYER  41%\nBANKER  49%\nTIE  10%';render();}return;}
 if(a==='NEXT_FIXTURE'){const next=current.game==='poker'?'poker_draw_ready':current.game==='gops'?'gops_7':current.game==='thirty_one'?'thirty_turn':current.id==='baccarat_reveal'?'baccarat_result':'baccarat_open';return openScene(next);}
 if(a==='TOGGLE_MOTION'){reduced=!reduced;log('setting.reduce_motion',{enabled:reduced});render();return;}
 if(a==='TOGGLE_CONTRAST'){highContrast=!highContrast;log('setting.high_contrast',{enabled:highContrast});render();return;}
 if(a==='CHOOSE_LOCAL')return info('本番は確認後に端末AIへ切替。\n残りの対戦は端末AIを使い、\n結果は混合対戦と記録します。');
 if(a==='RETRY_POLL')return info('同じ決定IDを照会します。\n新しい推論依頼は作りません。');
 if(a==='REMATCH')return info('同じルールで新規試合を作成。\n新しいmatch_idを発行し、\n前の点数を持ち越しません。');
 if(a==='IDENTITY_SAMPLE')return info('これは架空の名簿です。\n本番は既存の認証を使います。\n認証を重複実装しません。');
 return info('本番では既存コントローラーの\n公開情報へ接続します。\nこれはUI操作の見本です。');
}
const dev=document.getElementById('device');
function svgPoint(evt){const svg=document.getElementById('screen'),b=svg.getBoundingClientRect();return {x:(evt.clientX-b.left)*480/b.width,y:(evt.clientY-b.top)*480/b.height};}
dev.addEventListener('pointerdown',e=>{const hit=e.target.closest('[data-hit]');if(!hit||hit.dataset.enabled!=='true')return;const p=svgPoint(e);pointer={id:hit.dataset.hit,generation,...p};});
dev.addEventListener('pointerup',e=>{const hit=e.target.closest('[data-hit]'),p=svgPoint(e),saved=pointer;pointer=null;if(!hit||!saved||hit.dataset.enabled!=='true'||saved.id!==hit.dataset.hit||saved.generation!==generation||Math.hypot(p.x-saved.x,p.y-saved.y)>8)return;doAction(saved.id);});
dev.addEventListener('pointercancel',()=>pointer=null);
dev.addEventListener('keydown',e=>{if(!['Enter',' '].includes(e.key))return;const h=e.target.closest('[data-hit]');if(h&&h.dataset.enabled==='true'){e.preventDefault();doAction(h.dataset.hit);}});
const select=document.getElementById('scene-select');for(const s of screens){const op=document.createElement('option');op.value=s.id;op.textContent=s.name_ja;select.appendChild(op);}select.addEventListener('change',()=>openScene(select.value));
document.getElementById('reset').addEventListener('click',()=>openScene(current.id));
document.getElementById('show-settings').addEventListener('click',()=>openScene('settings'));
document.getElementById('toggle-guides').addEventListener('change',e=>{document.body.classList.toggle('guides',e.target.checked);document.getElementById('guide').style.display=e.target.checked?'block':'none';});
window.demo={openScene,getSvg,doAction,displayElements,state:()=>({current:clone(current),drafts:clone(drafts),generation,modal:clone(modal),confirmations}),setReady(ready){current.ai_ready=ready;if(current.phase.startsWith('DRAW'))current.elements.find(x=>x.id==='action_right').enabled=ready;render();},reset:()=>openScene(current.id)};
openScene('lobby',false);
