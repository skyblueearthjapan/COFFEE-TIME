"""Run host tests without editing the baseline or downloading SDKs/browsers."""
from pathlib import Path
import json, os, platform, shutil, subprocess, sys, tempfile
ROOT=Path(__file__).resolve().parents[1];(ROOT/'results').mkdir(exist_ok=True)
report={'scope':'host UI layer only, not game engine or target firmware','platform':platform.platform(),'python':sys.version.split()[0],'results':[]}
def run(name,command,outfile=None,env=None):
 p=subprocess.run(command,cwd=ROOT,text=True,capture_output=True,env=env,timeout=45)
 print(name, 'PASS' if p.returncode==0 else 'FAIL')
 if p.stdout: print(p.stdout.strip())
 if p.stderr: print(p.stderr.strip())
 item={'name':name,'passed':p.returncode==0,'stdout':p.stdout,'stderr':p.stderr}
 report['results'].append(item)
 if outfile and p.returncode==0:
  try: parsed=json.loads(p.stdout.strip().splitlines()[-1]);(ROOT/'results'/outfile).write_text(json.dumps(parsed,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
  except (ValueError,IndexError):item['passed']=False;item['error']='Expected JSON result not found'
 return item['passed']
run('static_layout',[sys.executable,'tests/layout_test.py'])
run('schema',[sys.executable,'tests/schema_test.py'])
node=shutil.which('node')
if node:run('javascript_ui',[node,'tests/ui_state_test.js'],'ui_state_tests.json')
else:report['results'].append({'name':'javascript_ui','passed':False,'error':'Node.js unavailable'})
cxx=os.environ.get('CXX') or shutil.which('g++') or shutil.which('clang++')
if cxx:
 with tempfile.TemporaryDirectory(prefix='cafe_ui_test_') as tmp:
  exe=str(Path(tmp)/'ui_test');san=str(Path(tmp)/'ui_san')
  opts=[cxx,'-std=c++17','-Wall','-Wextra','-Werror','-pedantic','tests/ui_contract_test.cpp']
  if run('cpp_build',opts+['-o',exe]):run('cpp_input_gate',[exe],'cpp_ui_tests.json')
  if os.name!='nt':
   if run('cpp_sanitizer_build',opts+['-fsanitize=address,undefined','-fno-omit-frame-pointer','-g','-o',san]):
    env=dict(os.environ);env['ASAN_OPTIONS']='detect_leaks=1';run('cpp_sanitizers',[san],'cpp_sanitizer_tests.json',env)
  else:report['results'].append({'name':'cpp_sanitizers','passed':None,'note':'Run sanitizer on supported host; not tested by this Windows run'})
else:report['results'].append({'name':'cpp_build','passed':False,'error':'C++17 compiler unavailable'})
report['passed']=all(x.get('passed') is True for x in report['results'])
report['lvgl_sdk_built']=False;report['esp32_tested']=False;report['google_jev_called']=False
(ROOT/'results/host_run.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('HOST RESULT', 'PASS' if report['passed'] else 'FAIL/NOT FULLY TESTED')
sys.exit(0 if report['passed'] else 1)
