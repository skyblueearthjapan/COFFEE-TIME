"""Verify every delivered file against manifest.sha256; does not mutate user data."""
from pathlib import Path
import hashlib,sys
R=Path(__file__).resolve().parents[1];errors=[];count=0
for line in (R/'manifest.sha256').read_text(encoding='utf-8').splitlines():
 expected,name=line.split('  ',1);rel=Path(name)
 if rel.is_absolute() or '..' in rel.parts:errors.append('Unsafe path: '+name);continue
 p=R/rel;count+=1
 if not p.is_file():errors.append('Missing: '+name)
 elif hashlib.sha256(p.read_bytes()).hexdigest()!=expected:errors.append('Changed: '+name)
print(f'{count} files checked; {len(errors)} discrepancies')
for e in errors:print(e)
sys.exit(bool(errors))
