"""Build a self-contained offline HTML from the canonical UI JSON and source JS."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
t=(ROOT/'preview/template.html').read_text(encoding='utf-8')
for marker,rel in [('/*STATE_CODE*/','reference/ui_state.js'),('/*APP_CODE*/','preview/app.js')]:
 t=t.replace(marker,(ROOT/rel).read_text(encoding='utf-8').replace('</script','<\\/script'))
for marker,rel in [('/*THEME_DATA*/','data/theme.json'),('/*SCENE_DATA*/','data/screens.json')]:
 t=t.replace(marker,json.dumps(json.loads((ROOT/rel).read_text(encoding='utf-8')),ensure_ascii=False,separators=(',',':')).replace('</','<\\/'))
(ROOT/'preview/index.html').write_text(t,encoding='utf-8')
print('Built preview/index.html')
