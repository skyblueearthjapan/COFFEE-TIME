"""Create the four-table overview from verified screenshots; ships no font files."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import os
R=Path(__file__).resolve().parents[1]
names=[('poker_bet_facing','POKER / BET'),('gops_7','GOPS / BID'),('thirty_turn','THIRTY-ONE / SWAP'),('baccarat_open','BACCARAT / OPEN')]
im=Image.new('RGB',(1080,1160),'#F0ECE3');d=ImageDraw.Draw(im)
p=os.environ.get('OVERVIEW_FONT')
if not p:
 for candidate in ['/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf','C:/Windows/Fonts/arial.ttf']:
  if Path(candidate).exists():p=candidate;break
font=ImageFont.truetype(p,26) if p else ImageFont.load_default(size=26)
for i,(sid,name) in enumerate(names):
 x=40+(i%2)*520;y=50+(i//2)*550;d.text((x,y-30),name,fill='#243A2E',font=font)
 img=Image.open(R/'assets/screens'/f'{sid}.png').convert('RGB');im.paste(img,(x,y+15))
im.save(R/'assets/FOUR_TABLES.png')
print('assets/FOUR_TABLES.png')
