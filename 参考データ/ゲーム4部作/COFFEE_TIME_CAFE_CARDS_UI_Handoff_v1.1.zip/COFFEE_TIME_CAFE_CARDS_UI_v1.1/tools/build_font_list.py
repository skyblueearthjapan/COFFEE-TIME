from pathlib import Path
import json,re,zipfile
R=Path(__file__).resolve().parents[1]
chars=set('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 !"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~')
def walk(v):
 if isinstance(v,str):chars.update(c for c in v if not c.isspace())
 elif isinstance(v,dict):
  for value in v.values():walk(value)
 elif isinstance(v,list):
  for value in v:walk(value)
for name in ['screens.json','content.ja.json','dialogs.ja.json']:
 walk(json.loads((R/'data'/name).read_text()))
# Preserve all original tutorial and dynamic text glyph requirements.
with zipfile.ZipFile(R/'baseline/CAFE_CARDS_Handoff_v1.0_READONLY.zip') as z:
 for name in ['data/content.ja.json','data/tutorials.ja.json']:
  walk(json.loads(z.read(name)))
# Source formatting contains supplementary fixture-only messages.
chars.update(c for c in (R/'preview/app.js').read_text() if ord(c)>127 and not c.isspace())
(R/'data/font_chars.txt').write_text(''.join(sorted(chars,key=ord))+'\n',encoding='utf-8')
print(json.dumps({'glyph_codepoints':len(chars),'font_binaries_included':False}))
