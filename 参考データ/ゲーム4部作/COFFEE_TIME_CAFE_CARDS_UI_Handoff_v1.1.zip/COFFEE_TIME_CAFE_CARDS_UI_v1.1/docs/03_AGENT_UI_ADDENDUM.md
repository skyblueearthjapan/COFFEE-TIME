# 03 / コーディングエージェント向けUI追補・組込み設計
**CAFE CARDS / TABLE LOUNGE v1.1.0 / 2026-09-22**

## 1. 作業範囲と版の固定
ゲームのRulesCoreは原本v1.0.0を維持し、HumanViewから描くUIを入れ替えます。単に背景画像を設定して終わる作業ではなく、4ゲームの全段階に対応した表示部品・入力契約・秘密保護を実装します。

同じファイル名の旧回答に、31の20/21手と24/25手、Google側の秘密管理とESP32側の秘密管理などの相違がありました。この追補は**同梱のSHA-256で固定された最終原本**だけに接続します。過去のチャットの要約や、同名の別ZIPを混ぜないでください。

| 項目 | 継続する原本仕様 |
|---|---|
| 真の山札・私的ゲーム状態 | ESP32側。AIへは許可した観測だけ |
| 31 | 通常20手、20手目KNOCKなら21手目応答。通常STANDなし |
| Google | 原本の7操作・5種類のゲームシートを変更しない |
| 本人・ゲスト | 共通プロフィール再利用。ゲストはRAM再開、本人は再認証 |
| APIモデル / 認証 | 原本・既存アダプターを継続。UIの都合でキーを新規保存しない |
| CASINO風表示 | 金銭機能を追加しない |

優先順：今回のユーザー要望 → このUI仕様（UI領域のみ）→ 固定原本。ゲームルールは本追補に変更権限なし。原本I4の座標と旧layoutデータだけ置き換えます。ルール/観測/保存/認証の回帰テストはそのまま残します。

## 2. 変更箇所の一覧
| 対象 | 行う変更 | 禁止する変更 |
|---|---|---|
| CafeCardsApp | `TableScene`と共通widgetを導入 | 第7〜9枠へ別アプリ化 |
| HumanView | presentation DTOを生成するadapterを追加 | private_stateの丸ごとserialize |
| CardView | back/face/absent、slot固定、選択表現 | 未公開のrankをhiddenプロパティで保持 |
| ActionButtonRow | legalActionsから表示、確認sheetへ | UIが賭け額やノック可否を独断計算 |
| PrivacyCover | 全私的要素を消去してから遷移 | 透明アニメーションで手札を残す |
| ProviderBadge | `JEV / 端末AI / 混合`を実状態から表示 | モックをJevの実測として表示 |
| Settings | theme/high_contrast/reduced_motionの追加 | ルールID、matchID、デッキの再生成 |

## 3. 表示用ViewModelを独立させる
`data/ui_view_model.schema.json`は**新しい外部APIではなくUI内部の契約**です。既存ControllerのHumanViewから新しいオブジェクトへ許可項目だけをコピーします。入力ネットワーク形式は原本と同じです。

必須の文脈：app_id、game_id、phase、match_id、revision、ui_generation、ui_version、theme_id、provider_used。カードは`zone+slot_id`で追跡し、表示順と内部スロット番号を分けます。

各CardViewは `face=absent|back|face`。back/absentはrank/suit/valueをnullにします。rendererが持てるのは公開表示値だけ。原本physicalIDはController側で扱い、相手札のIDをwidget.user_dataへ入れません。`known_cards`は公開集合として別zoneへ出し、AIの本当のslot位置を明かしません。

アクションは `{action_id,label,enabled,amount,requires_confirm,blocked_reason}`。行動IDの例はCHECK、RAISE、DRAW:5、PLAY:13、SWAP:2:0、KNOCK、STAND、PLAYERなど。UIは現局面のlegal_action_idsをもとにコントローラーへ渡します。

`data/screens.json`は描画の見本データであり、この本番DTOと完全に同じschemaではありません。見本には外部の画面選択UI用のfixture_idがあります。fixture選択やNEXT_FIXTUREを製品のゲーム進行へそのまま接続しないでください。

## 4. クリック→仮選択→確認→確定
入力イベントは次の順番にします。

1. PRESSEDで`match_id / revision / ui_generation / target_id / pointer`を記録。
2. RELEASED/CLICKEDの対応を採用LVGLで確認。PRESSINGではゲーム行動を送らない [S03]。
3. release先が違う、8px超ドラッグ、PRESS_LOST、世代違い、非アクティブpointerなら取消。
4. カードタップはdraftだけを変更。確認ボタンでConfirmSheetを開く。
5. 最終決定時にstampとlegalActions、AI確定済み、現在の本人/guestを再検証。
6. `UiIntent`をControllerへキュー送信。UIは直ちにbusyにして再送を遮断。
7. Controllerが原本の保存手順を行い、結果の新revisionを返す。
8. 新しいHumanViewで描く。保存結果不明や通信エラーだけで同じ行動を再発行しない。

**100msのデバウンスだけでは重複を防げません。** 純粋C++の`Gate`は、同revisionでui_generationだけが変わってもbusyを解除しないようにしています。ページ移動・モーダル再描画・カフェ復帰で、確定済みの交換をもう一度送ることを防ぎます。

Commandの同一性と保存済みrevisionはControllerが最終的に検証します。参考C++の64bit matchはローカルUIの照合タグです。本番の32hex等のmatch_idを切り詰めて認証や保存の代わりにしてはいけません。タグと完全IDの対応は所有Controllerに保持します。

確定したコマンドが**適用前に拒否されたとControllerが明示**した場合だけ、`releaseRejected(..., authoritativeNoEffect=true)`で再選択を認めます。HTTPタイムアウト、保存結果不明、古いreplyはこの解除条件にしません。

## 5. 非同期・LVGLタスク
既存のUIタスクとロックを継続します。LVGLは任意の複数タスクから同時に操作してよいわけではありません [S04]。Wi-Fi/HTTP/JSON parsingはworker、view更新はUIキュー経由。mutexを保持してUrlFetchApp待ち相当のネットワーク待機をしない。

```text
Touch -> UiIntentQueue -> CardsController
                              | apply/validate/save
                              v
                           HumanView
                              v
                 PresentationAdapter -> UI task

Jev/Google worker -> validated ProviderReply -> CardsController
                                              (UIを直接触らない)
```

応答を受けたらmatch_id、decision_id、revision、phaseを照合。新ゲーム、端末AIへ切替済み、削除済みroot、古いUIへ返った値は無視します。一時停止中に合法なAI回答を保存しても、手札画面を勝手に再表示しません。

UI objectのcallback user_dataは寿命の保証されたBinding配列に置き、ローカル変数のアドレスを渡さない。破棄前にタイマー/animation/callbackを取消し、古いgenerationでrootに触れないようにします。

## 6. LVGL8部品の導入
同梱`lvgl8/table_lounge.hpp/.cpp`はテーブルとボタンを作る接続例です。実LVGL8のSDK・日本語フォント・BSPでは未コンパイルです。純粋C++ referenceのホスト試験成功と混同しないでください。

既存がLVGL8なら8のまま、9なら既存9 APIに同じ概念を移植します。UI追補のためにmajor版を乗り換えません。lv_init、LVGLタイマー、PSRAM、RGB、GT911をもう一度初期化するコードは書きません。

実装順：
1. 既存rootの下に480×480のscoped rootを作り、TableFrameを描く。
2. 共通label/buttonのstyleを一度生成し、rootより長く保持。
3. HumanViewからカードのsurfaceを構築。更新ではrank/selected/stateだけ差分反映。
4. 各手札に固定の非回転hitboxを置き、slotへのBindingを登録。
5. ConfirmSheetとPrivacyCoverを常設して必要時に前面へ。
6. フォントは既存からbody/button/rankを注入し、丸ごと同梱しない。
7. 読書/履歴は専用panelを使い、テーブルの小さな隙間に押し込まない。

`lv_obj_remove_style_all`を用いる例では、pad・border・bg・font・scroll flagsを明示します。btn labelをクリック対象にしないかevent bubblingの設計を統一します。double callbackによる二重確定をテストします。選択に`LV_STATE_CHECKED`を使っても、CHECKABLEの自動トグル任せにせずdraftと同期します [S02]。

## 7. 秘密と本人の表示
以下のイベントでは**まず**カバーし、入力gestureとconfirm draftを取消してから処理します。
- カフェへ戻る、sleep、画面ロック、別プロフィール、logout、再認証待ち、重大エラー、別ゲーム開始。
- 個人snapshot再開では本人認証が終わるまでカードを生成しない。
- 画像キャッシュ、画面サムネイル、transition bufferに秘密を再表示させない。

PrivacyCoverの塗りとprivateオブジェクト非表示/消去をUIタスクで実行。BSPの描画flushが完了する前に他画面へアニメーションしない。目標100msは受入試験の計測値で判定し、ここでは達成を保証しません。

画面カバーは物理の覗き見防止や暗号化ではありません。許可された本人が見ている間の通常の視野角は残ります。秘密は高級感より優先し、フェードで隠す演出をしません。

## 8. 全状態のUI更新契約
| 状態 | 描画 | 入力 |
|---|---|---|
| loading/dealing | 公開進行とカード裏 | カフェ、ヘルプのみ |
| human draft | 公開許可カード＋候補 | 選択可、合法時だけ確認 |
| ai pending | 既に見える自分札は継続表示可 | 同時選択確定不可、draft可 |
| confirming | 不透明ConfirmSheet | 取消・1回の決定 |
| committed/applying | 保存中の文字、見える情報のみ | 同じrevisionのゲーム操作不可 |
| reveal | 保存済み結果の演出 | 二重配札/二重加点なし |
| hand/match result | 公開条件に応じた結果 | 次へ/再戦/内訳（許可時のみ） |
| paused/recover | カバー、説明 | 認証/再開/終了 |
| storage uncertain | カバー＋照合中 | 新しい手を送らず復旧 |

モード・providerが変わったら画面も即変更。「Jev待ち」の装飾を端末AI対戦に残しません。強制選択や厳密計算による結果には、その実際の出所を示します。

## 9. テーマ設定とデータ移行
新しいUI設定は `{schema:1,theme_id:'table_lounge',high_contrast:false,reduced_motion:false}`。既存`ct_cards`をclearしない。テーマ旧値/未知値は標準テーマへ戻し、ゲームsnapshotを廃棄しません。

文字列IDを変えるときもルールのaction IDは変えない。game revisionは行動確定だけ、UIの再配置はui_generationだけを進めます。ブラウザー見本のResetはfixtureを初期化する専用ボタンであり、製品に同じ局の札を引き直すボタンを追加する意味ではありません。

画面JSONをruntimeで外部からダウンロードして実行する構造はv1.1では不要。build時の静的リソースとし、任意JSONによるアクション実行は受け付けません。テーマファイルはプログラムの代わりではありません。

## 10. テストと納品ゲート
A：原本とexisting環境の保全、hash照合。B：JSON・UI gate・秘密投影のPC試験。C：実LVGLで静止画4本。D：draft/confirm/公開/復帰。E：全game phase＋既存Google/Jevの回帰。F：実機と人間の試遊。

PCブラウザーで動いたから実機が完成、ボタンが光ったからController保存成功、モック値が出たからJev接続成功とは報告しません。納品はソース差分、採用SDK版、map、heap計測、代表実機写真/動画、全受入結果、残課題を含めます。

実装の終わりは、4つのテーブルで初めて遊ぶ人が「今自分が何をするか」を理解でき、秘密が漏れず、カフェへ戻れることです。派手さを増やすために合法な操作や文字サイズを犠牲にしません。
