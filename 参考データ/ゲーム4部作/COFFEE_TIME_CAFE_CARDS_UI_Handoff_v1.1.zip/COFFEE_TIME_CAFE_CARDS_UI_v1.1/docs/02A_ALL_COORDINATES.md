# 画面要素の全座標（生成された付表）
UI v1.1.0 / 編集はdata/screens.jsonを先に変更して再生成。

## lobby / 4テーブルを選ぶ
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | CAFE CARDS | `—` |
| `meta` | label | 100,74,280,24 | 今日は、どの勝負にしますか？ | `—` |
| `table_poker` | button | 100,128,132,98 | POKER / 強気を、読む | `ENTER_TABLE` |
| `table_gops` | button | 248,128,132,98 | GOPS / 切り札を読む | `ENTER_TABLE` |
| `table_thirty_one` | button | 100,238,132,98 | THIRTY-ONE / 引き際が勝負 | `ENTER_TABLE` |
| `table_baccarat` | button | 248,238,132,98 | BACCARAT / 予想が分かれる | `ENTER_TABLE` |
| `lobby_note` | label | 98,356,284,26 | 対戦内の点数のみ・換金なし | `—` |
| `cafe` | button | 176,414,128,44 | カフェへ | `LEAVE_DEMO` |

## poker_bet_open / ポーカー：まだベットなし
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | CAFE POKER | `—` |
| `meta` | label | 100,74,280,24 | ハンド 2 / 5 ・ ゲスト | `—` |
| `opponent` | label | 150,110,180,22 | JEV  99 pt | `—` |
| `opp_0` | card | 169,132,26,34 | back | `None` |
| `opp_1` | card | 198,132,26,34 | back | `None` |
| `opp_2` | card | 227,132,26,34 | back | `None` |
| `opp_3` | card | 256,132,26,34 | back | `None` |
| `opp_4` | card | 285,132,26,34 | back | `None` |
| `pot_label` | label | 160,173,160,20 | POT | `—` |
| `pot` | label | 150,194,180,36 | 2 pt | `—` |
| `human` | label | 80,232,320,22 | あなた 99 pt  /  ワンペア | `—` |
| `hand_0` | card | 72,262,64,76 | face | `None` |
| `hand_1` | card | 140,262,64,76 | face | `None` |
| `hand_2` | card | 208,262,64,76 | face | `None` |
| `hand_3` | card | 276,262,64,76 | face | `None` |
| `hand_4` | card | 344,262,64,76 | face | `None` |
| `action_left` | button | 108,350,124,52 | 続ける | `CHECK` |
| `action_right` | button | 248,350,124,52 | 2点出す | `BET` |
| `cafe` | button | 176,414,128,44 | カフェへ | `PAUSE` |

## poker_bet_facing / ポーカー：相手のベットに応答
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | CAFE POKER | `—` |
| `meta` | label | 100,74,280,24 | ハンド 2 / 5 ・ ゲスト | `—` |
| `opponent` | label | 150,110,180,22 | JEV  97 pt | `—` |
| `opp_0` | card | 169,132,26,34 | back | `None` |
| `opp_1` | card | 198,132,26,34 | back | `None` |
| `opp_2` | card | 227,132,26,34 | back | `None` |
| `opp_3` | card | 256,132,26,34 | back | `None` |
| `opp_4` | card | 285,132,26,34 | back | `None` |
| `pot_label` | label | 160,173,160,20 | POT | `—` |
| `pot` | label | 150,194,180,36 | 4 pt | `—` |
| `human` | label | 80,232,320,22 | あなた 99 pt ／ 相手が2点出した | `—` |
| `hand_0` | card | 72,262,64,76 | face | `None` |
| `hand_1` | card | 140,262,64,76 | face | `None` |
| `hand_2` | card | 208,262,64,76 | face | `None` |
| `hand_3` | card | 276,262,64,76 | face | `None` |
| `hand_4` | card | 344,262,64,76 | face | `None` |
| `action_0` | button | 88,350,96,52 | 降りる | `FOLD` |
| `action_1` | button | 192,350,96,52 | 同額で / +2 pt | `CALL` |
| `action_2` | button | 296,350,96,52 | 上乗せ / +4 pt | `RAISE` |
| `cafe` | button | 176,414,128,44 | カフェへ | `PAUSE` |

## poker_draw_wait / ポーカー：交換待機
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | CAFE POKER | `—` |
| `meta` | label | 100,74,280,24 | ハンド 2 / 5 ・ カード交換 | `—` |
| `opponent` | label | 150,110,180,22 | JEV  97 pt | `—` |
| `opp_0` | card | 169,132,26,34 | back | `None` |
| `opp_1` | card | 198,132,26,34 | back | `None` |
| `opp_2` | card | 227,132,26,34 | back | `None` |
| `opp_3` | card | 256,132,26,34 | back | `None` |
| `opp_4` | card | 285,132,26,34 | back | `None` |
| `pot_label` | label | 160,173,160,20 | 交換する札を選択 | `—` |
| `pot` | label | 150,194,180,36 | 0 枚 | `—` |
| `human` | label | 80,232,320,22 | 相手の交換を待っています | `—` |
| `hand_0` | card | 72,262,64,76 | face | `poker_draw` |
| `hand_1` | card | 140,262,64,76 | face | `poker_draw` |
| `hand_2` | card | 208,262,64,76 | face | `poker_draw` |
| `hand_3` | card | 276,262,64,76 | face | `poker_draw` |
| `hand_4` | card | 344,262,64,76 | face | `poker_draw` |
| `action_left` | button | 108,350,124,52 | 選択解除 | `CLEAR_SELECTION` |
| `action_right` | button | 248,350,124,52 | 交換しない | `DRAW_CONFIRM` |
| `cafe` | button | 176,414,128,44 | カフェへ | `PAUSE` |

## poker_draw_ready / ポーカー：交換選択
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | CAFE POKER | `—` |
| `meta` | label | 100,74,280,24 | ハンド 2 / 5 ・ カード交換 | `—` |
| `opponent` | label | 150,110,180,22 | JEV  97 pt | `—` |
| `opp_0` | card | 169,132,26,34 | back | `None` |
| `opp_1` | card | 198,132,26,34 | back | `None` |
| `opp_2` | card | 227,132,26,34 | back | `None` |
| `opp_3` | card | 256,132,26,34 | back | `None` |
| `opp_4` | card | 285,132,26,34 | back | `None` |
| `pot_label` | label | 160,173,160,20 | 交換する札を選択 | `—` |
| `pot` | label | 150,194,180,36 | 0 枚 | `—` |
| `human` | label | 80,232,320,22 | 相手の選択は確定済み | `—` |
| `hand_0` | card | 72,262,64,76 | face | `poker_draw` |
| `hand_1` | card | 140,262,64,76 | face | `poker_draw` |
| `hand_2` | card | 208,262,64,76 | face | `poker_draw` |
| `hand_3` | card | 276,262,64,76 | face | `poker_draw` |
| `hand_4` | card | 344,262,64,76 | face | `poker_draw` |
| `action_left` | button | 108,350,124,52 | 選択解除 | `CLEAR_SELECTION` |
| `action_right` | button | 248,350,124,52 | 交換しない | `DRAW_CONFIRM` |
| `cafe` | button | 176,414,128,44 | カフェへ | `PAUSE` |

## poker_raise_capped / ポーカー：上乗せ上限
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | CAFE POKER | `—` |
| `meta` | label | 100,74,280,24 | ハンド 4 / 5 ・ 交換後 | `—` |
| `opponent` | label | 150,110,180,22 | JEV  85 pt | `—` |
| `opp_0` | card | 169,132,26,34 | back | `None` |
| `opp_1` | card | 198,132,26,34 | back | `None` |
| `opp_2` | card | 227,132,26,34 | back | `None` |
| `opp_3` | card | 256,132,26,34 | back | `None` |
| `opp_4` | card | 285,132,26,34 | back | `None` |
| `pot_label` | label | 160,173,160,20 | POT | `—` |
| `pot` | label | 150,194,180,36 | 26 pt | `—` |
| `human` | label | 80,232,320,22 | あなた89 pt / 同額には4点 | `—` |
| `hand_0` | card | 72,262,64,76 | face | `None` |
| `hand_1` | card | 140,262,64,76 | face | `None` |
| `hand_2` | card | 208,262,64,76 | face | `None` |
| `hand_3` | card | 276,262,64,76 | face | `None` |
| `hand_4` | card | 344,262,64,76 | face | `None` |
| `action_left` | button | 108,350,124,52 | 降りる | `FOLD` |
| `action_right` | button | 248,350,124,52 | 同額 +4 | `CALL` |
| `cafe` | button | 176,414,128,44 | カフェへ | `PAUSE` |

## poker_showdown / ポーカー：ショーダウン
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | CAFE POKER | `—` |
| `meta` | label | 100,74,280,24 | ハンド 2 / 5 ・ 手札公開 | `—` |
| `opp_role` | label | 116,108,248,22 | JEV：ワンペア | `—` |
| `opp_0` | card | 96,138,52,64 | face | `None` |
| `opp_1` | card | 155,138,52,64 | face | `None` |
| `opp_2` | card | 214,138,52,64 | face | `None` |
| `opp_3` | card | 273,138,52,64 | face | `None` |
| `opp_4` | card | 332,138,52,64 | face | `None` |
| `result` | label | 88,211,304,32 | あなたの勝ち | `—` |
| `detail` | label | 100,246,280,24 | 場の30点を獲得 | `—` |
| `hand_0` | card | 96,276,52,62 | face | `None` |
| `hand_1` | card | 155,276,52,62 | face | `None` |
| `hand_2` | card | 214,276,52,62 | face | `None` |
| `hand_3` | card | 273,276,52,62 | face | `None` |
| `hand_4` | card | 332,276,52,62 | face | `None` |
| `action_left` | button | 108,350,124,52 | 内訳 | `SHOW_DECISION` |
| `action_right` | button | 248,350,124,52 | 次のハンド | `NEXT_FIXTURE` |
| `cafe` | button | 176,414,128,44 | カフェへ | `PAUSE` |

## poker_fold_result / ポーカー：フォールド後は秘密保持
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | CAFE POKER | `—` |
| `meta` | label | 100,74,280,24 | ハンド 2 / 5 ・ フォールド | `—` |
| `result` | label | 88,145,304,36 | 相手が降りました | `—` |
| `detail` | label | 100,192,280,28 | 場の6点を獲得 | `—` |
| `privacy` | label | 90,248,300,28 | 双方の札は公開しません | `—` |
| `noprob` | label | 90,280,300,26 | 行動の確率内訳も非表示 | `—` |
| `action_left` | button | 108,350,124,52 | 点数 | `SHOW_SCORE` |
| `action_right` | button | 248,350,124,52 | 次のハンド | `NEXT_FIXTURE` |
| `cafe` | button | 176,414,128,44 | カフェへ | `PAUSE` |

## gops_7 / GOPS：7枚から選択
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | GOPS | `—` |
| `meta` | label | 100,74,280,24 | 7枚勝負 ・ ラウンド 1 / 7 | `—` |
| `opponent` | label | 98,105,284,24 | 相手の選択は確定済み | `—` |
| `prize_label` | label | 142,132,196,22 | 今回の得点 | `—` |
| `human_score` | label | 66,157,94,62 | あなた / 0 pt | `—` |
| `ai_score` | label | 320,157,94,62 | JEV / 0 pt | `—` |
| `prize` | card | 204,158,72,62 | face | `None` |
| `selection_info` | label | 104,226,272,22 | 札を選んでから確定 | `—` |
| `bid_1` | card | 96,254,68,82 | face | `gops` |
| `bid_2` | card | 172,254,68,82 | face | `gops` |
| `bid_3` | card | 248,254,68,82 | face | `gops` |
| `bid_4` | card | 324,254,68,82 | face | `gops` |
| `prev` | button | 40,268,44,52 | ‹ | `PAGE_PREV` |
| `next` | button | 400,268,44,52 | › | `PAGE_NEXT` |
| `action_left` | button | 108,350,124,52 | 残り札 | `SHOW_REMAINING` |
| `action_right` | button | 248,350,124,52 | この札で / 勝負 | `BID_CONFIRM` |
| `cafe` | button | 176,414,128,44 | カフェへ | `PAUSE` |

## gops_13 / GOPS：13枚の4ページ目
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | GOPS | `—` |
| `meta` | label | 100,74,280,24 | 13枚勝負 ・ ラウンド 1 / 13 | `—` |
| `opponent` | label | 98,105,284,24 | 相手の選択は確定済み | `—` |
| `prize_label` | label | 142,132,196,22 | 今回の得点 | `—` |
| `human_score` | label | 66,157,94,62 | あなた / 0 pt | `—` |
| `ai_score` | label | 320,157,94,62 | JEV / 0 pt | `—` |
| `prize` | card | 204,158,72,62 | face | `None` |
| `selection_info` | label | 104,226,272,22 | 札を選んでから確定 | `—` |
| `bid_13` | card | 96,254,68,82 | face | `gops` |
| `prev` | button | 40,268,44,52 | ‹ | `PAGE_PREV` |
| `next` | button | 400,268,44,52 | › | `PAGE_NEXT` |
| `action_left` | button | 108,350,124,52 | 残り札 | `SHOW_REMAINING` |
| `action_right` | button | 248,350,124,52 | この札で / 勝負 | `BID_CONFIRM` |
| `cafe` | button | 176,414,128,44 | カフェへ | `PAUSE` |

## gops_wait / GOPS：相手の確定待ち
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | GOPS | `—` |
| `meta` | label | 100,74,280,24 | 7枚勝負 ・ ラウンド 1 / 7 | `—` |
| `opponent` | label | 98,105,284,24 | JEVに問い合わせ中 | `—` |
| `prize_label` | label | 142,132,196,22 | 今回の得点 | `—` |
| `human_score` | label | 66,157,94,62 | あなた / 0 pt | `—` |
| `ai_score` | label | 320,157,94,62 | JEV / 0 pt | `—` |
| `prize` | card | 204,158,72,62 | face | `None` |
| `selection_info` | label | 104,226,272,22 | 札を選んでから確定 | `—` |
| `bid_1` | card | 96,254,68,82 | face | `gops` |
| `bid_2` | card | 172,254,68,82 | face | `gops` |
| `bid_3` | card | 248,254,68,82 | face | `gops` |
| `bid_4` | card | 324,254,68,82 | face | `gops` |
| `prev` | button | 40,268,44,52 | ‹ | `PAGE_PREV` |
| `next` | button | 400,268,44,52 | › | `PAGE_NEXT` |
| `action_left` | button | 108,350,124,52 | 残り札 | `SHOW_REMAINING` |
| `action_right` | button | 248,350,124,52 | この札で / 勝負 | `BID_CONFIRM` |
| `cafe` | button | 176,414,128,44 | カフェへ | `PAUSE` |

## gops_tie / GOPS：同点は得点を破棄
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | GOPS | `—` |
| `meta` | label | 100,74,280,24 | 7枚勝負 ・ ラウンド 3 / 7 | `—` |
| `result` | label | 92,118,296,32 | 同じ札です | `—` |
| `burn` | label | 92,158,296,28 | 今回の3点は破棄 | `—` |
| `you` | label | 90,202,136,26 | あなた | `—` |
| `opp` | label | 254,202,136,26 | JEV | `—` |
| `you_bid` | card | 128,238,66,88 | face | `None` |
| `ai_bid` | card | 286,238,66,88 | face | `None` |
| `action_left` | button | 108,350,124,52 | 残り札 | `SHOW_REMAINING` |
| `action_right` | button | 248,350,124,52 | 次の / ラウンド | `NEXT_FIXTURE` |
| `cafe` | button | 176,414,128,44 | カフェへ | `PAUSE` |

## gops_remaining / GOPS：公開の残り札
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | GOPS | `—` |
| `meta` | label | 100,74,280,24 | 公開済みの残り札 | `—` |
| `y_title` | label | 102,118,276,26 | あなたの残り | `—` |
| `y_cards` | label | 80,158,320,52 | 1  3  5  7  8  10  13 | `—` |
| `a_title` | label | 102,226,276,26 | JEVの残り | `—` |
| `a_cards` | label | 80,264,320,52 | 1  2  5  6  9  11  12 | `—` |
| `action_left` | button | 108,350,124,52 | 戻る | `RETURN_SCENE` |
| `action_right` | button | 248,350,124,52 | 閉じる | `RETURN_SCENE` |
| `cafe` | button | 176,414,128,44 | カフェへ | `PAUSE` |

## thirty_turn / 31：手札と場を一枚ずつ選ぶ
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | THIRTY-ONE | `—` |
| `meta` | label | 100,74,280,24 | ハンド 1 / 3 ・ 6 / 20手 | `—` |
| `opponent` | label | 112,100,256,24 | JEV  /  3枚は非公開 | `—` |
| `market_title` | label | 108,128,264,22 | 場のカード（共有） | `—` |
| `market_0` | card | 124,160,64,70 | face | `market` |
| `market_1` | card | 208,160,64,70 | face | `market` |
| `market_2` | card | 292,160,64,70 | face | `market` |
| `human` | label | 80,238,320,24 | あなた：21点（スペード） | `—` |
| `hand_0` | card | 124,268,64,70 | face | `thirty_hand` |
| `hand_1` | card | 208,268,64,70 | face | `thirty_hand` |
| `hand_2` | card | 292,268,64,70 | face | `thirty_hand` |
| `action_left` | button | 108,350,124,52 | 交換する | `SWAP_CONFIRM` |
| `action_right` | button | 248,350,124,52 | ここで勝負 | `KNOCK` |
| `cafe` | button | 176,414,128,44 | カフェへ | `PAUSE` |

## thirty_last_reply / 31：ノック後の最後の一手
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | THIRTY-ONE | `—` |
| `meta` | label | 100,74,280,24 | ハンド 1 / 3 ・ 最後の1手 | `—` |
| `opponent` | label | 112,100,256,24 | JEV  /  3枚は非公開 | `—` |
| `market_title` | label | 108,128,264,22 | 場のカード（共有） | `—` |
| `market_0` | card | 124,160,64,70 | face | `market` |
| `market_1` | card | 208,160,64,70 | face | `market` |
| `market_2` | card | 292,160,64,70 | face | `market` |
| `human` | label | 80,238,320,24 | あなた：21点（スペード） | `—` |
| `hand_0` | card | 124,268,64,70 | face | `thirty_hand` |
| `hand_1` | card | 208,268,64,70 | face | `thirty_hand` |
| `hand_2` | card | 292,268,64,70 | face | `thirty_hand` |
| `action_left` | button | 108,350,124,52 | 交換する | `SWAP_CONFIRM` |
| `action_right` | button | 248,350,124,52 | このまま / 比べる | `STAND` |
| `cafe` | button | 176,414,128,44 | カフェへ | `PAUSE` |

## thirty_result / 31：同じスートの得点を比較
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | THIRTY-ONE | `—` |
| `meta` | label | 100,74,280,24 | ハンド 1 / 3 ・ 手札公開 | `—` |
| `opp_score` | label | 116,106,248,26 | JEV：24点 | `—` |
| `opp_0` | card | 124,140,64,70 | face | `None` |
| `opp_1` | card | 208,140,64,70 | face | `None` |
| `opp_2` | card | 292,140,64,70 | face | `None` |
| `result` | label | 92,224,296,32 | あなた：30点 | `—` |
| `hand_0` | card | 124,268,64,70 | face | `None` |
| `hand_1` | card | 208,268,64,70 | face | `None` |
| `hand_2` | card | 292,268,64,70 | face | `None` |
| `action_left` | button | 108,350,124,52 | 終了理由 | `SHOW_REASON` |
| `action_right` | button | 248,350,124,52 | 次のハンド | `NEXT_FIXTURE` |
| `cafe` | button | 176,414,128,44 | カフェへ | `PAUSE` |

## baccarat_open / バカラ：OPEN予想
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | BACCARAT | `—` |
| `meta` | label | 100,74,280,24 | OPEN ・ ラウンド 2 / 5 | `—` |
| `player_label` | label | 90,105,300,26 | PLAYER  /  手札A | `—` |
| `banker_label` | label | 90,224,300,26 | BANKER  /  手札B | `—` |
| `player_0` | card | 124,140,64,70 | face | `None` |
| `player_1` | card | 208,140,64,70 | back | `None` |
| `player_2` | card | 292,140,64,70 | absent | `None` |
| `banker_0` | card | 124,260,64,70 | face | `None` |
| `banker_1` | card | 208,260,64,70 | back | `None` |
| `banker_2` | card | 292,260,64,70 | absent | `None` |
| `privacy` | label | 88,330,304,18 | 同じ札を見て、勝敗を予想 | `—` |
| `action_0` | button | 88,350,96,52 | PLAYER / 勝ち | `PREDICT_PLAYER` |
| `action_1` | button | 192,350,96,52 | BANKER / 勝ち | `PREDICT_BANKER` |
| `action_2` | button | 296,350,96,52 | 引き分け | `PREDICT_TIE` |
| `cafe` | button | 176,414,128,44 | カフェへ | `PAUSE` |

## baccarat_classic / バカラ：CLASSIC予想
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | BACCARAT | `—` |
| `meta` | label | 100,74,280,24 | CLASSIC ・ ラウンド 2 / 5 | `—` |
| `player_label` | label | 90,105,300,26 | PLAYER  /  手札A | `—` |
| `banker_label` | label | 90,224,300,26 | BANKER  /  手札B | `—` |
| `player_0` | card | 124,140,64,70 | back | `None` |
| `player_1` | card | 208,140,64,70 | back | `None` |
| `player_2` | card | 292,140,64,70 | absent | `None` |
| `banker_0` | card | 124,260,64,70 | back | `None` |
| `banker_1` | card | 208,260,64,70 | back | `None` |
| `banker_2` | card | 292,260,64,70 | absent | `None` |
| `privacy` | label | 88,330,304,18 | 同じ札を見て、勝敗を予想 | `—` |
| `action_0` | button | 88,350,96,52 | PLAYER / 勝ち | `PREDICT_PLAYER` |
| `action_1` | button | 192,350,96,52 | BANKER / 勝ち | `PREDICT_BANKER` |
| `action_2` | button | 296,350,96,52 | 引き分け | `PREDICT_TIE` |
| `cafe` | button | 176,414,128,44 | カフェへ | `PAUSE` |

## baccarat_reveal / バカラ：予想確定後
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | BACCARAT | `—` |
| `meta` | label | 100,74,280,24 | OPEN ・ ラウンド 2 / 5 | `—` |
| `player_label` | label | 90,105,300,26 | PLAYER  /  手札A | `—` |
| `banker_label` | label | 90,224,300,26 | BANKER  /  手札B | `—` |
| `player_0` | card | 124,140,64,70 | face | `None` |
| `player_1` | card | 208,140,64,70 | back | `None` |
| `player_2` | card | 292,140,64,70 | absent | `None` |
| `banker_0` | card | 124,260,64,70 | face | `None` |
| `banker_1` | card | 208,260,64,70 | back | `None` |
| `banker_2` | card | 292,260,64,70 | absent | `None` |
| `privacy` | label | 88,330,304,18 | あなた：PLAYER ／ JEV：BANKER | `—` |
| `action_left` | button | 108,350,124,52 | 予想を確認 | `SHOW_GUESSES` |
| `action_right` | button | 248,350,124,52 | カードを開く | `NEXT_FIXTURE` |
| `cafe` | button | 176,414,128,44 | カフェへ | `PAUSE` |

## baccarat_result / バカラ：公開した札と確定点
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | BACCARAT | `—` |
| `meta` | label | 100,74,280,24 | OPEN ・ ラウンド 2 / 5 | `—` |
| `player_label` | label | 90,105,300,26 | PLAYER  /  手札A：5点 | `—` |
| `banker_label` | label | 90,224,300,26 | BANKER  /  手札B：7点 | `—` |
| `player_0` | card | 124,140,64,70 | face | `None` |
| `player_1` | card | 208,140,64,70 | face | `None` |
| `player_2` | card | 292,140,64,70 | face | `None` |
| `banker_0` | card | 124,260,64,70 | face | `None` |
| `banker_1` | card | 208,260,64,70 | face | `None` |
| `banker_2` | card | 292,260,64,70 | absent | `None` |
| `privacy` | label | 88,330,304,18 | BANKER勝ち ／ JEVが的中 | `—` |
| `action_left` | button | 108,350,124,52 | 予想の内訳 | `SHOW_DECISION` |
| `action_right` | button | 248,350,124,52 | 次の / ラウンド | `NEXT_FIXTURE` |
| `cafe` | button | 176,414,128,44 | カフェへ | `PAUSE` |

## paused / 一時停止：秘密のない画面
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | CAFE CARDS | `—` |
| `meta` | label | 100,74,280,24 | 一時停止中 | `—` |
| `cover_title` | label | 90,144,300,36 | 手札を隠しています | `—` |
| `cover_body` | label | 90,202,300,76 | カフェへ戻れます。 / 再開には本人確認が必要です。 | `—` |
| `save` | label | 90,294,300,28 | 保存済みの試合を維持します | `—` |
| `action_left` | button | 108,350,124,52 | カフェへ | `LEAVE_DEMO` |
| `action_right` | button | 248,350,124,52 | 再開へ | `RESUME_DEMO` |
| `cafe` | button | 176,414,128,44 | 戻る | `RESUME_DEMO` |

## network_error / 通信障害：照会と切替
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | CAFE CARDS | `—` |
| `meta` | label | 100,74,280,24 | 接続を確認してください | `—` |
| `error_title` | label | 86,139,308,36 | 応答を確認できません | `—` |
| `error_body` | label | 86,199,308,76 | 同じ依頼を照会します。 / 札や点数は変更しません。 | `—` |
| `error_note` | label | 84,291,312,24 | 端末AIへの切替は本人が選択 | `—` |
| `action_left` | button | 108,350,124,52 | 照会する | `RETRY_POLL` |
| `action_right` | button | 248,350,124,52 | 端末AIへ | `CHOOSE_LOCAL` |
| `cafe` | button | 176,414,128,44 | カフェへ | `PAUSE` |

## match_result / 試合結果：対戦相手を明記
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | CAFE CARDS | `—` |
| `meta` | label | 100,74,280,24 | 今回の対戦結果 | `—` |
| `result_title` | label | 90,135,300,40 | あなたの勝ち | `—` |
| `res_game` | label | 86,185,308,30 | POKER / 5ハンド完了 | `—` |
| `res_scores` | label | 92,231,296,80 | あなた 112 pt / 相手 88 pt | `—` |
| `res_provider` | label | 92,316,296,24 | Jev＋端末AI  /  混合対戦 | `—` |
| `action_left` | button | 108,350,124,52 | 記録 | `SHOW_RECORD` |
| `action_right` | button | 248,350,124,52 | 再戦 | `REMATCH` |
| `cafe` | button | 176,414,128,44 | カフェへ | `PAUSE` |

## identity / 本人選択は既存認証へ接続
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | CAFE CARDS | `—` |
| `meta` | label | 100,74,280,24 | プレイヤー選択 | `—` |
| `person_0` | button | 112,122,256,48 | YUJI | `IDENTITY_SAMPLE` |
| `person_1` | button | 112,178,256,48 | SORA | `IDENTITY_SAMPLE` |
| `person_2` | button | 112,234,256,48 | MOKA | `IDENTITY_SAMPLE` |
| `person_3` | button | 112,290,256,48 | ゲスト | `IDENTITY_SAMPLE` |
| `auth_note` | label | 76,352,328,26 | 氏名・PIN・戦績はここで公開しない | `—` |
| `cafe` | button | 176,414,128,44 | 戻る | `LOBBY` |

## settings / 表示設定
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | CAFE CARDS | `—` |
| `meta` | label | 100,74,280,24 | 設定・プレビュー | `—` |
| `setup_title` | label | 104,116,272,30 | 見た目と動き | `—` |
| `motion` | button | 104,168,272,52 | 動きを控える：切替 | `TOGGLE_MOTION` |
| `contrast` | button | 104,232,272,52 | 高コントラスト：切替 | `TOGGLE_CONTRAST` |
| `setup_note` | label | 96,304,288,26 | ゲームのルールは変わりません | `—` |
| `action_left` | button | 108,350,124,52 | 戻る | `LOBBY` |
| `action_right` | button | 248,350,124,52 | テーブルへ | `RETURN_SCENE` |
| `cafe` | button | 176,414,128,44 | カフェへ | `PAUSE` |

## tutorial / チュートリアル：読む領域を確保
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | CAFE CARDS | `—` |
| `meta` | label | 100,74,280,24 | 遊び方 1 / 2 | `—` |
| `help_title` | label | 88,123,304,34 | 札を選んでから、決定 | `—` |
| `help_body` | label | 84,184,312,100 | カードを押すだけでは / 交換や勝負は確定しません。 / 確認画面で内容を確かめます。 | `—` |
| `help_note` | label | 90,304,300,26 | 現金・景品交換はありません | `—` |
| `action_left` | button | 108,350,124,52 | 戻る | `RETURN_SCENE` |
| `action_right` | button | 248,350,124,52 | 次へ | `HELP_NEXT` |
| `cafe` | button | 176,414,128,44 | カフェへ | `PAUSE` |

## decision_detail / 行動選択値：勝率と区別
| ID | 種類 | x,y,w,h | 文言・公開形 | 操作 |
|---|---|---|---|---|
| `title` | label | 128,42,224,28 | JEV の判断 | `—` |
| `meta` | label | 100,74,280,24 | 公開可能なハンドのみ | `—` |
| `meaning` | label | 90,116,300,32 | 行動候補の選択値 | `—` |
| `values` | label | 104,162,272,112 | CALL  62% / RAISE  24% / FOLD  14% | `—` |
| `notwin` | label | 88,288,304,28 | 勝率や心の声ではありません | `—` |
| `action_left` | button | 108,350,124,52 | 説明 | `SHOW_PROBABILITY_HELP` |
| `action_right` | button | 248,350,124,52 | 戻る | `RETURN_SCENE` |
| `cafe` | button | 176,414,128,44 | カフェへ | `PAUSE` |
