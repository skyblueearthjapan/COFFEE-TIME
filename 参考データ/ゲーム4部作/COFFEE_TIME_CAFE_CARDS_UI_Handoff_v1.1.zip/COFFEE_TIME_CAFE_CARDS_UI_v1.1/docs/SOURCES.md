# 参照資料・根拠・確認範囲
**資料確認：2026-09-22。公式資料の仕様と、本パッケージ独自のUI設計値を区別します。**

| ID | 一次資料 | 利用した事項 |
|---|---|---|
| S01 | https://docs.waveshare.com/ESP32-S3-Touch-LCD-2.8C | 対象の480×480タッチ画面、Flash/PSRAM、基本ボード仕様 |
| S02 | https://docs.lvgl.io/8.4/overview/style.html | styleの共有と寿命、state、transformの中間レイヤー |
| S03 | https://raw.githubusercontent.com/lvgl/lvgl/v8.4.0/docs/overview/event.md | クリック、押下、press-lost、スクロールのイベント |
| S04 | https://docs.lvgl.io/8.4/porting/os.html | UIタスクとmutexを統一する必要 |
| S05 | https://docs.lvgl.io/8.4/overview/font.html | UTF-8、フォント生成、必要文字の準備 |
| S06 | https://docs.typesafe.ai/primitives/choice | 候補別の選択値とconfidence。勝率の別名にしない |
| S07 | https://docs.lvgl.io/8.4/overview/drawing.html | 描画更新、既存バッファの利用、描画コスト |
| S08 | https://docs.lvgl.io/8.4/widgets/core/label.html | label、長文の表示と改行 |

上のリンク先は更新されることがあります。ライブラリを導入時に記録したcommit/バージョンで固定して再検証してください。公開されている仕様に基づく接続例であり、この作業では既存ESP32ワークスペースも実APIキーも使っていません。

ゲームルールはユーザーへ既に提供された原本を継続しています。今回、新しいポーカーや31の流派を調査して置き換える作業はしていません。原本をハッシュで特定し、全文と元ZIPを保全しました。ホスト検査は今回のUI層のみで、原本が報告した全手札列挙などを再実行したとは扱いません。

SVG、JSON、参考コード、Markdown、モック用カード/模様はこのパッケージ用の制作物です。実在のカジノのロゴやカード柄を使用していません。画像作成環境のフォントファイルは配布しません。スクリーンショット内の文字と、実行時の日本語フォントのビルドは別です。
