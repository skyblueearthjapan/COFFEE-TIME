"""Contract samples. Requires jsonschema; not a live protocol or game test."""
from pathlib import Path
import copy,json
import jsonschema
R=Path(__file__).resolve().parents[1]
schema=json.loads((R/'data/ui_view_model.schema.json').read_text());vm=json.loads((R/'data/example_view.json').read_text())
v=jsonschema.Draft202012Validator(schema);n=0
jsonschema.Draft202012Validator.check_schema(schema)
def check(obj,expected):
 global n;n+=1;assert v.is_valid(obj)==expected,(n,list(v.iter_errors(obj)))
check(vm,True)
for extra in ['deck','opponent_hand','future_cards','player_token','pin','ai_observation']:
 bad=copy.deepcopy(vm);bad[extra]=[];check(bad,False)
for key,value in [('rank',14),('suit','S'),('value',13),('selectable',True),('selected',True)]:
 bad=copy.deepcopy(vm);bad['cards'][0][key]=value;check(bad,False)
for rank in range(2,15):
 for suit in ['C','D','H','S']:
  good=copy.deepcopy(vm);good['cards'][5].update(rank=rank,suit=suit);check(good,True)
for value in range(1,14):
 good=copy.deepcopy(vm);good['cards'][5].update(zone='candidate',rank=None,suit=None,value=value);check(good,True)
bad=copy.deepcopy(vm);bad['cards'][5]['rank']=None;check(bad,False)
bad=copy.deepcopy(vm);bad['cards'][5]['value']=3;check(bad,False)
bad=copy.deepcopy(vm);bad['ui_version']='2.0';check(bad,False)
bad=copy.deepcopy(vm);bad['cards'][5]['secret']=3;check(bad,False)
bad=copy.deepcopy(vm);bad['covered']=True;check(bad,False)
good=copy.deepcopy(vm);good['covered']=True;good['cards']=[];check(good,True)
report={'passed':True,'samples':n,'scope':'internal presentation schema only'}
(R/'results/schema_tests.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
