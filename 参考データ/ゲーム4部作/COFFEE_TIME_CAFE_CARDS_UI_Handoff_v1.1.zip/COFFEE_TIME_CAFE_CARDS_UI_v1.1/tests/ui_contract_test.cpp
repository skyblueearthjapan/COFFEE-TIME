#include "../reference/ui_contract.hpp"
#include <cassert>
#include <iostream>
using namespace cafe::ui;
int main(){
 unsigned assertions=0;auto ck=[&](bool x){++assertions;assert(x);};
 Stamp s{1,2,3};Gate g;Command out;
 g.bind(s);ck(g.propose(s,4,true));ck(g.confirm(s,true,false,true,out));ck(out.action==4);
 for(int i=0;i<100;i++){ck(!g.confirm(s,true,false,true,out));g.bind(s);ck(!g.propose(s,4,true));}
 Stamp reflow{1,2,99};g.bind(reflow);ck(!g.propose(reflow,4,true));g.cover();g.uncover(reflow);ck(!g.propose(reflow,4,true));ck(!g.releaseRejected(reflow,false));ck(g.releaseRejected(reflow,true));ck(g.propose(reflow,4,true));ck(g.confirm(reflow,true,false,true,out));
 Stamp next{1,3,4};g.bind(next);ck(!g.propose(s,4,true));ck(!g.propose(next,4,false));ck(!g.propose(next,4,true,true,false));
 ck(g.propose(next,4,true,true,true));g.cover();ck(!g.confirm(next,true,true,true,out));
 g.uncover(next);ck(!g.confirm(next,true,false,true,out));ck(g.propose(next,5,true));ck(g.confirm(next,true,false,true,out));
 for(int i=0;i<416;i++){auto hidden=displayCard(true,false,i);ck(hidden.face==Face::Back);ck(hidden.visible_id==0xffff);ck(wellFormed(hidden));ck(wellFormed(displayCard(true,true,i)));}
 ck(!wellFormed({Face::Back,12}));ck(!wellFormed({Face::FaceUp,65535}));
 Gesture p;p.press(s,10,100,100);ck(p.release(s,10,104,102));ck(!p.release(s,10,104,102));
 p.press(s,10,100,100);ck(!p.release(next,10,100,100));p.press(s,10,100,100);ck(!p.release(s,11,100,100));
 p.press(s,10,100,100);ck(!p.release(s,10,120,100));p.press(s,10,100,100);p.cancel();ck(!p.release(s,10,100,100));
 ck(inside({176,414,128,44}));ck(!inside({0,0,100,100}));
 std::cout<<"{\"passed\":true,\"assertions\":"<<assertions<<",\"scope\":\"host input guard / display-card projection only\"}\n";
}
