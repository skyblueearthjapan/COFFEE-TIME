from pathlib import Path
import json, math, hashlib
P=Path(__file__).resolve().parents[1]
S=json.loads((P/'data/screens.json').read_text())['screens'];T=json.loads((P/'data/theme.json').read_text());errors=[];rects=0;targets=0
for s in S:
 ids=set();interactive=[]
 for e in s['elements']:
  assert e['id'] not in ids;ids.add(e['id']);x,y,w,h=e['rect'];rects+=1
  for lift in [0,-6] if e.get('select_group') else [0]:
   if any((a-240)**2+(b-240)**2>228**2 for a in (x,x+w) for b in (y+lift,y+h+lift)):errors.append((s['id'],e['id'],'outside-safe-circle'))
  if e['kind']=='button' or e.get('select_group'):
   targets+=1;interactive.append(e)
   if w<44 or h<44:errors.append((s['id'],e['id'],'touch-too-small'))
  if e['kind']=='card' and e['face']!='face' and any(e.get(k) is not None for k in ['rank','suit','value']):errors.append((s['id'],e['id'],'hidden-value'))
 for i,a in enumerate(interactive):
  x,y,w,h=a['rect']
  for b in interactive[i+1:]:
   xx,yy,ww,hh=b['rect']
   if min(x+w,xx+ww)>max(x,xx) and min(y+h,yy+hh)>max(y,yy):errors.append((s['id'],a['id'],b['id'],'overlapping-hitboxes'))
 if s.get('covered') and any(e.get('private') for e in s['elements']):errors.append((s['id'],'private-on-cover'))
# Automated regression checks tied to the baseline house rules.
d={s['id']:s for s in S}
assert 'STAND' not in d['thirty_turn']['legal_actions'];assert 'KNOCK' not in d['thirty_last_reply']['legal_actions']
assert all(e['kind']!='card' for e in d['poker_fold_result']['elements'])
assert len([e for e in d['baccarat_open']['elements'] if e['kind']=='card' and e['face']=='face'])==2
assert len([e for e in d['baccarat_classic']['elements'] if e['kind']=='card' and e['face']=='face'])==0
# Relative luminance arithmetic, used only for specified UI design targets.
def lum(h):
 v=[int(h[i:i+2],16)/255 for i in (1,3,5)];v=[c/12.92 if c<=.04045 else ((c+.055)/1.055)**2.4 for c in v];return sum(a*b for a,b in zip(v,[.2126,.7152,.0722]))
def contrast(a,b):
 a,b=sorted([lum(a),lum(b)]);return (b+.05)/(a+.05)
c=T['colors'];pairs=[('text','felt_top'),('muted','felt_top'),('gold','felt_top'),('ink','paper'),('red','paper'),('gold_ink','gold'),('text','button'),('text','danger'),('disabled_text','disabled')]
ratios={a+'/'+b:contrast(c[a],c[b]) for a,b in pairs}
for k,r in ratios.items():
 if r<4.5:errors.append(('contrast',k,r))
base=json.loads((P/'data/baseline.json').read_text())
assert hashlib.sha256((P/'baseline/CAFE_CARDS_Design_v1.0_READONLY.md').read_bytes()).hexdigest()==base['source_sha256']
report={'passed':not errors,'screens':len(S),'rectangles':rects,'touch_targets':targets,'checked_selection_lift_px':6,'contrast_ratios':ratios,'errors':errors,'scope':'static screen JSON geometry, key privacy cases, contrast arithmetic, baseline file integrity'}
(P/'results/layout_tests.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False));assert not errors
