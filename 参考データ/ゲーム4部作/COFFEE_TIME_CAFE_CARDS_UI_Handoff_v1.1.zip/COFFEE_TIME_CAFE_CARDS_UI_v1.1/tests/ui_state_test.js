'use strict';
const assert=require('node:assert/strict');const api=require('../reference/ui_state.js');let n=0;const ck=(x)=>{n++;assert.ok(x)};
let g=new api.ConfirmGate();const s={matchId:'m',revision:1,generation:1};g.bind(s);
ck(g.propose(s,'CALL',['CALL']));ck(g.confirm(s,['CALL']).action==='CALL');
for(let i=0;i<100;i++){ck(g.confirm(s,['CALL'])===null);g.bind(s);ck(!g.propose(s,'CALL',['CALL']));}
const moved={...s,generation:22};g.bind(moved);ck(!g.propose(moved,'CALL',['CALL']));g.cover();g.uncover({...moved,generation:23});ck(!g.propose({...moved,generation:23},'CALL',['CALL']));
ck(!g.releaseRejected(moved,false));ck(g.releaseRejected(moved,true));
const next={...s,revision:2,generation:2};g.bind(next);ck(!g.propose(s,'CALL',['CALL']));ck(!g.propose(next,'FOLD',['CALL']));ck(!g.propose(next,'CALL',['CALL'],true,false));
ck(g.propose(next,'CALL',['CALL'],true,true));g.cover();ck(g.confirm(next,['CALL'])===null);g.uncover(next);ck(g.confirm(next,['CALL'])===null);
for(let mask=0;mask<32;mask++){const indices=[0,1,2,3,4].filter(i=>mask&(1<<i));ck(api.drawMask(indices)===mask);}
for(let count=1;count<=13;count++)for(let page=0;page<Math.ceil(count/4);page++){let p=api.gopsPage(Array.from({length:count},(_,i)=>i+1),page);ck(p.values.length<=4);ck(p.values.every(v=>v>=1&&v<=count));}
for(let owed=0;owed<13;owed++)for(let r=0;r<3;r++){let a=api.legalBetActions(owed,r);ck(owed===0?a.includes('CHECK'):!a.includes('CHECK'));ck(owed>0&&r===2?!a.includes('RAISE'):true);}
ck(!api.decisionVisible('poker','HAND_RESULT',true,'jev',true));ck(api.decisionVisible('poker','HAND_RESULT',false,'jev',true));ck(!api.decisionVisible('gops','HUMAN_SELECT',false,'jev',false));
for(let rank=2;rank<=14;rank++)for(const suit of ['C','D','H','S']){let hidden=api.safeDisplayCard({rank,suit,secret:'NO'},false);ck(hidden.rank===null&&hidden.suit===null);ck(!JSON.stringify(hidden).includes('NO'));}
assert.throws(()=>api.gopsPage([1,1],0));assert.throws(()=>api.drawMask([6]));
console.log(JSON.stringify({passed:true,assertions:n,scope:'host UI state and privacy projection; no actual Jev or game rules'}));
