"""Optional Chromium inspection of the UI fixture preview. Not ESP32 or game-engine tests."""
from pathlib import Path
import json, os, shutil, sys
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
scenes=json.loads((ROOT/'data/screens.json').read_text())['screens']
report={'scope':'HTML fixture preview only; no game engine, ESP32, Google or Jev','checks':[],'text_issues':[],'browser_errors':[]}

def check(name,ok,detail=''):
 report['checks'].append({'name':name,'passed':bool(ok),'detail':detail})
 if not ok: print('FAIL',name,detail)
with sync_playwright() as p:
 exe=os.environ.get('CHROMIUM_PATH') or shutil.which('chromium') or shutil.which('google-chrome')
 browser=p.chromium.launch(**({'executable_path':exe} if exe else {}),headless=True,args=['--no-sandbox'])
 report['browser_version']=browser.version
 page=browser.new_page(viewport={'width':1240,'height':1000},device_scale_factor=1)
 page.on('pageerror',lambda e:report['browser_errors'].append(str(e)))
 # set_content avoids managed-browser file:// restrictions in the authoring environment.
 page.set_content((ROOT/'preview/index.html').read_text(),wait_until='load')
 page.evaluate('document.fonts.ready')
 (ROOT/'assets/screens').mkdir(parents=True,exist_ok=True)
 for scene in scenes:
  sid=scene['id'];page.evaluate('(id)=>demo.openScene(id)',sid)
  check('scene:'+sid,page.locator('#screen').count()==1)
  issues=page.evaluate('''()=>{
   const errors=[];for(const g of document.querySelectorAll('.textblock')){
    const r=g.dataset.rect.split(',').map(Number),t=g.querySelector('text'), style=getComputedStyle(t);
    const canvas=document.createElement('canvas'), ctx=canvas.getContext('2d');ctx.font=`${style.fontWeight} ${style.fontSize} ${style.fontFamily}`;
    for(const e of g.querySelectorAll('tspan')){const width=e.getComputedTextLength();if(width>r[2]+0.1)errors.push({id:g.dataset.element,text:e.textContent,width,available:r[2]});}
   }return errors;
  }''')
  report['text_issues'] +=[{'scene':sid,**x} for x in issues]
  page.locator('#screen').screenshot(path=str(ROOT/'assets/screens'/f'{sid}.png'))
  svg=page.evaluate('demo.getSvg()')
  (ROOT/'assets/screens'/f'{sid}.svg').write_text(svg,encoding='utf-8')
 # Open each fixed action sheet too; long confirmation text must not escape its panel.
 modal_count=0
 for scene in scenes:
  for element in scene['elements']:
   if element['kind']!='button':continue
   page.evaluate('(id)=>demo.openScene(id)',scene['id'])
   page.evaluate('(id)=>demo.doAction(id)',element['id'])
   if not page.locator('#modal').count():continue
   modal_count+=1
   problems=page.evaluate("""()=>[...document.querySelectorAll('#modal .textblock')].flatMap(b=>{const r=b.dataset.rect.split(',').map(Number);return [...b.querySelectorAll('tspan')].filter(t=>t.getComputedTextLength()>r[2]+.1).map(t=>({text:t.textContent,width:t.getComputedTextLength(),available:r[2]}))})""")
   report['text_issues'] += [{'scene':scene['id'],'action':element['id'],**x}for x in problems]
 report['modal_variants_checked']=modal_count
 # Every scene must be horizontally readable; physical sizes remain a hardware gate.
 check('all_static_text_widths',not report['text_issues'],report['text_issues'])
 page.evaluate("demo.openScene('poker_draw_ready')")
 page.locator('[data-hit="hand_0"]').click();page.locator('[data-hit="hand_2"]').click()
 check('poker_two_slot_mask',page.evaluate('demo.state().drafts.drawMask')==5)
 page.locator('[data-hit="action_right"]').click()
 check('poker_proposal_no_commit',page.evaluate('demo.state().confirmations')==0)
 check('draw_dialog_width',page.evaluate("Math.max(...[...document.querySelectorAll('#modal [data-element=modal_body] tspan')].map(e=>e.getComputedTextLength()))<=284"))
 page.locator('[data-hit="modal_cancel"]').click()
 check('poker_cancel_preserves_mask',page.evaluate('demo.state().drafts.drawMask')==5)
 page.locator('[data-hit="action_right"]').click();page.locator('[data-hit="modal_accept"]').click()
 page.evaluate("demo.doAction('modal_accept')")
 check('single_command_after_double_accept',page.evaluate('demo.state().confirmations')==1)
 check('accepted_dialog_width',page.evaluate("Math.max(...[...document.querySelectorAll('#modal [data-element=modal_body] tspan')].map(e=>e.getComputedTextLength()))<=284"))
 page.locator('[data-hit="modal_cancel"]').click()
 check('command_busy_disables_confirm',page.locator('[data-hit="action_right"]').get_attribute('data-enabled')=='false')
 page.evaluate("demo.openScene('poker_draw_wait');demo.doAction('hand_0');demo.doAction('action_right')")
 check('waiting_ai_blocks_confirm',page.evaluate('demo.state().modal') is None)
 page.evaluate('demo.setReady(true)');page.locator('[data-hit="action_right"]').click()
 check('ready_does_not_auto_submit',page.evaluate('demo.state().confirmations')==1)
 page.locator('[data-hit="modal_cancel"]').click()
 page.evaluate("demo.openScene('gops_13')")
 # Last page contains 13, then selection must survive paging back.
 page.evaluate("demo.doAction('bid_13');demo.doAction('prev')")
 check('gops_13_selection_persists',page.evaluate('demo.state().drafts.bid')==13)
 check('gops_selected_number_visible','13' in page.locator('[data-element="selection_info"]').text_content())
 page.evaluate("demo.openScene('thirty_turn');demo.doAction('hand_0');demo.doAction('market_1')")
 check('thirty_pair_selection',page.evaluate('demo.state().drafts.hand')=='hand_0' and page.evaluate('demo.state().drafts.market')=='market_1')
 check('thirty_normal_no_pass',page.locator('[data-action="STAND"]').count()==0)
 page.evaluate("demo.openScene('thirty_last_reply')")
 check('thirty_last_reply_no_knock',page.locator('[data-action="KNOCK"]').count()==0)
 page.evaluate("demo.openScene('baccarat_classic')")
 check('baccarat_classic_no_card_faces',all(e['face']!='face' for e in page.evaluate('demo.displayElements()') if e['kind']=='card'))
 page.evaluate("demo.openScene('baccarat_open')")
 check('baccarat_open_exactly_two_faces',sum(e['face']=='face' for e in page.evaluate('demo.displayElements()') if e['kind']=='card')==2)
 page.evaluate("demo.openScene('poker_fold_result')")
 check('fold_no_decision_button',page.locator('[data-action="SHOW_DECISION"]').count()==0)
 page.evaluate("demo.openScene('poker_bet_facing');demo.doAction('cafe')")
 check('pause_clears_private_dom',page.locator('[data-private="true"]').count()==0)
 check('pause_has_no_card_dom',page.locator('[data-card]').count()==0)
 # Pointer drag must not toggle a card or send command.
 page.evaluate("demo.openScene('poker_draw_ready')")
 box=page.locator('[data-hit="hand_0"]').bounding_box();x,y=box['x']+20,box['y']+30
 page.mouse.move(x,y);page.mouse.down();page.mouse.move(x+20,y);page.mouse.up()
 check('drag_not_click',page.evaluate('demo.state().drafts.drawMask||0')==0)
 page.evaluate("demo.openScene('settings');demo.doAction('motion');demo.doAction('contrast')")
 check('settings_still_renders',page.locator('#screen').count()==1)
 for width in [320,375,768,1240]:
  page.set_viewport_size({'width':width,'height':1000});page.evaluate("demo.openScene('poker_draw_ready')")
  check(f'viewport:{width}',page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1'))
 check('no_browser_errors',not report['browser_errors'],report['browser_errors'])
 browser.close()
report['passed']=all(c['passed'] for c in report['checks'])
report['count']=len(report['checks'])
(ROOT/'results/browser_tests.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'passed':report['passed'],'checks':report['count'],'text_issues':len(report['text_issues'])},ensure_ascii=False))
sys.exit(0 if report['passed'] else 1)
