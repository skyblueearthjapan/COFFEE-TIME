// GENERATED from data/theme.json. Do not adjust only this file.
#pragma once
#include <cstdint>
namespace cafe::ui::theme {
inline constexpr int width=480, height=480, safe_radius=228;
inline constexpr std::uint32_t backdrop=0x0D1713;
inline constexpr std::uint32_t walnut_dark=0x261C15;
inline constexpr std::uint32_t walnut_light=0x513725;
inline constexpr std::uint32_t brass=0xC6A66A;
inline constexpr std::uint32_t felt_top=0x164B3B;
inline constexpr std::uint32_t felt=0x123B30;
inline constexpr std::uint32_t felt_dark=0x0C2A22;
inline constexpr std::uint32_t text=0xF7EFDF;
inline constexpr std::uint32_t muted=0xD8CEB9;
inline constexpr std::uint32_t paper=0xF7EFE2;
inline constexpr std::uint32_t ink=0x17261E;
inline constexpr std::uint32_t red=0xA32638;
inline constexpr std::uint32_t button=0x183D31;
inline constexpr std::uint32_t button_pressed=0x23513F;
inline constexpr std::uint32_t gold=0xE0BD78;
inline constexpr std::uint32_t gold_ink=0x241C10;
inline constexpr std::uint32_t danger=0x762537;
inline constexpr std::uint32_t disabled=0x2D3D34;
inline constexpr std::uint32_t disabled_text=0xC1C8BD;
inline constexpr std::uint32_t divider=0x638573;
} // namespace cafe::ui::theme
