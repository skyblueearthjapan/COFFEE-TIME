#include "table_lounge.hpp"
#include "theme_tokens.hpp"
#include <cassert>
namespace cafe::ui::lv8 {
namespace {
void inert(lv_obj_t* obj) {
 lv_obj_clear_flag(obj,LV_OBJ_FLAG_SCROLLABLE);
 lv_obj_clear_flag(obj,LV_OBJ_FLAG_CLICKABLE);
}
lv_obj_t* panel(lv_obj_t* parent,Rect r,std::uint32_t rgb,int radius) {
 auto* o=lv_obj_create(parent);lv_obj_remove_style_all(o);inert(o);
 lv_obj_set_pos(o,r.x,r.y);lv_obj_set_size(o,r.w,r.h);
 lv_obj_set_style_pad_all(o,0,LV_PART_MAIN);
 lv_obj_set_style_bg_color(o,lv_color_hex(rgb),LV_PART_MAIN);
 lv_obj_set_style_bg_opa(o,LV_OPA_COVER,LV_PART_MAIN);
 lv_obj_set_style_radius(o,radius,LV_PART_MAIN);
 return o;
}
// Stable-lifetime shared styles. No lv_style_t with an expired stack address.
struct Shared {
 lv_style_t base{},pressed{},disabled{},primary{},danger{};bool ready=false;
 void init(){
  if(ready)return;
  lv_style_init(&base);lv_style_set_radius(&base,13);
  lv_style_set_bg_opa(&base,LV_OPA_COVER);lv_style_set_bg_color(&base,lv_color_hex(theme::button));
  lv_style_set_border_width(&base,1);lv_style_set_border_color(&base,lv_color_hex(theme::brass));
  lv_style_set_text_color(&base,lv_color_hex(theme::text));lv_style_set_pad_all(&base,0);
  lv_style_init(&pressed);lv_style_set_bg_color(&pressed,lv_color_hex(theme::button_pressed));
  lv_style_init(&disabled);lv_style_set_bg_color(&disabled,lv_color_hex(theme::disabled));
  lv_style_set_text_color(&disabled,lv_color_hex(theme::disabled_text));
  lv_style_init(&primary);lv_style_set_bg_color(&primary,lv_color_hex(theme::gold));
  lv_style_set_text_color(&primary,lv_color_hex(theme::gold_ink));
  lv_style_init(&danger);lv_style_set_bg_color(&danger,lv_color_hex(theme::danger));
  ready=true;
 }
};
Shared shared;
}
lv_obj_t* makeTableRoot(lv_obj_t* parent){
 auto* root=panel(parent,{0,0,480,480},theme::backdrop,0);
 panel(root,{26,98,428,296},theme::walnut_dark,148);
 panel(root,{33,105,414,282},theme::brass,141);
 auto* felt=panel(root,{40,112,400,268},theme::felt_top,134);
 lv_obj_set_style_bg_grad_color(felt,lv_color_hex(theme::felt_dark),LV_PART_MAIN);
 lv_obj_set_style_bg_grad_dir(felt,LV_GRAD_DIR_VER,LV_PART_MAIN);
 // Root is rectangular internally; physical round panel masks outside the display.
 // All interactive children MUST satisfy inside(rect); decorative layers are inert.
 return root;
}
lv_obj_t* makeLabel(lv_obj_t* parent,Rect r,const char* s,const lv_font_t* font,std::uint32_t rgb){
 assert(parent&&font&&s&&inside(r));
 auto* o=lv_label_create(parent);lv_obj_remove_style_all(o);inert(o);
 lv_obj_set_pos(o,r.x,r.y);lv_obj_set_size(o,r.w,r.h);
 lv_obj_set_style_text_font(o,font,LV_PART_MAIN);
 lv_obj_set_style_text_color(o,lv_color_hex(rgb),LV_PART_MAIN);
 lv_obj_set_style_text_align(o,LV_TEXT_ALIGN_CENTER,LV_PART_MAIN);
 lv_label_set_long_mode(o,LV_LABEL_LONG_WRAP);lv_label_set_text(o,s);
 // Validate text height with the actual font in the receiving project.
 return o;
}
lv_obj_t* makeButton(lv_obj_t* parent,Rect r,const char* text,ButtonKind kind,const Fonts& fonts,lv_event_cb_t cb,void* context){
 assert(parent&&fonts.button&&text&&inside(r)&&r.w>=44&&r.h>=44);
 shared.init();auto* b=lv_btn_create(parent);lv_obj_remove_style_all(b);
 lv_obj_clear_flag(b,LV_OBJ_FLAG_SCROLLABLE);
 lv_obj_set_pos(b,r.x,r.y);lv_obj_set_size(b,r.w,r.h);
 lv_obj_add_style(b,&shared.base,LV_PART_MAIN|LV_STATE_DEFAULT);
 if(kind==ButtonKind::Primary)lv_obj_add_style(b,&shared.primary,LV_PART_MAIN|LV_STATE_DEFAULT);
 if(kind==ButtonKind::Danger)lv_obj_add_style(b,&shared.danger,LV_PART_MAIN|LV_STATE_DEFAULT);
 lv_obj_add_style(b,&shared.pressed,LV_PART_MAIN|LV_STATE_PRESSED);
 // A dark pressed surface must not retain the primary dark text color.
 lv_obj_set_style_text_color(b,lv_color_hex(theme::text),LV_PART_MAIN|LV_STATE_PRESSED);
 lv_obj_add_style(b,&shared.disabled,LV_PART_MAIN|LV_STATE_DISABLED);
 lv_obj_set_style_text_font(b,fonts.button,LV_PART_MAIN);
 auto* label=lv_label_create(b);lv_obj_clear_flag(label,LV_OBJ_FLAG_CLICKABLE);
 lv_label_set_text(label,text);lv_obj_set_width(label,r.w-8);
 lv_label_set_long_mode(label,LV_LABEL_LONG_WRAP);
 lv_obj_set_style_text_align(label,LV_TEXT_ALIGN_CENTER,LV_PART_MAIN);lv_obj_center(label);
 if(cb)lv_obj_add_event_cb(b,cb,LV_EVENT_ALL,context);
 return b;
}
void setEnabled(lv_obj_t* button,bool enabled){
 if(enabled)lv_obj_clear_state(button,LV_STATE_DISABLED);else lv_obj_add_state(button,LV_STATE_DISABLED);
}
lv_obj_t* makePrivacyCover(lv_obj_t* parent,const Fonts& fonts){
 auto* cover=panel(parent,{0,0,480,480},theme::backdrop,0);
 lv_obj_add_flag(cover,LV_OBJ_FLAG_CLICKABLE); // blocks underlying pointer events
 makeLabel(cover,{110,186,260,64},"ゲームを一時停止",fonts.body,theme::text);
 lv_obj_add_flag(cover,LV_OBJ_FLAG_HIDDEN);return cover;
}
void showPrivacyCover(lv_obj_t* cover,lv_obj_t* content){
 // First cancel pending gestures/confirmations in Controller; call on UI task.
 lv_obj_add_flag(content,LV_OBJ_FLAG_HIDDEN);
 lv_obj_clear_flag(cover,LV_OBJ_FLAG_HIDDEN);lv_obj_move_foreground(cover);lv_obj_invalidate(cover);
 // The platform must wait for its actual display-flush barrier before transitions.
 // This function does not claim that framebuffer/GDMA flushing is synchronous.
}
void hidePrivacyCover(lv_obj_t* cover,lv_obj_t* content){
 lv_obj_clear_flag(content,LV_OBJ_FLAG_HIDDEN);lv_obj_add_flag(cover,LV_OBJ_FLAG_HIDDEN);
}
} // namespace cafe::ui::lv8
