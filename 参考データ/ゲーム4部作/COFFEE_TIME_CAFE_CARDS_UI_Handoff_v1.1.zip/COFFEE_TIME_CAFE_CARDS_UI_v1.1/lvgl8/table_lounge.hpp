#pragma once
// LVGL8 integration example, not built against the user's BSP/SDK in this delivery.
#include <lvgl.h>
#include "../reference/ui_contract.hpp"
namespace cafe::ui::lv8 {
struct Fonts {
 const lv_font_t* body{}; const lv_font_t* button{}; const lv_font_t* caption{};
};
enum class ButtonKind {Secondary,Primary,Danger};
// The caller owns the LVGL task/mutex. Fonts and event context outlive the objects.
lv_obj_t* makeTableRoot(lv_obj_t* parent);
lv_obj_t* makeLabel(lv_obj_t* parent,Rect rect,const char* utf8,const lv_font_t* font,std::uint32_t color);
lv_obj_t* makeButton(lv_obj_t* parent,Rect rect,const char* utf8,ButtonKind kind,const Fonts& fonts,lv_event_cb_t cb,void* stable_context);
void setEnabled(lv_obj_t* button,bool enabled);
// Create this as a sibling ABOVE private_content; do not put it inside that content.
lv_obj_t* makePrivacyCover(lv_obj_t* parent,const Fonts& fonts);
void showPrivacyCover(lv_obj_t* cover,lv_obj_t* private_content);
// Call only after authentication/current-owner checks and a clean HumanView bind.
void hidePrivacyCover(lv_obj_t* cover,lv_obj_t* private_content);
}
