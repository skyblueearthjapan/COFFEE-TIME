# CAFE CARDS — TABLE LOUNGE UI / エージェント引継ぎ一式
**COFFEE TIME 第6ゲーム / UI v1.1.0 / 2026-09-22 / 480×480丸型**

## 最初に読むこと
これは既存の4ゲームを、共通のポーカーテーブル風UIに仕上げる追補です。新しいルールエンジン・新しいサーバー・4つの別アプリを作る依頼ではありません。

1. `docs/01_UI_THEME_SPEC.md`：色、テーブル、文字、カード、共通部品、演出。
2. `docs/02_FOUR_GAME_LAYOUTS.md`：4ゲームと共通画面の配置・遷移・操作。
3. `docs/03_AGENT_UI_ADDENDUM.md`：既存コードへの接続、秘密の保護、版管理、実装順序。
4. `docs/04_ACCEPTANCE_AND_TEST_REPORT.md`：検査範囲、実機の受入試験。
5. `docs/05_AGENT_PROMPT.md`：実装エージェントへそのまま渡す指示。

表示の確認は `preview/index.html` をブラウザーで開いてください。画面上部の一覧で27場面を切り替えます。これは**固定データによるUI操作見本**です。4ゲームの完全対戦、Jev接続、Google記録、本人認証は行いません。見本の得点・札・予測値・名前は架空です。

## 何が正本か
- **ゲームルール・保存・API**：`baseline/CAFE_CARDS_Design_v1.0_READONLY.md`。
- 同じ名前の別版が過去に存在するため、採用原本をSHA-256で固定：
  `7fe570ff2d3292a025bbb88f78198b426dff1f4874ae288e558a6ba920e2f91e`。
- **UIの見た目・配置・操作追加**：このv1.1。原本のI4と旧layoutデータは、本UIデータで置換します。
- ID・色・座標：`data/`。挙動：3つの仕様書。矛盾した場合はテストを止め、両方を修正。
- 画像は参照図。ピクセル値を画像から再採寸せずJSONを使います。
- 原本のZIPも`baseline/`に保全しました。展開して旧UIをそのまま再採用しないでください。

**変更しないもの**：`app_id=cafe_cards`、`game_id=poker|gops|thirty_one|baccarat`、`rules_version=1.0.0`、既存5ゲーム、コーヒー＋1、BSP、GT911、Google契約、認証。UIは `theme_id=table_lounge`, `ui_version=1.1.0` を別管理。

## ZIPの構成
| 場所 | 役割 |
|---|---|
| docs | 仕様書・実装指示・出典・受入試験 |
| data | 共通テーマ、全レイアウト、27場面、文言、表示契約、必要文字一覧 |
| preview | ネット不要のHTML、JavaScript、生成元テンプレート |
| assets | 4ゲーム比較ボード、全場面PNG/SVG、部品SVG |
| reference | PCで検査するC++17 / JavaScriptの入力ゲートと安全な表示投影 |
| lvgl8 | LVGL8へつなぐ部品のコード例。実LVGL環境では未コンパイル |
| tests / tools | 検査・生成・ハッシュ照合 |
| results | 実行ログ・結果。ESP32実機の成績ではない |
| baseline | 指定した元設計書と元参考一式。読み取り専用資料 |

## 最初の実行
Python3、Node.js、C++17コンパイラーを用意し、ZIPのルートで実行します。
```sh
python tools/run_checks.py
```
ブラウザー検査は別途PlaywrightとChromiumがある環境で実行します。
```sh
python tests/browser_test.py
```
`CHROMIUM_PATH`で既存のChromium実行ファイルを指定できます。ブラウザーがない検査を合格扱いにしないでください。ブラウザー見本を修正したら `python tools/build_preview.py` で再生成します。

パッケージそのものの検証：`python tools/verify_package.py`。原本の全ゲームテストはこのUI検査とは別です。統合後には原本の受入試験124項目も回帰検証してください。

## 完了の意味
この一式は実装に着手するための仕様・画面データ・参考コードです。ESP32へ書込み済みではありません。ブラウザーの文字幅検査とホストロジック検査は実施しましたが、実機の日本語フォント・タッチ・描画速度・電池時間・既存Google/Jev接続は別途確認が必要です。未試験のものを「動作確認済み」にしないでください。
