# CAFE CARDS — 統合引継ぎ版

**COFFEE TIME第6ゲーム／4種類すべてを実装する設計／v1.0.0／2026-09-22**

このMarkdown一冊に、共通設計、ポーカー、GOPS、サーティワン、バカラ、実装・運用、124項目の受入試験、全設定と参考コードを収録しています。

読む順：共通設計 → 第I〜IV部の4ゲーム → 第V部の実装 → 第VI部の検査。後半の付録は機械で取り出す完全なファイル群です。

**資料中のPC検査は実行済みですが、ESP32への書込み、実Google/実Jev接続、電池時間、社内試遊は未実施です。** 書込み済み完成アプリや、AIの強さを保証した報告ではありません。

---

# COFFEE TIME 第6ゲーム — CAFE CARDS
## 4テーブル共通・実装設計書 v1.0.0

**作成・公式資料確認日：2026-09-22／日本語／対象：ESP32-S3-Touch-LCD-2.8C**

> 本書は「ポーカーだけを選ぶ」案ではない。**一つの入口 CAFE CARDS に、POKER・GOPS・THIRTY-ONE・BACCARATの4種類を全部収録する設計**である。各ゲームは最後まで遊べ、遊び方、戦績、中断、結果、再戦まで備える。別々のアプリや、COFFEE TIMEの第7〜9枠に分裂させない。
>
> 本文は振る舞いの正本、付録のJSONは定数・文言・カードIDの正本。矛盾があればテストを止め、一緒に修正する。参考コードはPCで検査したルール／API契約の核であり、実機への書込み済み完成ファームではない。実ESP32、既存Google、実Jevの接続やAIの強さを未試験で保証しない。

## 0. まずエージェントがすること

1. 許可された既存ワークスペースを調べ、LCD・GT911・バックライト・LVGL・BSP・Arduino/ESP-IDF版・保存区画・既存Google通信・ゲーム登録関数を記録する。
2. 元のソース、GAS、シート構成を保全。元の画面とタッチ、コーヒー＋1を再現してから変更する。ライブラリ一括更新、Flash全消去、パーティション変更から始めない。
3. 付録ファイルを取り出し、PC検査を再実行する。その後、共通UIと端末AIで各ゲームを完走させる。
4. 保存・再開・個人/ゲスト・Googleへの記録を接続する。最後にJevを実接続する。
5. 4本それぞれの受入試験を行い、実機ビルド、実機操作、実Google、実Jev、人のプレイ評価を別々に報告する。

**進行中の独断変更は禁止**：ゲームの採用数、31の流派、GOPSの同点処理、ポーカーの上乗せ上限、バカラの点数制度を実装途中に入れ替えない。外部環境が不明なら、純粋ロジックとモックから進め、架空のキー・COMポート・URLで接続成功と報告しない。

### 0.1 継承する確定条件

| 項目 | 継続する条件 |
|---|---|
| 端末 | COFFEE TIME。社内カフェの時計・天気・コーヒーカウンター |
| 基板 | Waveshare **ESP32-S3-Touch-LCD-2.8C**。丸型480×480・タッチ。別型番へ変更しない [S01] |
| 電池・筐体 | 803450・3.7V・1500mAh・1.25mm 2ピン・保護回路付き。B案の折りたたみ、本体内に電池も収納 |
| 入力 | タッチのみ。音声・カメラ・外部キーボード不要 |
| 既存ゲーム | AI ESPER、AI DUEL、CAFE DETECTIVE、CAFE WEREWOLF **3〜10人v2**、JEV REVERSIを保全 |
| Google | 既存のスプレッドシート運用を利用。VPSや新しいDB製品を必須にしない |
| 対戦 | 人間1人対Jev。全4種類を一つの入口から選択 |
| 金銭 | 現金、課金、賭けの入金、換金、景品交換、他人へのポイント譲渡は一切作らない |

ハードの16MB Flash・8MB PSRAMは基板全体の容量であり、ゲームが全量を自由に使えることを意味しない [S01]。既存ファーム、OTA区画、フォント、他ゲームの使用量を実測する。

### 0.2 本書が決める初期仕様

ユーザーの趣旨に沿って未決定部分を閉じる、今回の設計判断である。

| テーブル | v1.0で収録する内容 | 1試合 |
|---|---|---|
| POKER | 5カードドロー、固定額ベット、交換1回 | 5ハンド、100点ずつから開始 |
| GOPS | 7枚版／13枚版を同じコアで選択 | 7回または13回の競り合い |
| THIRTY-ONE | 公開の場3枚と交換するカフェ流派 | 3ハンド、各ハンド通常20手まで |
| BACCARAT | OPEN／CLASSICを同じ配布ルールで選択 | 5ラウンドの予想勝負 |

上記を「すべて既存競技の公式ルールそのまま」と説明しない。特にポーカーの点数上限、GOPSの得点破棄、31の同点・終了、OPENバカラは本アプリの明示的な調整である。

### 0.3 盛り込むものと、入れないもの

盛り込む：4種類の異なる判断、操作式チュートリアル、意味のある結果表示、ゲーム別記録、再戦、秘密保護、障害からの復旧。

入れない：現金、チップ購入、共通財布、公開人別ランキング、確実に勝てる宣伝、AIが実際には選んでいない演出、カードの後からの差替え、カードゲーム同士の人物評価の合算、長い強制演出、終了を妨げる連続ログイン報酬。

「盛り盛り」は機能の分量ではなく、4種類をそれぞれ成立させ、初心者が迷わない仕上げを意味する。

## 1. 一つのアプリとしての全体像

```text
COFFEE TIME / GAME
  1 AI ESPER
  2 AI DUEL
  3 CAFE DETECTIVE
  4 CAFE WEREWOLF (3〜10人)
  5 JEV REVERSI
  6 CAFE CARDS
       ├ POKER
       ├ GOPS → 7 / 13
       ├ THIRTY-ONE
       └ BACCARAT → OPEN / CLASSIC
```

`app_id=cafe_cards`、`game_id=poker|gops|thirty_one|baccarat`。設定キーは `ct_cards` 以下。他ゲームのID・保存キーを変更しない。

開始フロー：テーブル → 自分/ゲスト → バリエーション（必要な2ゲームだけ）→ 対戦相手Jev/端末AI → 開始。チュートリアルはどこからでも一度戻れる。前回の選択を覚えてよいが、前の人のプロフィールを自動ログインしない。

端末AIは各ゲームで最後まで動く参考対戦相手。「オフラインのJev」とは呼ばない。Jevに接続できない場合は明示して本人に選ばせる。途中切替は試合の残り全部を端末AIにし、自動でJevへ戻さない。結果は `mixed` とする。

## 2. 雰囲気・言葉・報酬

喫茶「余白」の小さなテーブルが舞台。実在のカジノのロゴ、カード裏、UI、人物画像を流用しない。Jevの人間らしい長文生成は不要で、状況IDに対応する短い文章を表示する。

| 状況 | 使う文章例 | 避ける説明 |
|---|---|---|
| ポーカーで相手が降りる | 「相手が降りました。場の持ち点を獲得。」 | 非公開手を根拠に「ブラフ成功率90%」 |
| GOPSで小さい札が勝つ | 「3の札で8点を獲得。」 | 内部の想像を「AIを完全に操った」 |
| 31の最後の交換で逆転 | 「最後の交換で29点に。今回はあなたの勝ち。」 | 偶然を確実な技量とする説明 |
| バカラの予想が一致 | 「今回は、同じ予想です。」 | 人間の予想に合わせてAIの回答を変更 |

「判断の内訳」は任意。Jevが返した確率は行動への相対的な選択値であり、その行動の勝率や最適な混合戦略ではない [S02]。勝率は実際の完了試合の数から別計算する。`confidence`も勝率の別名にしない。

通常は200〜450ms程度の短いカード表示を使う設計値とし、低動作モードは即時切替。画面を進めるための無意味な待ち時間や、何度も音を鳴らす演出は作らない。対戦中に履歴やヒントを見ても時計で負けにしない。

## 3. 共通カードモデル

物理カードIDは `copy*52 + suit*13 + (rank-2)`。

- `suit=0:C, 1:D, 2:H, 3:S`、`rank=2..14`、14がA。
- 通常1組は0〜51、8組のバカラは0〜415。見た目が同じでもcopyが違えば別の物理カード。
- ジョーカーなし。ポーカー/31で同じ物理カードを重複保持しない。
- 52枚の全ID・表示・各ゲームの点数は `data/cards.json`。
- GOPSは通常カードのrankと**別の1〜Nのトークン**。Aを14として比較してはいけない。画面も1〜13の数字表示とし、13は必ず1より強い。

常に「ルール上のスロット」と「画面上の位置」を区別する。手札を自動ソートして交換対象の番号を変えない。並べ替えを将来追加するなら、画面位置→固定slot_idの表を保持する。

## 4. 配布と秘密情報の責任分離

### 4.1 信頼するもの・守れる範囲

ゲームの真の状態と山札はESP32に保持する。本アプリは会社内の娯楽で、改造された端末や管理者から秘密を守る競技サーバーではない。ファーム改変、物理Flash読出し、既存アカウントの乗っ取りに対する完全な不正防止を保証しない。

一方、通常の利用では次を守る。

1. UIは人間に公開してよいビューだけで描く。
2. Jevと端末AIは、相手として知ってよいビューだけで選ぶ。
3. 山札・未来の札・相手の秘密・未公開の選択をモデルに送らない。
4. Googleへはモデルに必要なAI自身の手札と公開状態を一時送るが、デバイスの全状態・山札は送らない。
5. 過去の人間の手札は、実際にショーダウンで公開されたときだけ利用できる。フォールドしたハンドの手札を学習データへ混ぜない。

### 4.2 同時と逐次の違い

| 機会 | 決定順序 |
|---|---|
| ポーカーのベット | 手番順。相手の直前の公開ベットを見て判断してよい |
| ポーカーのカード交換 | AI交換選択を確定→人間が確定→双方の交換枚数を公開→交換実行 |
| GOPSの競り札 | AI札を確定→人間が確定→同時公開。途中の人間の選択は送らない |
| 31の交換/ノック | 手番順。相手の公開された交換後の場を見て判断してよい |
| バカラの予想 | 未来の配布順を先に固定→AI予想確定→人間確定→両予想と残りカードを公開 |

同時選択は、人間が仮選択してもその値をネットワークに送らない。AIの応答が来る前は確定ボタンを無効にする。UIは「相手の選択は確定済み」と示すが、未確定中にその表示を出さない。

`private_state`を作って後から秘密キーを削除する方式ではなく、`makeObservation()`が新しいオブジェクトへ許可フィールドだけをコピーする。将来内部フィールドが増えても漏れないことを差分テストする。


---

# 第I部 — CAFE POKER
## 5枚の手札と、相手の強気を読む

## P1. 採用する流派と一試合

5カード・ドローを土台とし、交換前後に一度ずつベット段階を設ける [S03]。本アプリは以下の**固定5ハンド・仮想持ち点制**へ調整する。役判定は標準的なハイポーカーの序列に合わせる [S04] が、競技カジノの賭け・ブラインド・オールインを再現するものではない。

| 条件 | 確定値 |
|---|---|
| ID / variant | `poker / fixed5` |
| 参加者 | 人間H、Jevまたは端末AIのA |
| 試合の長さ | 必ず5ハンド。途中終了は中止で、残りを自動敗北にしない |
| 最初の持ち点 | 双方100。5ハンド間は持ち越し、再戦時は100へ戻す |
| 各ハンドの開始 | 新しくシャッフルした52枚、双方1点の参加点を場へ |
| 配る枚数 | 各5枚。ディーラーでない側から交互に1枚ずつ |
| カード交換 | 0〜5枚を一度だけ。双方の選択が確定してから実行 |
| 交換前の単位 | 2点 |
| 交換後の単位 | 4点 |
| 上乗せの上限 | 各ベット段階で2回。最初のBETは上乗せ回数に含めない |
| 最終勝敗 | 5ハンド後の持ち点。多い側の勝ち、100対100なら引き分け |

ディーラーは開始時に一度抽選し、その後のハンドで交互にする。**配布・交換・ベット先手はいずれも非ディーラー**という本アプリの規則で統一する。初期配布の途中で山札を引き直さない。交換前に降りたハンドでは、交換後のステージを作らず次のハンドへ進む。

## P2. 「持ち点が足りない」を構造的に防ぐ

ベット段階一つについて、最終的に双方が払う上限は `単位×(最初のBET1回＋RAISE2回)`。

```text
1ハンドの自分の拠出上限 = 参加点1 + 交換前2×3 + 交換後4×3 = 19
5ハンドで全て失った場合 = 19×5 = 95
最初の100 − 95 = 5
```

第5ハンド開始前でも24点以上残るため、合法な拠出19点を支払える。これが、オールイン・サイドポット・不足分補充・チップ購入を不要にする根拠である。試合を6ハンド以上へ勝手に拡張すると保証が変わる。

不変条件：`Hの残点 + Aの残点 + pot == 200`。`pot<=38`。値は非負整数。ポットは解決時に全額を移動し0へ戻す。途中の表記は「場の持ち点」であり、現金換算を表示しない。

## P3. 合法な全ベット行動

`street_paid[2]`はこのベット段階だけの拠出額。参加点と前段階の拠出を混ぜない。`owed=max(street_paid)-street_paid[actor]`。

| 状態 | 行動ID | 日本語 | 支払い・遷移 |
|---|---|---|---|
| owed=0 | CHECK | 追加せず続ける | 0点。双方続けてCHECKなら段階終了 |
| owed=0 | BET | 2点出す／4点出す | unit点。相手の反応待ち |
| owed>0 | FOLD | 降りる | 0点。相手が場を獲得してハンド終了 |
| owed>0 | CALL | 同じ額で勝負 | owed点。拠出を一致させて段階終了 |
| owed>0かつraises<2 | RAISE | さらに上乗せ | owed+unit点。raisesを1増加し相手へ |

owed=0のときにFOLD、owed>0のときにCHECKは不可。上乗せ2回後のRAISEボタンは消す。ベット金額のテンキーは作らない。チェック後に相手がBETした場合、チェックした側はFOLD/CALL/RAISEから反応できる。

例（交換前）：H CHECK → A BET2 → H RAISE4（差額2＋上乗せ2）→ A RAISE4 → H CALL2。段階終了時は双方6点拠出である。最後のCALLをさらに相手の手番へ回してはいけない。

## P4. カード交換の全32選択

固定slot0〜4に対してbitを立てる。`mask=0`は交換なし、31は全部交換。例えば`mask=5`はslot0とslot2を交換する。全選択は`data/poker_draw_choices.json`にある。

1. 交換段階へ入る前の状態を保存する。
2. JevへAI自身の5枚と公開履歴を渡し、`DRAW:0`〜`DRAW:31`から選ばせる。
3. 応答検証後、AIのmaskとdecision_idを保存する。まだ人間へ枚数を見せない。
4. 人間の仮選択は端末内だけ。独立した「交換する」で確定する。0枚の場合も「交換しない」を確認する。
5. 両mask確定を一つのゲーム更新として保存。ここで初めて双方の枚数を公開する。
6. 非ディーラーのslot昇順、ディーラーのslot昇順で、山札の次の札と交換する。捨て札は今回の山札へ戻さない。バーンカードなし。
7. 交換後ベット段階へ。先手は再び非ディーラー、unit=4、paidとraisesとchecksを初期化。

最大でも初期10枚＋交換10枚＝20枚しか使わない。全交換でも山札不足は起きない。再送や電源復旧でmaskや配布順を再抽選しない。人間の交換札の種類は相手へ非公開で、枚数だけが公開情報。

## P5. 役の序列と同役比較（弱い順）

`PokerValue.key`は6整数で、左から辞書順比較する。末尾の不要要素は0。

| category | 役 | 比較キー（categoryの後） |
|---:|---|---|
| 0 | ハイカード | 5枚のrank降順 |
| 1 | ワンペア | ペアrank、残り3枚降順 |
| 2 | ツーペア | 大きいペア、小さいペア、残り1枚 |
| 3 | スリーカード | 3枚組rank、残り2枚降順 |
| 4 | ストレート | 一番大きいrank。A2345だけ5扱い |
| 5 | フラッシュ | 5枚のrank降順 |
| 6 | フルハウス | 3枚組rank、ペアrank |
| 7 | フォーカード | 4枚組rank、残り1枚 |
| 8 | ストレートフラッシュ | 一番大きいrank。10JQKAは14 |

ロイヤルフラッシュはcategory8/high14の表示名で、独立の勝敗カテゴリではない。A2345は有効、QKA23など循環は無効。スートの優劣はなく、完全同キーなら同役引き分け。CALLか両CHECKでショーダウンしたpotは、双方の拠出が一致しているため偶数であり、半分ずつ分ける。

役の一覧は、自分の手札へ特別な操作をせず閲覧できる。表示は日本語＋実際の5枚。単なる推定ではなくコード判定。`poker_compare()`がinvalid=-2を返したら中止・破損扱いとし、AI勝ちへ落とさない。

## P6. 状態と画面

```text
HAND_START → DEAL → BET_PRE → (FOLD→HAND_RESULT)
                         ↓両CHECK/CALL
                  DRAW_AI_PREPARE → DRAW_HUMAN_CONFIRM
                         ↓双方確定
                    DRAW_RESOLVE → BET_POST
                         ↓FOLDまたはSHOWDOWN
                    HAND_RESULT → 次ハンド / MATCH_RESULT
```

カード5枚は同一行で固定し、選択札に枠と「交換」の小バッジを付ける。表面の5枚そのものを右左へスワイプして押し間違える作りにはしない。開始・現在段階・ハンド番号・残点・場の点を見られる。相手のカードはショーダウンまで裏向き。

結果：獲得pot、両者の残点、公開可能なら双方の役、勝敗理由。フォールドで終わった場合は両者の札を非公開のままにする。ゲーム管理者が内部の札を知っていても、結果文章から間接的に公開しない。

Jevの行動内訳はハンド終了後にだけ閲覧可能。**フォールドで終了したハンドでは確率内訳も非表示**とし、行動と点数だけを見せる。確率から相手の隠れた役の強さを推定する補助情報を不必要に与えない。通常画面で「AIはフルハウスを狙っています」等を創作しない。

## P7. Jevと端末AI

Jevの入力：自分の5枚、計算済みの役キー、自分の捨て札、両残点、場、段階の拠出、合法行動、双方確定後の交換枚数、公開の行動履歴、同意済みの個人傾向。相手の現在5枚、非公開捨て札、交換前の相手mask、山札順は除外する。

モデルへの目的は「5ハンド後の持ち点を増やすため合法な行動を一つ選ぶ」。強さ、ブラフ頻度、理論最適性を保証しない。`Choice`の確率をそのまま実勝率や最適ランダム戦略としない [S02,S05]。

端末AI v1は第V部の固定ポリシー。交換時は役を壊さない手順、ベットは役ランクと保存済みの乱数で行動する。高度な未知札全探索は必須にしない。強い相手ではなく通信なしで完走できる比較基準として評価する。

個人傾向は公開された行動だけから集計する。特に`FOLD/facing_bet_opportunities`と`(BET+RAISE)/aggressive_opportunities`を区別する。「降りる機会が0」なら0%とせず、データ不足。サンプル20未満は「傾向を観察中」と表示する。本人の他ゲームの性格推定は混ぜない。

## P8. このゲームの受入ポイント

全役判定、キッカー、ホイール、同役、フォールド、チェック→BETへの反応、最大上乗せ、全交換、0枚交換、dealer切替、5連敗しても合法支払い可能、手札非漏洩、2回押しで2回交換しないことを試験する。

遊びの評価は「相手の交換枚数やベットが判断材料になったか」「最大3ボタンの意味が理解できたか」「負けても自分の選択を振り返れたか」。勝率だけで合否を決めない。


---

# 第II部 — GOPS
## 切り札を出すのは、今ですか？

## G1. 採用ルール

両者が同じ数値の札を持ち、公開された得点札を秘密の入札で取り合うGOPSを土台とする [S06,S07]。本書は同点の得点を**破棄**する流派に固定し、持越しや累積オークションを混ぜない。

| variant | 手札 | 得点札 | ラウンド数 | 総得点プール |
|---|---|---|---:|---:|
| quick7（初期） | 各1〜7 | 1〜7を一度シャッフル | 7 | 28 |
| classic13 | 各1〜13 | 1〜13を一度シャッフル | 13 | 91 |

A/J/Q/Kのトランプ記号を強さに誤解させないよう、ゲームの札は1〜Nをそのまま表示する。札13は強いが、それを使った回の獲得点は**場の得点札**であり、必ず13点を得るわけではない。

## G2. 一回の全処理

1. 山の次の得点札を一枚だけ公開。未来の順番はどちらにも渡さない。
2. AIに、自分の残札・人間の残札・現在得点・公開済みの入札履歴を渡す。
3. AIの札を確定・保存してから、人間の確定ボタンを有効にする。未確定の人間の仮選択を送らない。
4. 人間が未使用札を選択し「この札で勝負」で確定。確定した札は変更不可。
5. 双方を同時公開。大きい札を出した側に得点札の点を加算。同じ数字なら誰も加点せずburnedへ。
6. 両方の札を残札から除外。勝ち札だけ除外するのではない。
7. N回後に得点を比較。等しければ引き分け。追加戦や残点比例補正はしない。

最後の残札が一枚ならAIは強制選択し、Jevを呼ばない。`provider=forced`で記録する。人間側は自動進行せず本人が確定する。

## G3. 具体例と不変条件

quick7で現在の得点札6。Hが5、Aが3ならHに6点。双方の5と3は消費される。次が得点2で双方2を出したら、2点は破棄。次の回へ上乗せしない。

不変条件：

```text
Hの得点 + Aの得点 + burned = 公開・決着済みの得点札の合計
両者の残札の枚数 = N - 決着した回数
両者の残札には重複なし、各値は1..N
```

得点札の順番は1..Nの順列。終了後の札順一覧は見せてよいが、進行中の未来部分は画面・ログ・Jevに出さない。同じ得点札が再び出たら再送の二重反映か破損であり、正常な追加ラウンドとして扱わない。

## G4. 状態・UI・公開記憶

`PRIZE_REVEAL → AI_PREPARE → HUMAN_SELECT → SEALED → REVEAL_SCORE → NEXT / RESULT`

13枚を一行に縮めない。未使用札を小さい順に**4枚ずつページ表示**し、1〜4ページを移動する。候補ボタンの大きさは7枚版と共通。仮選択はページ変更で失わないが、選んだ数字は中央の確認文にも出す。別の「決定」が必要。

「残り札」画面は双方の全未使用数字を表示する。公開済みの札を覚える記憶競争にしない。過去の行は「得点6／あなた5／相手3／あなた+6」と簡潔にする。現在の未公開入札は履歴へ先に加えない。

人間が仮選択中にAPIが返っても自動確定しない。カフェへ戻る場合は選択ドラフトを保存して一時停止。既に確定したAI札を別の札に置き換えない。

## G5. Jevの判断と履歴

全合法候補 `PLAY:1`〜`PLAY:N` のうち残っているものだけを渡す。現在得点札、残札両者、現在スコア、過去の対局で公開された最大26入札を材料にする。プレイヤー名、他ゲームの履歴、次の得点札は送らない。

目的は各回の勝率ではなく、N回終了時の合計得点。弱い得点札で強い札を消費することの機会費用も指示へ含める。ただしゲーム理論的な最適戦略と断定しない。

履歴は同variantだけ。個人の傾向を長期保存する場合も、得点札の低/中/高と使用札の低/中/高の件数、公開済みの直近26組に限定する。「いつも弱気」といった人格表現は出さない。

端末AIは、得点の順位に近い自分の残札を基準に、保存済み乱数で隣の札も選ぶ軽量方針（第V部）。人間の今回の選択を見るローカルAIは不適合。

## G6. 実装時の注意

参考`Gops::choose()`は双方確定した呼出し内で集計し、sealedを空にして次へ進む。コントローラーは呼出し前の得点札・先にsealedしたAI札・人間札をイベントへ退避し、一度だけ`RESOLVE`記録を作る。モデルの返答処理から直接2回`choose`を呼ばない。

同時選択は端末内の相手札を直接読めば破れる信頼モデルであり、悪意ある改造ファームからの保護を保証しない。通常アプリの情報分離と時系列は自動試験する。

## G7. 受入ポイント

7・13の全ラウンド、同点破棄、残札の双方除去、連続同点、最終同点、先にAIを確定、強制一札で課金なし、4枚ページの13枚目、前のラウンド応答の無視、独立した新試合の得点順生成。

プレイ評価は「次のために札を残したいと感じるか」「残札を見返せるか」「同点で得点が消える理由が分かるか」。単に毎回最大札を押すゲームになっていないかも確認する。


---

# 第III部 — THIRTY-ONE
## もう一枚待つか。今、勝負するか。

## T1. 採用するのは「場の3枚と交換する」流派

サーティワンには複数の遊び方がある。本書は、手札3枚と公開の場3枚を使うBicycleの紹介を土台に [S08]、短時間向けに次の**market3カフェルール**を固定する。山札から毎ターン引く流派、捨て札山、3枚組30.5点、スートによる同点判定を混ぜない。

- 人間1人とAI、手札3枚ずつ。場の3枚は双方が見て交換できる。
- 新しい52枚をハンド開始時にシャッフル。先手から交互に3枚ずつ配り、続く3枚を場へ。
- 同じスートの合計を計算し、4スートのうち最大の値が手の得点。
- A=11、J/Q/K=10、2〜10は数字。3枚しかないので最大31点。
- 1試合3ハンド。ハンド勝利1点、引き分けは双方0点。最終の勝ち数を比較。
- 先手を試合開始時に抽選し、ハンドごとに交互にする。

残り43枚はそのハンドでは使用しない。場の札が弱いからと勝手に交換・補充しない。

## T2. 得点・同点の全例

| 手札 | 得点・意味 |
|---|---|
| SA・SK・H7 | スペード21、ハート7 → 21 |
| SA・SK・S9 | 30 |
| SA・SK・SQ | 31。直ちに終わる |
| C7・D7・H7 | 7。3枚組の特典はない |
| C10・DJ・HQ | 10。スートが違うので30ではない |
| SA・S9・H2 vs HA・H9・D3 | 両方20で引き分け。残りの別スートの札で差をつけない |

本アプリの同点は常に引き分け。参照資料の一部にある高札比較や初期ノックの特例は採用しない、と遊び方にも明記する。

## T3. 通常ターンの全行動

| ID | 操作 | その後 |
|---|---|---|
| `SWAP:i:j`（i,j=0..2） | 自分のslot iと場のslot jを1対1交換 | 31になれば即終了。それ以外は相手へ |
| `KNOCK` | 交換せず「ここで勝負」を宣言 | 相手が最後に1回、交換またはそのままを選ぶ |

通常ターンにSTAND（パス）はない。ノックしながら交換する、2枚まとめて交換する、場を全部取り替える操作はない。

ノックを受けた相手の最後の行動は `SWAP:i:j` 9通りまたは `STAND` の10通り。再ノックは禁止。交換をしてもしなくても、その後は手札公開して終了。ノックした人がもう一度交換できるようにしない。

## T4. 終わる順序・20手制限

1. 初期配布直後に双方の得点を確認。どちらかが31なら、最初の手番前に両手札を公開して終了。両方31なら引き分け。
2. 交換で31ができたら、他の条件より先に即終了。相手の追加ターンはない。
3. ノック後の最後の応答なら比較して終了。
4. 通常行動が20に達した交換なら、その手の後に比較して終了。
5. **20手目がノックなら、21手目の最後の応答を一度だけ許す。** ノックを選んだだけで即終了に変えない。

`turn_count`は両者合計の確定行動数。表示ページ移動・仮選択・ヒント閲覧では増えない。ハンドは必ず最大21行動以内に終了する。人間の読書や考える時間に制限を付けるものではない。

端末AIとの循環交換で無限に続くことを防ぐためのカフェ独自ルール。20手目前は「あと1手で比べます。ここで勝負を選ぶと相手に最後の1手」と正しく表示する。

## T5. 公開された札の記憶

場から取った札は公開情報であり、あとからその人の手にあることを推測できる。アプリはこれを両者へ同等に表示する。

`known_cards[actor]`は、公開の交換により今もその人が持っていると分かる札の集合。

```text
交換前の手から出した札 out を known_cards[actor] から除く
場から取得した札 in を known_cards[actor] に加える
```

初期手札は空集合。例えばAIが場からSAを取れば人間側に「相手が持つと分かっている札：SA」。AIが後でSAを場へ戻せば表示から消す。3枚とも公開交換で判明した場合は、3枚全部を知っていてよい。逆に内部の本当の手札を見てknownを補完してはならない。

HとAの本当の手札、場の合計9枚には同じ物理札がない。knownは各手札の部分集合で最大3。私的手札と公開既知集合を混同しない。

## T6. 状態・画面・選択

```text
DEAL → 初期31判定 → TURN
                    ├ SWAP → 31 / 最終手 / 上限 / 相手TURN
                    └ KNOCK → LAST_REPLY → 比較
                  HAND_RESULT → 次ハンド / MATCH_RESULT
```

通常画面は上段「場の3枚」、下段「あなたの3枚」。自分の札→場の札をタッチして枠を付け、「交換する」で確定する。順序を逆にタッチしても内部slotを保って選択できる。確定までは何度でも選び直せる。

「ここで勝負」は別の操作から確認画面を開く。通常SWAPの確定ボタンとノックを同じタッチ領域で入れ替えて誤操作を誘わない。最後の応答は「交換する／このまま比べる」。得点と同スートの強調は人間の手だけ表示する。相手の最終得点は公開前に出さない。

結果には双方3枚、同スート合計、終わった理由（31・ノック・20手）、当ハンドと3ハンドの成績を表示する。

## T7. Jev・端末AI・個人傾向

Jevへは自分の3枚と得点、公開場、相手の公開既知札、手番数、最終応答か、公開交換履歴、個人のノック/交換傾向を渡す。相手の未知札・未使用の山は送らない。各SWAP候補の説明には入れ替える具体札を付ける。文字画像を読ませず構造値を使用する。

端末AIは可能な9交換を実際に評価し、最高得点を選ぶ。同得点はi,j昇順。通常は現在27以上または改善する交換なしならノック、それ以外は最高得点交換。最後の応答では厳密に点数が改善するなら交換、改善しなければSTAND。これは固定の比較基準であり「最強」ではない。

通常20手目前に局面からノックが合法であることを保持する。評価関数の都合でノックを拒否しない。モデルがKNOCKを返しても、実は最終応答だったら不正応答として止める。

統計は本人の通常ターンのSWAP数・KNOCK数、最後の応答のSWAP/STAND、平均ノック時点（公開手番数）を別に持つ。公開されていない相手の手の点数を使って「弱いのにノックした」と人物評価しない。

## T8. 受入ポイント

全22,100通りの3枚の手を得点検査。31の初期・交換後、双方31、同点、スート混在、3枚組ボーナスなし、20手目交換、20手目ノック＋21手目応答、通常STAND拒否、再ノック拒否、公開既知札の削除、3ハンド先手交代、中断時の選択枠リセットを確認する。

遊びの評価は「場と自分の札を取り違えないか」「ノックの意味が分かるか」「点数が合う理由が見えるか」。ポーカーの用語を使い回して理解を妨げない。


---

# 第IV部 — CAFE BACCARAT
## あなたとJev、同じ予想ですか？

## B1. プレイヤーとバンカーは「手札の側」の名前

本アプリのバカラはプント・バンコの配布・追加札条件を使う [S09,S10]。**PLAYER側＝人間、BANKER側＝Jevではない。** 人間もJevも同じ二つの手札の勝敗を予想する。AIが任意に札を引いたり止めたりするゲームではない。

| variant | 人間とJevが予想前に見るもの |
|---|---|
| OPEN（初期） | PLAYERの1枚目とBANKERの1枚目だけ |
| CLASSIC | 札は一枚も見ない |

OPENはカフェ独自の一部公開ルール。両方とも賭け金・配当率・バンカー手数料・高倍率のサイドベットは実装しない。**予想が当たれば1点、外れれば0点、5回で比較**する。引き分け予想の的中も1点。両者同じ予想をしてよく、両方的中なら双方+1。

## B2. 山札と点数

各ラウンドごとに新しい8組416枚を公平にシャッフル。ラウンド内では引いた札を戻さない。連続シュー、途中のカットカード、バーンカードは使わない。5回戦全体で一つの416枚から配り続ける、と勝手に変えない。

A=1、2〜9は数字、10/J/Q/K=0。手の点数は合計の一の位。7+6=3、9+9=8。スートは点に関係ない。カードIDはcopyを含んで区別し、例えば同じスート・数字の2枚が違うcopyから出るのは合法。

## B3. 配布順と終了判定

最初の4枚は必ず `P1, B1, P2, B2`。最初の2枚ずつの合計点を計算する。

- **どちらかが8または9ならナチュラル。両方とも追加札なしで比較。** 片側だけさらに引かせない。
- それ以外でPLAYERが0〜5なら3枚目を引き、6〜7なら止める。
- PLAYERが止めた場合、BANKERは0〜5なら引き、6〜7なら止める。
- PLAYERが引いた場合、BANKERは下表に従う。

### BANKERの追加表

列はPLAYERの**3枚目そのものの値**であり、PLAYERの最終合計ではない。○=引く、−=止める。

| BANKERの初期合計 | P3=0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 |
|---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| 0 | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ |
| 1 | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ |
| 2 | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ |
| 3 | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | − | ○ |
| 4 | − | − | ○ | ○ | ○ | ○ | ○ | ○ | − | − |
| 5 | − | − | − | − | ○ | ○ | ○ | ○ | − | − |
| 6 | − | − | − | − | − | − | ○ | ○ | − | − |
| 7 | − | − | − | − | − | − | − | − | − | − |

8/9の行はナチュラルで先に終了するため表の処理へ入らない [S09,S10]。

PLAYERが引いた場合、5枚目がP3、BANKERも引けば6枚目がB3。PLAYERが止めBANKERだけ引く場合は、**5枚目がB3**であって6枚目へ飛ばない。最後に一の位同士を比較し、同数ならTIE。

参考コードは6枚の候補ストリームを受けるが、`used=4..6`で実際に使った枚数を返す。未使用の札を結果画面へ見せない。次ラウンドは新しい416枚に戻すので、未使用候補を次回の先頭へ回さない。

## B4. 公平な予想と進行

```text
ROUND_START（山札順を固定・保存）
 → OPENならP1/B1表示、CLASSICなら裏向き
 → AI_PREDICT（予想確定・保存）
 → HUMAN_PREDICT（選択と確認）
 → 予想双方公開
 → 残りの札を順番に表示、規則で追加
 → 得点・説明
 → 次ラウンド / MATCH_RESULT
```

AIにはPLAYER/BANKER/TIEの3候補しか与えない。未来の4〜6枚の候補、残り山、実際の勝敗、人間が今回選ぼうとしている側を送らない。OPENの公開1枚だけでナチュラルを判定してはいけない。2枚合計が必要である。

Jevの出力に合わせて山札やカードを変更しない。同じ相手予想を嫌って逆へ変えない。Jevの確率は人間の予想が確定するまで隠し、確定後に任意表示する。

## B5. 端末側の計算予想

`data/baccarat_probabilities.json`には、毎回新しい8組・ラウンド内非復元抽選という条件で、公開1枚ずつの値10×10組と非公開CLASSICの正確な組合せ計算結果を収録する。

生成器は各値の枚数を0値128枚、1〜9各32枚として、6位置の値列1,000,000通りを非復元抽選の重み付きで列挙する。実際に4枚で終わる局も、残り2位置について合計すると同じ確率へ戻る。単に1,000,000個を同じ重みで平均したものではない。

| 条件 | PLAYER | BANKER | TIE |
|---|---:|---:|---:|
| CLASSIC | 0.44624660934217 | 0.45859742263134 | 0.095155968023625 |
| OPEN：P1=7、B1=2 | 0.51468709057041 | 0.38318723677965 | 0.10212567264997 |
| OPEN：P1=2、B1=7 | 0.37159966361307 | 0.52673498380874 | 0.10166535257823 |

これらは**プログラムで算出した値**で、Jevの実測や、実カジノの払い戻し率ではない。計算には採用した追加札条件を使う。端末AIは該当3値の最大を予想し、完全同率ならPLAYER→BANKER→TIE順。毎回新しく山を作るので、CLASSICで同じ予想が続いても正常である。

Jev対戦では、この正解側の計算表をモデルに渡さない。Jevの予測と計算基準を比較するためである。計算表を使用したモードは「計算予想」と明示し、Jevがその数値を出したように表示しない。

## B6. 履歴と見せ方

毎回新しい山なので、過去のP/B連続や人間の癖は次回の札の原因にならない。Jevへ過去の勝敗列・個人予想傾向を送って「流れを読んで勝つ」とは説明しない。

記録は試合勝敗と的中数、OPEN/CLASSIC別、対戦相手別。予想当たり率の母数は完了した予想ラウンド。5回の勝敗だけでモデルの優劣を証明しない。「TIEが出そうだから点を多く賭ける」等の機能もない。

最大3枚ずつのカードは2段。数字・マーク・一の位の合計を大きく表示。「引いた理由」は短く、例えば「PLAYERは4点なので、3枚目を引きます」。この理由は規則から作り、Jevの自由文ではない。

## B7. 受入ポイント

片側のみナチュラル、両側ナチュラル、PLAYER停止時のBANKER5点、B3のP3=8だけ停止、B4/B5/B6の境界、5枚目の行先、同じ見た目の別copy、同物理ID重複拒否、予想三択の全9組×実結果3組、両者同予想、TIE的中1点、OPEN/CLASSICの情報分離を確認する。

楽しさの評価は「結果までが長過ぎないか」「PLAYER/BANKERを人間/AIと混同しないか」「今見えたカードが次で変わる期待感があるか」。判断を変えて展開を操作するゲームではないことを、他3本と区別する。


---

# 第V部 — 共通実装・通信・復旧マニュアル

## I1. モジュール構成と責任

```text
既存COFFEE TIME
 ├ AppRegistry / CoffeeCounter / Clock / Weather / 既存5ゲーム
 └ CafeCardsApp
     ├ Menu・IdentityAdapter・Tutorial・ResultUI
     ├ CardsController（状態変更の唯一の入口）
     ├ PokerMatch / GopsMatch / ThirtyOneMatch / BaccaratMatch
     ├ RulesCore（純粋なルール）
     ├ HumanView / AIObservation（秘密を分離）
     ├ LocalPolicy / JevDecisionClient
     ├ SnapshotStore / PublicEventWriter
     └ ExistingGoogleTransportAdapter
            ↓ HTTPS
         GAS cafe_cards router
           ├ 既存IdentityAdapter・端末認証
           ├ strict observation gate・Jev HTTP
           ├ 決定予約／結果の冪等処理
           └ 非公開GoogleゲームWorkbook
```

`RulesCore`へLCD、Wi-Fi、時刻、乱数の初期化、Google書込みを持ち込まない。乱数列を外から注入して、同じ入力なら同じ結果にできる。付録のC++はこの層の参考実装。UIアプリ・永続化アダプター・GAS全業務処理は本章の契約に従って既存環境へ組み込む。

参考実装の公開structを本番の任意書込みAPIにしない。外部イベントは検証したコントローラーだけが変更する。内部のゲーム状態を公開JSONレスポンスへ丸ごとserializeする関数を作らない。

## I2. 基板・LVGLを壊さない導入

2.8CはLCDとタッチが既に基板上で接続されている。追加のGPIO配線をゲームのために行わない。既存の表示が動いているなら、BSPの初期化、GT911用I²C、I/O拡張、RGB/PSRAMの設定をそのまま使用する [S01]。

既存LVGLが8なら8を継続し、9へ一括移行しない。既存のUIロック/タイマータスクへゲームを追加する。LVGLは通常の並列アクセスに自動で安全になるものではないため、UI所有タスクとロック方針を一本化する [S22]。長いHTTP待ちをUIタスクやLVGLロック中に実行しない。

ポインター→カードslot変換は `LV_EVENT_CLICKED` 等の確定イベントへ接続し、押している間に繰り返すイベントで何度も配布・交換しない [S23]。スクロールで指が外れた操作をクリックと誤認しない。プレスした画面のgenerationとリリース時のgenerationが違ったら破棄する。

## I3. コントローラー状態とイベントの全体

共通state：`MENU, IDENTITY, SETUP, TUTORIAL, DEALING, HUMAN_SELECT, AI_PENDING, SEALED_WAIT, REVEAL, HAND_RESULT, MATCH_RESULT, PAUSED, RECOVER_AUTH, ERROR`。

ゲーム固有phaseは以下。

| game | phase |
|---|---|
| poker | bet_pre / draw / bet_post / hand_result |
| gops | bid / round_result |
| thirty_one | turn / last_reply / hand_result |
| baccarat | predict / round_result |

共通event：`SelectGame, SelectVariant, BeginMatch, SelectCard, SelectAction, Confirm, ProviderReply, RetryPoll, ChooseLocal, AnimationDone, NextHand, Pause, Resume, AbortConfirmed, Reauthenticate, StorageFailed`。

端末内では `match_id, revision, ui_generation, decision_id` を全イベントへ結び付ける。revisionは状態が確定するごとに増加し、同じGUIの古いボタンが二度操作しても二重反映しない。

### 更新のパターン

```cpp
// 組込み時の構成例。実プロジェクトの型とエラーハンドラへ接続する。
Result CardsController::confirm(const ActionEnvelope& e) {
    if (e.match_id != state.match_id || e.revision != state.revision)
        return Result::Stale;
    if (ui_busy || !legalHumanAction(state, e.action))
        return Result::Rejected;
    auto next = state;                 // 固定上限を持つ状態コピー
    if (!applyLegalAction(next, e.action)) return Result::Rejected;
    appendPrivateReplayEvent(next, e.action);
    ++next.revision;
    if (!validateInvariants(next)) return Result::Corrupt;
    if (!store.saveAndReadBack(next)) { showStorageError(); return Result::Storage; }
    state = next;                     // 保存できた確定状態だけを正本にする
    ui_busy = true;
    postRender(makeHumanView(state));
    scheduleNextTask(state);           // 通信をここで同期実行しない
    return Result::Accepted;
}
```

大きなsnapshotを小さなFreeRTOSスタックへコピーしない。上の`next`は本番では事前確保した作業領域へ置き、スタック使用量を実測する。これは接続方法を示す擬似インターフェースで、`CardsController`全体のコンパイル済みコードではない。ゲストRAMモードの`store`はRAM更新として同じインターフェースを満たす。保存結果不明のとき、UIだけ先へ進めてはいけない。

ボタンのbusy解除は、その状態で新しい入力が許されることを確認してから行う。100msのデバウンスだけで重複イベントを防いだことにしない。

## I4. 丸型画面の確定配置

表示サイズ480×480、中心(240,240)。本文・タッチ要素の安全円を半径228とする。四角形の四隅すべてが安全円内であることを検査する。角が円外に出る352px以上の大きな正方形を、丸型画面の内側と見なさない。

全矩形は `data/layouts.json`。主要配置：

| 画面 | 配置 |
|---|---|
| 4テーブル選択 | x=96/248、y=134/254、136×104の2×2 |
| ポーカー手札5枚 | x=70+68i、y=190、64×92 |
| GOPS候補4枚 | x=96+76i、y=202、68×96。ページ式 |
| 31の場3枚 | x=116+88i、y=145、72×86 |
| 31の手札3枚 | 同x、y=254、72×86 |
| バカラの各3枚 | x=116+88i、y=143/252、72×84 |
| 3行動ボタン | x=96+100i、y=346、88×48 |
| 2行動ボタン | x=112/248、y=360、120×48 |
| カフェへ戻る | x=168、y=416、144×36。補助操作 |

上のテンプレートを同時に全部重ねない。例えば31は2行動用、ポーカーのベットは3行動用。メニューの本文・ページボタンも安全円で検査する。36px高さのカフェ補助ボタンを除き、主要な確定操作は高さ44px以上。カードは選択領域であり、そこで実ゲーム処理を確定しない。

本文日本語は22pxを初期値、補足18px、主要数字28〜36px。ボタン88px幅に長文を一行で詰めない。最大2行で短くし、完全な支払額説明は中央の確認カードで出す。画面を縮小して無理に情報を載せず、別ページの手札詳細・ルール・公開履歴へ分ける。

カード美術は数字とC/D/H/Sのマークで描き、色だけで区別しない。標準フォントに絵文字のトランプがあると仮定しない。漢字・かなは既存の許諾済みフォントから必要字形をビルド時にサブセット化する。フォントファイルを本引継ぎに含めない。

開始時に当該ゲームの遊び方が開ける。`data/tutorials.ja.json`の22ページを正本とし、初回は「練習して始める」を選べる。練習は固定の公開札、戦績なし、Jev呼出しなし。本番デッキへ練習の札やseedを流用しない。

## I5. 秘密画面とカフェ復帰

ポーカー/31の人間手札は共有端末で私的情報。カフェボタン、スリープ、プロフィール切替、エラー時は直ちに不透明のカバーを描き、privateのラベル・カードobjを破棄または非表示にする。サムネイル、画面遷移アニメーションの残像、復帰直後の前ユーザー手札を防ぐ。

ゲームを止めてからカウンターへ戻り、コーヒー＋1は通常どおり操作可能。別ゲームを起動しても本試合の非公開札を覗ける一覧はない。1つのCAFE CARDS未完試合だけを持ち、別テーブルを始める前に「再開／この試合を終了」を選ばせる。

ゲストは同じ電源セッションのRAM上だけ再開できる。本人確認機能がないことを表示する。電源断後のゲスト再開はしない。本人プロフィールは再認証後に再開する。途中で別人の戦績へひもづけ直す操作はない。

## I6. 乱数と同じ結果を維持する仕組み

`Deck::init()`はFisher–Yatesでシャッフルし、indexはrejection samplingを使う。`rand()%N`、起動時刻だけのseed、毎ラウンド固定seedを本番に使わない。テスト用mt19937は試験専用。

ESP32-S3の乱数には、RFなど有効なエントロピー源に関する条件がある [S20]。採用環境で安全なハード乱数源を初期化し、RF停止中の方針も明記する。必要なら起動時の真性乱数から暗号学的DRBGを初期化し、各ゲームへ渡す。ADC/他用途へ影響する乱数用設定を独断で変更しない。

本番のmatch_id・decision_idは128bit乱数の32hex。シャッフルした全順列とcursorは登録ユーザーのprivate snapshotに保持し、リトライ・復帰では生成し直さない。ポーカーの新ハンド、31の新ハンド、バカラの新ラウンドは規則どおり新しい山だが、同じハンドの通信再試行は新しい山ではない。

端末AIの抽選も、その決定を予約した時に一度だけ行い保存する。GOPSのjitterは`uniform(3)-1`、ポーカーのrollは`uniform(100)`。付録の`local_poker_bet`へ生の32bitを渡して`%100`だけに依存せず、0〜99に無偏り化して渡す。

## I7. 端末AIポリシー（全4種類）

| ゲーム・段階 | 方針 |
|---|---|
| ポーカー交換 | ストレート/フラッシュ/フルハウス/ストレートフラッシュは保持。ペア類は組になったrankを保持し単独札を交換。ハイカードなら4枚同スートを優先保持、それ以外は上位2rankを保持し3枚交換 |
| ポーカー追加不要時 | ツーペア以上はBET。ワンペアは45%、ハイカードは12%でBET、他はCHECK |
| ポーカー相手のBETあり | 上乗せ可ならツーペア以上はRAISE、ペア15%、ハイカード5%でRAISE。その後残る場合ペア以上はCALL、ハイカードはroll<25ならCALL、それ以外FOLD |
| GOPS | 昇順の自分の残札k枚から `round((prize-1)*(k-1)/(N-1))` の位置を基準とし、保存済みjitter -1/0/+1を加えて範囲内へclamp |
| 31通常 | 9交換を試算。現在27以上、または改善なしならKNOCK。それ以外は最高得点交換 |
| 31最後 | 改善交換ありなら最高得点交換、なければSTAND |
| バカラ | 組合せ計算済み表の3値最大。完全同率はPLAYER→BANKER→TIE |

複数候補の同率はslot順を採用する。これらは固定の比較基準であり、Jevの返答を偽装するものではない。ポーカーは場の状況を詳細に読む強力な専用エンジンではない。局所的な不合理さはプレイ試験で把握し、変更するなら`policy_version`を上げる。

## I8. Jevの契約を正確に使う

資料確認日の初期モデルは`jev-1.13.0`。実アカウントでアクセスを確認して固定する。最新aliasへ無断追随しない [S11]。プロンプトは英語ルール＋構造化した観測、画面は日本語。カード画像を送る仕様はない。

```http
POST https://api.typesafe.ai/v1/systemone
Authorization: Bearer <Script PropertiesのJEV_API_KEY>
Content-Type: application/json
```

```json
{
  "model": "jev-1.13.0",
  "state": {
    "rules": "固定した当該ゲームの英語ルール",
    "observation": {"game":"baccarat","variant":"classic","phase":"predict","rules_version":"1.0.0","decks":8,"fresh_deck_each_round":true,"public_first_cards":null}
  },
  "questions": {
    "action": {
      "type":"choice",
      "instructions":"Predict the final table-hand outcome using only public information.",
      "criteria": {
        "PLAYER":"PLAYER final points exceed BANKER.",
        "BANKER":"BANKER final points exceed PLAYER.",
        "TIE":"Final point totals are equal."
      }
    }
  }
}
```

上の`rules`は説明用で、本番は`reference/jev_contract.js`の実ルール全文を使う。`state/model/questions`と`type/instructions/criteria`は公式HTTP形 [S02,S12]。自由な日本語の行動文を返してもらって曖昧に解釈する方式ではない。

返答は`answers.action`を読み、以下を全て検証する。

- type=choice。候補キー集合が現在の合法IDと完全一致。
- 各確率はnumber・有限・0〜1。合計1±0.001。許容内の丸め誤差だけ再正規化。
- choiceは合法で最大値と1e-6以内で一致。confidenceは0〜1の有限number。
- modelは非空文字列。要求と異なる実モデルの場合は保守ログへ残し、運用で許可済みの実モデル以外は接続検査を失敗させる。
- HTML、null、文字列の数字、NaN、余分な候補、欠落、配列をオブジェクト扱いしない。

低confidenceだけを理由に同じ場面を何度も呼び直さない。最大候補を一度採用する。モデルの確率は選択の内訳、実際の勝率や数学的な真の確率とは別 [S02,S05]。

### 観測生成とサーバー検査

ESP32は `makeAIObservation` で新しいオブジェクトを組み立てる。GASは `reference/observation_gate.js` の `requestFromObservation()` で全キーと合法IDを検査し、固定ルール・候補説明を再構築する。端末から自由文のinstructionsを受け取らない。

`reference/jev_contract.js`の`buildObservation(full)`は許可フィールド抽出の参考。**GASへfullを送るためのコードではない。** GASで持っていない人間の手札を埋めるために架空の札を作らない。

GASの形・整合性検査だけで隠れた実札の正しさまで証明できるわけではない。通常の信頼済みファームが合法な手番で呼ぶことを前提にし、記録は`validation_level=device_attested`とする。

### UrlFetchAppの設定

```javascript
const response = UrlFetchApp.fetch('https://api.typesafe.ai/v1/systemone', {
  method: 'post', contentType: 'application/json',
  headers: {Authorization: 'Bearer ' + apiKey},
  payload: JSON.stringify(validatedJevBody),
  muteHttpExceptions: true, followRedirects: false,
  validateHttpsCertificates: true, timeoutSeconds: 8
});
```

現行公式リファレンスには`timeoutSeconds`がある [S15]。実アカウントで挙動を検査する。GAS起動・Sheets操作を含めた全応答時間が8秒になる保証ではない。Promiseやsleepで同期HTTPを中断できたことにしない。

401/403は認証の問題としてJevを停止。400/422は契約異常。429はRetry-Afterまたは60秒クールダウン、5xx/529/タイムアウト/不正応答は当該decisionをunavailableにする [S12]。残りの試合を端末AIに切り替えるか、待つか、終了するかを本人が選ぶ。

## I9. 全ネットワークAPI

ゲーム用公開入口は7操作。既存認証サービスの登録/login/guest/logoutは別の共通IdentityAdapterを使い、ここに同名の別ユーザーDBを作らない。

### 共通リクエストとレスポンス

```json
{
  "namespace":"cafe_cards", "api_version":1,
  "action":"decision.prepare",
  "request_id":"11111111111111111111111111111111",
  "device_id":"22222222222222222222222222222222",
  "device_token":"<端末の秘密値>", "player_token":"<期限付き本人またはゲストtoken>",
  "created_at_ms":1790030000000, "sent_at_ms":1790030000000,
  "payload":{
    "match_id":"33333333333333333333333333333333",
    "decision_id":"44444444444444444444444444444444",
    "decision_seq":1,"revision":2,"phase":"predict",
    "observation":{"game":"baccarat","variant":"classic","phase":"predict","rules_version":"1.0.0","decks":8,"fresh_deck_each_round":true,"public_first_cards":null},
    "legal_ids":["BANKER","PLAYER","TIE"]
  }
}
```

ID・時刻は架空の形式例。秘密をソースへ埋め込まない。payloadは`data/api_contract.json`の全フィールドが必要で、未知のキーを拒否する。

```json
{
  "namespace":"cafe_cards", "api_version":1,
  "request_id":"11111111111111111111111111111111",
  "server_time_ms":1790030000500,"ok":true,
  "data":{"decision_id":"44444444444444444444444444444444","status":"ready","observation_hash":"<64hex>","result_or_null":{"selected_id":"BANKER","probabilities":{"BANKER":0.5,"PLAYER":0.4,"TIE":0.1},"confidence":0.12,"model":"jev-1.13.0","normalization_applied":false},"lease_until_ms":1790030060000},
  "error":null
}
```

確率は応答形の説明例でありモデルの実測ではない。error時は`ok=false,data=null,error={code,message_ja,retryable,retry_after_ms}`。HTTP200でもok、namespace、版、request_id、Content-Type、JSONを確認する。端末POSTは16KiB、レスポンス8KiBをアプリ上限にする。

| action | 役割と重要な規則 |
|---|---|
| hello | 端末認証、時刻・利用可能game/variant・Jev設定・保守状態。未設定の利用権をavailableにしない |
| profile.get | token本人の当該game/variantの集計。別player_idをpayloadで指定させない |
| match.open | client生成IDを採用。game/variant/rules/owner/deviceを固定しactive登録。24時間期限 |
| decision.prepare | 同一match/decisionの呼出し枠を一度だけ予約。合法IDと観測を検証しJevを一度呼ぶ |
| decision.get | 同じjobを照会。照会だけで再度Jevを呼ばない |
| match.finish | 完了結果の範囲・保存済みAI記録との整合を検証、結果と統計を一度だけ確定 |
| match.abort | 未完を中止。completedを後からabortedにしない。中止は負けに加算しない |

profile.get以外の認証付き操作は本人または同一deviceの有効guestを使える。helloのみdevice認証でplayer_token=null。`first_actor`はポーカーでは**初回ディーラー**、31では初回先手、他はnull。このAPI名は共通化のためのラベルで、ゲーム内の役割を取り違えない。

### モデル観測の表記を曖昧にしない

観測のSELFは常にAI、OPPONENTは人間。ポーカーの`draw_counts`は`{self,opponent}`、`stacks`と`contribution`も同じラベル。内部の`hands[0]=H,[1]=A`という配列順を説明なしでモデルへ投げない。全観測の許可キーは`reference/observation_gate.js`に列挙し、その深さまで検査する。

### リクエスト・再送・時刻

- request_idは一つの業務操作で固定、再送も同ID・同payload。sent_at_ms/tokenだけ更新可。
- created_at_msから48時間超の更新はREPLAY_TOO_OLD。sent_at_msはサーバーと±5分、helloだけ未同期0を許可。
- request key=`device_id:request_id`。指紋は`{action,device_id,actor_id,payload}`の再帰的キーソートJSONをHMAC-SHA256化。秘密を含む生リクエストをログへ置かない。
- 同ID別payloadはIDEMPOTENCY_CONFLICT。認証主体を変えて再送したら所有権エラー。
- MatchIDは一度使用したら再利用しない。再戦は新ID、カード/乱数も新しいもの。

### decision応答の状態

`pending, ready, unavailable, cancelled`。pendingの`result_or_null=null`。readyなら確定回答。unavailableは再呼出し不可で、failure_codeをerrorまたは状態説明に付ける。cancelledは中止した試合の未完job。

サーバー上のjob keyは`device_id:match_id:decision_id`。decision_seqは試合内で1〜40、game別上限も適用する。古い同一seqを別decision_idで取り直そうとした場合はconflict。forced処理もローカルイベントに残すが、外部jobは作らない。

## I10. 冪等なJev呼出し・並行処理

**一つのdecisionに、アプリケーションから最大1回のJev要求**を送る。ネットワーク外部側の内部リトライ・課金までexactly-onceと保証しない。

1. ScriptLockを取得 [S17]。認証、期限、スキーマ、観測・合法IDを検査。
2. 同じjobがあればハッシュ一致を確かめ、状態を返す。readyの回答は固定。
3. 新規ならgeneration、60秒lease、call_reserved=trueを永続予約。端末日次上限とmatch上限もこの時に消費する。
4. 永続化の成功を確認してからロックを解放。呼出し予約の所有者だけがJevを呼ぶ。
5. 戻ったら再ロック。jobが同じgeneration・pendingで、期限内、match activeである場合だけreadyへ保存。
6. 期限超過・中止・世代違いの返答は捨てる。復旧ワーカーは再度Jevを呼ばない。
7. 処理が途中で落ちた場合、lease後はunavailable。結果不明を理由に同じ選択を取り直さない。

上限は端末1日1000予約、試合あたりPoker40/GOPS13/31は33/Baccarat5。これは本アプリの運用初期値で、サービスの公式上限そのものではない。Google/Jevの実際のquotaも確認する [S19]。カフェの既存通信よりゲームを優先してquotaを使い切らない。

ESP32の1HTTP試行は15秒でUI上の待ちを分離。job照会は2/4/8/8秒、以後8秒間隔でleaseを超えたら打切り案内。待機中もカフェへ戻れる。待機はプレイヤーの敗北にしない。

## I11. Googleシートの全定義と保存方法

`data/api_contract.json`の`sheets`に5種の**全列順**を収録。名前を変えず自動初期化し、既存同名のヘッダーが異なれば止める。clearして作り直さない。

| シート | 意味 |
|---|---|
| CardsMeta | schema版、索引、次の行番号、日次予約数、最後のwrite receipt、保守状態 |
| CardsMatches_YYYYMM | 一試合の所有者・種類・期限・結果・公開イベント・集計適用版 |
| CardsDecisions_YYYYMMDD | AIの一決定の予約・世代・期限・確定回答・失敗理由。生の秘密状態は置かない |
| CardsProfiles | 本人×game×variant×rules×provider別の統計と公開傾向 |
| CardsReceipts_YYYYMMDD | リクエスト指紋、応答参照、重複防止の受付台帳 |

日時タブはサーバーAsia/Tokyo基準。match.openでcreated_monthを返し、端末のローカル日付からタブ名を推測しない。日付をまたいだdecision再送も既存jobの索引を探す。

### 列値の詳細

- `player_id`は共通認証で確定。guestはランダム一時ID、CardsProfilesに行を作らない。
- `status`：matchはactive/completed/aborted/expired、decisionはpending/ready/unavailable/cancelled。
- `expires_at_ms`はcreated+24hの固定。pollだけで延長しない。
- `human_score/opponent_score`：Poker最終持ち点、GOPS獲得点、31ハンド勝ち数、Baccarat的中数。中止はnull。
- `winner`：H/A/D、completedだけ。`end_reason=completed|user|expired|corrupt|guest_restart|fault`。
- `provider_counts_json={jev:n,local:n,forced:n}`。requested=jevで途中local使用ならcohort=mixed。
- `public_events_json`は第I14節の公開イベントだけ。山札・隠れた札・tokenは不可。
- `result_hash`はmatchID/型/結果/公開履歴/出所のcanonical JSON SHA-256。finish再送で値が違えばRESULT_CONFLICT。
- `validation_level`は`device_attested`。実際にはしていないサーバーでの秘密全棋譜検証を意味させない。
- `stats_applied_version`は登録本人への当該結果適用後の版、guestはnull。
- decisionの`request_hash`はphase/revision/observation/legal_idsの指紋。`observation_hash`は観測のSHA-256。
- `result_json`は選択ID・合法確率・confidence・実model・丸め有無。使用量・latencyは実測できたものだけ、未取得null。
- `profile_key=player_id|game|variant|rules_version|cohort`。cohortはjev/local/mixed。Baccaratの計算予想はlocalに含め、表示名だけ区別。
- receiptのsafe_response_jsonにtokenを保存しない。ここで本人ログインtokenを新規発行する操作はない。

### 一括保存と不明な書込み

シートは管理者専用Workbook。既存カフェ集計が共有されているなら別の非公開Workbookを使う。関係タブは一Workbook・一つのApps Script書込み元に集約。

同じScriptLock配下で更新前のデータを再読、IDと版を確認。CardsMetaの`active_owner:<id>`と`active_device:<id>`でCAFE CARDSの未完試合を一つに制限する。ID→行索引はキャッシュ不在ならID列だけ検索し、実際の行IDを再確認する。新しい行は`next_row:<tab>`で単調割当し、行追加と同時batchでカウンターも更新する。行の追加、next_rowカウンター、結果、stats版、receiptを**一つのSheets.Spreadsheets.batchUpdate**にする。Google APIはサブ要求を検証し一括適用するが [S18]、他ユーザー編集との完全なDBトランザクションではない。直接ソート・編集・行削除を運用禁止とする。

`userEnteredValue.stringValue`でID/JSON/人名を文字として入れ、formulaValueは使わない。各JSONセルはアプリ上限24,000UTF-8 bytes、公開イベントは12KiB以下。超えた場合に中途半端に切り詰めず、イベント形式の肥大をエラーとして修正。

書込み前にScript Propertiesへ`CARDS_WRITE_BARRIER_JSON`（txID、receiptKey、期待hash）を保存。batchUpdateが成功応答ならreceipt照合してbarrierを消す。応答が途絶えた場合はbarrierを残し、新規の状態更新を止める。保守処理がreceiptを読み、当該batchが確定済みなら続行。不明なら`STORAGE_UNCERTAIN`で停止し、盲目的に同じappendを再送しない。

存在しないreceiptを一度読んだだけで「絶対未適用」と断定せず、失敗の種別・監査・復元手順に従う。安全側停止は利用不能になることがあるが、二重戦績や二重課金より優先する。CacheServiceは高速化のヒントであって保存台帳ではない。

## I12. HTTPS・配備・鍵

GAS Web Appは`e.postData.contents`からJSONを読み、ContentServiceで返す [S13,S14]。一般のHTTPサーバーのような任意Authorizationヘッダー取得やTextOutput.setStatusCodeを前提にしない。端末認証tokenはJSON本文、URLには置かない。

ContentServiceは一時的なGoogleホストへリダイレクトする [S14]。ESP32はscript.google.comへPOSTし、302/303なら許可済みHTTPSのscript.googleusercontent.comへ**GET・本文なし・tokenなし**で追従。最大3回。未知ホスト、HTTPへの降格、ログインHTML、秘密POSTを再送させる307/308は拒否して設定確認。証明書検証を無効化して接続完了としない。

| Script Property | 意味 |
|---|---|
| CARDS_SPREADSHEET_ID | 非公開ゲームWorkbook |
| JEV_API_KEY | 共通Jev API鍵。Flashへコピーしない |
| CARDS_JEV_MODEL | 初期jev-1.13.0、実接続試験後に固定 |
| CARDS_RECEIPT_KEY_HEX | request指紋の32byte以上秘密、他用途と分離 |
| CARDS_DEVICE_TOKEN_SHA256_〈id〉 | 既存端末認証adapterが使えるなら共通登録値を参照 |
| CARDS_MAINTENANCE | trueなら新規試合/新推論停止 |
| CARDS_WRITE_BARRIER_JSON | 未確定書込みの小さい記録 |
| CARDS_DEPLOYMENT_VERSION | デプロイしたソースの版 |
| CARDS_JEV_COOLDOWN_UNTIL_MS | API障害時の再試行抑制 |

Script Propertiesはスクリプト編集者から秘密を隔離する専用金庫ではない [S16]。編集権限を限定する。新秘密はPCの暗号学的乱数で生成し、ソース・git・スクリーンショットへ残さない。

配備：既存バックアップ→テストWorkbook→Sheets高度サービス→schema初期化→Script Properties→既存doPostにnamespace分岐追加→テスト/exec→端末認証→モック→Jev→結果記録→本番切替。`/dev`を本番URLにしない。Workspaceの匿名呼出し禁止を勝手に解除しない。許可された既存の認証経路を使い、不可ならオンライン機能を未配備として止める。

## I13. 個人登録・ゲスト・記録の意味

既存のAI DUELで設計された個人登録を`IdentityAdapter`へ切り出して利用する。新しいCAFE CARDS用の同名アカウントや別PINを勝手に発行しない。既存コードが未実装でもゲスト/端末AIは実装可能。本人機能が未実装なら匿名を本人として保存しない。

期待する共通認証interface：`listPlayers(page), login(player_id,pin), beginGuest(device_id), validate(token,device_id), logout(token)`。実際の操作名は既存へマッピングし、旧アプリのlogoutやactiveMatch消去を不用意に呼ばない。トークンはRAM、PINもRAMで認証後破棄。

個人統計は次の構造を基準にする。

```json
{
  "version":1,"matches_completed":0,"wins":0,"losses":0,"draws":0,
  "aborted":0,"hands_completed":0,"rounds_completed":0,
  "score_sum":0,"recent_results":[],
  "behavior":{"sample_n":0,"fold":0,"check":0,"call":0,"bet":0,"raise":0,
    "knock":0,"swap":0,"stand":0,"aggressive_opportunities":0,"facing_bet_opportunities":0},
  "behavior_window":[],"gops_recent_public":[],"last_match_id":null
}
```

`recent_results`最大20試合（各要素はwinner,score,completed_at_ms）。`behavior_window`最大200要素（各要素はaction,phase,turn,can_aggress,faces_bet）。札やPINを含めない。`behavior`は直近200の該当する公開人間意思決定から再計算し、モデルへはこの有限windowを送る。累計カウンターの無制限増加を32bitの暗黙wrapに任せない。長期数は64bit、画面桁あふれは省略表記とする。

ポーカーのaggressive opportunityはその行動前にBETまたはRAISEが合法だった人間の番。facingはCALL/FOLDが合法な番。31の通常/最後を区別した集計を追加し、履歴イベントから再構築できるようにする。GOPSは同variantの直近26の公開結果だけ。バカラに個人の予想傾向を送らない。

試合勝率=`wins/matches_completed`。引分けも母数に含める。バカラの的中率=`correct/rounds_completed`は別表示。中止は勝敗の母数に含めない。未完ハンドのprivate行動から個人傾向を更新しない。5回の小標本をAI強さや人物能力の評価にしない。

保持：登録試合明細180日、guest明細1日、decisionは試合終了から2日、receipt2日、累計/直近windowは退会/リセットまで。退会はCAFE CARDSの履歴・stats・private snapshotにも連携し、他ゲームとの削除範囲を管理UIで明示する。バックアップから削除済み本人を復活させない。

## I14. 公開イベントと結果の全形式

共通イベント `{seq, hand_or_round, actor, kind, data}`。seqは1から連番、actorはH/A/SYSTEM。時刻は勝敗ロジックに使わず、表示・監査用。最大192イベント。配布の札順は含めない。

| game/kind | dataの内容 |
|---|---|
| poker/HAND_START | hand_no, dealer, start_stacks。手札なし |
| poker/BET_ACTION | action, debit, unit, raises, stacks, pot |
| poker/DRAW_COUNTS | human_count, ai_count。双方確定後だけ |
| poker/HAND_END | winner, folded, end_stacks, pot_awarded。showdown時だけfinal_hands[2]とkeys[2] |
| gops/ROUND_END | prize, human_bid, ai_bid, winner, scores, burned |
| thirty_one/HAND_START | hand_no, first_actor, market。両手札なし |
| thirty_one/SWAP | out_card, in_card, actor, turn。これらは場から見えて合法 |
| thirty_one/KNOCK・STAND | actor, turn |
| thirty_one/HAND_END | hands[2], scores[2], reason, winner |
| baccarat/ROUND_END | actual_used_cards, np,nb,pt,bt,outcome, predictions[2], points[2]。未使用の候補札なし |
| common/FALLBACK | from=jev,to=local,decision_id,reason。秘密なし |

結果JSONは `{game,variant,completed_units,human_score,opponent_score,winner,end_reason,provider_cohort,hand_results}`。completed_unitsはP5/G7または13/T3/B5。hand_resultsは各公開決着の最小集計、GOPSは各得点結果。incompleteをcompletedへ格上げしない。

サーバー検証：Poker最終計200、GOPS両得点+burned=28/91、31勝ち数+相手勝ち数+引分けハンド=3、Baccarat各的中0..5。AIの公開行動は保存ready結果と一致することを照合する。参照できない内部札の公平性を「サーバー検証済み」としない。

## I15. 保存形式・電源断・所有者

### 保存方針

registeredはprivate snapshotを**2スロット各最大32KiB**で保存。普通のデフォルトNVSにそのまま64KiBが空いていると仮定しない。実機の保存区画・他ゲームの使用量を測り、既存FS/専用領域のStorageAdapterを選ぶ。区画変更はバックアップ・承認・移行手順付き。足りない場合、保存不可を明示してRAM限定とするが、本人試合を復旧可能と表示してはいけない。

データは長さ付きの固定スキーマで明示encodeし、C++structの生メモリーをそのまま書かない。little-endianの整数またはcanonical JSONで表現を統一。CRC32は破損検知で、秘密保持や改ざん防止の暗号ではない。NVSの耐障害性や暗号化も採用環境で確認する [S21]。

### スナップショットの完全なフィールド群

```text
header: magic="CTC1", schema=1, generation(uint64), payload_length, crc32
common: match_id, owner_id, is_guest(false), game,variant,rules_version,
        requested_provider, current_provider, cohort,
        created_at_ms, expires_at_ms, revision, phase, suspended,
        dealer_or_first_actor, completed_units, match_scores,
        event_log, public_events, provider_counts
private_game:
  poker: hand_no, deck_order[52], cursor, hands[2][5], discards[0..10],
         draw_masks[2], stacks[2],pot,street_paid[2],actor,unit,raises,checks,winner,folded
  gops: n,prize_order[n],round_index,remaining_masks[2],sealed[2],scores[2],burned
  thirty_one: hand_no,deck_order[52],hands[2][3],market[3],known_masks[2],
              actor,turn_count,knocker,finished,end_reason,hand_wins[2]
  baccarat: round_no,deck_order[416],first_six[6],guesses[2],
            outcome_or_pending,used_count,totals_or_pending,prediction_scores[2]
pending: decision_id,decision_seq,request_id,phase,revision,observation_hash,
         generation,status,selected_id,probabilities_optional,local_random_choice,
         human_draft_optional,job_created_day
sync: match_opened_online,server_created_month,pending_finish_request_id,
      result_hash,finish_acknowledged,identity_profile_version
```

token・PIN・Jev鍵は一切含めない。JSONならnullと不存在を勝手に混ぜない。private event_logはルール再生用の全確定手と開始デッキの参照、public_eventsは送信用。前者をネットワークへ送らない。

### 書込み・復元の手順

非activeスロットへgeneration+1を書込→完了→再読しCRC/長さを検査→active参照を切替。起動時は両方を検証し最大generationを採用。壊れた新スロットしかなければ古い有効スロット。両方不正ならデータを勝手に合成せず再開不可。

復元後はrule replayと不変条件を照合する。山札が順列か、cursor妥当か、手札/捨て札との位置が整合するか、得点/消費札/手数/phaseが矛盾しないか、pendingが現在局面かを確認。referenceのpublic structへディスクの値を無検証代入しない。

起動後は共通メニュー「再開可能な試合があります」。本人再認証成功後だけprivate画面を描く。期限24時間を超えたら無効終了。時刻不確かならオンライン再同期まで本人再開保留。guestはRAMのみなので電源断後再開不可。

secret保存を許容しない運用なら、registered再開を無効化する設定を管理者が選ぶ。ただしこの制限をゲーム設定変更や戦績復旧の成功と混同しない。人狼の「秘密はRAMだけ」と、今回の個人カードの要件は別である。

### 未確定ネットワークと復旧

readyを受けてまだカードへ反映していない場合は、同decisionをgetし保存した選択を再利用。反映済みrevisionの古い返答は無視。pause中に返答が届いたら状態へ一度保存するが画面を再開しない。`ChooseLocal`で切替済みなら、後で来たJev返答へ戻らない。

## I16. メモリー・電池・性能の予算

- 52枚は104byte、416枚は832byte（uint16）。4ゲームが8MBをカードだけで使うわけではない。
- 動的ゲーム状態は同時に1種類、固定上限のvariant/union等を使う。全4画面の画像を常時RAMへ載せない。
- 480×480×2byteのフレーム1面は460,800byte。既存BSPのバッファ数を調べ、追加UIが勝手に別の全画面バッファを複数確保しない。
- JSONの1要求16KiB、応答8KiBを上限としてパーサーも制限。ArduinoJson等を選ぶ場合は既存版に合わせ、巨大な無制限String連結を避ける。
- 初期目標：各タッチ選択への視覚反応100ms以内、HTTP中もカフェへ戻れる。これは受入目標で実測値ではない。
- バックライト暗転は120秒無操作でpause後に行う。非公開手を出したまま低輝度にするだけでは不十分。
- 1500mAhの駆動時間は実装後に電池側で測定する。USB給電電流をそのまま3.7V電池の電流に置き換えない。未検証の残量％を表示しない。

## I17. 実装の順序と各段階の完了条件

| 段階 | 作業 | 合格条件 |
|---|---|---|
| 0 | 原本保全・環境確認 | LCD/タッチ/＋1/既存5ゲームを再現 |
| 1 | 付録PC検査、共通カード型 | 全検査成功、版とツールを記録 |
| 2 | 4テーブルメニュー・練習 | 4入口と全遊び方が丸画面で読める |
| 3 | GOPS端末AI | 7/13を完走、同時選択と残札確認 |
| 4 | 31端末AI | 3ハンド、ノック/上限/既知札を完走 |
| 5 | Poker端末AI | 5ハンド、交換・全ベット・得点保存 |
| 6 | Baccarat計算予想 | 5回、OPEN/CLASSIC、全追加札条件 |
| 7 | private保存・再開 | 強制電源断、再認証、secret非表示 |
| 8 | Google・共通本人 | mock decision、記録の再送・失敗復旧 |
| 9 | Jev実接続 | 4種類で実応答・料金枠・時間・入力分離を検査 |
| 10 | 社内試遊 | 各ゲームの理解・再戦したさ・操作負担を評価 |

これは完成時にゲーム数を削る順序ではなく、4種類を丁寧に積み上げる順序。途中状態は開発ビルドと明示し、未実装ボタンで完成を装わない。

## I18. 実装者に要求する納品物

変更した既存コードの差分、固定依存版、ビルド/書込み手順、テスト用/本番GASの区別、全schema移行、秘密を含まない設定例、API応答の機密除去済み記録、実機受入表、復旧/ロールバック手順、未達事項を納品する。

本書の参考コードだけをコンパイルして、既存端末に組み込めたと報告しない。「単体テスト成功」「ESP32ビルド成功」「書込み成功」「実機操作確認」「Google実保存」「Jev実呼出し」「試遊評価」は別項目で報告する。


---

# 第VI部 — 検査、運用、根拠資料

## Q1. 実機・実サービス受入試験

以下の**124項目**は、コーディングエージェントが実装した対象環境で実施する。全行の初期状態は`not_run_on_target`。PC参考コードの成功を、この表の実機合格へ一括転記しない。証拠、担当者、日時を記録する。

| ID | 確認内容 | 合格条件 | 状態 |
|---|---|---|---|
| BASE-01 | 原本保全 | 変更前のBSP・LVGL・Google設定・ゲーム登録のバックアップが存在する | 未実施 |
| BASE-02 | 型番 | 実機が2.8Cであることと480×480を確認する | 未実施 |
| BASE-03 | 既存カウンター | 4本を追加後も+1を2回押すと2だけ増える | 未実施 |
| BASE-04 | 既存5ゲーム | 人狼3〜10人v2を含む既存5本の起動と終了を確認する | 未実施 |
| BASE-05 | 入口一つ | 第6メニューCAFE CARDSだけから4種類へ分岐する | 未実施 |
| BASE-06 | 全ゲーム完走 | 端末AIでP5ハンド・G7/13・31は3ハンド・B5回を終了する | 未実施 |
| BASE-07 | 文言 | 全119文言キーと22ページの文字に欠けがない | 未実施 |
| BASE-08 | 依存固定 | 使用core・LVGL・コンパイラ・BSP・ライブラリ版を記録する | 未実施 |
| BASE-09 | 練習 | 固定練習が課金や正式戦績・本番乱数に影響しない | 未実施 |
| BASE-10 | 禁止機能 | 課金・換金・景品・共通財布・人事連携がない | 未実施 |
| SEC-01 | 相手手札隔離 | 人間の未知手札を変えてもAI要求の意味が変わらない | 未実施 |
| SEC-02 | 未来札隔離 | 山札未来部分を変えても同じ公開状態のAI要求が一致する | 未実施 |
| SEC-03 | GOPS未公開札 | 人間の仮選択をJev要求に含めない | 未実施 |
| SEC-04 | 交換未公開 | ポーカーの人間maskをAI交換決定前に送らない | 未実施 |
| SEC-05 | バカラ未公開 | 人間予想・勝敗・未来6枚を送らない | 未実施 |
| SEC-06 | 私的捨て札 | ポーカーの相手捨て札が公開履歴・統計から漏れない | 未実施 |
| SEC-07 | 31公開既知 | 正当に公開された取得札だけを既知集合へ追加する | 未実施 |
| SEC-08 | ネスト未知キー | 余分なroot・nested keyをGASで拒否する | 未実施 |
| SEC-09 | API鍵 | Jev鍵が端末Flash・ソース・ログに存在しない | 未実施 |
| SEC-10 | 本人認証 | 別人token/他deviceでprivate試合と統計を取得できない | 未実施 |
| SEC-11 | PIN | 生PINとplayer_tokenがsnapshotへ書かれない | 未実施 |
| SEC-12 | 画面退避 | カフェ復帰・ログアウト・エラーで手札が残像を含め消える | 未実施 |
| SEC-13 | ログ | 例外・シリアルに山札・token・非公開手札を出さない | 未実施 |
| SEC-14 | モデル文言 | confidence・行動確率を実勝率と表示しない | 未実施 |
| SEC-15 | 役判定分離 | Jev応答で役の強さや点数規則を書き換えられない | 未実施 |
| SEC-16 | 共有Workbook | 一般公開カフェシートにprivate記録を入れない | 未実施 |
| P-01 | 配布順 | 非dealer→dealerへ交互に5枚、初期cursor=10 | 未実施 |
| P-02 | 先手交代 | 初回dealerを記録し5ハンドで交互にする | 未実施 |
| P-03 | CHECK2回 | 両CHECKで一度だけ次段階へ進む | 未実施 |
| P-04 | CHECK後BET | 相手BETへのFOLD/CALL/RAISEが表示される | 未実施 |
| P-05 | 額一致 | CALLは不足額だけを支払う | 未実施 |
| P-06 | RAISE | 不足額+unitを払い、回数を1だけ増やす | 未実施 |
| P-07 | 上限 | 2回上乗せ後のRAISE拒否、CALL/FOLDは可能 | 未実施 |
| P-08 | 段階初期化 | 交換後unit=4、paid/raises/checksが0 | 未実施 |
| P-09 | 無料FOLD禁止 | owed=0でFOLDできない | 未実施 |
| P-10 | 残点保証 | 最悪5連敗でも最後に5点以上、補充なし | 未実施 |
| P-11 | 総点 | 各確定状態でstacks+pot=200 | 未実施 |
| P-12 | 交換0 | 双方0枚でも正しく交換後へ進む | 未実施 |
| P-13 | 交換5 | 双方5枚を交換しても重複・枯渇しない | 未実施 |
| P-14 | 交換順 | 双方mask固定後、非dealer固定slot昇順から引く | 未実施 |
| P-15 | ホイール | A2345は5-high、QKA23はストレートではない | 未実施 |
| P-16 | 同役比較 | 全カテゴリのキッカー比較とスート同点を確認する | 未実施 |
| P-17 | フォールド | 一度だけpot授与、未公開札と内訳を見せない | 未実施 |
| P-18 | 同役分配 | 偶数potを半分ずつ分ける | 未実施 |
| P-19 | 試合勝敗 | ハンド勝利数でなく5ハンド後の持ち点で決める | 未実施 |
| P-20 | 再戦 | 新matchId・新配布、持ち点100へ戻る | 未実施 |
| G-01 | 7枚 | 7回で終了し総得点+破棄=28 | 未実施 |
| G-02 | 13枚 | 13回で終了し総得点+破棄=91 | 未実施 |
| G-03 | 場の点 | 勝ち札の数字でなく得点札の数字を加える | 未実施 |
| G-04 | 同点 | 得点破棄・双方消費・持越しなし | 未実施 |
| G-05 | 両方消費 | 負けた側の札も残札から消える | 未実施 |
| G-06 | 重複札 | 使った札を再度出す操作を拒否する | 未実施 |
| G-07 | 公開残札 | 両者の残札が実状態と一致する | 未実施 |
| G-08 | 秘密確定順 | AI札保存より前に人間Confirmできない | 未実施 |
| G-09 | 最終一枚 | 強制処理でJevを呼ばずforced記録になる | 未実施 |
| G-10 | ページ | 13枚目を選べて表示切替でドラフトを保つ | 未実施 |
| G-11 | 引分け | 最終同点で追加回を勝手に作らない | 未実施 |
| G-12 | 得点順 | 未来得点が見えず、復旧で順番が変わらない | 未実施 |
| T-01 | 配布 | 初期9物理札が相異なり場3枚 | 未実施 |
| T-02 | 同スート | 別スートの得点を足さない | 未実施 |
| T-03 | Aと絵札 | A11、JQK10 | 未実施 |
| T-04 | 3枚組 | 777は7点で特典なし | 未実施 |
| T-05 | 点数同点 | 別スートの余り札・キッカーで差をつけない | 未実施 |
| T-06 | 単交換 | 一ターン一対一交換だけ | 未実施 |
| T-07 | 通常STAND禁止 | 通常でパスボタンが出ない | 未実施 |
| T-08 | ノック | 交換せず相手へ最終応答権を渡す | 未実施 |
| T-09 | 最終応答 | 交換/STANDの後ただちに比べる | 未実施 |
| T-10 | 再ノック禁止 | 最終応答でKNOCKを拒否する | 未実施 |
| T-11 | 初期31 | 片側/両側31で正しく即終了 | 未実施 |
| T-12 | 交換後31 | 相手追加ターンなしで終了 | 未実施 |
| T-13 | 20手交換 | 20番目SWAP後に比べる | 未実施 |
| T-14 | 20手ノック | 21番目の最終応答を一度許す | 未実施 |
| T-15 | 既知削除 | 公開取得札を場へ戻すと既知集合から消える | 未実施 |
| T-16 | 3ハンド | 先手交代し勝ち数で試合を比べる | 未実施 |
| B-01 | 新山 | 5ラウンドそれぞれ416枚から開始する | 未実施 |
| B-02 | 非復元 | 同じ物理IDを同一回で二度引かない | 未実施 |
| B-03 | 見た目重複 | copy違いの同じカード表示は許される | 未実施 |
| B-04 | 配布順 | P1B1P2B2の順である | 未実施 |
| B-05 | OPEN | 1枚ずつだけ表示、2枚合計結果はまだ不明 | 未実施 |
| B-06 | CLASSIC | 一枚も予想前に公開しない | 未実施 |
| B-07 | ナチュラル | どちらか8/9で両方止める | 未実施 |
| B-08 | P停止B5 | P6/7のときB5は引く | 未実施 |
| B-09 | B3境界 | P3=8のみ止める | 未実施 |
| B-10 | B4B5B6境界 | 追加表80セルと停止分岐を照合する | 未実施 |
| B-11 | 5枚目行先 | P停止時は次札がB3、6枚目を飛ばさない | 未実施 |
| B-12 | 予想同一 | 人間AIが同じ予想でも変更せず両者加点可能 | 未実施 |
| B-13 | TIE得点 | TIEを当てても1点、倍率や手数料なし | 未実施 |
| B-14 | 表とJev | 計算値の表示とJev予測を別の出所にする | 未実施 |
| NET-01 | 認証 | device/本人/guestの所有権と期限を確認する | 未実施 |
| NET-02 | 型検査 | 未知action・variant・範囲外を拒否する | 未実施 |
| NET-03 | モデル固定 | 使用モデルと要求/応答の実版を記録する | 未実施 |
| NET-04 | API不正 | 合計不正・候補漏れ・不正数値・非合法返答を拒否する | 未実施 |
| NET-05 | 同一再送 | 同ID同要求のJev呼出し枠が一回だけ | 未実施 |
| NET-06 | 別内容再送 | 同ID別観測をconflictにする | 未実施 |
| NET-07 | 並行要求 | 複数HTTP要求で同決定が二重予約されない | 未実施 |
| NET-08 | lease | 遅延・クラッシュ後の不明jobを再度推論しない | 未実施 |
| NET-09 | 旧返答 | 他match/revisionの返答を適用しない | 未実施 |
| NET-10 | pause返答 | pause中readyは保存だけ、勝手に画面復帰しない | 未実施 |
| NET-11 | 途中local | 本人選択後は残り試合local、後着Jevを無視 | 未実施 |
| NET-12 | リダイレクト | 302/303は本文なしGET、未知ホストは拒否 | 未実施 |
| NET-13 | HTML200 | Googleログイン画面をJSON成功と扱わない | 未実施 |
| NET-14 | quota | 上限・429・キー障害でカフェ本体まで停止しない | 未実施 |
| REC-01 | A/B書込み | 古い有効snapshotを残して新slotへ書く | 未実施 |
| REC-02 | 書込み中電断 | 途中切断時にCRC有効世代だけ復元する | 未実施 |
| REC-03 | 両方破損 | 再抽選による再開をせず無効を表示する | 未実施 |
| REC-04 | カード再生 | deck順列/cursor/手札/イベント整合を照合する | 未実施 |
| REC-05 | 本人再開 | 再認証するまで私的手札を表示しない | 未実施 |
| REC-06 | ゲスト電断 | 旧guestのprivate試合を別guestへ渡さない | 未実施 |
| REC-07 | 24h期限 | 期限超過の試合を勝敗に混ぜない | 未実施 |
| REC-08 | 結果再送 | finishの応答消失で成績を二重加算しない | 未実施 |
| REC-09 | 別結果 | 同matchの結果改変をconflictにする | 未実施 |
| REC-10 | Google不明書込 | barrierを残し盲目的なappend再送をしない | 未実施 |
| REC-11 | 退会 | private snapshot・各ゲーム記録の削除範囲を確認する | 未実施 |
| REC-12 | 区画不足 | 保存区画を無断消去・拡張しない | 未実施 |
| PLAY-01 | 文字 | 日本語と数字・マークを実機で複数人が読める | 未実施 |
| PLAY-02 | タッチ | 選択後確認で誤交換・誤入札を防げる | 未実施 |
| PLAY-03 | 4種の違い | 各テーブルで異なる判断を楽しめる | 未実施 |
| PLAY-04 | ポーカー | 用語を知らない人が金額と降りる意味を理解する | 未実施 |
| PLAY-05 | GOPS | 小さい札を残す/使う選択に理由を持てる | 未実施 |
| PLAY-06 | 31 | ノック後の最後の一手を誤解しない | 未実施 |
| PLAY-07 | バカラ | 二つの手札と人間AIを混同しない | 未実施 |
| PLAY-08 | AIの役割 | 同じ手ばかり等がないか実Jev各20試合を観察する | 未実施 |
| PLAY-09 | 電池 | 実電池条件の平均電流・温度・連続時間を測定する | 未実施 |
| PLAY-10 | 中断性 | いつでも一時停止してコーヒー+1へ戻れる | 未実施 |

## Q2. 面白さの試遊と採用判定

初回は少なくとも6人に遊んでもらい、各ゲームを初見の人2人以上が触る。ポーカー経験者だけで全体の分かりやすさを判断しない。個人名を点数表へ公開せず、匿名の感想を集める。
質問は「次に押すものが分かったか」「何で勝ち負けが決まったか説明できるか」「通信待ちが気になったか」「もう一度違う選び方で遊びたいか」。理解できない箇所を優先修正し、派手な演出を追加して隠さない。
Jevの4種類の実力は未測定。合法行動率、呼出し時間、フォールド/ノック等の偏り、再戦意向をモード別に観察する。端末AI相手と比較して意味のある違いがあるかを確認し、すべて同じ勝率目標に合わせた配札操作はしない。

## Q3. トラブル対応・運用

1. LCDが映らない：原本の基板サンプルへ戻して比較。ゲーム用にBSPやPSRAMを再設定しない。
2. タッチがずれる：既存座標と円形レイアウトを確認。ルールエンジンを変更しない。
3. 個人履歴が見えない：共通認証・owner・variant・cohortを確認。別人へ紐付けて復旧しない。
4. Jevが使えない：端末→GAS、GAS→Jev、キー、契約、quotaを切り分け。通信エラーを勝敗にしない。
5. STORAGE_UNCERTAIN：新規ゲーム更新を止め、barrier/receiptを管理者が照合。勝手に行を削除して再送しない。
6. 電池切れ後：本人ならsnapshot検査と再認証、guestなら旧試合破棄。再抽選して続きとして扱わない。
7. 規則改訂：rules_versionを上げ、保存局を互換判定。新旧別統計にし、古いカード状態へ新規則を適用しない。

## Q4. 実際にこの資料作成中に実施した検査

実行環境は`results/environment.json`。以下は配布する参考コードの実測結果で、外部サービスやESP32の結果ではない。
| 検査 | 実行結果 |
|---|---|
| C++基本ルール | 全26グループ成功。通常ビルドは警告をエラー扱い |
| ポーカー役 | 全2,598,960手を列挙し、9カテゴリの件数と一致 |
| ポーカー進行 | 2,000試合・10,000ハンド。全1,024の交換mask組合せ、ベットの52終端経路を検査 |
| GOPS | 7/13合計2,000ゲーム、得点・残札の保存条件を検査 |
| 31 | 全22,100の3枚得点、3,000ハンド進行、ノックと20+1境界 |
| バカラ | 1,000,000の6値列を別表実装と照合。予想の全27組の得点 |
| C++/JavaScript | 独立の役判定・31得点を2,000手で照合 |
| Jev契約 | 23グループ成功。4ゲームで隠れた入力変更の非干渉、不正応答11種類 |
| 観測境界 | 18グループ成功。余分なキー、違う合法ID、公開前カードなど拒否 |
| 通信状態モデル | 72アサーション成功、同時64予約で呼出し枠1回 |
| ローカルAI | ポーカー15,000合法行動、31は10,000条件を検査 |
| データ | 52カード・31矩形の安全円・101確率表・119文言・22ページの整合 |
| 追加メモリー検査 | ASan/UBSanで小規模の25グループ成功 |

全ゲームの全到達状態を網羅した証明ではない。乱数試験の通過もシャッフルの暗号学的安全性の証明ではない。実Jev正解率、GASの処理時間、API課金、本人情報運用、フォント、日本語レイアウト、電池持続、4種類の楽しさは実機受入で確認する。

## Q5. 参考ファイルの使い方

Python3.10以上、Node18以上、C++17対応コンパイラを用意する。ファイルを展開したルートで次を実行する。

```bash
python tools/run_checks.py --full
python tools/run_checks.py --full --sanitize
```

WindowsはMSYS2等のg++またはCXXで指定した対応コンパイラを使う。Sanitizer未対応の環境は通常検査だけ実施し、追加検査の未実施を明記する。結果は標準で`results_local/`へ保存し、配布時の実行結果`results/`を上書きしない。

`core/cards_core.hpp`は4ゲームのルール、`reference/local_policy.hpp`は比較基準の相手、`reference/jev_contract.js`は観測抽出とモデル契約、`reference/observation_gate.js`はGAS境界用の観測・合法ID検証。`reference/decision_protocol.py`は並行予約と遅延応答の実行可能なモデルであり、本物のSheets保存処理ではない。
`tools/baccarat_table.cpp`は確率表の再生成用。生成結果はdoubleへ落とす前に長い精度で重みを加算するが、表は有限桁に丸めてある。ビルドする端末へ重い全列挙を入れる必要はない。

## Q6. 調査した一次資料と確認範囲

ルールの参照部分と、今回のカフェ向け独自変更を本文で分けた。資料確認日2026-09-22。公開情報は実アカウントの利用可否や自社端末の動作を保証しない。

**[S01] Waveshare 2.8C** — ボード・メモリー・タッチ・電池端子。
`https://docs.waveshare.com/ESP32-S3-Touch-LCD-2.8C`

**[S02] TypeSafe Choice** — 型付き候補選択と応答構造。
`https://docs.typesafe.ai/primitives/choice`

**[S03] Loto-Québec Five Card Draw** — 5枚交換型ポーカーの土台。
`https://www.espacejeux.com/en/ok-poker/how-to-play/games/5-card-draw`

**[S04] Bicycle Basics of Poker** — 役の強さ・基本的な決着。
`https://bicyclecards.com/how-to-play/basics-of-poker`

**[S05] TypeSafe Jev jaggedness** — 数値計算をコードへ分ける判断。
`https://docs.typesafe.ai/model-jaggedness/jev-1.13`

**[S06] Coppercod GOPS** — 同時入札と得点札の土台。
`https://coppercod.games/game/gops/`

**[S07] Google DeepMind OpenSpiel Goofspiel** — 札数/順番を分けたゲーム実装。
`https://raw.githubusercontent.com/google-deepmind/open_spiel/master/open_spiel/games/goofspiel/goofspiel.h`

**[S08] Bicycle Thirty-One** — 3枚と公開の場を交換する流派。
`https://bicyclecards.com/how-to-play/thirty-one`

**[S09] Venetian Baccarat** — 配布順・ナチュラル・追加札。
`https://www.venetianlasvegas.com/resort/casino/table-games/how-to-play-baccarat.html`

**[S10] Four Winds Mini Baccarat** — PLAYER停止時のBANKER条件の照合。
`https://fourwindscasino.com/blog/minibaccarat/`

**[S11] TypeSafe Models** — 固定モデルID・文字入力・言語・学習の扱い。
`https://docs.typesafe.ai/models`

**[S12] TypeSafe HTTP API** — エンドポイント・認証・エラー。
`https://docs.typesafe.ai/api`

**[S13] Apps Script Web Apps** — doPost・Web App配備。
`https://developers.google.com/apps-script/guides/web`

**[S14] Apps Script Content Service** — JSON返答とリダイレクト。
`https://developers.google.com/apps-script/guides/content`

**[S15] UrlFetchApp** — 外部HTTP・timeoutSeconds。
`https://developers.google.com/apps-script/reference/url-fetch/url-fetch-app`

**[S16] Properties Service** — スクリプト設定と秘密の保管場所。
`https://developers.google.com/apps-script/guides/properties`

**[S17] LockService** — 同一スクリプト実行の排他。
`https://developers.google.com/apps-script/reference/lock/lock-service`

**[S18] Sheets batchUpdate** — 一括検証/更新と同時編集上の留意。
`https://developers.google.com/workspace/sheets/api/reference/rest/v4/spreadsheets/batchUpdate`

**[S19] Apps Script quotas** — 実際のアカウント上限の確認先。
`https://developers.google.com/apps-script/guides/services/quotas`

**[S20] ESP32-S3 Random Generation** — エントロピー源と本番乱数。
`https://docs.espressif.com/projects/esp-idf/en/stable/esp32s3/api-reference/system/random.html`

**[S21] ESP32-S3 NVS** — 保存・暗号化・実機区画。
`https://docs.espressif.com/projects/esp-idf/en/stable/esp32s3/api-reference/storage/nvs_flash.html`

**[S22] LVGL8 OS porting** — UI所有タスクと排他。
`https://raw.githubusercontent.com/lvgl/lvgl/v8.3.11/docs/porting/os.md`

**[S23] LVGL8 events** — クリックと押下継続の区別。
`https://raw.githubusercontent.com/lvgl/lvgl/v8.3.11/docs/overview/event.md`

### 既存設計書との接続

AI DUEL v1の本人認証・非公開Sheets・ContentService取扱い、JEV REVERSI v1の丸画面と再送原則、CAFE WEREWOLF v2の3〜10人対応を読み合わせた。既存資料の匿名前提を本カード集へ一律コピーしたり、私的手札のあるゲームへ公開盤面だけの復元を流用したりしない。実際のPCワークスペース・GASコードは未取得なので、継承箇所はエージェントが実物と照合する。

## Q7. エージェントへ渡す最終指示

> 本書をCAFE CARDSの正本として、COFFEE TIME第6メニューに4種類を実装してください。既存BSP、LCD/タッチ、コーヒー＋1、5つのゲーム、Google連携を保全してください。まずPC検査、次に端末AIで全ゲーム完走、次に保存・共通本人認証・Googleの再送と復旧、最後にJevへ進めてください。未来の札・相手の非公開手札をJevへ送らず、同時選択はAIを先に確定してください。本文の独自ルールを勝手に別流派へ変えないでください。全受入項目を記録し、書込み済み・実API接続済み・試遊済みを区別して報告してください。


---
# 付録 — 全ファイルと安全な取り出し方

次のPythonコードを、既存プロジェクトとは別の場所へ `extract_handoff.py` として保存します。その後、統合書のパスと、新しい空の取り出し先を指定します。

```bash
python extract_handoff.py COFFEE_TIME_CAFE_CARDS_Design_v1.0.md cafe_cards_source
cd cafe_cards_source
python tools/run_checks.py --full
```

取り出しコードはSHA-256・サイズ・パスを検査し、既存ファイルのあるフォルダーへの上書きを拒否します。既存ファームへ直接展開しないでください。ファイルの内容が編集されている場合は検査を止めます。

````python
#!/usr/bin/env python3
"""Extract full-text attachments from the master Markdown, verifying SHA-256.
Safe defaults: new/empty directory only; reject traversal, symlinks, duplicates,
unknown absolute paths, and changed/truncated code blocks. No network access.
"""
from __future__ import annotations
import argparse, hashlib, json, re
from pathlib import Path, PurePosixPath

MARKER=re.compile(r'^<!-- CAFE_CARDS_FILE (.+) -->$')

def extract(md: Path, destination: Path) -> dict:
    lines=md.read_text(encoding='utf8').splitlines(keepends=True)
    files=[]; seen=set(); i=0
    while i<len(lines):
        match=MARKER.fullmatch(lines[i].rstrip('\r\n'))
        if not match:i+=1;continue
        info=json.loads(match.group(1)); name=info['path']; pure=PurePosixPath(name)
        if pure.is_absolute() or '..' in pure.parts or '\\' in name or ':' in name or str(pure)!=name or name in seen:
            raise ValueError('Unsafe or duplicate path: '+name)
        seen.add(name);i+=1
        if i>=len(lines):raise ValueError('Missing opening fence')
        opening=re.fullmatch(r'(`{4,})[A-Za-z0-9_-]*\r?\n?',lines[i])
        if not opening:raise ValueError('Bad opening fence for '+name)
        fence=opening.group(1);i+=1;body=[]
        while i<len(lines) and lines[i].rstrip('\r\n')!=fence:
            body.append(lines[i]);i+=1
        if i>=len(lines):raise ValueError('Unclosed file '+name)
        i+=1
        data=''.join(body).encode('utf8')
        if hashlib.sha256(data).hexdigest()!=info['sha256'] or len(data)!=info['bytes']:
            raise ValueError('Content hash/length mismatch: '+name)
        files.append((name,data))
    if not files:raise ValueError('No embedded files found')
    if destination.exists() and (destination.is_symlink() or any(destination.iterdir())):
        raise ValueError('Destination must be a new or empty directory')
    destination.mkdir(parents=True,exist_ok=True);base=destination.resolve()
    for name,data in files:
        path=base/name
        if not path.resolve().is_relative_to(base):raise ValueError('Path escape')
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(data)
    return {'embedded_files_extracted':len(files),'sha256_verified':True,'destination':str(base)}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('markdown',type=Path);ap.add_argument('destination',type=Path)
    args=ap.parse_args();print(json.dumps(extract(args.markdown,args.destination),ensure_ascii=False,indent=2))
if __name__=='__main__':main()
````


## ファイル：`README.md`

<!-- CAFE_CARDS_FILE {"path":"README.md","bytes":1646,"sha256":"772d4343ce93545bef87deb18c858150accd8d69c9dca252cbb76992293fc5a7"} -->
`````markdown
# CAFE CARDS — コーディングエージェント引継ぎ v1.0.0

対象はCOFFEE TIMEの第6ゲーム。一つの入口からPOKER・GOPS・THIRTY-ONE・BACCARATの全4種類を遊ぶ。

## 読む順番

1. 統合設計書 `COFFEE_TIME_CAFE_CARDS_Design_v1.0.md`（このZIPのrootにある場合）。
2. 分割版なら `docs/00_COMMON.md` → `01_POKER.md` → `02_GOPS.md` → `03_THIRTY_ONE.md` → `04_BACCARAT.md` → `05_IMPLEMENTATION.md` → `06_TESTS_SOURCES.md`。
3. `data/rules.json`・`api_contract.json`・`acceptance.json` を合わせて読む。

## 最初の実行

```bash
python tools/run_checks.py --full
python tools/run_checks.py --full --sanitize
```

必要環境：Python3.10以上、Node18以上、C++17対応g++など。ESP32・Google・Jevが未接続でもPC検査はできる。

## 渡し方

統合Markdownはコード・データ・分割文書を埋め込んでおり、1ファイルだけでも取り出せる。統合書の取り出し説明を参照。

同梱のルールコードと検査は参考実装。既存BSPに接続するUI/保存/GASサービス全体が書込み済みという意味ではない。実装担当は実機と実サービスの受入124項目を別途記録する。

## 必ず守ること

- 既存LCD/GT911/コーヒー＋1/5つのゲーム/Google連携を保全。
- 第6入口一つ、4種類全部を仕上げる。
- 非公開手札・未来デッキをJevに送らず、金銭・課金・換金・景品を追加しない。
- ローカルAIをJevの実績にしない。
- ルール変更時は文章・JSON・コード・テスト・版を同時に更新する。
`````

## ファイル：`core/cards_core.hpp`

<!-- CAFE_CARDS_FILE {"path":"core/cards_core.hpp","bytes":12388,"sha256":"b53af1f275168095248877839b37708dac52a99a33fe2a80231e2ddbc4cd044d"} -->
`````cpp
#pragma once
// CAFE CARDS v1.0.0 -- portable rules reference, no network/UI/RNG seeding.
// Card identity: copy*52 + suit*13 + (rank-2); suits C,D,H,S; ranks 2..14(A).
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstddef>
#include <functional>

namespace cafe_cards {
using Card = uint16_t;
using Rng32 = uint32_t (*)(void*);
constexpr int H = 0, AI = 1, DRAW = 2, NONE = -1;
inline int rank(Card c) { return int(c % 13) + 2; }
inline int suit(Card c) { return int((c % 52) / 13); }
inline int baccarat_value(Card c) { int r=rank(c); return r==14?1:(r>=10?0:r); }
inline int value31(Card c) { int r=rank(c); return r==14?11:(r>=10?10:r); }
inline bool valid_cards(const Card* p, int n, int copies=1) {
    if (!p || n<0 || n>416 || copies<1 || copies>8) return false;
    std::array<bool,416> seen{};
    for (int i=0;i<n;++i) { if (p[i]>=52*copies || seen[p[i]]) return false; seen[p[i]]=true; }
    return true;
}
// Caller supplies a correctly seeded source; tests use deterministic generators.
inline uint32_t uniform(Rng32 rng, void* ctx, uint32_t bound) {
    if (!rng || !bound) return 0; // Production adapter must reject invalid configuration.
    uint32_t threshold=uint32_t(-bound)%bound;
    uint32_t x;
    do { x=rng(ctx); } while (x<threshold);
    return x%bound;
}
struct Deck {
    std::array<Card,416> cards{};
    int size=0, cursor=0;
    bool init(int copies, Rng32 rng, void* ctx) {
        if ((copies!=1 && copies!=8) || !rng) return false;
        size=52*copies; cursor=0;
        for (int i=0;i<size;++i) cards[i]=Card(i);
        for (int i=size-1;i>0;--i) std::swap(cards[i],cards[uniform(rng,ctx,uint32_t(i+1))]);
        return true;
    }
    bool take(Card& out) { if (cursor<0 || cursor>=size) return false; out=cards[cursor++]; return true; }
    bool valid() const { return (size==52 || size==416) && cursor>=0 && cursor<=size && valid_cards(cards.data(),size,size/52); }
};

struct PokerValue {
    // category: high, pair, two_pair, trips, straight, flush, full, quads, straight_flush
    std::array<int,6> key{};
    bool valid=false;
};
inline PokerValue poker_value(const std::array<Card,5>& h) {
    PokerValue out;
    if (!valid_cards(h.data(),5)) return out;
    out.valid=true;
    std::array<int,15> count{};
    std::array<int,5> ranks{};
    bool flush=true;
    for (int i=0;i<5;++i) { ++count[rank(h[i])]; ranks[i]=rank(h[i]); flush=flush && suit(h[i])==suit(h[0]); }
    std::sort(ranks.begin(),ranks.end(),std::greater<int>());
    int straight=0, distinct=0;
    for(int r=2;r<=14;++r) if(count[r]) ++distinct;
    if (distinct==5 && ranks[0]-ranks[4]==4) straight=ranks[0];
    if (ranks==std::array<int,5>{14,5,4,3,2}) straight=5;
    int four=0,three=0,np=0; std::array<int,2> pair{}; std::array<int,5> singles{}; int ns=0;
    for(int r=14;r>=2;--r) {
        if(count[r]==4) four=r;
        else if(count[r]==3) three=r;
        else if(count[r]==2) pair[np++]=r;
        else if(count[r]==1) singles[ns++]=r;
    }
    auto& k=out.key;
    if(straight && flush) k={8,straight,0,0,0,0};
    else if(four) k={7,four,singles[0],0,0,0};
    else if(three && np==1) k={6,three,pair[0],0,0,0};
    else if(flush) k={5,ranks[0],ranks[1],ranks[2],ranks[3],ranks[4]};
    else if(straight) k={4,straight,0,0,0,0};
    else if(three) k={3,three,singles[0],singles[1],0,0};
    else if(np==2) k={2,pair[0],pair[1],singles[0],0,0};
    else if(np==1) k={1,pair[0],singles[0],singles[1],singles[2],0};
    else k={0,ranks[0],ranks[1],ranks[2],ranks[3],ranks[4]};
    return out;
}
inline int poker_compare(const std::array<Card,5>& a,const std::array<Card,5>& b) {
    auto x=poker_value(a),y=poker_value(b);
    if(!x.valid || !y.valid) return -2;
    return x.key>y.key?1:(x.key<y.key?-1:0);
}
enum class BetAction : uint8_t { Check,Bet,Call,Raise,Fold };
struct Street {
    std::array<int,2> paid{};
    int actor=0,unit=2,raises=0,checks=0;
    bool closed=false; int fold_winner=NONE;
    bool legal(BetAction a) const {
        if(closed || actor<0 || actor>1) return false;
        int owed=paid[1-actor]-paid[actor];
        if(owed>0) return a==BetAction::Call || a==BetAction::Fold || (a==BetAction::Raise && raises<2);
        return a==BetAction::Check || (a==BetAction::Bet && paid[0]==0 && paid[1]==0);
    }
    // Return debit through output parameter. Rejected action does not mutate state.
    bool apply(int who,BetAction a,int& debit) {
        debit=0;
        if(who!=actor || !legal(a)) return false;
        int target=std::max(paid[0],paid[1]);
        if(a==BetAction::Fold) { closed=true;fold_winner=1-who;return true; }
        if(a==BetAction::Check) { if(++checks==2) closed=true; else actor=1-who;return true; }
        if(a==BetAction::Bet || a==BetAction::Raise) {
            target+=unit; if(a==BetAction::Raise) ++raises;
            debit=target-paid[who]; paid[who]=target;checks=0;actor=1-who;return true;
        }
        debit=target-paid[who];paid[who]=target;closed=true;return true; // call
    }
};
enum class PokerPhase : uint8_t { Pre,Draw,Post,Finished };
struct PokerHand {
    Deck deck;
    std::array<std::array<Card,5>,2> hands{};
    std::array<Card,10> discards{}; int discard_count=0;
    std::array<int,2> stack{100,100}, draw_masks{-1,-1};
    int pot=0,dealer=0,winner=NONE; bool folded=false;
    PokerPhase phase=PokerPhase::Finished; Street street;
    bool start(const Deck& d,int dl,std::array<int,2> before) {
        if(dl<0 || dl>1 || d.size!=52 || d.cursor!=0 || !d.valid() || before[0]<19 || before[1]<19 || before[0]+before[1]!=200) return false;
        deck=d;dealer=dl;stack=before;pot=2;--stack[0];--stack[1];winner=NONE;folded=false;
        draw_masks={-1,-1};discard_count=0;
        int first=1-dealer;
        for(int k=0;k<5;++k) for(int x=0;x<2;++x) { int who=x?dealer:first; deck.take(hands[who][k]); }
        phase=PokerPhase::Pre;street=Street{};street.actor=first;street.unit=2;
        return true;
    }
    void award(int w) {
        winner=w;
        if(w==DRAW) { stack[0]+=pot/2;stack[1]+=pot/2; }
        else stack[w]+=pot;
        pot=0;phase=PokerPhase::Finished;
    }
    bool bet(int who,BetAction a) {
        if(phase!=PokerPhase::Pre && phase!=PokerPhase::Post) return false;
        Street next=street; int debit=0;
        if(!next.apply(who,a,debit) || debit>stack[who]) return false;
        street=next;stack[who]-=debit;pot+=debit;
        if(street.closed) {
            if(street.fold_winner!=NONE) {folded=true;award(street.fold_winner);}
            else if(phase==PokerPhase::Pre) phase=PokerPhase::Draw;
            else {int cmp=poker_compare(hands[0],hands[1]);award(cmp>0?0:(cmp<0?1:DRAW));}
        }
        return true;
    }
    bool draw(int who,int mask) {
        if(phase!=PokerPhase::Draw || who<0 || who>1 || mask<0 || mask>31 || draw_masks[who]!=-1) return false;
        draw_masks[who]=mask;
        if(draw_masks[0]<0 || draw_masks[1]<0) return true;
        // Both choices sealed. No discard recycling; replace fixed slots in nondealer/dealer order.
        for(int x=0;x<2;++x) { int p=x?dealer:1-dealer;
            for(int i=0;i<5;++i) if(draw_masks[p]&(1<<i)) {
                discards[discard_count++]=hands[p][i];deck.take(hands[p][i]);
            }
        }
        phase=PokerPhase::Post;street=Street{};street.actor=1-dealer;street.unit=4;return true;
    }
};

struct Gops {
    int n=0,index=0,burned=0; std::array<int,13> prizes{};
    std::array<uint16_t,2> remaining{};std::array<int,2> sealed{-1,-1},score{};
    bool init(int count,const std::array<int,13>& order) {
        if(count!=7 && count!=13) return false;
        uint16_t bits=0;
        for(int i=0;i<count;++i) {int p=order[i];if(p<1 || p>count || (bits&(1u<<(p-1)))) return false;bits|=uint16_t(1u<<(p-1));}
        n=count;index=burned=0;prizes=order;remaining={bits,bits};sealed={-1,-1};score={0,0};return true;
    }
    bool done() const {return n>0 && index==n;}
    bool choose(int who,int value) {
        if(n==0 || done() || who<0 || who>1 || value<1 || value>n || sealed[who]!=-1 || !(remaining[who]&(1u<<(value-1)))) return false;
        sealed[who]=value;
        if(sealed[0]<0 || sealed[1]<0) return true;
        if(sealed[0]==sealed[1]) burned+=prizes[index]; else score[sealed[0]>sealed[1]?0:1]+=prizes[index];
        for(int i=0;i<2;++i) remaining[i]&=uint16_t(~(1u<<(sealed[i]-1)));
        ++index;sealed={-1,-1};return true;
    }
    int winner() const {return !done()?NONE:(score[0]>score[1]?H:(score[0]<score[1]?AI:DRAW));}
};
inline int score31(const std::array<Card,3>& h) {
    if(!valid_cards(h.data(),3)) return -1;
    std::array<int,4> sums{};for(auto c:h) sums[suit(c)]+=value31(c);
    return *std::max_element(sums.begin(),sums.end());
}
struct ThirtyOne {
    std::array<std::array<Card,3>,2> hands{};std::array<Card,3> market{};
    std::array<uint64_t,2> publicly_known{};
    int actor=0,turns=0,knocker=NONE,winner=NONE;bool finished=false;
    enum End { None,Natural,Knocked,Limit } end=None;
    bool init(const std::array<Card,9>& deal,int first) {
        if(!valid_cards(deal.data(),9) || first<0 || first>1) return false;
        for(int k=0;k<3;++k) {hands[first][k]=deal[2*k];hands[1-first][k]=deal[2*k+1];market[k]=deal[6+k];}
        actor=first;turns=0;knocker=NONE;winner=NONE;finished=false;end=None;publicly_known={0,0};
        if(score31(hands[0])==31 || score31(hands[1])==31) finish(Natural);
        return true;
    }
    void finish(End why) {finished=true;end=why;int a=score31(hands[0]),b=score31(hands[1]);winner=a>b?H:(a<b?AI:DRAW);}
    bool swap(int who,int hi,int mi) {
        if(finished || who!=actor || hi<0 || hi>2 || mi<0 || mi>2) return false;
        Card out=hands[who][hi],in=market[mi];
        std::swap(hands[who][hi],market[mi]);
        publicly_known[who]&=~(uint64_t(1)<<out);publicly_known[who]|=(uint64_t(1)<<in);++turns;
        if(score31(hands[who])==31) finish(Natural);
        else if(knocker!=NONE) finish(Knocked);
        else if(turns>=20) finish(Limit);
        else actor=1-who;
        return true;
    }
    bool knock(int who) {
        if(finished || who!=actor || knocker!=NONE) return false;
        knocker=who;++turns;actor=1-who;return true; // exactly one final reply, even on turn 20
    }
    bool stand(int who) {
        if(finished || who!=actor || knocker==NONE || who==knocker) return false;
        ++turns;finish(Knocked);return true;
    }
};
inline bool banker_draws(int total,int player_third) {
    if(total<0 || total>9 || player_third<-1 || player_third>9) return false;
    if(player_third<0) return total<=5;
    if(total<=2) return true;
    if(total==3) return player_third!=8;
    if(total==4) return player_third>=2 && player_third<=7;
    if(total==5) return player_third>=4 && player_third<=7;
    if(total==6) return player_third==6 || player_third==7;
    return false;
}
struct BaccaratResult {
    std::array<int,3> p{-1,-1,-1},b{-1,-1,-1};
    int np=0,nb=0,used=0,pt=0,bt=0,winner=NONE;bool natural=false,valid=false;
};
inline BaccaratResult baccarat_from_values(const std::array<int,6>& v) {
    BaccaratResult r;
    for(auto x:v) if(x<0 || x>9) return r;
    r.valid=true;r.p[0]=v[0];r.b[0]=v[1];r.p[1]=v[2];r.b[1]=v[3];r.np=r.nb=2;r.used=4;
    r.pt=(v[0]+v[2])%10;r.bt=(v[1]+v[3])%10;r.natural=r.pt>=8 || r.bt>=8;
    if(!r.natural) {
        int third=-1;
        if(r.pt<=5) {third=v[r.used++];r.p[r.np++]=third;r.pt=(r.pt+third)%10;}
        if(banker_draws(r.bt,third)) {int x=v[r.used++];r.b[r.nb++]=x;r.bt=(r.bt+x)%10;}
    }
    r.winner=r.pt>r.bt?0:(r.pt<r.bt?1:DRAW);return r;
}
inline BaccaratResult baccarat_from_cards(const std::array<Card,6>& c) {
    if(!valid_cards(c.data(),6,8)) return {};
    std::array<int,6> v{};for(int i=0;i<6;++i) v[i]=baccarat_value(c[i]);return baccarat_from_values(v);
}
// Independent match aggregation: P/B are table sides, not the human/AI actors.
struct BaccaratPredictions {
    std::array<int,2> guess{-1,-1};
    bool choose(int who,int outcome) {if(who<0 || who>1 || outcome<0 || outcome>2 || guess[who]!=-1) return false;guess[who]=outcome;return true;}
    bool ready() const {return guess[0]>=0 && guess[1]>=0;}
    std::array<int,2> points(int outcome) const {if(!ready() || outcome<0 || outcome>2) return {0,0};return {int(guess[0]==outcome),int(guess[1]==outcome)};}
};
} // namespace cafe_cards
`````

## ファイル：`data/acceptance.json`

<!-- CAFE_CARDS_FILE {"path":"data/acceptance.json","bytes":26669,"sha256":"4b51a20ccaee234770b1ea20115d62980c8431858edf916e29fe91d002442d79"} -->
`````json
[
  {
    "id": "BASE-01",
    "title": "原本保全",
    "expected": "変更前のBSP・LVGL・Google設定・ゲーム登録のバックアップが存在する",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "BASE-02",
    "title": "型番",
    "expected": "実機が2.8Cであることと480×480を確認する",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "BASE-03",
    "title": "既存カウンター",
    "expected": "4本を追加後も+1を2回押すと2だけ増える",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "BASE-04",
    "title": "既存5ゲーム",
    "expected": "人狼3〜10人v2を含む既存5本の起動と終了を確認する",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "BASE-05",
    "title": "入口一つ",
    "expected": "第6メニューCAFE CARDSだけから4種類へ分岐する",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "BASE-06",
    "title": "全ゲーム完走",
    "expected": "端末AIでP5ハンド・G7/13・31は3ハンド・B5回を終了する",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "BASE-07",
    "title": "文言",
    "expected": "全119文言キーと22ページの文字に欠けがない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "BASE-08",
    "title": "依存固定",
    "expected": "使用core・LVGL・コンパイラ・BSP・ライブラリ版を記録する",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "BASE-09",
    "title": "練習",
    "expected": "固定練習が課金や正式戦績・本番乱数に影響しない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "BASE-10",
    "title": "禁止機能",
    "expected": "課金・換金・景品・共通財布・人事連携がない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "SEC-01",
    "title": "相手手札隔離",
    "expected": "人間の未知手札を変えてもAI要求の意味が変わらない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "SEC-02",
    "title": "未来札隔離",
    "expected": "山札未来部分を変えても同じ公開状態のAI要求が一致する",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "SEC-03",
    "title": "GOPS未公開札",
    "expected": "人間の仮選択をJev要求に含めない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "SEC-04",
    "title": "交換未公開",
    "expected": "ポーカーの人間maskをAI交換決定前に送らない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "SEC-05",
    "title": "バカラ未公開",
    "expected": "人間予想・勝敗・未来6枚を送らない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "SEC-06",
    "title": "私的捨て札",
    "expected": "ポーカーの相手捨て札が公開履歴・統計から漏れない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "SEC-07",
    "title": "31公開既知",
    "expected": "正当に公開された取得札だけを既知集合へ追加する",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "SEC-08",
    "title": "ネスト未知キー",
    "expected": "余分なroot・nested keyをGASで拒否する",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "SEC-09",
    "title": "API鍵",
    "expected": "Jev鍵が端末Flash・ソース・ログに存在しない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "SEC-10",
    "title": "本人認証",
    "expected": "別人token/他deviceでprivate試合と統計を取得できない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "SEC-11",
    "title": "PIN",
    "expected": "生PINとplayer_tokenがsnapshotへ書かれない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "SEC-12",
    "title": "画面退避",
    "expected": "カフェ復帰・ログアウト・エラーで手札が残像を含め消える",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "SEC-13",
    "title": "ログ",
    "expected": "例外・シリアルに山札・token・非公開手札を出さない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "SEC-14",
    "title": "モデル文言",
    "expected": "confidence・行動確率を実勝率と表示しない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "SEC-15",
    "title": "役判定分離",
    "expected": "Jev応答で役の強さや点数規則を書き換えられない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "SEC-16",
    "title": "共有Workbook",
    "expected": "一般公開カフェシートにprivate記録を入れない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "P-01",
    "title": "配布順",
    "expected": "非dealer→dealerへ交互に5枚、初期cursor=10",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "P-02",
    "title": "先手交代",
    "expected": "初回dealerを記録し5ハンドで交互にする",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "P-03",
    "title": "CHECK2回",
    "expected": "両CHECKで一度だけ次段階へ進む",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "P-04",
    "title": "CHECK後BET",
    "expected": "相手BETへのFOLD/CALL/RAISEが表示される",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "P-05",
    "title": "額一致",
    "expected": "CALLは不足額だけを支払う",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "P-06",
    "title": "RAISE",
    "expected": "不足額+unitを払い、回数を1だけ増やす",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "P-07",
    "title": "上限",
    "expected": "2回上乗せ後のRAISE拒否、CALL/FOLDは可能",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "P-08",
    "title": "段階初期化",
    "expected": "交換後unit=4、paid/raises/checksが0",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "P-09",
    "title": "無料FOLD禁止",
    "expected": "owed=0でFOLDできない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "P-10",
    "title": "残点保証",
    "expected": "最悪5連敗でも最後に5点以上、補充なし",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "P-11",
    "title": "総点",
    "expected": "各確定状態でstacks+pot=200",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "P-12",
    "title": "交換0",
    "expected": "双方0枚でも正しく交換後へ進む",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "P-13",
    "title": "交換5",
    "expected": "双方5枚を交換しても重複・枯渇しない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "P-14",
    "title": "交換順",
    "expected": "双方mask固定後、非dealer固定slot昇順から引く",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "P-15",
    "title": "ホイール",
    "expected": "A2345は5-high、QKA23はストレートではない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "P-16",
    "title": "同役比較",
    "expected": "全カテゴリのキッカー比較とスート同点を確認する",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "P-17",
    "title": "フォールド",
    "expected": "一度だけpot授与、未公開札と内訳を見せない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "P-18",
    "title": "同役分配",
    "expected": "偶数potを半分ずつ分ける",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "P-19",
    "title": "試合勝敗",
    "expected": "ハンド勝利数でなく5ハンド後の持ち点で決める",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "P-20",
    "title": "再戦",
    "expected": "新matchId・新配布、持ち点100へ戻る",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "G-01",
    "title": "7枚",
    "expected": "7回で終了し総得点+破棄=28",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "G-02",
    "title": "13枚",
    "expected": "13回で終了し総得点+破棄=91",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "G-03",
    "title": "場の点",
    "expected": "勝ち札の数字でなく得点札の数字を加える",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "G-04",
    "title": "同点",
    "expected": "得点破棄・双方消費・持越しなし",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "G-05",
    "title": "両方消費",
    "expected": "負けた側の札も残札から消える",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "G-06",
    "title": "重複札",
    "expected": "使った札を再度出す操作を拒否する",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "G-07",
    "title": "公開残札",
    "expected": "両者の残札が実状態と一致する",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "G-08",
    "title": "秘密確定順",
    "expected": "AI札保存より前に人間Confirmできない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "G-09",
    "title": "最終一枚",
    "expected": "強制処理でJevを呼ばずforced記録になる",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "G-10",
    "title": "ページ",
    "expected": "13枚目を選べて表示切替でドラフトを保つ",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "G-11",
    "title": "引分け",
    "expected": "最終同点で追加回を勝手に作らない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "G-12",
    "title": "得点順",
    "expected": "未来得点が見えず、復旧で順番が変わらない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "T-01",
    "title": "配布",
    "expected": "初期9物理札が相異なり場3枚",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "T-02",
    "title": "同スート",
    "expected": "別スートの得点を足さない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "T-03",
    "title": "Aと絵札",
    "expected": "A11、JQK10",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "T-04",
    "title": "3枚組",
    "expected": "777は7点で特典なし",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "T-05",
    "title": "点数同点",
    "expected": "別スートの余り札・キッカーで差をつけない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "T-06",
    "title": "単交換",
    "expected": "一ターン一対一交換だけ",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "T-07",
    "title": "通常STAND禁止",
    "expected": "通常でパスボタンが出ない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "T-08",
    "title": "ノック",
    "expected": "交換せず相手へ最終応答権を渡す",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "T-09",
    "title": "最終応答",
    "expected": "交換/STANDの後ただちに比べる",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "T-10",
    "title": "再ノック禁止",
    "expected": "最終応答でKNOCKを拒否する",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "T-11",
    "title": "初期31",
    "expected": "片側/両側31で正しく即終了",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "T-12",
    "title": "交換後31",
    "expected": "相手追加ターンなしで終了",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "T-13",
    "title": "20手交換",
    "expected": "20番目SWAP後に比べる",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "T-14",
    "title": "20手ノック",
    "expected": "21番目の最終応答を一度許す",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "T-15",
    "title": "既知削除",
    "expected": "公開取得札を場へ戻すと既知集合から消える",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "T-16",
    "title": "3ハンド",
    "expected": "先手交代し勝ち数で試合を比べる",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "B-01",
    "title": "新山",
    "expected": "5ラウンドそれぞれ416枚から開始する",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "B-02",
    "title": "非復元",
    "expected": "同じ物理IDを同一回で二度引かない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "B-03",
    "title": "見た目重複",
    "expected": "copy違いの同じカード表示は許される",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "B-04",
    "title": "配布順",
    "expected": "P1B1P2B2の順である",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "B-05",
    "title": "OPEN",
    "expected": "1枚ずつだけ表示、2枚合計結果はまだ不明",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "B-06",
    "title": "CLASSIC",
    "expected": "一枚も予想前に公開しない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "B-07",
    "title": "ナチュラル",
    "expected": "どちらか8/9で両方止める",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "B-08",
    "title": "P停止B5",
    "expected": "P6/7のときB5は引く",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "B-09",
    "title": "B3境界",
    "expected": "P3=8のみ止める",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "B-10",
    "title": "B4B5B6境界",
    "expected": "追加表80セルと停止分岐を照合する",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "B-11",
    "title": "5枚目行先",
    "expected": "P停止時は次札がB3、6枚目を飛ばさない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "B-12",
    "title": "予想同一",
    "expected": "人間AIが同じ予想でも変更せず両者加点可能",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "B-13",
    "title": "TIE得点",
    "expected": "TIEを当てても1点、倍率や手数料なし",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "B-14",
    "title": "表とJev",
    "expected": "計算値の表示とJev予測を別の出所にする",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "NET-01",
    "title": "認証",
    "expected": "device/本人/guestの所有権と期限を確認する",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "NET-02",
    "title": "型検査",
    "expected": "未知action・variant・範囲外を拒否する",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "NET-03",
    "title": "モデル固定",
    "expected": "使用モデルと要求/応答の実版を記録する",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "NET-04",
    "title": "API不正",
    "expected": "合計不正・候補漏れ・不正数値・非合法返答を拒否する",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "NET-05",
    "title": "同一再送",
    "expected": "同ID同要求のJev呼出し枠が一回だけ",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "NET-06",
    "title": "別内容再送",
    "expected": "同ID別観測をconflictにする",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "NET-07",
    "title": "並行要求",
    "expected": "複数HTTP要求で同決定が二重予約されない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "NET-08",
    "title": "lease",
    "expected": "遅延・クラッシュ後の不明jobを再度推論しない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "NET-09",
    "title": "旧返答",
    "expected": "他match/revisionの返答を適用しない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "NET-10",
    "title": "pause返答",
    "expected": "pause中readyは保存だけ、勝手に画面復帰しない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "NET-11",
    "title": "途中local",
    "expected": "本人選択後は残り試合local、後着Jevを無視",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "NET-12",
    "title": "リダイレクト",
    "expected": "302/303は本文なしGET、未知ホストは拒否",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "NET-13",
    "title": "HTML200",
    "expected": "Googleログイン画面をJSON成功と扱わない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "NET-14",
    "title": "quota",
    "expected": "上限・429・キー障害でカフェ本体まで停止しない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "REC-01",
    "title": "A/B書込み",
    "expected": "古い有効snapshotを残して新slotへ書く",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "REC-02",
    "title": "書込み中電断",
    "expected": "途中切断時にCRC有効世代だけ復元する",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "REC-03",
    "title": "両方破損",
    "expected": "再抽選による再開をせず無効を表示する",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "REC-04",
    "title": "カード再生",
    "expected": "deck順列/cursor/手札/イベント整合を照合する",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "REC-05",
    "title": "本人再開",
    "expected": "再認証するまで私的手札を表示しない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "REC-06",
    "title": "ゲスト電断",
    "expected": "旧guestのprivate試合を別guestへ渡さない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "REC-07",
    "title": "24h期限",
    "expected": "期限超過の試合を勝敗に混ぜない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "REC-08",
    "title": "結果再送",
    "expected": "finishの応答消失で成績を二重加算しない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "REC-09",
    "title": "別結果",
    "expected": "同matchの結果改変をconflictにする",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "REC-10",
    "title": "Google不明書込",
    "expected": "barrierを残し盲目的なappend再送をしない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "REC-11",
    "title": "退会",
    "expected": "private snapshot・各ゲーム記録の削除範囲を確認する",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "REC-12",
    "title": "区画不足",
    "expected": "保存区画を無断消去・拡張しない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "PLAY-01",
    "title": "文字",
    "expected": "日本語と数字・マークを実機で複数人が読める",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "PLAY-02",
    "title": "タッチ",
    "expected": "選択後確認で誤交換・誤入札を防げる",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "PLAY-03",
    "title": "4種の違い",
    "expected": "各テーブルで異なる判断を楽しめる",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "PLAY-04",
    "title": "ポーカー",
    "expected": "用語を知らない人が金額と降りる意味を理解する",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "PLAY-05",
    "title": "GOPS",
    "expected": "小さい札を残す/使う選択に理由を持てる",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "PLAY-06",
    "title": "31",
    "expected": "ノック後の最後の一手を誤解しない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "PLAY-07",
    "title": "バカラ",
    "expected": "二つの手札と人間AIを混同しない",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "PLAY-08",
    "title": "AIの役割",
    "expected": "同じ手ばかり等がないか実Jev各20試合を観察する",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "PLAY-09",
    "title": "電池",
    "expected": "実電池条件の平均電流・温度・連続時間を測定する",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  },
  {
    "id": "PLAY-10",
    "title": "中断性",
    "expected": "いつでも一時停止してコーヒー+1へ戻れる",
    "status": "not_run_on_target",
    "evidence": "",
    "tester": "",
    "date": ""
  }
]
`````

## ファイル：`data/api_contract.json`

<!-- CAFE_CARDS_FILE {"path":"data/api_contract.json","bytes":4623,"sha256":"9461acf08fc2f221370a9286bcfe20dac3ec851a3a75fb6cb1ed89b8c3a9ff65"} -->
`````json
{
  "namespace": "cafe_cards",
  "api_version": 1,
  "method": "POST",
  "envelope": [
    "namespace",
    "api_version",
    "action",
    "request_id",
    "device_id",
    "device_token",
    "player_token",
    "created_at_ms",
    "sent_at_ms",
    "payload"
  ],
  "actions": {
    "hello": {
      "auth": "device",
      "payload": {},
      "returns": [
        "capabilities",
        "server_time_ms",
        "rules_version",
        "model",
        "maintenance"
      ]
    },
    "profile.get": {
      "auth": "player",
      "payload": {
        "game": "enum:poker|gops|thirty_one|baccarat",
        "variant": "registered_variant"
      },
      "returns": [
        "stats",
        "last_completed_at_ms"
      ]
    },
    "match.open": {
      "auth": "player_or_guest",
      "payload": {
        "match_id": "hex32",
        "game": "game_enum",
        "variant": "registered_variant",
        "opponent": "jev|local",
        "rules_version": "1.0.0",
        "first_actor": "0|1|null"
      },
      "returns": [
        "match_id",
        "status",
        "created_month",
        "expires_at_ms",
        "profile_snapshot_version"
      ]
    },
    "decision.prepare": {
      "auth": "player_or_guest",
      "payload": {
        "match_id": "hex32",
        "decision_id": "hex32",
        "decision_seq": "int:1..40",
        "revision": "int:0..192",
        "phase": "game_phase_enum",
        "observation": "strict_allowlisted_view",
        "legal_ids": "ASCII_sorted_unique_list"
      },
      "returns": [
        "decision_id",
        "status",
        "observation_hash",
        "result_or_null",
        "lease_until_ms"
      ]
    },
    "decision.get": {
      "auth": "player_or_guest",
      "payload": {
        "match_id": "hex32",
        "decision_id": "hex32"
      },
      "returns": [
        "decision_id",
        "status",
        "observation_hash",
        "result_or_null",
        "lease_until_ms"
      ]
    },
    "match.finish": {
      "auth": "player_or_guest",
      "payload": {
        "match_id": "hex32",
        "result": "strict_match_summary",
        "public_events": "bounded_array",
        "public_events_hash": "sha256hex",
        "provider_counts": "jev/local/forced",
        "rules_version": "1.0.0"
      },
      "returns": [
        "record_id",
        "status",
        "stats_version",
        "validation_level"
      ]
    },
    "match.abort": {
      "auth": "player_or_guest",
      "payload": {
        "match_id": "hex32",
        "reason": "user|expired|corrupt|guest_restart|fault"
      },
      "returns": [
        "match_id",
        "status"
      ]
    }
  },
  "errors": [
    "AUTH_FAILED",
    "AUTH_EXPIRED",
    "FORBIDDEN",
    "BAD_REQUEST",
    "VERSION_MISMATCH",
    "MATCH_ACTIVE",
    "MATCH_EXPIRED",
    "MATCH_TERMINAL",
    "DECISION_NOT_FOUND",
    "IDEMPOTENCY_CONFLICT",
    "ILLEGAL_ACTION",
    "PROVIDER_UNAVAILABLE",
    "PROVIDER_INVALID",
    "RATE_LIMITED",
    "PENDING",
    "STORAGE_UNCERTAIN",
    "MAINTENANCE",
    "RESULT_CONFLICT",
    "REPLAY_TOO_OLD"
  ],
  "sheets": {
    "CardsMeta": [
      "key",
      "value_json",
      "updated_at_ms"
    ],
    "CardsMatches_YYYYMM": [
      "match_id",
      "device_id",
      "player_id",
      "is_guest",
      "game",
      "variant",
      "rules_version",
      "opponent_requested",
      "status",
      "created_at_ms",
      "expires_at_ms",
      "completed_at_ms",
      "human_score",
      "opponent_score",
      "winner",
      "end_reason",
      "provider_counts_json",
      "public_events_json",
      "public_events_hash",
      "result_hash",
      "validation_level",
      "stats_applied_version"
    ],
    "CardsDecisions_YYYYMMDD": [
      "job_key",
      "match_id",
      "decision_id",
      "decision_seq",
      "revision",
      "phase",
      "request_hash",
      "observation_hash",
      "status",
      "generation",
      "call_reserved",
      "lease_until_ms",
      "result_json",
      "failure_code",
      "model",
      "input_tokens",
      "latency_ms",
      "created_at_ms",
      "finished_at_ms"
    ],
    "CardsProfiles": [
      "profile_key",
      "player_id",
      "game",
      "variant",
      "rules_version",
      "stats_version",
      "stats_json",
      "history_start_ms",
      "last_match_id",
      "updated_at_ms"
    ],
    "CardsReceipts_YYYYMMDD": [
      "request_key",
      "fingerprint",
      "actor_id",
      "action",
      "resource_ref",
      "status",
      "safe_response_json",
      "created_at_ms",
      "expires_at_ms"
    ]
  }
}
`````

## ファイル：`data/baccarat_probabilities.json`

<!-- CAFE_CARDS_FILE {"path":"data/baccarat_probabilities.json","bytes":16591,"sha256":"fe3b72d2adfcb8cabb5ad18d3a1f5b78a3c62d9d3add255c1e25cbbdd6aaee98"} -->
`````json
{
  "rules": "fresh8_v1",
  "order": [
    "PLAYER",
    "BANKER",
    "TIE"
  ],
  "method": "enumerate_all_1000000_six_value_streams_without_replacement",
  "classic": [
    0.44624660934217,
    0.45859742263134,
    0.095155968023625
  ],
  "open": [
    {
      "p_first": 0,
      "b_first": 0,
      "probabilities": [
        0.45045709872374,
        0.46014304826574,
        0.08939985301053
      ]
    },
    {
      "p_first": 0,
      "b_first": 1,
      "probabilities": [
        0.44691024199569,
        0.46505979944543,
        0.088029958558902
      ]
    },
    {
      "p_first": 0,
      "b_first": 2,
      "probabilities": [
        0.44316149462705,
        0.46884407507729,
        0.087994430295684
      ]
    },
    {
      "p_first": 0,
      "b_first": 3,
      "probabilities": [
        0.44012526660487,
        0.47189090603962,
        0.087983827355534
      ]
    },
    {
      "p_first": 0,
      "b_first": 4,
      "probabilities": [
        0.43379756632188,
        0.47860803655345,
        0.087594397124698
      ]
    },
    {
      "p_first": 0,
      "b_first": 5,
      "probabilities": [
        0.42061060485727,
        0.49263616874796,
        0.086753226394793
      ]
    },
    {
      "p_first": 0,
      "b_first": 6,
      "probabilities": [
        0.40213626518696,
        0.50138186817818,
        0.09648186663488
      ]
    },
    {
      "p_first": 0,
      "b_first": 7,
      "probabilities": [
        0.37112858303395,
        0.53016914592479,
        0.098702271041274
      ]
    },
    {
      "p_first": 0,
      "b_first": 8,
      "probabilities": [
        0.32835300727212,
        0.58505952047755,
        0.086587472250346
      ]
    },
    {
      "p_first": 0,
      "b_first": 9,
      "probabilities": [
        0.31101648330346,
        0.60232756536292,
        0.086655951333639
      ]
    },
    {
      "p_first": 1,
      "b_first": 0,
      "probabilities": [
        0.4527013640974,
        0.45820649666689,
        0.089092139235736
      ]
    },
    {
      "p_first": 1,
      "b_first": 1,
      "probabilities": [
        0.44769622828083,
        0.46175019459027,
        0.090553577128935
      ]
    },
    {
      "p_first": 1,
      "b_first": 2,
      "probabilities": [
        0.44399495375097,
        0.46700155656485,
        0.089003489684216
      ]
    },
    {
      "p_first": 1,
      "b_first": 3,
      "probabilities": [
        0.44070824760473,
        0.4703243355172,
        0.088967416878109
      ]
    },
    {
      "p_first": 1,
      "b_first": 4,
      "probabilities": [
        0.43237018484422,
        0.47887120101403,
        0.088758614141793
      ]
    },
    {
      "p_first": 1,
      "b_first": 5,
      "probabilities": [
        0.4184913096245,
        0.49391308417635,
        0.087595606199187
      ]
    },
    {
      "p_first": 1,
      "b_first": 6,
      "probabilities": [
        0.39891503177478,
        0.49984801941276,
        0.1012369488125
      ]
    },
    {
      "p_first": 1,
      "b_first": 7,
      "probabilities": [
        0.37034250045392,
        0.52900678020156,
        0.10065071934456
      ]
    },
    {
      "p_first": 1,
      "b_first": 8,
      "probabilities": [
        0.32780682881973,
        0.58404342354743,
        0.088149747632881
      ]
    },
    {
      "p_first": 1,
      "b_first": 9,
      "probabilities": [
        0.3110607603117,
        0.60066672205298,
        0.088272517635352
      ]
    },
    {
      "p_first": 2,
      "b_first": 0,
      "probabilities": [
        0.4549472278008,
        0.45497979648066,
        0.090072975718564
      ]
    },
    {
      "p_first": 2,
      "b_first": 1,
      "probabilities": [
        0.45139388753774,
        0.45856233745036,
        0.090043775011947
      ]
    },
    {
      "p_first": 2,
      "b_first": 2,
      "probabilities": [
        0.44625373989993,
        0.46226980580155,
        0.091476454298553
      ]
    },
    {
      "p_first": 2,
      "b_first": 3,
      "probabilities": [
        0.44262301493212,
        0.46749705833485,
        0.089879926733074
      ]
    },
    {
      "p_first": 2,
      "b_first": 4,
      "probabilities": [
        0.43237593200638,
        0.4783655744627,
        0.089258493530966
      ]
    },
    {
      "p_first": 2,
      "b_first": 5,
      "probabilities": [
        0.41776588551647,
        0.49035615171243,
        0.091877962771136
      ]
    },
    {
      "p_first": 2,
      "b_first": 6,
      "probabilities": [
        0.40074101505553,
        0.4968128531905,
        0.102446131754
      ]
    },
    {
      "p_first": 2,
      "b_first": 7,
      "probabilities": [
        0.37159966361307,
        0.52673498380874,
        0.10166535257823
      ]
    },
    {
      "p_first": 2,
      "b_first": 8,
      "probabilities": [
        0.32961869791904,
        0.58116062765123,
        0.089220674429761
      ]
    },
    {
      "p_first": 2,
      "b_first": 9,
      "probabilities": [
        0.31230702736312,
        0.59839679228936,
        0.089296180347553
      ]
    },
    {
      "p_first": 3,
      "b_first": 0,
      "probabilities": [
        0.45783476238755,
        0.45111141684539,
        0.091053820767081
      ]
    },
    {
      "p_first": 3,
      "b_first": 1,
      "probabilities": [
        0.45435837218964,
        0.4546993324389,
        0.090942295371497
      ]
    },
    {
      "p_first": 3,
      "b_first": 2,
      "probabilities": [
        0.45067647504201,
        0.45842119197484,
        0.09090233298319
      ]
    },
    {
      "p_first": 3,
      "b_first": 3,
      "probabilities": [
        0.44511065491861,
        0.46279075436541,
        0.092098590716013
      ]
    },
    {
      "p_first": 3,
      "b_first": 4,
      "probabilities": [
        0.43287007459511,
        0.47348269491455,
        0.093647230490385
      ]
    },
    {
      "p_first": 3,
      "b_first": 5,
      "probabilities": [
        0.42061320274755,
        0.48626452075219,
        0.093122276500308
      ]
    },
    {
      "p_first": 3,
      "b_first": 6,
      "probabilities": [
        0.4034854549892,
        0.49371538644003,
        0.10279915857081
      ]
    },
    {
      "p_first": 3,
      "b_first": 7,
      "probabilities": [
        0.37436617628848,
        0.52310007774903,
        0.10253374596253
      ]
    },
    {
      "p_first": 3,
      "b_first": 8,
      "probabilities": [
        0.33168663978007,
        0.57814117034809,
        0.090172189871872
      ]
    },
    {
      "p_first": 3,
      "b_first": 9,
      "probabilities": [
        0.31435876846875,
        0.59539472975708,
        0.090246501774207
      ]
    },
    {
      "p_first": 4,
      "b_first": 0,
      "probabilities": [
        0.46137503299957,
        0.44435057113575,
        0.094274395864702
      ]
    },
    {
      "p_first": 4,
      "b_first": 1,
      "probabilities": [
        0.45780226941732,
        0.44780962472661,
        0.09438810585611
      ]
    },
    {
      "p_first": 4,
      "b_first": 2,
      "probabilities": [
        0.45413296687045,
        0.45192830958338,
        0.093938723546203
      ]
    },
    {
      "p_first": 4,
      "b_first": 3,
      "probabilities": [
        0.44973635092874,
        0.45616160486498,
        0.094102044206328
      ]
    },
    {
      "p_first": 4,
      "b_first": 4,
      "probabilities": [
        0.43721282313565,
        0.45446508470475,
        0.10832209215963
      ]
    },
    {
      "p_first": 4,
      "b_first": 5,
      "probabilities": [
        0.42446954620965,
        0.47896964156137,
        0.096560812229018
      ]
    },
    {
      "p_first": 4,
      "b_first": 6,
      "probabilities": [
        0.40663204050304,
        0.48655075723871,
        0.10681720225829
      ]
    },
    {
      "p_first": 4,
      "b_first": 7,
      "probabilities": [
        0.37632115434004,
        0.51783827440805,
        0.10584057125194
      ]
    },
    {
      "p_first": 4,
      "b_first": 8,
      "probabilities": [
        0.33437125128452,
        0.57266640514574,
        0.092962343569777
      ]
    },
    {
      "p_first": 4,
      "b_first": 9,
      "probabilities": [
        0.31703095806776,
        0.58934793361262,
        0.093621108319657
      ]
    },
    {
      "p_first": 5,
      "b_first": 0,
      "probabilities": [
        0.47075751023297,
        0.43391666316393,
        0.095325826603128
      ]
    },
    {
      "p_first": 5,
      "b_first": 1,
      "probabilities": [
        0.46718041752439,
        0.43753408513478,
        0.095285497340878
      ]
    },
    {
      "p_first": 5,
      "b_first": 2,
      "probabilities": [
        0.46337218766979,
        0.44138246209259,
        0.095245350237655
      ]
    },
    {
      "p_first": 5,
      "b_first": 3,
      "probabilities": [
        0.45871964561923,
        0.44252409332469,
        0.098756261056124
      ]
    },
    {
      "p_first": 5,
      "b_first": 4,
      "probabilities": [
        0.45859112272111,
        0.4428726560365,
        0.098536221242436
      ]
    },
    {
      "p_first": 5,
      "b_first": 5,
      "probabilities": [
        0.43463028036911,
        0.45680544286739,
        0.10856427676354
      ]
    },
    {
      "p_first": 5,
      "b_first": 6,
      "probabilities": [
        0.4158973673779,
        0.47616041932955,
        0.10794221329259
      ]
    },
    {
      "p_first": 5,
      "b_first": 7,
      "probabilities": [
        0.38478024806114,
        0.50821194246882,
        0.10700780947008
      ]
    },
    {
      "p_first": 5,
      "b_first": 8,
      "probabilities": [
        0.34237675680476,
        0.5630400940681,
        0.094583149127178
      ]
    },
    {
      "p_first": 5,
      "b_first": 9,
      "probabilities": [
        0.32497220545469,
        0.58036252754912,
        0.094665266996227
      ]
    },
    {
      "p_first": 6,
      "b_first": 0,
      "probabilities": [
        0.4899370844775,
        0.40876676405957,
        0.10129615146295
      ]
    },
    {
      "p_first": 6,
      "b_first": 1,
      "probabilities": [
        0.4873609020106,
        0.41068771443212,
        0.10195138355732
      ]
    },
    {
      "p_first": 6,
      "b_first": 2,
      "probabilities": [
        0.48442275353346,
        0.4134810821972,
        0.10209616426937
      ]
    },
    {
      "p_first": 6,
      "b_first": 3,
      "probabilities": [
        0.482185938236,
        0.4160172666315,
        0.10179679513254
      ]
    },
    {
      "p_first": 6,
      "b_first": 4,
      "probabilities": [
        0.47634709751553,
        0.41962205331456,
        0.10403084916995
      ]
    },
    {
      "p_first": 6,
      "b_first": 5,
      "probabilities": [
        0.46541813698878,
        0.43063031311546,
        0.1039515498958
      ]
    },
    {
      "p_first": 6,
      "b_first": 6,
      "probabilities": [
        0.41467962151154,
        0.42226367943362,
        0.16305669905487
      ]
    },
    {
      "p_first": 6,
      "b_first": 7,
      "probabilities": [
        0.38864128330975,
        0.50089289809066,
        0.11046581859962
      ]
    },
    {
      "p_first": 6,
      "b_first": 8,
      "probabilities": [
        0.3546821567286,
        0.54372639745232,
        0.10159144581912
      ]
    },
    {
      "p_first": 6,
      "b_first": 9,
      "probabilities": [
        0.33724502626787,
        0.56050439546029,
        0.10225057827188
      ]
    },
    {
      "p_first": 7,
      "b_first": 0,
      "probabilities": [
        0.52027167694183,
        0.37842813522202,
        0.10130018783617
      ]
    },
    {
      "p_first": 7,
      "b_first": 1,
      "probabilities": [
        0.51746975108737,
        0.38036243570283,
        0.10216781320984
      ]
    },
    {
      "p_first": 7,
      "b_first": 2,
      "probabilities": [
        0.51468709057041,
        0.38318723677965,
        0.10212567264997
      ]
    },
    {
      "p_first": 7,
      "b_first": 3,
      "probabilities": [
        0.51128243110147,
        0.38638910324041,
        0.10232846565816
      ]
    },
    {
      "p_first": 7,
      "b_first": 4,
      "probabilities": [
        0.50662336724661,
        0.38942445749334,
        0.1039521752601
      ]
    },
    {
      "p_first": 7,
      "b_first": 5,
      "probabilities": [
        0.49581200277048,
        0.40037556515896,
        0.10381243207059
      ]
    },
    {
      "p_first": 7,
      "b_first": 6,
      "probabilities": [
        0.49327324559036,
        0.39608431021877,
        0.1106424441909
      ]
    },
    {
      "p_first": 7,
      "b_first": 7,
      "probabilities": [
        0.41491243138444,
        0.42236632842781,
        0.16272124018779
      ]
    },
    {
      "p_first": 7,
      "b_first": 8,
      "probabilities": [
        0.38039669216861,
        0.51746819282294,
        0.10213511500848
      ]
    },
    {
      "p_first": 7,
      "b_first": 9,
      "probabilities": [
        0.36336671849182,
        0.53461182551148,
        0.10202145599673
      ]
    },
    {
      "p_first": 8,
      "b_first": 0,
      "probabilities": [
        0.5750855361381,
        0.33571064366666,
        0.089203820195265
      ]
    },
    {
      "p_first": 8,
      "b_first": 1,
      "probabilities": [
        0.57239593698552,
        0.33786371133478,
        0.089740351679734
      ]
    },
    {
      "p_first": 8,
      "b_first": 2,
      "probabilities": [
        0.56899255615274,
        0.34127330671234,
        0.089734137134952
      ]
    },
    {
      "p_first": 8,
      "b_first": 3,
      "probabilities": [
        0.56623692867072,
        0.34375763937618,
        0.090005431953135
      ]
    },
    {
      "p_first": 8,
      "b_first": 4,
      "probabilities": [
        0.56138956750761,
        0.34749674343804,
        0.091113689054381
      ]
    },
    {
      "p_first": 8,
      "b_first": 5,
      "probabilities": [
        0.55049656449558,
        0.35801779588711,
        0.091485639617342
      ]
    },
    {
      "p_first": 8,
      "b_first": 6,
      "probabilities": [
        0.53604766532971,
        0.36214337432667,
        0.10180896034365
      ]
    },
    {
      "p_first": 8,
      "b_first": 7,
      "probabilities": [
        0.50999678205617,
        0.38783285188269,
        0.10217036606117
      ]
    },
    {
      "p_first": 8,
      "b_first": 8,
      "probabilities": [
        0.42311875393298,
        0.43077588877861,
        0.14610535728844
      ]
    },
    {
      "p_first": 8,
      "b_first": 9,
      "probabilities": [
        0.40619378453826,
        0.50069362868875,
        0.093112586773021
      ]
    },
    {
      "p_first": 9,
      "b_first": 0,
      "probabilities": [
        0.59225210580484,
        0.31844793161284,
        0.089299962582341
      ]
    },
    {
      "p_first": 9,
      "b_first": 1,
      "probabilities": [
        0.5889491670582,
        0.32118792457289,
        0.089862908368944
      ]
    },
    {
      "p_first": 9,
      "b_first": 2,
      "probabilities": [
        0.58616922849583,
        0.32400146494762,
        0.089829306556583
      ]
    },
    {
      "p_first": 9,
      "b_first": 3,
      "probabilities": [
        0.58337928223954,
        0.32652011894161,
        0.090100598818875
      ]
    },
    {
      "p_first": 9,
      "b_first": 4,
      "probabilities": [
        0.57797722819204,
        0.33032472122735,
        0.091698050580639
      ]
    },
    {
      "p_first": 9,
      "b_first": 5,
      "probabilities": [
        0.56764083608773,
        0.34085300974857,
        0.091506154163729
      ]
    },
    {
      "p_first": 9,
      "b_first": 6,
      "probabilities": [
        0.55279419907894,
        0.34474914304182,
        0.10245665787927
      ]
    },
    {
      "p_first": 9,
      "b_first": 7,
      "probabilities": [
        0.52695997265589,
        0.37100509945441,
        0.10203492788973
      ]
    },
    {
      "p_first": 9,
      "b_first": 8,
      "probabilities": [
        0.49296948805816,
        0.41391725870306,
        0.093113253238808
      ]
    },
    {
      "p_first": 9,
      "b_first": 9,
      "probabilities": [
        0.42289408091104,
        0.43070568329472,
        0.14640023579427
      ]
    }
  ]
}
`````

## ファイル：`data/cards.json`

<!-- CAFE_CARDS_FILE {"path":"data/cards.json","bytes":8604,"sha256":"bfcda0932d3b3f643f7e9d93d498ac38338edd61cde08e80f26e1f4747c56a67"} -->
`````json
{
  "version": 1,
  "copies": "physical_id=copy*52+id",
  "cards": [
    {
      "id": 0,
      "code": "C2",
      "suit": "C",
      "rank": 2,
      "poker_rank": 2,
      "thirty_one_value": 2,
      "baccarat_value": 2
    },
    {
      "id": 1,
      "code": "C3",
      "suit": "C",
      "rank": 3,
      "poker_rank": 3,
      "thirty_one_value": 3,
      "baccarat_value": 3
    },
    {
      "id": 2,
      "code": "C4",
      "suit": "C",
      "rank": 4,
      "poker_rank": 4,
      "thirty_one_value": 4,
      "baccarat_value": 4
    },
    {
      "id": 3,
      "code": "C5",
      "suit": "C",
      "rank": 5,
      "poker_rank": 5,
      "thirty_one_value": 5,
      "baccarat_value": 5
    },
    {
      "id": 4,
      "code": "C6",
      "suit": "C",
      "rank": 6,
      "poker_rank": 6,
      "thirty_one_value": 6,
      "baccarat_value": 6
    },
    {
      "id": 5,
      "code": "C7",
      "suit": "C",
      "rank": 7,
      "poker_rank": 7,
      "thirty_one_value": 7,
      "baccarat_value": 7
    },
    {
      "id": 6,
      "code": "C8",
      "suit": "C",
      "rank": 8,
      "poker_rank": 8,
      "thirty_one_value": 8,
      "baccarat_value": 8
    },
    {
      "id": 7,
      "code": "C9",
      "suit": "C",
      "rank": 9,
      "poker_rank": 9,
      "thirty_one_value": 9,
      "baccarat_value": 9
    },
    {
      "id": 8,
      "code": "C10",
      "suit": "C",
      "rank": 10,
      "poker_rank": 10,
      "thirty_one_value": 10,
      "baccarat_value": 0
    },
    {
      "id": 9,
      "code": "CJ",
      "suit": "C",
      "rank": 11,
      "poker_rank": 11,
      "thirty_one_value": 10,
      "baccarat_value": 0
    },
    {
      "id": 10,
      "code": "CQ",
      "suit": "C",
      "rank": 12,
      "poker_rank": 12,
      "thirty_one_value": 10,
      "baccarat_value": 0
    },
    {
      "id": 11,
      "code": "CK",
      "suit": "C",
      "rank": 13,
      "poker_rank": 13,
      "thirty_one_value": 10,
      "baccarat_value": 0
    },
    {
      "id": 12,
      "code": "CA",
      "suit": "C",
      "rank": 14,
      "poker_rank": 14,
      "thirty_one_value": 11,
      "baccarat_value": 1
    },
    {
      "id": 13,
      "code": "D2",
      "suit": "D",
      "rank": 2,
      "poker_rank": 2,
      "thirty_one_value": 2,
      "baccarat_value": 2
    },
    {
      "id": 14,
      "code": "D3",
      "suit": "D",
      "rank": 3,
      "poker_rank": 3,
      "thirty_one_value": 3,
      "baccarat_value": 3
    },
    {
      "id": 15,
      "code": "D4",
      "suit": "D",
      "rank": 4,
      "poker_rank": 4,
      "thirty_one_value": 4,
      "baccarat_value": 4
    },
    {
      "id": 16,
      "code": "D5",
      "suit": "D",
      "rank": 5,
      "poker_rank": 5,
      "thirty_one_value": 5,
      "baccarat_value": 5
    },
    {
      "id": 17,
      "code": "D6",
      "suit": "D",
      "rank": 6,
      "poker_rank": 6,
      "thirty_one_value": 6,
      "baccarat_value": 6
    },
    {
      "id": 18,
      "code": "D7",
      "suit": "D",
      "rank": 7,
      "poker_rank": 7,
      "thirty_one_value": 7,
      "baccarat_value": 7
    },
    {
      "id": 19,
      "code": "D8",
      "suit": "D",
      "rank": 8,
      "poker_rank": 8,
      "thirty_one_value": 8,
      "baccarat_value": 8
    },
    {
      "id": 20,
      "code": "D9",
      "suit": "D",
      "rank": 9,
      "poker_rank": 9,
      "thirty_one_value": 9,
      "baccarat_value": 9
    },
    {
      "id": 21,
      "code": "D10",
      "suit": "D",
      "rank": 10,
      "poker_rank": 10,
      "thirty_one_value": 10,
      "baccarat_value": 0
    },
    {
      "id": 22,
      "code": "DJ",
      "suit": "D",
      "rank": 11,
      "poker_rank": 11,
      "thirty_one_value": 10,
      "baccarat_value": 0
    },
    {
      "id": 23,
      "code": "DQ",
      "suit": "D",
      "rank": 12,
      "poker_rank": 12,
      "thirty_one_value": 10,
      "baccarat_value": 0
    },
    {
      "id": 24,
      "code": "DK",
      "suit": "D",
      "rank": 13,
      "poker_rank": 13,
      "thirty_one_value": 10,
      "baccarat_value": 0
    },
    {
      "id": 25,
      "code": "DA",
      "suit": "D",
      "rank": 14,
      "poker_rank": 14,
      "thirty_one_value": 11,
      "baccarat_value": 1
    },
    {
      "id": 26,
      "code": "H2",
      "suit": "H",
      "rank": 2,
      "poker_rank": 2,
      "thirty_one_value": 2,
      "baccarat_value": 2
    },
    {
      "id": 27,
      "code": "H3",
      "suit": "H",
      "rank": 3,
      "poker_rank": 3,
      "thirty_one_value": 3,
      "baccarat_value": 3
    },
    {
      "id": 28,
      "code": "H4",
      "suit": "H",
      "rank": 4,
      "poker_rank": 4,
      "thirty_one_value": 4,
      "baccarat_value": 4
    },
    {
      "id": 29,
      "code": "H5",
      "suit": "H",
      "rank": 5,
      "poker_rank": 5,
      "thirty_one_value": 5,
      "baccarat_value": 5
    },
    {
      "id": 30,
      "code": "H6",
      "suit": "H",
      "rank": 6,
      "poker_rank": 6,
      "thirty_one_value": 6,
      "baccarat_value": 6
    },
    {
      "id": 31,
      "code": "H7",
      "suit": "H",
      "rank": 7,
      "poker_rank": 7,
      "thirty_one_value": 7,
      "baccarat_value": 7
    },
    {
      "id": 32,
      "code": "H8",
      "suit": "H",
      "rank": 8,
      "poker_rank": 8,
      "thirty_one_value": 8,
      "baccarat_value": 8
    },
    {
      "id": 33,
      "code": "H9",
      "suit": "H",
      "rank": 9,
      "poker_rank": 9,
      "thirty_one_value": 9,
      "baccarat_value": 9
    },
    {
      "id": 34,
      "code": "H10",
      "suit": "H",
      "rank": 10,
      "poker_rank": 10,
      "thirty_one_value": 10,
      "baccarat_value": 0
    },
    {
      "id": 35,
      "code": "HJ",
      "suit": "H",
      "rank": 11,
      "poker_rank": 11,
      "thirty_one_value": 10,
      "baccarat_value": 0
    },
    {
      "id": 36,
      "code": "HQ",
      "suit": "H",
      "rank": 12,
      "poker_rank": 12,
      "thirty_one_value": 10,
      "baccarat_value": 0
    },
    {
      "id": 37,
      "code": "HK",
      "suit": "H",
      "rank": 13,
      "poker_rank": 13,
      "thirty_one_value": 10,
      "baccarat_value": 0
    },
    {
      "id": 38,
      "code": "HA",
      "suit": "H",
      "rank": 14,
      "poker_rank": 14,
      "thirty_one_value": 11,
      "baccarat_value": 1
    },
    {
      "id": 39,
      "code": "S2",
      "suit": "S",
      "rank": 2,
      "poker_rank": 2,
      "thirty_one_value": 2,
      "baccarat_value": 2
    },
    {
      "id": 40,
      "code": "S3",
      "suit": "S",
      "rank": 3,
      "poker_rank": 3,
      "thirty_one_value": 3,
      "baccarat_value": 3
    },
    {
      "id": 41,
      "code": "S4",
      "suit": "S",
      "rank": 4,
      "poker_rank": 4,
      "thirty_one_value": 4,
      "baccarat_value": 4
    },
    {
      "id": 42,
      "code": "S5",
      "suit": "S",
      "rank": 5,
      "poker_rank": 5,
      "thirty_one_value": 5,
      "baccarat_value": 5
    },
    {
      "id": 43,
      "code": "S6",
      "suit": "S",
      "rank": 6,
      "poker_rank": 6,
      "thirty_one_value": 6,
      "baccarat_value": 6
    },
    {
      "id": 44,
      "code": "S7",
      "suit": "S",
      "rank": 7,
      "poker_rank": 7,
      "thirty_one_value": 7,
      "baccarat_value": 7
    },
    {
      "id": 45,
      "code": "S8",
      "suit": "S",
      "rank": 8,
      "poker_rank": 8,
      "thirty_one_value": 8,
      "baccarat_value": 8
    },
    {
      "id": 46,
      "code": "S9",
      "suit": "S",
      "rank": 9,
      "poker_rank": 9,
      "thirty_one_value": 9,
      "baccarat_value": 9
    },
    {
      "id": 47,
      "code": "S10",
      "suit": "S",
      "rank": 10,
      "poker_rank": 10,
      "thirty_one_value": 10,
      "baccarat_value": 0
    },
    {
      "id": 48,
      "code": "SJ",
      "suit": "S",
      "rank": 11,
      "poker_rank": 11,
      "thirty_one_value": 10,
      "baccarat_value": 0
    },
    {
      "id": 49,
      "code": "SQ",
      "suit": "S",
      "rank": 12,
      "poker_rank": 12,
      "thirty_one_value": 10,
      "baccarat_value": 0
    },
    {
      "id": 50,
      "code": "SK",
      "suit": "S",
      "rank": 13,
      "poker_rank": 13,
      "thirty_one_value": 10,
      "baccarat_value": 0
    },
    {
      "id": 51,
      "code": "SA",
      "suit": "S",
      "rank": 14,
      "poker_rank": 14,
      "thirty_one_value": 11,
      "baccarat_value": 1
    }
  ]
}
`````

## ファイル：`data/content.ja.json`

<!-- CAFE_CARDS_FILE {"path":"data/content.ja.json","bytes":6176,"sha256":"9508d2227cc08e8e17c9b76ebafcde8af4e5a4e1fc021911315e4be256fe23dc"} -->
`````json
{
  "suite.title": "CAFE CARDS",
  "suite.subtitle": "今日は、どんな勝負にしますか？",
  "suite.notice": "得点はゲーム内だけ。現金・景品との交換はありません。",
  "suite.poker": "POKER",
  "suite.gops": "GOPS",
  "suite.thirty_one": "THIRTY-ONE",
  "suite.baccarat": "BACCARAT",
  "suite.poker_tag": "その強気、本物ですか？",
  "suite.gops_tag": "切り札を出すのは、今ですか？",
  "suite.thirty_one_tag": "もう少し育てる？ 今、勝負する？",
  "suite.baccarat_tag": "あなたとJev、同じ予想ですか？",
  "common.start": "はじめる",
  "common.howto": "遊び方",
  "common.guest": "ゲストで遊ぶ",
  "common.profile": "自分を選ぶ",
  "common.confirm": "これで決定",
  "common.cancel": "選び直す",
  "common.back": "戻る",
  "common.cafe": "カフェへ",
  "common.continue": "続ける",
  "common.pause": "一時停止",
  "common.resume": "再開する",
  "common.abort": "対戦を終了",
  "common.abort_ask": "この対戦を中止しますか？ 勝敗には数えません。",
  "common.restart": "もう一度遊ぶ",
  "common.next": "次へ",
  "common.previous": "前へ",
  "common.round_next": "次の勝負へ",
  "common.your_turn": "あなたの番です",
  "common.ai_turn": "Jevが選んでいます",
  "common.local_turn": "端末AIが選んでいます",
  "common.ready": "相手の選択は確定済み",
  "common.mixed": "途中から端末AI",
  "common.local": "端末AI",
  "common.jevinvalid": "Jevの応答を確認できませんでした",
  "common.fallback_ask": "この対戦の残りを端末AIで続けますか？",
  "common.fallback_yes": "端末AIで続ける",
  "common.wait": "復旧を待つ",
  "common.offline": "通信できません",
  "common.pending_save": "記録の送信待ち",
  "common.saved": "記録しました",
  "common.save_failed": "保存できません。再開地点を守るため中断します。",
  "common.expired": "再開できる期限を過ぎました",
  "common.bad_snapshot": "記録が壊れているため再開できません",
  "common.hidden": "手札を隠しています",
  "common.auth_required": "本人の確認をしてから再開します",
  "common.guest_reboot": "再起動したため、ゲストの対戦は終了しました",
  "common.win": "あなたの勝ち！",
  "common.lose": "今回は相手の勝ち",
  "common.draw": "引き分けです",
  "common.no_winner": "対戦は中止されました",
  "common.tutorial": "練習中：戦績には記録しません",
  "common.forced": "残りの選択肢は一つです",
  "common.detail": "判断の内訳",
  "common.confidence": "候補の偏り：勝率ではありません",
  "common.predict_label": "Jevの予測：実際の勝率とは限りません",
  "poker.hand": "第{n}/5回",
  "poker.chips": "持ち点 {you} / {ai}",
  "poker.pot": "場の持ち点 {pot}",
  "poker.ante": "双方1点を場に出しました",
  "poker.check": "追加せず続ける",
  "poker.bet": "{amount}点出す",
  "poker.call": "{amount}点で勝負",
  "poker.raise": "{amount}点を追加",
  "poker.fold": "この手を降りる",
  "poker.fold_confirm": "この手を降りますか？",
  "poker.replace": "交換する札を選択",
  "poker.draw_confirm": "{n}枚を交換する",
  "poker.draw_zero": "交換せず進む",
  "poker.draw_done": "あなた{you}枚／相手{ai}枚交換",
  "poker.fold_result": "相手が降りました。手札は公開しません。",
  "poker.showdown": "手札を比べます",
  "poker.split": "同じ強さです。場の持ち点を半分ずつ戻します。",
  "poker.no_detail": "降りた手の秘密や判断の内訳は公開しません。",
  "poker.match_end": "5回の合計持ち点で勝負！",
  "poker.check_tip": "相手がまだ出していないので、追加せず続けられます。",
  "gops.prize": "今回の得点 {n}",
  "gops.remain": "残り {n}枚",
  "gops.choose": "出す札を選んでください",
  "gops.confirm": "{n}を出しますか？",
  "gops.tie": "同じ札。今回はどちらも得点なし",
  "gops.gain": "{who}が{n}点獲得",
  "gops.used": "使用済み",
  "gops.score": "得点 {you} / {ai}",
  "gops.last": "最後の札を確定してください",
  "gops.quick": "7枚・短期戦",
  "gops.classic": "13枚・通常戦",
  "gops.no_carry": "同点の得点は次へ持ち越しません。",
  "thirty_one.market": "場の3枚",
  "thirty_one.hand": "あなたの3枚",
  "thirty_one.score": "同じマークの合計：{score}",
  "thirty_one.swap": "札を交換",
  "thirty_one.knock": "勝負を仕掛ける",
  "thirty_one.knock_confirm": "今の手で勝負しますか？ 相手には最後の1回があります。",
  "thirty_one.stand": "この手で勝負",
  "thirty_one.final": "最後に1回、交換するか今の手で勝負できます",
  "thirty_one.natural": "31点！ すぐに勝負です",
  "thirty_one.limit": "20手になったので手を比べます",
  "thirty_one.tie": "同じ点数なので引き分けです",
  "thirty_one.known": "公開された相手の札",
  "thirty_one.match_end": "3回勝負の結果",
  "baccarat.open": "1枚ずつ公開",
  "baccarat.classic": "配る前に予想",
  "baccarat.player": "PLAYER側",
  "baccarat.banker": "BANKER側",
  "baccarat.tie": "引き分け",
  "baccarat.choose": "最後の点数が高い側は？",
  "baccarat.same": "今回は、同じ予想です",
  "baccarat.different": "予想が分かれました",
  "baccarat.correct": "的中！",
  "baccarat.incorrect": "今回は外れました",
  "baccarat.natural": "最初の2枚が8/9点。追加はありません。",
  "baccarat.draw3": "ルールにより3枚目を配ります",
  "baccarat.stand": "この側は2枚で止まります",
  "baccarat.total": "合計の一の位：{score}点",
  "baccarat.result": "{outcome}",
  "baccarat.match_end": "5回の的中数で勝負！",
  "baccarat.fresh": "毎回、新しい8組から配ります",
  "baccarat.no_payout": "引き分けを当てても1点。倍率はありません。"
}
`````

## ファイル：`data/layouts.json`

<!-- CAFE_CARDS_FILE {"path":"data/layouts.json","bytes":3289,"sha256":"895bb318a6624ad522ce8b59d119400f0567d5ba7ff2c0f1b8b2ed70f7a4fcf2"} -->
`````json
{
  "safe_circle": {
    "cx": 240,
    "cy": 240,
    "r": 228
  },
  "menu": [
    {
      "id": "poker",
      "x": 96,
      "y": 134,
      "w": 136,
      "h": 104
    },
    {
      "id": "gops",
      "x": 248,
      "y": 134,
      "w": 136,
      "h": 104
    },
    {
      "id": "thirty_one",
      "x": 96,
      "y": 254,
      "w": 136,
      "h": 104
    },
    {
      "id": "baccarat",
      "x": 248,
      "y": 254,
      "w": 136,
      "h": 104
    }
  ],
  "poker_cards": [
    {
      "id": "slot_0",
      "x": 70,
      "y": 190,
      "w": 64,
      "h": 92
    },
    {
      "id": "slot_1",
      "x": 138,
      "y": 190,
      "w": 64,
      "h": 92
    },
    {
      "id": "slot_2",
      "x": 206,
      "y": 190,
      "w": 64,
      "h": 92
    },
    {
      "id": "slot_3",
      "x": 274,
      "y": 190,
      "w": 64,
      "h": 92
    },
    {
      "id": "slot_4",
      "x": 342,
      "y": 190,
      "w": 64,
      "h": 92
    }
  ],
  "three_actions": [
    {
      "id": "action_0",
      "x": 96,
      "y": 346,
      "w": 88,
      "h": 48
    },
    {
      "id": "action_1",
      "x": 196,
      "y": 346,
      "w": 88,
      "h": 48
    },
    {
      "id": "action_2",
      "x": 296,
      "y": 346,
      "w": 88,
      "h": 48
    }
  ],
  "gops_cards": [
    {
      "id": "page_slot_0",
      "x": 96,
      "y": 202,
      "w": 68,
      "h": 96
    },
    {
      "id": "page_slot_1",
      "x": 172,
      "y": 202,
      "w": 68,
      "h": 96
    },
    {
      "id": "page_slot_2",
      "x": 248,
      "y": 202,
      "w": 68,
      "h": 96
    },
    {
      "id": "page_slot_3",
      "x": 324,
      "y": 202,
      "w": 68,
      "h": 96
    }
  ],
  "three_market": [
    {
      "id": "market_0",
      "x": 116,
      "y": 145,
      "w": 72,
      "h": 86
    },
    {
      "id": "market_1",
      "x": 204,
      "y": 145,
      "w": 72,
      "h": 86
    },
    {
      "id": "market_2",
      "x": 292,
      "y": 145,
      "w": 72,
      "h": 86
    }
  ],
  "three_hand": [
    {
      "id": "hand_0",
      "x": 116,
      "y": 254,
      "w": 72,
      "h": 86
    },
    {
      "id": "hand_1",
      "x": 204,
      "y": 254,
      "w": 72,
      "h": 86
    },
    {
      "id": "hand_2",
      "x": 292,
      "y": 254,
      "w": 72,
      "h": 86
    }
  ],
  "two_actions": [
    {
      "id": "action_left",
      "x": 112,
      "y": 360,
      "w": 120,
      "h": 48
    },
    {
      "id": "action_right",
      "x": 248,
      "y": 360,
      "w": 120,
      "h": 48
    }
  ],
  "footer": [
    {
      "id": "cafe",
      "x": 168,
      "y": 416,
      "w": 144,
      "h": 36
    }
  ],
  "baccarat_p": [
    {
      "id": "P1",
      "x": 116,
      "y": 143,
      "w": 72,
      "h": 84
    },
    {
      "id": "P2",
      "x": 204,
      "y": 143,
      "w": 72,
      "h": 84
    },
    {
      "id": "P3",
      "x": 292,
      "y": 143,
      "w": 72,
      "h": 84
    }
  ],
  "baccarat_b": [
    {
      "id": "B1",
      "x": 116,
      "y": 252,
      "w": 72,
      "h": 84
    },
    {
      "id": "B2",
      "x": 204,
      "y": 252,
      "w": 72,
      "h": 84
    },
    {
      "id": "B3",
      "x": 292,
      "y": 252,
      "w": 72,
      "h": 84
    }
  ]
}
`````

## ファイル：`data/poker_draw_choices.json`

<!-- CAFE_CARDS_FILE {"path":"data/poker_draw_choices.json","bytes":3803,"sha256":"15615dd5e3546a09ad76c537caaa3c1fa43ac1f99b56fca6461f64830932c787"} -->
`````json
[
  {
    "action_id": "DRAW:0",
    "mask": 0,
    "replace_slots": [],
    "count": 0
  },
  {
    "action_id": "DRAW:1",
    "mask": 1,
    "replace_slots": [
      0
    ],
    "count": 1
  },
  {
    "action_id": "DRAW:2",
    "mask": 2,
    "replace_slots": [
      1
    ],
    "count": 1
  },
  {
    "action_id": "DRAW:3",
    "mask": 3,
    "replace_slots": [
      0,
      1
    ],
    "count": 2
  },
  {
    "action_id": "DRAW:4",
    "mask": 4,
    "replace_slots": [
      2
    ],
    "count": 1
  },
  {
    "action_id": "DRAW:5",
    "mask": 5,
    "replace_slots": [
      0,
      2
    ],
    "count": 2
  },
  {
    "action_id": "DRAW:6",
    "mask": 6,
    "replace_slots": [
      1,
      2
    ],
    "count": 2
  },
  {
    "action_id": "DRAW:7",
    "mask": 7,
    "replace_slots": [
      0,
      1,
      2
    ],
    "count": 3
  },
  {
    "action_id": "DRAW:8",
    "mask": 8,
    "replace_slots": [
      3
    ],
    "count": 1
  },
  {
    "action_id": "DRAW:9",
    "mask": 9,
    "replace_slots": [
      0,
      3
    ],
    "count": 2
  },
  {
    "action_id": "DRAW:10",
    "mask": 10,
    "replace_slots": [
      1,
      3
    ],
    "count": 2
  },
  {
    "action_id": "DRAW:11",
    "mask": 11,
    "replace_slots": [
      0,
      1,
      3
    ],
    "count": 3
  },
  {
    "action_id": "DRAW:12",
    "mask": 12,
    "replace_slots": [
      2,
      3
    ],
    "count": 2
  },
  {
    "action_id": "DRAW:13",
    "mask": 13,
    "replace_slots": [
      0,
      2,
      3
    ],
    "count": 3
  },
  {
    "action_id": "DRAW:14",
    "mask": 14,
    "replace_slots": [
      1,
      2,
      3
    ],
    "count": 3
  },
  {
    "action_id": "DRAW:15",
    "mask": 15,
    "replace_slots": [
      0,
      1,
      2,
      3
    ],
    "count": 4
  },
  {
    "action_id": "DRAW:16",
    "mask": 16,
    "replace_slots": [
      4
    ],
    "count": 1
  },
  {
    "action_id": "DRAW:17",
    "mask": 17,
    "replace_slots": [
      0,
      4
    ],
    "count": 2
  },
  {
    "action_id": "DRAW:18",
    "mask": 18,
    "replace_slots": [
      1,
      4
    ],
    "count": 2
  },
  {
    "action_id": "DRAW:19",
    "mask": 19,
    "replace_slots": [
      0,
      1,
      4
    ],
    "count": 3
  },
  {
    "action_id": "DRAW:20",
    "mask": 20,
    "replace_slots": [
      2,
      4
    ],
    "count": 2
  },
  {
    "action_id": "DRAW:21",
    "mask": 21,
    "replace_slots": [
      0,
      2,
      4
    ],
    "count": 3
  },
  {
    "action_id": "DRAW:22",
    "mask": 22,
    "replace_slots": [
      1,
      2,
      4
    ],
    "count": 3
  },
  {
    "action_id": "DRAW:23",
    "mask": 23,
    "replace_slots": [
      0,
      1,
      2,
      4
    ],
    "count": 4
  },
  {
    "action_id": "DRAW:24",
    "mask": 24,
    "replace_slots": [
      3,
      4
    ],
    "count": 2
  },
  {
    "action_id": "DRAW:25",
    "mask": 25,
    "replace_slots": [
      0,
      3,
      4
    ],
    "count": 3
  },
  {
    "action_id": "DRAW:26",
    "mask": 26,
    "replace_slots": [
      1,
      3,
      4
    ],
    "count": 3
  },
  {
    "action_id": "DRAW:27",
    "mask": 27,
    "replace_slots": [
      0,
      1,
      3,
      4
    ],
    "count": 4
  },
  {
    "action_id": "DRAW:28",
    "mask": 28,
    "replace_slots": [
      2,
      3,
      4
    ],
    "count": 3
  },
  {
    "action_id": "DRAW:29",
    "mask": 29,
    "replace_slots": [
      0,
      2,
      3,
      4
    ],
    "count": 4
  },
  {
    "action_id": "DRAW:30",
    "mask": 30,
    "replace_slots": [
      1,
      2,
      3,
      4
    ],
    "count": 4
  },
  {
    "action_id": "DRAW:31",
    "mask": 31,
    "replace_slots": [
      0,
      1,
      2,
      3,
      4
    ],
    "count": 5
  }
]
`````

## ファイル：`data/rules.json`

<!-- CAFE_CARDS_FILE {"path":"data/rules.json","bytes":2927,"sha256":"8741b6b36fe204b1e5067c05ebc4ebf5bf9e83554f2868ecda12d8edab7c9cd3"} -->
`````json
{
  "suite_id": "cafe_cards",
  "menu_slot": 6,
  "version": "1.0.0",
  "date": "2026-09-22",
  "device": "ESP32-S3-Touch-LCD-2.8C",
  "resolution": [
    480,
    480
  ],
  "initial_opponent": "jev",
  "money": {
    "real_money": false,
    "purchase": false,
    "redemption": false,
    "prizes": false,
    "cross_game_wallet": false
  },
  "poker": {
    "id": "poker",
    "variant": "fixed5",
    "hands": 5,
    "starting_chips_each": 100,
    "ante_each": 1,
    "bet_units": [
      2,
      4
    ],
    "max_raises_per_street": 2,
    "max_contribution_per_hand": 19,
    "deck_copies": 1,
    "draw_rounds": 1,
    "draw_mask_min": 0,
    "draw_mask_max": 31,
    "deal_first": "nondealer",
    "bet_first": "nondealer",
    "swap_order": [
      "nondealer",
      "dealer"
    ],
    "side_pots": false,
    "all_in": false,
    "suit_tiebreak": false
  },
  "gops": {
    "id": "gops",
    "variants": {
      "quick7": 7,
      "classic13": 13
    },
    "default": "quick7",
    "tie": "burn_prize",
    "carryover": false,
    "bids": "simultaneous",
    "last_round_single_option": "forced"
  },
  "thirty_one": {
    "id": "thirty_one",
    "variant": "market3",
    "hands": 3,
    "cards_each": 3,
    "market_cards": 3,
    "ace": 11,
    "face": 10,
    "score": "max_same_suit_sum",
    "tie": "draw",
    "three_of_kind_bonus": false,
    "knock": "instead_of_swap",
    "reply_actions": [
      "SWAP",
      "STAND"
    ],
    "normal_actions": [
      "SWAP",
      "KNOCK"
    ],
    "normal_action_cap": 20,
    "max_actions_with_reply": 21,
    "natural31": "immediate_end",
    "both_initial31": "draw",
    "deck_copies": 1
  },
  "baccarat": {
    "id": "baccarat",
    "variants": [
      "open",
      "classic"
    ],
    "default": "open",
    "rounds": 5,
    "decks": 8,
    "fresh_pack_each_round": true,
    "burn_cards": false,
    "cut_card": false,
    "prediction_points_correct": 1,
    "tie_prediction_points_correct": 1,
    "payouts": false,
    "order": [
      "P1",
      "B1",
      "P2",
      "B2",
      "P3_if_required",
      "B3_if_required"
    ],
    "natural8or9": "end_both",
    "banker_if_player_stands": "draw_0_to_5"
  },
  "limits": {
    "idle_pause_ms": 120000,
    "profile_hide_ms": 60000,
    "registered_resume_max_ms": 86400000,
    "snapshot_bytes": 32768,
    "snapshot_slots": 2,
    "max_events": 192,
    "request_bytes": 16384,
    "response_bytes": 8192,
    "jev_timeout_seconds": 8,
    "decision_lease_ms": 60000,
    "ui_http_timeout_ms": 15000,
    "poll_intervals_ms": [
      2000,
      4000,
      8000,
      8000
    ],
    "daily_jev_reservations_per_device": 1000,
    "calls_per_match": {
      "poker": 40,
      "gops": 13,
      "thirty_one": 33,
      "baccarat": 5
    },
    "retention_days": {
      "registered_matches": 180,
      "guest_matches": 1,
      "decisions_after_match": 2,
      "receipts": 2
    }
  }
}
`````

## ファイル：`data/tutorials.ja.json`

<!-- CAFE_CARDS_FILE {"path":"data/tutorials.ja.json","bytes":3439,"sha256":"e5df01fecd6fb8de42fa67ef75848a08224b44d871cf5d2dd7515b039659245d"} -->
`````json
{
  "poker": [
    [
      "5枚で役を作ろう",
      "手札5枚を受け取ります。強い役を作るか、相手を降ろすと勝ちです。"
    ],
    [
      "押しただけでは確定しません",
      "札や行動を選んでから「これで決定」。迷ったら選び直せます。"
    ],
    [
      "上乗せは決まった額",
      "交換前は2点ずつ、交換後は4点ずつ。上乗せは各段階2回までです。"
    ],
    [
      "交換は1回だけ",
      "0〜5枚を選びます。相手も同時に決め、双方が確定してから交換します。"
    ],
    [
      "Aは二つの使い方",
      "A・2・3・4・5は5が上のストレート。Q・K・A・2・3はつながりません。"
    ],
    [
      "持ち点で決着",
      "100点ずつで始め、5回終わったときに多い側が勝ち。点数に金銭価値はありません。"
    ]
  ],
  "gops": [
    [
      "同じ札でスタート",
      "双方に1〜7、または1〜13の札。使った札は戻りません。"
    ],
    [
      "得点を取り合う",
      "場に出た得点を見て、自分の札を一つ選びます。相手の今回の札は秘密です。"
    ],
    [
      "同時に開く",
      "大きな札を出した側が場の得点を獲得。同じ数字なら、両方の札と得点を使い切ります。"
    ],
    [
      "最後まで考えよう",
      "小さな得点に大きな札を使うと、後で困るかもしれません。最後は合計点で勝負。"
    ]
  ],
  "thirty_one": [
    [
      "同じマークを集める",
      "手札は3枚。4種類のマークごとに足し、一番高い合計があなたの点数です。"
    ],
    [
      "Aは11、絵札は10",
      "Aは11点、J・Q・Kは10点。同じ数字3枚の特別点はありません。"
    ],
    [
      "場と1枚ずつ交換",
      "自分の1枚と場の1枚を選んで交換。場へ出した札は相手にも見えます。"
    ],
    [
      "勝負を仕掛ける",
      "交換の代わりにノックすると、相手に最後の交換チャンスが1回あります。"
    ],
    [
      "31なら即決着",
      "31点になったらすぐに公開。同点は引き分け。長く続いたら20手で比べます。"
    ],
    [
      "この端末だけの短期戦",
      "通常の流派とは一部違うカフェルールです。3回の勝ち数で決めます。"
    ]
  ],
  "baccarat": [
    [
      "二つの側を予想",
      "PLAYER側とBANKER側は手札の呼び名。人間とJevの呼び名ではありません。"
    ],
    [
      "9点に近い方が勝ち",
      "Aは1点、10・J・Q・Kは0点。足した数字の一の位だけを比べます。"
    ],
    [
      "引くかどうかは自動",
      "追加カードは決まったルールで配られます。人間もJevも引き方を変更できません。"
    ],
    [
      "1枚ずつ見て予想",
      "OPENでは各側の最初の1枚が見えます。残りのカードは、人間にもJevにも分かりません。"
    ],
    [
      "当たれば1点",
      "引き分けを当てても1点です。5回の的中数を比べましょう。"
    ],
    [
      "未来は分かりません",
      "毎回新しい山札を使うため、前の勝敗の並びで次が決まるわけではありません。"
    ]
  ]
}
`````

## ファイル：`docs/00_COMMON.md`

<!-- CAFE_CARDS_FILE {"path":"docs/00_COMMON.md","bytes":10390,"sha256":"effa3f67da450f9ad98c3120ead62cb0821b687d3ba5fea8831cff57dad6cadb"} -->
`````markdown
# COFFEE TIME 第6ゲーム — CAFE CARDS
## 4テーブル共通・実装設計書 v1.0.0

**作成・公式資料確認日：2026-09-22／日本語／対象：ESP32-S3-Touch-LCD-2.8C**

> 本書は「ポーカーだけを選ぶ」案ではない。**一つの入口 CAFE CARDS に、POKER・GOPS・THIRTY-ONE・BACCARATの4種類を全部収録する設計**である。各ゲームは最後まで遊べ、遊び方、戦績、中断、結果、再戦まで備える。別々のアプリや、COFFEE TIMEの第7〜9枠に分裂させない。
>
> 本文は振る舞いの正本、付録のJSONは定数・文言・カードIDの正本。矛盾があればテストを止め、一緒に修正する。参考コードはPCで検査したルール／API契約の核であり、実機への書込み済み完成ファームではない。実ESP32、既存Google、実Jevの接続やAIの強さを未試験で保証しない。

## 0. まずエージェントがすること

1. 許可された既存ワークスペースを調べ、LCD・GT911・バックライト・LVGL・BSP・Arduino/ESP-IDF版・保存区画・既存Google通信・ゲーム登録関数を記録する。
2. 元のソース、GAS、シート構成を保全。元の画面とタッチ、コーヒー＋1を再現してから変更する。ライブラリ一括更新、Flash全消去、パーティション変更から始めない。
3. 付録ファイルを取り出し、PC検査を再実行する。その後、共通UIと端末AIで各ゲームを完走させる。
4. 保存・再開・個人/ゲスト・Googleへの記録を接続する。最後にJevを実接続する。
5. 4本それぞれの受入試験を行い、実機ビルド、実機操作、実Google、実Jev、人のプレイ評価を別々に報告する。

**進行中の独断変更は禁止**：ゲームの採用数、31の流派、GOPSの同点処理、ポーカーの上乗せ上限、バカラの点数制度を実装途中に入れ替えない。外部環境が不明なら、純粋ロジックとモックから進め、架空のキー・COMポート・URLで接続成功と報告しない。

### 0.1 継承する確定条件

| 項目 | 継続する条件 |
|---|---|
| 端末 | COFFEE TIME。社内カフェの時計・天気・コーヒーカウンター |
| 基板 | Waveshare **ESP32-S3-Touch-LCD-2.8C**。丸型480×480・タッチ。別型番へ変更しない [S01] |
| 電池・筐体 | 803450・3.7V・1500mAh・1.25mm 2ピン・保護回路付き。B案の折りたたみ、本体内に電池も収納 |
| 入力 | タッチのみ。音声・カメラ・外部キーボード不要 |
| 既存ゲーム | AI ESPER、AI DUEL、CAFE DETECTIVE、CAFE WEREWOLF **3〜10人v2**、JEV REVERSIを保全 |
| Google | 既存のスプレッドシート運用を利用。VPSや新しいDB製品を必須にしない |
| 対戦 | 人間1人対Jev。全4種類を一つの入口から選択 |
| 金銭 | 現金、課金、賭けの入金、換金、景品交換、他人へのポイント譲渡は一切作らない |

ハードの16MB Flash・8MB PSRAMは基板全体の容量であり、ゲームが全量を自由に使えることを意味しない [S01]。既存ファーム、OTA区画、フォント、他ゲームの使用量を実測する。

### 0.2 本書が決める初期仕様

ユーザーの趣旨に沿って未決定部分を閉じる、今回の設計判断である。

| テーブル | v1.0で収録する内容 | 1試合 |
|---|---|---|
| POKER | 5カードドロー、固定額ベット、交換1回 | 5ハンド、100点ずつから開始 |
| GOPS | 7枚版／13枚版を同じコアで選択 | 7回または13回の競り合い |
| THIRTY-ONE | 公開の場3枚と交換するカフェ流派 | 3ハンド、各ハンド通常20手まで |
| BACCARAT | OPEN／CLASSICを同じ配布ルールで選択 | 5ラウンドの予想勝負 |

上記を「すべて既存競技の公式ルールそのまま」と説明しない。特にポーカーの点数上限、GOPSの得点破棄、31の同点・終了、OPENバカラは本アプリの明示的な調整である。

### 0.3 盛り込むものと、入れないもの

盛り込む：4種類の異なる判断、操作式チュートリアル、意味のある結果表示、ゲーム別記録、再戦、秘密保護、障害からの復旧。

入れない：現金、チップ購入、共通財布、公開人別ランキング、確実に勝てる宣伝、AIが実際には選んでいない演出、カードの後からの差替え、カードゲーム同士の人物評価の合算、長い強制演出、終了を妨げる連続ログイン報酬。

「盛り盛り」は機能の分量ではなく、4種類をそれぞれ成立させ、初心者が迷わない仕上げを意味する。

## 1. 一つのアプリとしての全体像

```text
COFFEE TIME / GAME
  1 AI ESPER
  2 AI DUEL
  3 CAFE DETECTIVE
  4 CAFE WEREWOLF (3〜10人)
  5 JEV REVERSI
  6 CAFE CARDS
       ├ POKER
       ├ GOPS → 7 / 13
       ├ THIRTY-ONE
       └ BACCARAT → OPEN / CLASSIC
```

`app_id=cafe_cards`、`game_id=poker|gops|thirty_one|baccarat`。設定キーは `ct_cards` 以下。他ゲームのID・保存キーを変更しない。

開始フロー：テーブル → 自分/ゲスト → バリエーション（必要な2ゲームだけ）→ 対戦相手Jev/端末AI → 開始。チュートリアルはどこからでも一度戻れる。前回の選択を覚えてよいが、前の人のプロフィールを自動ログインしない。

端末AIは各ゲームで最後まで動く参考対戦相手。「オフラインのJev」とは呼ばない。Jevに接続できない場合は明示して本人に選ばせる。途中切替は試合の残り全部を端末AIにし、自動でJevへ戻さない。結果は `mixed` とする。

## 2. 雰囲気・言葉・報酬

喫茶「余白」の小さなテーブルが舞台。実在のカジノのロゴ、カード裏、UI、人物画像を流用しない。Jevの人間らしい長文生成は不要で、状況IDに対応する短い文章を表示する。

| 状況 | 使う文章例 | 避ける説明 |
|---|---|---|
| ポーカーで相手が降りる | 「相手が降りました。場の持ち点を獲得。」 | 非公開手を根拠に「ブラフ成功率90%」 |
| GOPSで小さい札が勝つ | 「3の札で8点を獲得。」 | 内部の想像を「AIを完全に操った」 |
| 31の最後の交換で逆転 | 「最後の交換で29点に。今回はあなたの勝ち。」 | 偶然を確実な技量とする説明 |
| バカラの予想が一致 | 「今回は、同じ予想です。」 | 人間の予想に合わせてAIの回答を変更 |

「判断の内訳」は任意。Jevが返した確率は行動への相対的な選択値であり、その行動の勝率や最適な混合戦略ではない [S02]。勝率は実際の完了試合の数から別計算する。`confidence`も勝率の別名にしない。

通常は200〜450ms程度の短いカード表示を使う設計値とし、低動作モードは即時切替。画面を進めるための無意味な待ち時間や、何度も音を鳴らす演出は作らない。対戦中に履歴やヒントを見ても時計で負けにしない。

## 3. 共通カードモデル

物理カードIDは `copy*52 + suit*13 + (rank-2)`。

- `suit=0:C, 1:D, 2:H, 3:S`、`rank=2..14`、14がA。
- 通常1組は0〜51、8組のバカラは0〜415。見た目が同じでもcopyが違えば別の物理カード。
- ジョーカーなし。ポーカー/31で同じ物理カードを重複保持しない。
- 52枚の全ID・表示・各ゲームの点数は `data/cards.json`。
- GOPSは通常カードのrankと**別の1〜Nのトークン**。Aを14として比較してはいけない。画面も1〜13の数字表示とし、13は必ず1より強い。

常に「ルール上のスロット」と「画面上の位置」を区別する。手札を自動ソートして交換対象の番号を変えない。並べ替えを将来追加するなら、画面位置→固定slot_idの表を保持する。

## 4. 配布と秘密情報の責任分離

### 4.1 信頼するもの・守れる範囲

ゲームの真の状態と山札はESP32に保持する。本アプリは会社内の娯楽で、改造された端末や管理者から秘密を守る競技サーバーではない。ファーム改変、物理Flash読出し、既存アカウントの乗っ取りに対する完全な不正防止を保証しない。

一方、通常の利用では次を守る。

1. UIは人間に公開してよいビューだけで描く。
2. Jevと端末AIは、相手として知ってよいビューだけで選ぶ。
3. 山札・未来の札・相手の秘密・未公開の選択をモデルに送らない。
4. Googleへはモデルに必要なAI自身の手札と公開状態を一時送るが、デバイスの全状態・山札は送らない。
5. 過去の人間の手札は、実際にショーダウンで公開されたときだけ利用できる。フォールドしたハンドの手札を学習データへ混ぜない。

### 4.2 同時と逐次の違い

| 機会 | 決定順序 |
|---|---|
| ポーカーのベット | 手番順。相手の直前の公開ベットを見て判断してよい |
| ポーカーのカード交換 | AI交換選択を確定→人間が確定→双方の交換枚数を公開→交換実行 |
| GOPSの競り札 | AI札を確定→人間が確定→同時公開。途中の人間の選択は送らない |
| 31の交換/ノック | 手番順。相手の公開された交換後の場を見て判断してよい |
| バカラの予想 | 未来の配布順を先に固定→AI予想確定→人間確定→両予想と残りカードを公開 |

同時選択は、人間が仮選択してもその値をネットワークに送らない。AIの応答が来る前は確定ボタンを無効にする。UIは「相手の選択は確定済み」と示すが、未確定中にその表示を出さない。

`private_state`を作って後から秘密キーを削除する方式ではなく、`makeObservation()`が新しいオブジェクトへ許可フィールドだけをコピーする。将来内部フィールドが増えても漏れないことを差分テストする。
`````

## ファイル：`docs/01_POKER.md`

<!-- CAFE_CARDS_FILE {"path":"docs/01_POKER.md","bytes":9573,"sha256":"06e37d32355440ad37946784d593d0db8a490c03ffb475196e72af6443a60acb"} -->
`````markdown
# 第I部 — CAFE POKER
## 5枚の手札と、相手の強気を読む

## P1. 採用する流派と一試合

5カード・ドローを土台とし、交換前後に一度ずつベット段階を設ける [S03]。本アプリは以下の**固定5ハンド・仮想持ち点制**へ調整する。役判定は標準的なハイポーカーの序列に合わせる [S04] が、競技カジノの賭け・ブラインド・オールインを再現するものではない。

| 条件 | 確定値 |
|---|---|
| ID / variant | `poker / fixed5` |
| 参加者 | 人間H、Jevまたは端末AIのA |
| 試合の長さ | 必ず5ハンド。途中終了は中止で、残りを自動敗北にしない |
| 最初の持ち点 | 双方100。5ハンド間は持ち越し、再戦時は100へ戻す |
| 各ハンドの開始 | 新しくシャッフルした52枚、双方1点の参加点を場へ |
| 配る枚数 | 各5枚。ディーラーでない側から交互に1枚ずつ |
| カード交換 | 0〜5枚を一度だけ。双方の選択が確定してから実行 |
| 交換前の単位 | 2点 |
| 交換後の単位 | 4点 |
| 上乗せの上限 | 各ベット段階で2回。最初のBETは上乗せ回数に含めない |
| 最終勝敗 | 5ハンド後の持ち点。多い側の勝ち、100対100なら引き分け |

ディーラーは開始時に一度抽選し、その後のハンドで交互にする。**配布・交換・ベット先手はいずれも非ディーラー**という本アプリの規則で統一する。初期配布の途中で山札を引き直さない。交換前に降りたハンドでは、交換後のステージを作らず次のハンドへ進む。

## P2. 「持ち点が足りない」を構造的に防ぐ

ベット段階一つについて、最終的に双方が払う上限は `単位×(最初のBET1回＋RAISE2回)`。

```text
1ハンドの自分の拠出上限 = 参加点1 + 交換前2×3 + 交換後4×3 = 19
5ハンドで全て失った場合 = 19×5 = 95
最初の100 − 95 = 5
```

第5ハンド開始前でも24点以上残るため、合法な拠出19点を支払える。これが、オールイン・サイドポット・不足分補充・チップ購入を不要にする根拠である。試合を6ハンド以上へ勝手に拡張すると保証が変わる。

不変条件：`Hの残点 + Aの残点 + pot == 200`。`pot<=38`。値は非負整数。ポットは解決時に全額を移動し0へ戻す。途中の表記は「場の持ち点」であり、現金換算を表示しない。

## P3. 合法な全ベット行動

`street_paid[2]`はこのベット段階だけの拠出額。参加点と前段階の拠出を混ぜない。`owed=max(street_paid)-street_paid[actor]`。

| 状態 | 行動ID | 日本語 | 支払い・遷移 |
|---|---|---|---|
| owed=0 | CHECK | 追加せず続ける | 0点。双方続けてCHECKなら段階終了 |
| owed=0 | BET | 2点出す／4点出す | unit点。相手の反応待ち |
| owed>0 | FOLD | 降りる | 0点。相手が場を獲得してハンド終了 |
| owed>0 | CALL | 同じ額で勝負 | owed点。拠出を一致させて段階終了 |
| owed>0かつraises<2 | RAISE | さらに上乗せ | owed+unit点。raisesを1増加し相手へ |

owed=0のときにFOLD、owed>0のときにCHECKは不可。上乗せ2回後のRAISEボタンは消す。ベット金額のテンキーは作らない。チェック後に相手がBETした場合、チェックした側はFOLD/CALL/RAISEから反応できる。

例（交換前）：H CHECK → A BET2 → H RAISE4（差額2＋上乗せ2）→ A RAISE4 → H CALL2。段階終了時は双方6点拠出である。最後のCALLをさらに相手の手番へ回してはいけない。

## P4. カード交換の全32選択

固定slot0〜4に対してbitを立てる。`mask=0`は交換なし、31は全部交換。例えば`mask=5`はslot0とslot2を交換する。全選択は`data/poker_draw_choices.json`にある。

1. 交換段階へ入る前の状態を保存する。
2. JevへAI自身の5枚と公開履歴を渡し、`DRAW:0`〜`DRAW:31`から選ばせる。
3. 応答検証後、AIのmaskとdecision_idを保存する。まだ人間へ枚数を見せない。
4. 人間の仮選択は端末内だけ。独立した「交換する」で確定する。0枚の場合も「交換しない」を確認する。
5. 両mask確定を一つのゲーム更新として保存。ここで初めて双方の枚数を公開する。
6. 非ディーラーのslot昇順、ディーラーのslot昇順で、山札の次の札と交換する。捨て札は今回の山札へ戻さない。バーンカードなし。
7. 交換後ベット段階へ。先手は再び非ディーラー、unit=4、paidとraisesとchecksを初期化。

最大でも初期10枚＋交換10枚＝20枚しか使わない。全交換でも山札不足は起きない。再送や電源復旧でmaskや配布順を再抽選しない。人間の交換札の種類は相手へ非公開で、枚数だけが公開情報。

## P5. 役の序列と同役比較（弱い順）

`PokerValue.key`は6整数で、左から辞書順比較する。末尾の不要要素は0。

| category | 役 | 比較キー（categoryの後） |
|---:|---|---|
| 0 | ハイカード | 5枚のrank降順 |
| 1 | ワンペア | ペアrank、残り3枚降順 |
| 2 | ツーペア | 大きいペア、小さいペア、残り1枚 |
| 3 | スリーカード | 3枚組rank、残り2枚降順 |
| 4 | ストレート | 一番大きいrank。A2345だけ5扱い |
| 5 | フラッシュ | 5枚のrank降順 |
| 6 | フルハウス | 3枚組rank、ペアrank |
| 7 | フォーカード | 4枚組rank、残り1枚 |
| 8 | ストレートフラッシュ | 一番大きいrank。10JQKAは14 |

ロイヤルフラッシュはcategory8/high14の表示名で、独立の勝敗カテゴリではない。A2345は有効、QKA23など循環は無効。スートの優劣はなく、完全同キーなら同役引き分け。CALLか両CHECKでショーダウンしたpotは、双方の拠出が一致しているため偶数であり、半分ずつ分ける。

役の一覧は、自分の手札へ特別な操作をせず閲覧できる。表示は日本語＋実際の5枚。単なる推定ではなくコード判定。`poker_compare()`がinvalid=-2を返したら中止・破損扱いとし、AI勝ちへ落とさない。

## P6. 状態と画面

```text
HAND_START → DEAL → BET_PRE → (FOLD→HAND_RESULT)
                         ↓両CHECK/CALL
                  DRAW_AI_PREPARE → DRAW_HUMAN_CONFIRM
                         ↓双方確定
                    DRAW_RESOLVE → BET_POST
                         ↓FOLDまたはSHOWDOWN
                    HAND_RESULT → 次ハンド / MATCH_RESULT
```

カード5枚は同一行で固定し、選択札に枠と「交換」の小バッジを付ける。表面の5枚そのものを右左へスワイプして押し間違える作りにはしない。開始・現在段階・ハンド番号・残点・場の点を見られる。相手のカードはショーダウンまで裏向き。

結果：獲得pot、両者の残点、公開可能なら双方の役、勝敗理由。フォールドで終わった場合は両者の札を非公開のままにする。ゲーム管理者が内部の札を知っていても、結果文章から間接的に公開しない。

Jevの行動内訳はハンド終了後にだけ閲覧可能。**フォールドで終了したハンドでは確率内訳も非表示**とし、行動と点数だけを見せる。確率から相手の隠れた役の強さを推定する補助情報を不必要に与えない。通常画面で「AIはフルハウスを狙っています」等を創作しない。

## P7. Jevと端末AI

Jevの入力：自分の5枚、計算済みの役キー、自分の捨て札、両残点、場、段階の拠出、合法行動、双方確定後の交換枚数、公開の行動履歴、同意済みの個人傾向。相手の現在5枚、非公開捨て札、交換前の相手mask、山札順は除外する。

モデルへの目的は「5ハンド後の持ち点を増やすため合法な行動を一つ選ぶ」。強さ、ブラフ頻度、理論最適性を保証しない。`Choice`の確率をそのまま実勝率や最適ランダム戦略としない [S02,S05]。

端末AI v1は第V部の固定ポリシー。交換時は役を壊さない手順、ベットは役ランクと保存済みの乱数で行動する。高度な未知札全探索は必須にしない。強い相手ではなく通信なしで完走できる比較基準として評価する。

個人傾向は公開された行動だけから集計する。特に`FOLD/facing_bet_opportunities`と`(BET+RAISE)/aggressive_opportunities`を区別する。「降りる機会が0」なら0%とせず、データ不足。サンプル20未満は「傾向を観察中」と表示する。本人の他ゲームの性格推定は混ぜない。

## P8. このゲームの受入ポイント

全役判定、キッカー、ホイール、同役、フォールド、チェック→BETへの反応、最大上乗せ、全交換、0枚交換、dealer切替、5連敗しても合法支払い可能、手札非漏洩、2回押しで2回交換しないことを試験する。

遊びの評価は「相手の交換枚数やベットが判断材料になったか」「最大3ボタンの意味が理解できたか」「負けても自分の選択を振り返れたか」。勝率だけで合否を決めない。
`````

## ファイル：`docs/02_GOPS.md`

<!-- CAFE_CARDS_FILE {"path":"docs/02_GOPS.md","bytes":5494,"sha256":"e2c6728fdbcbeb2e274d7a68ea7d5f51d35a50c5ab747e7fd0e0c37b925d2cb7"} -->
`````markdown
# 第II部 — GOPS
## 切り札を出すのは、今ですか？

## G1. 採用ルール

両者が同じ数値の札を持ち、公開された得点札を秘密の入札で取り合うGOPSを土台とする [S06,S07]。本書は同点の得点を**破棄**する流派に固定し、持越しや累積オークションを混ぜない。

| variant | 手札 | 得点札 | ラウンド数 | 総得点プール |
|---|---|---|---:|---:|
| quick7（初期） | 各1〜7 | 1〜7を一度シャッフル | 7 | 28 |
| classic13 | 各1〜13 | 1〜13を一度シャッフル | 13 | 91 |

A/J/Q/Kのトランプ記号を強さに誤解させないよう、ゲームの札は1〜Nをそのまま表示する。札13は強いが、それを使った回の獲得点は**場の得点札**であり、必ず13点を得るわけではない。

## G2. 一回の全処理

1. 山の次の得点札を一枚だけ公開。未来の順番はどちらにも渡さない。
2. AIに、自分の残札・人間の残札・現在得点・公開済みの入札履歴を渡す。
3. AIの札を確定・保存してから、人間の確定ボタンを有効にする。未確定の人間の仮選択を送らない。
4. 人間が未使用札を選択し「この札で勝負」で確定。確定した札は変更不可。
5. 双方を同時公開。大きい札を出した側に得点札の点を加算。同じ数字なら誰も加点せずburnedへ。
6. 両方の札を残札から除外。勝ち札だけ除外するのではない。
7. N回後に得点を比較。等しければ引き分け。追加戦や残点比例補正はしない。

最後の残札が一枚ならAIは強制選択し、Jevを呼ばない。`provider=forced`で記録する。人間側は自動進行せず本人が確定する。

## G3. 具体例と不変条件

quick7で現在の得点札6。Hが5、Aが3ならHに6点。双方の5と3は消費される。次が得点2で双方2を出したら、2点は破棄。次の回へ上乗せしない。

不変条件：

```text
Hの得点 + Aの得点 + burned = 公開・決着済みの得点札の合計
両者の残札の枚数 = N - 決着した回数
両者の残札には重複なし、各値は1..N
```

得点札の順番は1..Nの順列。終了後の札順一覧は見せてよいが、進行中の未来部分は画面・ログ・Jevに出さない。同じ得点札が再び出たら再送の二重反映か破損であり、正常な追加ラウンドとして扱わない。

## G4. 状態・UI・公開記憶

`PRIZE_REVEAL → AI_PREPARE → HUMAN_SELECT → SEALED → REVEAL_SCORE → NEXT / RESULT`

13枚を一行に縮めない。未使用札を小さい順に**4枚ずつページ表示**し、1〜4ページを移動する。候補ボタンの大きさは7枚版と共通。仮選択はページ変更で失わないが、選んだ数字は中央の確認文にも出す。別の「決定」が必要。

「残り札」画面は双方の全未使用数字を表示する。公開済みの札を覚える記憶競争にしない。過去の行は「得点6／あなた5／相手3／あなた+6」と簡潔にする。現在の未公開入札は履歴へ先に加えない。

人間が仮選択中にAPIが返っても自動確定しない。カフェへ戻る場合は選択ドラフトを保存して一時停止。既に確定したAI札を別の札に置き換えない。

## G5. Jevの判断と履歴

全合法候補 `PLAY:1`〜`PLAY:N` のうち残っているものだけを渡す。現在得点札、残札両者、現在スコア、過去の対局で公開された最大26入札を材料にする。プレイヤー名、他ゲームの履歴、次の得点札は送らない。

目的は各回の勝率ではなく、N回終了時の合計得点。弱い得点札で強い札を消費することの機会費用も指示へ含める。ただしゲーム理論的な最適戦略と断定しない。

履歴は同variantだけ。個人の傾向を長期保存する場合も、得点札の低/中/高と使用札の低/中/高の件数、公開済みの直近26組に限定する。「いつも弱気」といった人格表現は出さない。

端末AIは、得点の順位に近い自分の残札を基準に、保存済み乱数で隣の札も選ぶ軽量方針（第V部）。人間の今回の選択を見るローカルAIは不適合。

## G6. 実装時の注意

参考`Gops::choose()`は双方確定した呼出し内で集計し、sealedを空にして次へ進む。コントローラーは呼出し前の得点札・先にsealedしたAI札・人間札をイベントへ退避し、一度だけ`RESOLVE`記録を作る。モデルの返答処理から直接2回`choose`を呼ばない。

同時選択は端末内の相手札を直接読めば破れる信頼モデルであり、悪意ある改造ファームからの保護を保証しない。通常アプリの情報分離と時系列は自動試験する。

## G7. 受入ポイント

7・13の全ラウンド、同点破棄、残札の双方除去、連続同点、最終同点、先にAIを確定、強制一札で課金なし、4枚ページの13枚目、前のラウンド応答の無視、独立した新試合の得点順生成。

プレイ評価は「次のために札を残したいと感じるか」「残札を見返せるか」「同点で得点が消える理由が分かるか」。単に毎回最大札を押すゲームになっていないかも確認する。
`````

## ファイル：`docs/03_THIRTY_ONE.md`

<!-- CAFE_CARDS_FILE {"path":"docs/03_THIRTY_ONE.md","bytes":7448,"sha256":"683735114d1129f9bffc02749794e9a193c65c0a3010dad319011d809af3116c"} -->
`````markdown
# 第III部 — THIRTY-ONE
## もう一枚待つか。今、勝負するか。

## T1. 採用するのは「場の3枚と交換する」流派

サーティワンには複数の遊び方がある。本書は、手札3枚と公開の場3枚を使うBicycleの紹介を土台に [S08]、短時間向けに次の**market3カフェルール**を固定する。山札から毎ターン引く流派、捨て札山、3枚組30.5点、スートによる同点判定を混ぜない。

- 人間1人とAI、手札3枚ずつ。場の3枚は双方が見て交換できる。
- 新しい52枚をハンド開始時にシャッフル。先手から交互に3枚ずつ配り、続く3枚を場へ。
- 同じスートの合計を計算し、4スートのうち最大の値が手の得点。
- A=11、J/Q/K=10、2〜10は数字。3枚しかないので最大31点。
- 1試合3ハンド。ハンド勝利1点、引き分けは双方0点。最終の勝ち数を比較。
- 先手を試合開始時に抽選し、ハンドごとに交互にする。

残り43枚はそのハンドでは使用しない。場の札が弱いからと勝手に交換・補充しない。

## T2. 得点・同点の全例

| 手札 | 得点・意味 |
|---|---|
| SA・SK・H7 | スペード21、ハート7 → 21 |
| SA・SK・S9 | 30 |
| SA・SK・SQ | 31。直ちに終わる |
| C7・D7・H7 | 7。3枚組の特典はない |
| C10・DJ・HQ | 10。スートが違うので30ではない |
| SA・S9・H2 vs HA・H9・D3 | 両方20で引き分け。残りの別スートの札で差をつけない |

本アプリの同点は常に引き分け。参照資料の一部にある高札比較や初期ノックの特例は採用しない、と遊び方にも明記する。

## T3. 通常ターンの全行動

| ID | 操作 | その後 |
|---|---|---|
| `SWAP:i:j`（i,j=0..2） | 自分のslot iと場のslot jを1対1交換 | 31になれば即終了。それ以外は相手へ |
| `KNOCK` | 交換せず「ここで勝負」を宣言 | 相手が最後に1回、交換またはそのままを選ぶ |

通常ターンにSTAND（パス）はない。ノックしながら交換する、2枚まとめて交換する、場を全部取り替える操作はない。

ノックを受けた相手の最後の行動は `SWAP:i:j` 9通りまたは `STAND` の10通り。再ノックは禁止。交換をしてもしなくても、その後は手札公開して終了。ノックした人がもう一度交換できるようにしない。

## T4. 終わる順序・20手制限

1. 初期配布直後に双方の得点を確認。どちらかが31なら、最初の手番前に両手札を公開して終了。両方31なら引き分け。
2. 交換で31ができたら、他の条件より先に即終了。相手の追加ターンはない。
3. ノック後の最後の応答なら比較して終了。
4. 通常行動が20に達した交換なら、その手の後に比較して終了。
5. **20手目がノックなら、21手目の最後の応答を一度だけ許す。** ノックを選んだだけで即終了に変えない。

`turn_count`は両者合計の確定行動数。表示ページ移動・仮選択・ヒント閲覧では増えない。ハンドは必ず最大21行動以内に終了する。人間の読書や考える時間に制限を付けるものではない。

端末AIとの循環交換で無限に続くことを防ぐためのカフェ独自ルール。20手目前は「あと1手で比べます。ここで勝負を選ぶと相手に最後の1手」と正しく表示する。

## T5. 公開された札の記憶

場から取った札は公開情報であり、あとからその人の手にあることを推測できる。アプリはこれを両者へ同等に表示する。

`known_cards[actor]`は、公開の交換により今もその人が持っていると分かる札の集合。

```text
交換前の手から出した札 out を known_cards[actor] から除く
場から取得した札 in を known_cards[actor] に加える
```

初期手札は空集合。例えばAIが場からSAを取れば人間側に「相手が持つと分かっている札：SA」。AIが後でSAを場へ戻せば表示から消す。3枚とも公開交換で判明した場合は、3枚全部を知っていてよい。逆に内部の本当の手札を見てknownを補完してはならない。

HとAの本当の手札、場の合計9枚には同じ物理札がない。knownは各手札の部分集合で最大3。私的手札と公開既知集合を混同しない。

## T6. 状態・画面・選択

```text
DEAL → 初期31判定 → TURN
                    ├ SWAP → 31 / 最終手 / 上限 / 相手TURN
                    └ KNOCK → LAST_REPLY → 比較
                  HAND_RESULT → 次ハンド / MATCH_RESULT
```

通常画面は上段「場の3枚」、下段「あなたの3枚」。自分の札→場の札をタッチして枠を付け、「交換する」で確定する。順序を逆にタッチしても内部slotを保って選択できる。確定までは何度でも選び直せる。

「ここで勝負」は別の操作から確認画面を開く。通常SWAPの確定ボタンとノックを同じタッチ領域で入れ替えて誤操作を誘わない。最後の応答は「交換する／このまま比べる」。得点と同スートの強調は人間の手だけ表示する。相手の最終得点は公開前に出さない。

結果には双方3枚、同スート合計、終わった理由（31・ノック・20手）、当ハンドと3ハンドの成績を表示する。

## T7. Jev・端末AI・個人傾向

Jevへは自分の3枚と得点、公開場、相手の公開既知札、手番数、最終応答か、公開交換履歴、個人のノック/交換傾向を渡す。相手の未知札・未使用の山は送らない。各SWAP候補の説明には入れ替える具体札を付ける。文字画像を読ませず構造値を使用する。

端末AIは可能な9交換を実際に評価し、最高得点を選ぶ。同得点はi,j昇順。通常は現在27以上または改善する交換なしならノック、それ以外は最高得点交換。最後の応答では厳密に点数が改善するなら交換、改善しなければSTAND。これは固定の比較基準であり「最強」ではない。

通常20手目前に局面からノックが合法であることを保持する。評価関数の都合でノックを拒否しない。モデルがKNOCKを返しても、実は最終応答だったら不正応答として止める。

統計は本人の通常ターンのSWAP数・KNOCK数、最後の応答のSWAP/STAND、平均ノック時点（公開手番数）を別に持つ。公開されていない相手の手の点数を使って「弱いのにノックした」と人物評価しない。

## T8. 受入ポイント

全22,100通りの3枚の手を得点検査。31の初期・交換後、双方31、同点、スート混在、3枚組ボーナスなし、20手目交換、20手目ノック＋21手目応答、通常STAND拒否、再ノック拒否、公開既知札の削除、3ハンド先手交代、中断時の選択枠リセットを確認する。

遊びの評価は「場と自分の札を取り違えないか」「ノックの意味が分かるか」「点数が合う理由が見えるか」。ポーカーの用語を使い回して理解を妨げない。
`````

## ファイル：`docs/04_BACCARAT.md`

<!-- CAFE_CARDS_FILE {"path":"docs/04_BACCARAT.md","bytes":7131,"sha256":"ab5e21e6d1e8757c92b85659d0c24295227e279cd7cff17b747d182dc9efe589"} -->
`````markdown
# 第IV部 — CAFE BACCARAT
## あなたとJev、同じ予想ですか？

## B1. プレイヤーとバンカーは「手札の側」の名前

本アプリのバカラはプント・バンコの配布・追加札条件を使う [S09,S10]。**PLAYER側＝人間、BANKER側＝Jevではない。** 人間もJevも同じ二つの手札の勝敗を予想する。AIが任意に札を引いたり止めたりするゲームではない。

| variant | 人間とJevが予想前に見るもの |
|---|---|
| OPEN（初期） | PLAYERの1枚目とBANKERの1枚目だけ |
| CLASSIC | 札は一枚も見ない |

OPENはカフェ独自の一部公開ルール。両方とも賭け金・配当率・バンカー手数料・高倍率のサイドベットは実装しない。**予想が当たれば1点、外れれば0点、5回で比較**する。引き分け予想の的中も1点。両者同じ予想をしてよく、両方的中なら双方+1。

## B2. 山札と点数

各ラウンドごとに新しい8組416枚を公平にシャッフル。ラウンド内では引いた札を戻さない。連続シュー、途中のカットカード、バーンカードは使わない。5回戦全体で一つの416枚から配り続ける、と勝手に変えない。

A=1、2〜9は数字、10/J/Q/K=0。手の点数は合計の一の位。7+6=3、9+9=8。スートは点に関係ない。カードIDはcopyを含んで区別し、例えば同じスート・数字の2枚が違うcopyから出るのは合法。

## B3. 配布順と終了判定

最初の4枚は必ず `P1, B1, P2, B2`。最初の2枚ずつの合計点を計算する。

- **どちらかが8または9ならナチュラル。両方とも追加札なしで比較。** 片側だけさらに引かせない。
- それ以外でPLAYERが0〜5なら3枚目を引き、6〜7なら止める。
- PLAYERが止めた場合、BANKERは0〜5なら引き、6〜7なら止める。
- PLAYERが引いた場合、BANKERは下表に従う。

### BANKERの追加表

列はPLAYERの**3枚目そのものの値**であり、PLAYERの最終合計ではない。○=引く、−=止める。

| BANKERの初期合計 | P3=0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 |
|---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| 0 | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ |
| 1 | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ |
| 2 | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ |
| 3 | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | − | ○ |
| 4 | − | − | ○ | ○ | ○ | ○ | ○ | ○ | − | − |
| 5 | − | − | − | − | ○ | ○ | ○ | ○ | − | − |
| 6 | − | − | − | − | − | − | ○ | ○ | − | − |
| 7 | − | − | − | − | − | − | − | − | − | − |

8/9の行はナチュラルで先に終了するため表の処理へ入らない [S09,S10]。

PLAYERが引いた場合、5枚目がP3、BANKERも引けば6枚目がB3。PLAYERが止めBANKERだけ引く場合は、**5枚目がB3**であって6枚目へ飛ばない。最後に一の位同士を比較し、同数ならTIE。

参考コードは6枚の候補ストリームを受けるが、`used=4..6`で実際に使った枚数を返す。未使用の札を結果画面へ見せない。次ラウンドは新しい416枚に戻すので、未使用候補を次回の先頭へ回さない。

## B4. 公平な予想と進行

```text
ROUND_START（山札順を固定・保存）
 → OPENならP1/B1表示、CLASSICなら裏向き
 → AI_PREDICT（予想確定・保存）
 → HUMAN_PREDICT（選択と確認）
 → 予想双方公開
 → 残りの札を順番に表示、規則で追加
 → 得点・説明
 → 次ラウンド / MATCH_RESULT
```

AIにはPLAYER/BANKER/TIEの3候補しか与えない。未来の4〜6枚の候補、残り山、実際の勝敗、人間が今回選ぼうとしている側を送らない。OPENの公開1枚だけでナチュラルを判定してはいけない。2枚合計が必要である。

Jevの出力に合わせて山札やカードを変更しない。同じ相手予想を嫌って逆へ変えない。Jevの確率は人間の予想が確定するまで隠し、確定後に任意表示する。

## B5. 端末側の計算予想

`data/baccarat_probabilities.json`には、毎回新しい8組・ラウンド内非復元抽選という条件で、公開1枚ずつの値10×10組と非公開CLASSICの正確な組合せ計算結果を収録する。

生成器は各値の枚数を0値128枚、1〜9各32枚として、6位置の値列1,000,000通りを非復元抽選の重み付きで列挙する。実際に4枚で終わる局も、残り2位置について合計すると同じ確率へ戻る。単に1,000,000個を同じ重みで平均したものではない。

| 条件 | PLAYER | BANKER | TIE |
|---|---:|---:|---:|
| CLASSIC | 0.44624660934217 | 0.45859742263134 | 0.095155968023625 |
| OPEN：P1=7、B1=2 | 0.51468709057041 | 0.38318723677965 | 0.10212567264997 |
| OPEN：P1=2、B1=7 | 0.37159966361307 | 0.52673498380874 | 0.10166535257823 |

これらは**プログラムで算出した値**で、Jevの実測や、実カジノの払い戻し率ではない。計算には採用した追加札条件を使う。端末AIは該当3値の最大を予想し、完全同率ならPLAYER→BANKER→TIE順。毎回新しく山を作るので、CLASSICで同じ予想が続いても正常である。

Jev対戦では、この正解側の計算表をモデルに渡さない。Jevの予測と計算基準を比較するためである。計算表を使用したモードは「計算予想」と明示し、Jevがその数値を出したように表示しない。

## B6. 履歴と見せ方

毎回新しい山なので、過去のP/B連続や人間の癖は次回の札の原因にならない。Jevへ過去の勝敗列・個人予想傾向を送って「流れを読んで勝つ」とは説明しない。

記録は試合勝敗と的中数、OPEN/CLASSIC別、対戦相手別。予想当たり率の母数は完了した予想ラウンド。5回の勝敗だけでモデルの優劣を証明しない。「TIEが出そうだから点を多く賭ける」等の機能もない。

最大3枚ずつのカードは2段。数字・マーク・一の位の合計を大きく表示。「引いた理由」は短く、例えば「PLAYERは4点なので、3枚目を引きます」。この理由は規則から作り、Jevの自由文ではない。

## B7. 受入ポイント

片側のみナチュラル、両側ナチュラル、PLAYER停止時のBANKER5点、B3のP3=8だけ停止、B4/B5/B6の境界、5枚目の行先、同じ見た目の別copy、同物理ID重複拒否、予想三択の全9組×実結果3組、両者同予想、TIE的中1点、OPEN/CLASSICの情報分離を確認する。

楽しさの評価は「結果までが長過ぎないか」「PLAYER/BANKERを人間/AIと混同しないか」「今見えたカードが次で変わる期待感があるか」。判断を変えて展開を操作するゲームではないことを、他3本と区別する。
`````

## ファイル：`docs/05_IMPLEMENTATION.md`

<!-- CAFE_CARDS_FILE {"path":"docs/05_IMPLEMENTATION.md","bytes":39927,"sha256":"77fef45e9c16e7e14b0de624f4967489fcca3283b5e40f7f5c3d13ca65445274"} -->
`````markdown
# 第V部 — 共通実装・通信・復旧マニュアル

## I1. モジュール構成と責任

```text
既存COFFEE TIME
 ├ AppRegistry / CoffeeCounter / Clock / Weather / 既存5ゲーム
 └ CafeCardsApp
     ├ Menu・IdentityAdapter・Tutorial・ResultUI
     ├ CardsController（状態変更の唯一の入口）
     ├ PokerMatch / GopsMatch / ThirtyOneMatch / BaccaratMatch
     ├ RulesCore（純粋なルール）
     ├ HumanView / AIObservation（秘密を分離）
     ├ LocalPolicy / JevDecisionClient
     ├ SnapshotStore / PublicEventWriter
     └ ExistingGoogleTransportAdapter
            ↓ HTTPS
         GAS cafe_cards router
           ├ 既存IdentityAdapter・端末認証
           ├ strict observation gate・Jev HTTP
           ├ 決定予約／結果の冪等処理
           └ 非公開GoogleゲームWorkbook
```

`RulesCore`へLCD、Wi-Fi、時刻、乱数の初期化、Google書込みを持ち込まない。乱数列を外から注入して、同じ入力なら同じ結果にできる。付録のC++はこの層の参考実装。UIアプリ・永続化アダプター・GAS全業務処理は本章の契約に従って既存環境へ組み込む。

参考実装の公開structを本番の任意書込みAPIにしない。外部イベントは検証したコントローラーだけが変更する。内部のゲーム状態を公開JSONレスポンスへ丸ごとserializeする関数を作らない。

## I2. 基板・LVGLを壊さない導入

2.8CはLCDとタッチが既に基板上で接続されている。追加のGPIO配線をゲームのために行わない。既存の表示が動いているなら、BSPの初期化、GT911用I²C、I/O拡張、RGB/PSRAMの設定をそのまま使用する [S01]。

既存LVGLが8なら8を継続し、9へ一括移行しない。既存のUIロック/タイマータスクへゲームを追加する。LVGLは通常の並列アクセスに自動で安全になるものではないため、UI所有タスクとロック方針を一本化する [S22]。長いHTTP待ちをUIタスクやLVGLロック中に実行しない。

ポインター→カードslot変換は `LV_EVENT_CLICKED` 等の確定イベントへ接続し、押している間に繰り返すイベントで何度も配布・交換しない [S23]。スクロールで指が外れた操作をクリックと誤認しない。プレスした画面のgenerationとリリース時のgenerationが違ったら破棄する。

## I3. コントローラー状態とイベントの全体

共通state：`MENU, IDENTITY, SETUP, TUTORIAL, DEALING, HUMAN_SELECT, AI_PENDING, SEALED_WAIT, REVEAL, HAND_RESULT, MATCH_RESULT, PAUSED, RECOVER_AUTH, ERROR`。

ゲーム固有phaseは以下。

| game | phase |
|---|---|
| poker | bet_pre / draw / bet_post / hand_result |
| gops | bid / round_result |
| thirty_one | turn / last_reply / hand_result |
| baccarat | predict / round_result |

共通event：`SelectGame, SelectVariant, BeginMatch, SelectCard, SelectAction, Confirm, ProviderReply, RetryPoll, ChooseLocal, AnimationDone, NextHand, Pause, Resume, AbortConfirmed, Reauthenticate, StorageFailed`。

端末内では `match_id, revision, ui_generation, decision_id` を全イベントへ結び付ける。revisionは状態が確定するごとに増加し、同じGUIの古いボタンが二度操作しても二重反映しない。

### 更新のパターン

```cpp
// 組込み時の構成例。実プロジェクトの型とエラーハンドラへ接続する。
Result CardsController::confirm(const ActionEnvelope& e) {
    if (e.match_id != state.match_id || e.revision != state.revision)
        return Result::Stale;
    if (ui_busy || !legalHumanAction(state, e.action))
        return Result::Rejected;
    auto next = state;                 // 固定上限を持つ状態コピー
    if (!applyLegalAction(next, e.action)) return Result::Rejected;
    appendPrivateReplayEvent(next, e.action);
    ++next.revision;
    if (!validateInvariants(next)) return Result::Corrupt;
    if (!store.saveAndReadBack(next)) { showStorageError(); return Result::Storage; }
    state = next;                     // 保存できた確定状態だけを正本にする
    ui_busy = true;
    postRender(makeHumanView(state));
    scheduleNextTask(state);           // 通信をここで同期実行しない
    return Result::Accepted;
}
```

大きなsnapshotを小さなFreeRTOSスタックへコピーしない。上の`next`は本番では事前確保した作業領域へ置き、スタック使用量を実測する。これは接続方法を示す擬似インターフェースで、`CardsController`全体のコンパイル済みコードではない。ゲストRAMモードの`store`はRAM更新として同じインターフェースを満たす。保存結果不明のとき、UIだけ先へ進めてはいけない。

ボタンのbusy解除は、その状態で新しい入力が許されることを確認してから行う。100msのデバウンスだけで重複イベントを防いだことにしない。

## I4. 丸型画面の確定配置

表示サイズ480×480、中心(240,240)。本文・タッチ要素の安全円を半径228とする。四角形の四隅すべてが安全円内であることを検査する。角が円外に出る352px以上の大きな正方形を、丸型画面の内側と見なさない。

全矩形は `data/layouts.json`。主要配置：

| 画面 | 配置 |
|---|---|
| 4テーブル選択 | x=96/248、y=134/254、136×104の2×2 |
| ポーカー手札5枚 | x=70+68i、y=190、64×92 |
| GOPS候補4枚 | x=96+76i、y=202、68×96。ページ式 |
| 31の場3枚 | x=116+88i、y=145、72×86 |
| 31の手札3枚 | 同x、y=254、72×86 |
| バカラの各3枚 | x=116+88i、y=143/252、72×84 |
| 3行動ボタン | x=96+100i、y=346、88×48 |
| 2行動ボタン | x=112/248、y=360、120×48 |
| カフェへ戻る | x=168、y=416、144×36。補助操作 |

上のテンプレートを同時に全部重ねない。例えば31は2行動用、ポーカーのベットは3行動用。メニューの本文・ページボタンも安全円で検査する。36px高さのカフェ補助ボタンを除き、主要な確定操作は高さ44px以上。カードは選択領域であり、そこで実ゲーム処理を確定しない。

本文日本語は22pxを初期値、補足18px、主要数字28〜36px。ボタン88px幅に長文を一行で詰めない。最大2行で短くし、完全な支払額説明は中央の確認カードで出す。画面を縮小して無理に情報を載せず、別ページの手札詳細・ルール・公開履歴へ分ける。

カード美術は数字とC/D/H/Sのマークで描き、色だけで区別しない。標準フォントに絵文字のトランプがあると仮定しない。漢字・かなは既存の許諾済みフォントから必要字形をビルド時にサブセット化する。フォントファイルを本引継ぎに含めない。

開始時に当該ゲームの遊び方が開ける。`data/tutorials.ja.json`の22ページを正本とし、初回は「練習して始める」を選べる。練習は固定の公開札、戦績なし、Jev呼出しなし。本番デッキへ練習の札やseedを流用しない。

## I5. 秘密画面とカフェ復帰

ポーカー/31の人間手札は共有端末で私的情報。カフェボタン、スリープ、プロフィール切替、エラー時は直ちに不透明のカバーを描き、privateのラベル・カードobjを破棄または非表示にする。サムネイル、画面遷移アニメーションの残像、復帰直後の前ユーザー手札を防ぐ。

ゲームを止めてからカウンターへ戻り、コーヒー＋1は通常どおり操作可能。別ゲームを起動しても本試合の非公開札を覗ける一覧はない。1つのCAFE CARDS未完試合だけを持ち、別テーブルを始める前に「再開／この試合を終了」を選ばせる。

ゲストは同じ電源セッションのRAM上だけ再開できる。本人確認機能がないことを表示する。電源断後のゲスト再開はしない。本人プロフィールは再認証後に再開する。途中で別人の戦績へひもづけ直す操作はない。

## I6. 乱数と同じ結果を維持する仕組み

`Deck::init()`はFisher–Yatesでシャッフルし、indexはrejection samplingを使う。`rand()%N`、起動時刻だけのseed、毎ラウンド固定seedを本番に使わない。テスト用mt19937は試験専用。

ESP32-S3の乱数には、RFなど有効なエントロピー源に関する条件がある [S20]。採用環境で安全なハード乱数源を初期化し、RF停止中の方針も明記する。必要なら起動時の真性乱数から暗号学的DRBGを初期化し、各ゲームへ渡す。ADC/他用途へ影響する乱数用設定を独断で変更しない。

本番のmatch_id・decision_idは128bit乱数の32hex。シャッフルした全順列とcursorは登録ユーザーのprivate snapshotに保持し、リトライ・復帰では生成し直さない。ポーカーの新ハンド、31の新ハンド、バカラの新ラウンドは規則どおり新しい山だが、同じハンドの通信再試行は新しい山ではない。

端末AIの抽選も、その決定を予約した時に一度だけ行い保存する。GOPSのjitterは`uniform(3)-1`、ポーカーのrollは`uniform(100)`。付録の`local_poker_bet`へ生の32bitを渡して`%100`だけに依存せず、0〜99に無偏り化して渡す。

## I7. 端末AIポリシー（全4種類）

| ゲーム・段階 | 方針 |
|---|---|
| ポーカー交換 | ストレート/フラッシュ/フルハウス/ストレートフラッシュは保持。ペア類は組になったrankを保持し単独札を交換。ハイカードなら4枚同スートを優先保持、それ以外は上位2rankを保持し3枚交換 |
| ポーカー追加不要時 | ツーペア以上はBET。ワンペアは45%、ハイカードは12%でBET、他はCHECK |
| ポーカー相手のBETあり | 上乗せ可ならツーペア以上はRAISE、ペア15%、ハイカード5%でRAISE。その後残る場合ペア以上はCALL、ハイカードはroll<25ならCALL、それ以外FOLD |
| GOPS | 昇順の自分の残札k枚から `round((prize-1)*(k-1)/(N-1))` の位置を基準とし、保存済みjitter -1/0/+1を加えて範囲内へclamp |
| 31通常 | 9交換を試算。現在27以上、または改善なしならKNOCK。それ以外は最高得点交換 |
| 31最後 | 改善交換ありなら最高得点交換、なければSTAND |
| バカラ | 組合せ計算済み表の3値最大。完全同率はPLAYER→BANKER→TIE |

複数候補の同率はslot順を採用する。これらは固定の比較基準であり、Jevの返答を偽装するものではない。ポーカーは場の状況を詳細に読む強力な専用エンジンではない。局所的な不合理さはプレイ試験で把握し、変更するなら`policy_version`を上げる。

## I8. Jevの契約を正確に使う

資料確認日の初期モデルは`jev-1.13.0`。実アカウントでアクセスを確認して固定する。最新aliasへ無断追随しない [S11]。プロンプトは英語ルール＋構造化した観測、画面は日本語。カード画像を送る仕様はない。

```http
POST https://api.typesafe.ai/v1/systemone
Authorization: Bearer <Script PropertiesのJEV_API_KEY>
Content-Type: application/json
```

```json
{
  "model": "jev-1.13.0",
  "state": {
    "rules": "固定した当該ゲームの英語ルール",
    "observation": {"game":"baccarat","variant":"classic","phase":"predict","rules_version":"1.0.0","decks":8,"fresh_deck_each_round":true,"public_first_cards":null}
  },
  "questions": {
    "action": {
      "type":"choice",
      "instructions":"Predict the final table-hand outcome using only public information.",
      "criteria": {
        "PLAYER":"PLAYER final points exceed BANKER.",
        "BANKER":"BANKER final points exceed PLAYER.",
        "TIE":"Final point totals are equal."
      }
    }
  }
}
```

上の`rules`は説明用で、本番は`reference/jev_contract.js`の実ルール全文を使う。`state/model/questions`と`type/instructions/criteria`は公式HTTP形 [S02,S12]。自由な日本語の行動文を返してもらって曖昧に解釈する方式ではない。

返答は`answers.action`を読み、以下を全て検証する。

- type=choice。候補キー集合が現在の合法IDと完全一致。
- 各確率はnumber・有限・0〜1。合計1±0.001。許容内の丸め誤差だけ再正規化。
- choiceは合法で最大値と1e-6以内で一致。confidenceは0〜1の有限number。
- modelは非空文字列。要求と異なる実モデルの場合は保守ログへ残し、運用で許可済みの実モデル以外は接続検査を失敗させる。
- HTML、null、文字列の数字、NaN、余分な候補、欠落、配列をオブジェクト扱いしない。

低confidenceだけを理由に同じ場面を何度も呼び直さない。最大候補を一度採用する。モデルの確率は選択の内訳、実際の勝率や数学的な真の確率とは別 [S02,S05]。

### 観測生成とサーバー検査

ESP32は `makeAIObservation` で新しいオブジェクトを組み立てる。GASは `reference/observation_gate.js` の `requestFromObservation()` で全キーと合法IDを検査し、固定ルール・候補説明を再構築する。端末から自由文のinstructionsを受け取らない。

`reference/jev_contract.js`の`buildObservation(full)`は許可フィールド抽出の参考。**GASへfullを送るためのコードではない。** GASで持っていない人間の手札を埋めるために架空の札を作らない。

GASの形・整合性検査だけで隠れた実札の正しさまで証明できるわけではない。通常の信頼済みファームが合法な手番で呼ぶことを前提にし、記録は`validation_level=device_attested`とする。

### UrlFetchAppの設定

```javascript
const response = UrlFetchApp.fetch('https://api.typesafe.ai/v1/systemone', {
  method: 'post', contentType: 'application/json',
  headers: {Authorization: 'Bearer ' + apiKey},
  payload: JSON.stringify(validatedJevBody),
  muteHttpExceptions: true, followRedirects: false,
  validateHttpsCertificates: true, timeoutSeconds: 8
});
```

現行公式リファレンスには`timeoutSeconds`がある [S15]。実アカウントで挙動を検査する。GAS起動・Sheets操作を含めた全応答時間が8秒になる保証ではない。Promiseやsleepで同期HTTPを中断できたことにしない。

401/403は認証の問題としてJevを停止。400/422は契約異常。429はRetry-Afterまたは60秒クールダウン、5xx/529/タイムアウト/不正応答は当該decisionをunavailableにする [S12]。残りの試合を端末AIに切り替えるか、待つか、終了するかを本人が選ぶ。

## I9. 全ネットワークAPI

ゲーム用公開入口は7操作。既存認証サービスの登録/login/guest/logoutは別の共通IdentityAdapterを使い、ここに同名の別ユーザーDBを作らない。

### 共通リクエストとレスポンス

```json
{
  "namespace":"cafe_cards", "api_version":1,
  "action":"decision.prepare",
  "request_id":"11111111111111111111111111111111",
  "device_id":"22222222222222222222222222222222",
  "device_token":"<端末の秘密値>", "player_token":"<期限付き本人またはゲストtoken>",
  "created_at_ms":1790030000000, "sent_at_ms":1790030000000,
  "payload":{
    "match_id":"33333333333333333333333333333333",
    "decision_id":"44444444444444444444444444444444",
    "decision_seq":1,"revision":2,"phase":"predict",
    "observation":{"game":"baccarat","variant":"classic","phase":"predict","rules_version":"1.0.0","decks":8,"fresh_deck_each_round":true,"public_first_cards":null},
    "legal_ids":["BANKER","PLAYER","TIE"]
  }
}
```

ID・時刻は架空の形式例。秘密をソースへ埋め込まない。payloadは`data/api_contract.json`の全フィールドが必要で、未知のキーを拒否する。

```json
{
  "namespace":"cafe_cards", "api_version":1,
  "request_id":"11111111111111111111111111111111",
  "server_time_ms":1790030000500,"ok":true,
  "data":{"decision_id":"44444444444444444444444444444444","status":"ready","observation_hash":"<64hex>","result_or_null":{"selected_id":"BANKER","probabilities":{"BANKER":0.5,"PLAYER":0.4,"TIE":0.1},"confidence":0.12,"model":"jev-1.13.0","normalization_applied":false},"lease_until_ms":1790030060000},
  "error":null
}
```

確率は応答形の説明例でありモデルの実測ではない。error時は`ok=false,data=null,error={code,message_ja,retryable,retry_after_ms}`。HTTP200でもok、namespace、版、request_id、Content-Type、JSONを確認する。端末POSTは16KiB、レスポンス8KiBをアプリ上限にする。

| action | 役割と重要な規則 |
|---|---|
| hello | 端末認証、時刻・利用可能game/variant・Jev設定・保守状態。未設定の利用権をavailableにしない |
| profile.get | token本人の当該game/variantの集計。別player_idをpayloadで指定させない |
| match.open | client生成IDを採用。game/variant/rules/owner/deviceを固定しactive登録。24時間期限 |
| decision.prepare | 同一match/decisionの呼出し枠を一度だけ予約。合法IDと観測を検証しJevを一度呼ぶ |
| decision.get | 同じjobを照会。照会だけで再度Jevを呼ばない |
| match.finish | 完了結果の範囲・保存済みAI記録との整合を検証、結果と統計を一度だけ確定 |
| match.abort | 未完を中止。completedを後からabortedにしない。中止は負けに加算しない |

profile.get以外の認証付き操作は本人または同一deviceの有効guestを使える。helloのみdevice認証でplayer_token=null。`first_actor`はポーカーでは**初回ディーラー**、31では初回先手、他はnull。このAPI名は共通化のためのラベルで、ゲーム内の役割を取り違えない。

### モデル観測の表記を曖昧にしない

観測のSELFは常にAI、OPPONENTは人間。ポーカーの`draw_counts`は`{self,opponent}`、`stacks`と`contribution`も同じラベル。内部の`hands[0]=H,[1]=A`という配列順を説明なしでモデルへ投げない。全観測の許可キーは`reference/observation_gate.js`に列挙し、その深さまで検査する。

### リクエスト・再送・時刻

- request_idは一つの業務操作で固定、再送も同ID・同payload。sent_at_ms/tokenだけ更新可。
- created_at_msから48時間超の更新はREPLAY_TOO_OLD。sent_at_msはサーバーと±5分、helloだけ未同期0を許可。
- request key=`device_id:request_id`。指紋は`{action,device_id,actor_id,payload}`の再帰的キーソートJSONをHMAC-SHA256化。秘密を含む生リクエストをログへ置かない。
- 同ID別payloadはIDEMPOTENCY_CONFLICT。認証主体を変えて再送したら所有権エラー。
- MatchIDは一度使用したら再利用しない。再戦は新ID、カード/乱数も新しいもの。

### decision応答の状態

`pending, ready, unavailable, cancelled`。pendingの`result_or_null=null`。readyなら確定回答。unavailableは再呼出し不可で、failure_codeをerrorまたは状態説明に付ける。cancelledは中止した試合の未完job。

サーバー上のjob keyは`device_id:match_id:decision_id`。decision_seqは試合内で1〜40、game別上限も適用する。古い同一seqを別decision_idで取り直そうとした場合はconflict。forced処理もローカルイベントに残すが、外部jobは作らない。

## I10. 冪等なJev呼出し・並行処理

**一つのdecisionに、アプリケーションから最大1回のJev要求**を送る。ネットワーク外部側の内部リトライ・課金までexactly-onceと保証しない。

1. ScriptLockを取得 [S17]。認証、期限、スキーマ、観測・合法IDを検査。
2. 同じjobがあればハッシュ一致を確かめ、状態を返す。readyの回答は固定。
3. 新規ならgeneration、60秒lease、call_reserved=trueを永続予約。端末日次上限とmatch上限もこの時に消費する。
4. 永続化の成功を確認してからロックを解放。呼出し予約の所有者だけがJevを呼ぶ。
5. 戻ったら再ロック。jobが同じgeneration・pendingで、期限内、match activeである場合だけreadyへ保存。
6. 期限超過・中止・世代違いの返答は捨てる。復旧ワーカーは再度Jevを呼ばない。
7. 処理が途中で落ちた場合、lease後はunavailable。結果不明を理由に同じ選択を取り直さない。

上限は端末1日1000予約、試合あたりPoker40/GOPS13/31は33/Baccarat5。これは本アプリの運用初期値で、サービスの公式上限そのものではない。Google/Jevの実際のquotaも確認する [S19]。カフェの既存通信よりゲームを優先してquotaを使い切らない。

ESP32の1HTTP試行は15秒でUI上の待ちを分離。job照会は2/4/8/8秒、以後8秒間隔でleaseを超えたら打切り案内。待機中もカフェへ戻れる。待機はプレイヤーの敗北にしない。

## I11. Googleシートの全定義と保存方法

`data/api_contract.json`の`sheets`に5種の**全列順**を収録。名前を変えず自動初期化し、既存同名のヘッダーが異なれば止める。clearして作り直さない。

| シート | 意味 |
|---|---|
| CardsMeta | schema版、索引、次の行番号、日次予約数、最後のwrite receipt、保守状態 |
| CardsMatches_YYYYMM | 一試合の所有者・種類・期限・結果・公開イベント・集計適用版 |
| CardsDecisions_YYYYMMDD | AIの一決定の予約・世代・期限・確定回答・失敗理由。生の秘密状態は置かない |
| CardsProfiles | 本人×game×variant×rules×provider別の統計と公開傾向 |
| CardsReceipts_YYYYMMDD | リクエスト指紋、応答参照、重複防止の受付台帳 |

日時タブはサーバーAsia/Tokyo基準。match.openでcreated_monthを返し、端末のローカル日付からタブ名を推測しない。日付をまたいだdecision再送も既存jobの索引を探す。

### 列値の詳細

- `player_id`は共通認証で確定。guestはランダム一時ID、CardsProfilesに行を作らない。
- `status`：matchはactive/completed/aborted/expired、decisionはpending/ready/unavailable/cancelled。
- `expires_at_ms`はcreated+24hの固定。pollだけで延長しない。
- `human_score/opponent_score`：Poker最終持ち点、GOPS獲得点、31ハンド勝ち数、Baccarat的中数。中止はnull。
- `winner`：H/A/D、completedだけ。`end_reason=completed|user|expired|corrupt|guest_restart|fault`。
- `provider_counts_json={jev:n,local:n,forced:n}`。requested=jevで途中local使用ならcohort=mixed。
- `public_events_json`は第I14節の公開イベントだけ。山札・隠れた札・tokenは不可。
- `result_hash`はmatchID/型/結果/公開履歴/出所のcanonical JSON SHA-256。finish再送で値が違えばRESULT_CONFLICT。
- `validation_level`は`device_attested`。実際にはしていないサーバーでの秘密全棋譜検証を意味させない。
- `stats_applied_version`は登録本人への当該結果適用後の版、guestはnull。
- decisionの`request_hash`はphase/revision/observation/legal_idsの指紋。`observation_hash`は観測のSHA-256。
- `result_json`は選択ID・合法確率・confidence・実model・丸め有無。使用量・latencyは実測できたものだけ、未取得null。
- `profile_key=player_id|game|variant|rules_version|cohort`。cohortはjev/local/mixed。Baccaratの計算予想はlocalに含め、表示名だけ区別。
- receiptのsafe_response_jsonにtokenを保存しない。ここで本人ログインtokenを新規発行する操作はない。

### 一括保存と不明な書込み

シートは管理者専用Workbook。既存カフェ集計が共有されているなら別の非公開Workbookを使う。関係タブは一Workbook・一つのApps Script書込み元に集約。

同じScriptLock配下で更新前のデータを再読、IDと版を確認。CardsMetaの`active_owner:<id>`と`active_device:<id>`でCAFE CARDSの未完試合を一つに制限する。ID→行索引はキャッシュ不在ならID列だけ検索し、実際の行IDを再確認する。新しい行は`next_row:<tab>`で単調割当し、行追加と同時batchでカウンターも更新する。行の追加、next_rowカウンター、結果、stats版、receiptを**一つのSheets.Spreadsheets.batchUpdate**にする。Google APIはサブ要求を検証し一括適用するが [S18]、他ユーザー編集との完全なDBトランザクションではない。直接ソート・編集・行削除を運用禁止とする。

`userEnteredValue.stringValue`でID/JSON/人名を文字として入れ、formulaValueは使わない。各JSONセルはアプリ上限24,000UTF-8 bytes、公開イベントは12KiB以下。超えた場合に中途半端に切り詰めず、イベント形式の肥大をエラーとして修正。

書込み前にScript Propertiesへ`CARDS_WRITE_BARRIER_JSON`（txID、receiptKey、期待hash）を保存。batchUpdateが成功応答ならreceipt照合してbarrierを消す。応答が途絶えた場合はbarrierを残し、新規の状態更新を止める。保守処理がreceiptを読み、当該batchが確定済みなら続行。不明なら`STORAGE_UNCERTAIN`で停止し、盲目的に同じappendを再送しない。

存在しないreceiptを一度読んだだけで「絶対未適用」と断定せず、失敗の種別・監査・復元手順に従う。安全側停止は利用不能になることがあるが、二重戦績や二重課金より優先する。CacheServiceは高速化のヒントであって保存台帳ではない。

## I12. HTTPS・配備・鍵

GAS Web Appは`e.postData.contents`からJSONを読み、ContentServiceで返す [S13,S14]。一般のHTTPサーバーのような任意Authorizationヘッダー取得やTextOutput.setStatusCodeを前提にしない。端末認証tokenはJSON本文、URLには置かない。

ContentServiceは一時的なGoogleホストへリダイレクトする [S14]。ESP32はscript.google.comへPOSTし、302/303なら許可済みHTTPSのscript.googleusercontent.comへ**GET・本文なし・tokenなし**で追従。最大3回。未知ホスト、HTTPへの降格、ログインHTML、秘密POSTを再送させる307/308は拒否して設定確認。証明書検証を無効化して接続完了としない。

| Script Property | 意味 |
|---|---|
| CARDS_SPREADSHEET_ID | 非公開ゲームWorkbook |
| JEV_API_KEY | 共通Jev API鍵。Flashへコピーしない |
| CARDS_JEV_MODEL | 初期jev-1.13.0、実接続試験後に固定 |
| CARDS_RECEIPT_KEY_HEX | request指紋の32byte以上秘密、他用途と分離 |
| CARDS_DEVICE_TOKEN_SHA256_〈id〉 | 既存端末認証adapterが使えるなら共通登録値を参照 |
| CARDS_MAINTENANCE | trueなら新規試合/新推論停止 |
| CARDS_WRITE_BARRIER_JSON | 未確定書込みの小さい記録 |
| CARDS_DEPLOYMENT_VERSION | デプロイしたソースの版 |
| CARDS_JEV_COOLDOWN_UNTIL_MS | API障害時の再試行抑制 |

Script Propertiesはスクリプト編集者から秘密を隔離する専用金庫ではない [S16]。編集権限を限定する。新秘密はPCの暗号学的乱数で生成し、ソース・git・スクリーンショットへ残さない。

配備：既存バックアップ→テストWorkbook→Sheets高度サービス→schema初期化→Script Properties→既存doPostにnamespace分岐追加→テスト/exec→端末認証→モック→Jev→結果記録→本番切替。`/dev`を本番URLにしない。Workspaceの匿名呼出し禁止を勝手に解除しない。許可された既存の認証経路を使い、不可ならオンライン機能を未配備として止める。

## I13. 個人登録・ゲスト・記録の意味

既存のAI DUELで設計された個人登録を`IdentityAdapter`へ切り出して利用する。新しいCAFE CARDS用の同名アカウントや別PINを勝手に発行しない。既存コードが未実装でもゲスト/端末AIは実装可能。本人機能が未実装なら匿名を本人として保存しない。

期待する共通認証interface：`listPlayers(page), login(player_id,pin), beginGuest(device_id), validate(token,device_id), logout(token)`。実際の操作名は既存へマッピングし、旧アプリのlogoutやactiveMatch消去を不用意に呼ばない。トークンはRAM、PINもRAMで認証後破棄。

個人統計は次の構造を基準にする。

```json
{
  "version":1,"matches_completed":0,"wins":0,"losses":0,"draws":0,
  "aborted":0,"hands_completed":0,"rounds_completed":0,
  "score_sum":0,"recent_results":[],
  "behavior":{"sample_n":0,"fold":0,"check":0,"call":0,"bet":0,"raise":0,
    "knock":0,"swap":0,"stand":0,"aggressive_opportunities":0,"facing_bet_opportunities":0},
  "behavior_window":[],"gops_recent_public":[],"last_match_id":null
}
```

`recent_results`最大20試合（各要素はwinner,score,completed_at_ms）。`behavior_window`最大200要素（各要素はaction,phase,turn,can_aggress,faces_bet）。札やPINを含めない。`behavior`は直近200の該当する公開人間意思決定から再計算し、モデルへはこの有限windowを送る。累計カウンターの無制限増加を32bitの暗黙wrapに任せない。長期数は64bit、画面桁あふれは省略表記とする。

ポーカーのaggressive opportunityはその行動前にBETまたはRAISEが合法だった人間の番。facingはCALL/FOLDが合法な番。31の通常/最後を区別した集計を追加し、履歴イベントから再構築できるようにする。GOPSは同variantの直近26の公開結果だけ。バカラに個人の予想傾向を送らない。

試合勝率=`wins/matches_completed`。引分けも母数に含める。バカラの的中率=`correct/rounds_completed`は別表示。中止は勝敗の母数に含めない。未完ハンドのprivate行動から個人傾向を更新しない。5回の小標本をAI強さや人物能力の評価にしない。

保持：登録試合明細180日、guest明細1日、decisionは試合終了から2日、receipt2日、累計/直近windowは退会/リセットまで。退会はCAFE CARDSの履歴・stats・private snapshotにも連携し、他ゲームとの削除範囲を管理UIで明示する。バックアップから削除済み本人を復活させない。

## I14. 公開イベントと結果の全形式

共通イベント `{seq, hand_or_round, actor, kind, data}`。seqは1から連番、actorはH/A/SYSTEM。時刻は勝敗ロジックに使わず、表示・監査用。最大192イベント。配布の札順は含めない。

| game/kind | dataの内容 |
|---|---|
| poker/HAND_START | hand_no, dealer, start_stacks。手札なし |
| poker/BET_ACTION | action, debit, unit, raises, stacks, pot |
| poker/DRAW_COUNTS | human_count, ai_count。双方確定後だけ |
| poker/HAND_END | winner, folded, end_stacks, pot_awarded。showdown時だけfinal_hands[2]とkeys[2] |
| gops/ROUND_END | prize, human_bid, ai_bid, winner, scores, burned |
| thirty_one/HAND_START | hand_no, first_actor, market。両手札なし |
| thirty_one/SWAP | out_card, in_card, actor, turn。これらは場から見えて合法 |
| thirty_one/KNOCK・STAND | actor, turn |
| thirty_one/HAND_END | hands[2], scores[2], reason, winner |
| baccarat/ROUND_END | actual_used_cards, np,nb,pt,bt,outcome, predictions[2], points[2]。未使用の候補札なし |
| common/FALLBACK | from=jev,to=local,decision_id,reason。秘密なし |

結果JSONは `{game,variant,completed_units,human_score,opponent_score,winner,end_reason,provider_cohort,hand_results}`。completed_unitsはP5/G7または13/T3/B5。hand_resultsは各公開決着の最小集計、GOPSは各得点結果。incompleteをcompletedへ格上げしない。

サーバー検証：Poker最終計200、GOPS両得点+burned=28/91、31勝ち数+相手勝ち数+引分けハンド=3、Baccarat各的中0..5。AIの公開行動は保存ready結果と一致することを照合する。参照できない内部札の公平性を「サーバー検証済み」としない。

## I15. 保存形式・電源断・所有者

### 保存方針

registeredはprivate snapshotを**2スロット各最大32KiB**で保存。普通のデフォルトNVSにそのまま64KiBが空いていると仮定しない。実機の保存区画・他ゲームの使用量を測り、既存FS/専用領域のStorageAdapterを選ぶ。区画変更はバックアップ・承認・移行手順付き。足りない場合、保存不可を明示してRAM限定とするが、本人試合を復旧可能と表示してはいけない。

データは長さ付きの固定スキーマで明示encodeし、C++structの生メモリーをそのまま書かない。little-endianの整数またはcanonical JSONで表現を統一。CRC32は破損検知で、秘密保持や改ざん防止の暗号ではない。NVSの耐障害性や暗号化も採用環境で確認する [S21]。

### スナップショットの完全なフィールド群

```text
header: magic="CTC1", schema=1, generation(uint64), payload_length, crc32
common: match_id, owner_id, is_guest(false), game,variant,rules_version,
        requested_provider, current_provider, cohort,
        created_at_ms, expires_at_ms, revision, phase, suspended,
        dealer_or_first_actor, completed_units, match_scores,
        event_log, public_events, provider_counts
private_game:
  poker: hand_no, deck_order[52], cursor, hands[2][5], discards[0..10],
         draw_masks[2], stacks[2],pot,street_paid[2],actor,unit,raises,checks,winner,folded
  gops: n,prize_order[n],round_index,remaining_masks[2],sealed[2],scores[2],burned
  thirty_one: hand_no,deck_order[52],hands[2][3],market[3],known_masks[2],
              actor,turn_count,knocker,finished,end_reason,hand_wins[2]
  baccarat: round_no,deck_order[416],first_six[6],guesses[2],
            outcome_or_pending,used_count,totals_or_pending,prediction_scores[2]
pending: decision_id,decision_seq,request_id,phase,revision,observation_hash,
         generation,status,selected_id,probabilities_optional,local_random_choice,
         human_draft_optional,job_created_day
sync: match_opened_online,server_created_month,pending_finish_request_id,
      result_hash,finish_acknowledged,identity_profile_version
```

token・PIN・Jev鍵は一切含めない。JSONならnullと不存在を勝手に混ぜない。private event_logはルール再生用の全確定手と開始デッキの参照、public_eventsは送信用。前者をネットワークへ送らない。

### 書込み・復元の手順

非activeスロットへgeneration+1を書込→完了→再読しCRC/長さを検査→active参照を切替。起動時は両方を検証し最大generationを採用。壊れた新スロットしかなければ古い有効スロット。両方不正ならデータを勝手に合成せず再開不可。

復元後はrule replayと不変条件を照合する。山札が順列か、cursor妥当か、手札/捨て札との位置が整合するか、得点/消費札/手数/phaseが矛盾しないか、pendingが現在局面かを確認。referenceのpublic structへディスクの値を無検証代入しない。

起動後は共通メニュー「再開可能な試合があります」。本人再認証成功後だけprivate画面を描く。期限24時間を超えたら無効終了。時刻不確かならオンライン再同期まで本人再開保留。guestはRAMのみなので電源断後再開不可。

secret保存を許容しない運用なら、registered再開を無効化する設定を管理者が選ぶ。ただしこの制限をゲーム設定変更や戦績復旧の成功と混同しない。人狼の「秘密はRAMだけ」と、今回の個人カードの要件は別である。

### 未確定ネットワークと復旧

readyを受けてまだカードへ反映していない場合は、同decisionをgetし保存した選択を再利用。反映済みrevisionの古い返答は無視。pause中に返答が届いたら状態へ一度保存するが画面を再開しない。`ChooseLocal`で切替済みなら、後で来たJev返答へ戻らない。

## I16. メモリー・電池・性能の予算

- 52枚は104byte、416枚は832byte（uint16）。4ゲームが8MBをカードだけで使うわけではない。
- 動的ゲーム状態は同時に1種類、固定上限のvariant/union等を使う。全4画面の画像を常時RAMへ載せない。
- 480×480×2byteのフレーム1面は460,800byte。既存BSPのバッファ数を調べ、追加UIが勝手に別の全画面バッファを複数確保しない。
- JSONの1要求16KiB、応答8KiBを上限としてパーサーも制限。ArduinoJson等を選ぶ場合は既存版に合わせ、巨大な無制限String連結を避ける。
- 初期目標：各タッチ選択への視覚反応100ms以内、HTTP中もカフェへ戻れる。これは受入目標で実測値ではない。
- バックライト暗転は120秒無操作でpause後に行う。非公開手を出したまま低輝度にするだけでは不十分。
- 1500mAhの駆動時間は実装後に電池側で測定する。USB給電電流をそのまま3.7V電池の電流に置き換えない。未検証の残量％を表示しない。

## I17. 実装の順序と各段階の完了条件

| 段階 | 作業 | 合格条件 |
|---|---|---|
| 0 | 原本保全・環境確認 | LCD/タッチ/＋1/既存5ゲームを再現 |
| 1 | 付録PC検査、共通カード型 | 全検査成功、版とツールを記録 |
| 2 | 4テーブルメニュー・練習 | 4入口と全遊び方が丸画面で読める |
| 3 | GOPS端末AI | 7/13を完走、同時選択と残札確認 |
| 4 | 31端末AI | 3ハンド、ノック/上限/既知札を完走 |
| 5 | Poker端末AI | 5ハンド、交換・全ベット・得点保存 |
| 6 | Baccarat計算予想 | 5回、OPEN/CLASSIC、全追加札条件 |
| 7 | private保存・再開 | 強制電源断、再認証、secret非表示 |
| 8 | Google・共通本人 | mock decision、記録の再送・失敗復旧 |
| 9 | Jev実接続 | 4種類で実応答・料金枠・時間・入力分離を検査 |
| 10 | 社内試遊 | 各ゲームの理解・再戦したさ・操作負担を評価 |

これは完成時にゲーム数を削る順序ではなく、4種類を丁寧に積み上げる順序。途中状態は開発ビルドと明示し、未実装ボタンで完成を装わない。

## I18. 実装者に要求する納品物

変更した既存コードの差分、固定依存版、ビルド/書込み手順、テスト用/本番GASの区別、全schema移行、秘密を含まない設定例、API応答の機密除去済み記録、実機受入表、復旧/ロールバック手順、未達事項を納品する。

本書の参考コードだけをコンパイルして、既存端末に組み込めたと報告しない。「単体テスト成功」「ESP32ビルド成功」「書込み成功」「実機操作確認」「Google実保存」「Jev実呼出し」「試遊評価」は別項目で報告する。
`````

## ファイル：`docs/06_TESTS_SOURCES.md`

<!-- CAFE_CARDS_FILE {"path":"docs/06_TESTS_SOURCES.md","bytes":21204,"sha256":"7ff6de9ca05f717b1117083c75ddf5b85b6ebd909f039ffbc4d8dc71072833fe"} -->
`````markdown
# 第VI部 — 検査、運用、根拠資料

## Q1. 実機・実サービス受入試験

以下の**124項目**は、コーディングエージェントが実装した対象環境で実施する。全行の初期状態は`not_run_on_target`。PC参考コードの成功を、この表の実機合格へ一括転記しない。証拠、担当者、日時を記録する。

| ID | 確認内容 | 合格条件 | 状態 |
|---|---|---|---|
| BASE-01 | 原本保全 | 変更前のBSP・LVGL・Google設定・ゲーム登録のバックアップが存在する | 未実施 |
| BASE-02 | 型番 | 実機が2.8Cであることと480×480を確認する | 未実施 |
| BASE-03 | 既存カウンター | 4本を追加後も+1を2回押すと2だけ増える | 未実施 |
| BASE-04 | 既存5ゲーム | 人狼3〜10人v2を含む既存5本の起動と終了を確認する | 未実施 |
| BASE-05 | 入口一つ | 第6メニューCAFE CARDSだけから4種類へ分岐する | 未実施 |
| BASE-06 | 全ゲーム完走 | 端末AIでP5ハンド・G7/13・31は3ハンド・B5回を終了する | 未実施 |
| BASE-07 | 文言 | 全119文言キーと22ページの文字に欠けがない | 未実施 |
| BASE-08 | 依存固定 | 使用core・LVGL・コンパイラ・BSP・ライブラリ版を記録する | 未実施 |
| BASE-09 | 練習 | 固定練習が課金や正式戦績・本番乱数に影響しない | 未実施 |
| BASE-10 | 禁止機能 | 課金・換金・景品・共通財布・人事連携がない | 未実施 |
| SEC-01 | 相手手札隔離 | 人間の未知手札を変えてもAI要求の意味が変わらない | 未実施 |
| SEC-02 | 未来札隔離 | 山札未来部分を変えても同じ公開状態のAI要求が一致する | 未実施 |
| SEC-03 | GOPS未公開札 | 人間の仮選択をJev要求に含めない | 未実施 |
| SEC-04 | 交換未公開 | ポーカーの人間maskをAI交換決定前に送らない | 未実施 |
| SEC-05 | バカラ未公開 | 人間予想・勝敗・未来6枚を送らない | 未実施 |
| SEC-06 | 私的捨て札 | ポーカーの相手捨て札が公開履歴・統計から漏れない | 未実施 |
| SEC-07 | 31公開既知 | 正当に公開された取得札だけを既知集合へ追加する | 未実施 |
| SEC-08 | ネスト未知キー | 余分なroot・nested keyをGASで拒否する | 未実施 |
| SEC-09 | API鍵 | Jev鍵が端末Flash・ソース・ログに存在しない | 未実施 |
| SEC-10 | 本人認証 | 別人token/他deviceでprivate試合と統計を取得できない | 未実施 |
| SEC-11 | PIN | 生PINとplayer_tokenがsnapshotへ書かれない | 未実施 |
| SEC-12 | 画面退避 | カフェ復帰・ログアウト・エラーで手札が残像を含め消える | 未実施 |
| SEC-13 | ログ | 例外・シリアルに山札・token・非公開手札を出さない | 未実施 |
| SEC-14 | モデル文言 | confidence・行動確率を実勝率と表示しない | 未実施 |
| SEC-15 | 役判定分離 | Jev応答で役の強さや点数規則を書き換えられない | 未実施 |
| SEC-16 | 共有Workbook | 一般公開カフェシートにprivate記録を入れない | 未実施 |
| P-01 | 配布順 | 非dealer→dealerへ交互に5枚、初期cursor=10 | 未実施 |
| P-02 | 先手交代 | 初回dealerを記録し5ハンドで交互にする | 未実施 |
| P-03 | CHECK2回 | 両CHECKで一度だけ次段階へ進む | 未実施 |
| P-04 | CHECK後BET | 相手BETへのFOLD/CALL/RAISEが表示される | 未実施 |
| P-05 | 額一致 | CALLは不足額だけを支払う | 未実施 |
| P-06 | RAISE | 不足額+unitを払い、回数を1だけ増やす | 未実施 |
| P-07 | 上限 | 2回上乗せ後のRAISE拒否、CALL/FOLDは可能 | 未実施 |
| P-08 | 段階初期化 | 交換後unit=4、paid/raises/checksが0 | 未実施 |
| P-09 | 無料FOLD禁止 | owed=0でFOLDできない | 未実施 |
| P-10 | 残点保証 | 最悪5連敗でも最後に5点以上、補充なし | 未実施 |
| P-11 | 総点 | 各確定状態でstacks+pot=200 | 未実施 |
| P-12 | 交換0 | 双方0枚でも正しく交換後へ進む | 未実施 |
| P-13 | 交換5 | 双方5枚を交換しても重複・枯渇しない | 未実施 |
| P-14 | 交換順 | 双方mask固定後、非dealer固定slot昇順から引く | 未実施 |
| P-15 | ホイール | A2345は5-high、QKA23はストレートではない | 未実施 |
| P-16 | 同役比較 | 全カテゴリのキッカー比較とスート同点を確認する | 未実施 |
| P-17 | フォールド | 一度だけpot授与、未公開札と内訳を見せない | 未実施 |
| P-18 | 同役分配 | 偶数potを半分ずつ分ける | 未実施 |
| P-19 | 試合勝敗 | ハンド勝利数でなく5ハンド後の持ち点で決める | 未実施 |
| P-20 | 再戦 | 新matchId・新配布、持ち点100へ戻る | 未実施 |
| G-01 | 7枚 | 7回で終了し総得点+破棄=28 | 未実施 |
| G-02 | 13枚 | 13回で終了し総得点+破棄=91 | 未実施 |
| G-03 | 場の点 | 勝ち札の数字でなく得点札の数字を加える | 未実施 |
| G-04 | 同点 | 得点破棄・双方消費・持越しなし | 未実施 |
| G-05 | 両方消費 | 負けた側の札も残札から消える | 未実施 |
| G-06 | 重複札 | 使った札を再度出す操作を拒否する | 未実施 |
| G-07 | 公開残札 | 両者の残札が実状態と一致する | 未実施 |
| G-08 | 秘密確定順 | AI札保存より前に人間Confirmできない | 未実施 |
| G-09 | 最終一枚 | 強制処理でJevを呼ばずforced記録になる | 未実施 |
| G-10 | ページ | 13枚目を選べて表示切替でドラフトを保つ | 未実施 |
| G-11 | 引分け | 最終同点で追加回を勝手に作らない | 未実施 |
| G-12 | 得点順 | 未来得点が見えず、復旧で順番が変わらない | 未実施 |
| T-01 | 配布 | 初期9物理札が相異なり場3枚 | 未実施 |
| T-02 | 同スート | 別スートの得点を足さない | 未実施 |
| T-03 | Aと絵札 | A11、JQK10 | 未実施 |
| T-04 | 3枚組 | 777は7点で特典なし | 未実施 |
| T-05 | 点数同点 | 別スートの余り札・キッカーで差をつけない | 未実施 |
| T-06 | 単交換 | 一ターン一対一交換だけ | 未実施 |
| T-07 | 通常STAND禁止 | 通常でパスボタンが出ない | 未実施 |
| T-08 | ノック | 交換せず相手へ最終応答権を渡す | 未実施 |
| T-09 | 最終応答 | 交換/STANDの後ただちに比べる | 未実施 |
| T-10 | 再ノック禁止 | 最終応答でKNOCKを拒否する | 未実施 |
| T-11 | 初期31 | 片側/両側31で正しく即終了 | 未実施 |
| T-12 | 交換後31 | 相手追加ターンなしで終了 | 未実施 |
| T-13 | 20手交換 | 20番目SWAP後に比べる | 未実施 |
| T-14 | 20手ノック | 21番目の最終応答を一度許す | 未実施 |
| T-15 | 既知削除 | 公開取得札を場へ戻すと既知集合から消える | 未実施 |
| T-16 | 3ハンド | 先手交代し勝ち数で試合を比べる | 未実施 |
| B-01 | 新山 | 5ラウンドそれぞれ416枚から開始する | 未実施 |
| B-02 | 非復元 | 同じ物理IDを同一回で二度引かない | 未実施 |
| B-03 | 見た目重複 | copy違いの同じカード表示は許される | 未実施 |
| B-04 | 配布順 | P1B1P2B2の順である | 未実施 |
| B-05 | OPEN | 1枚ずつだけ表示、2枚合計結果はまだ不明 | 未実施 |
| B-06 | CLASSIC | 一枚も予想前に公開しない | 未実施 |
| B-07 | ナチュラル | どちらか8/9で両方止める | 未実施 |
| B-08 | P停止B5 | P6/7のときB5は引く | 未実施 |
| B-09 | B3境界 | P3=8のみ止める | 未実施 |
| B-10 | B4B5B6境界 | 追加表80セルと停止分岐を照合する | 未実施 |
| B-11 | 5枚目行先 | P停止時は次札がB3、6枚目を飛ばさない | 未実施 |
| B-12 | 予想同一 | 人間AIが同じ予想でも変更せず両者加点可能 | 未実施 |
| B-13 | TIE得点 | TIEを当てても1点、倍率や手数料なし | 未実施 |
| B-14 | 表とJev | 計算値の表示とJev予測を別の出所にする | 未実施 |
| NET-01 | 認証 | device/本人/guestの所有権と期限を確認する | 未実施 |
| NET-02 | 型検査 | 未知action・variant・範囲外を拒否する | 未実施 |
| NET-03 | モデル固定 | 使用モデルと要求/応答の実版を記録する | 未実施 |
| NET-04 | API不正 | 合計不正・候補漏れ・不正数値・非合法返答を拒否する | 未実施 |
| NET-05 | 同一再送 | 同ID同要求のJev呼出し枠が一回だけ | 未実施 |
| NET-06 | 別内容再送 | 同ID別観測をconflictにする | 未実施 |
| NET-07 | 並行要求 | 複数HTTP要求で同決定が二重予約されない | 未実施 |
| NET-08 | lease | 遅延・クラッシュ後の不明jobを再度推論しない | 未実施 |
| NET-09 | 旧返答 | 他match/revisionの返答を適用しない | 未実施 |
| NET-10 | pause返答 | pause中readyは保存だけ、勝手に画面復帰しない | 未実施 |
| NET-11 | 途中local | 本人選択後は残り試合local、後着Jevを無視 | 未実施 |
| NET-12 | リダイレクト | 302/303は本文なしGET、未知ホストは拒否 | 未実施 |
| NET-13 | HTML200 | Googleログイン画面をJSON成功と扱わない | 未実施 |
| NET-14 | quota | 上限・429・キー障害でカフェ本体まで停止しない | 未実施 |
| REC-01 | A/B書込み | 古い有効snapshotを残して新slotへ書く | 未実施 |
| REC-02 | 書込み中電断 | 途中切断時にCRC有効世代だけ復元する | 未実施 |
| REC-03 | 両方破損 | 再抽選による再開をせず無効を表示する | 未実施 |
| REC-04 | カード再生 | deck順列/cursor/手札/イベント整合を照合する | 未実施 |
| REC-05 | 本人再開 | 再認証するまで私的手札を表示しない | 未実施 |
| REC-06 | ゲスト電断 | 旧guestのprivate試合を別guestへ渡さない | 未実施 |
| REC-07 | 24h期限 | 期限超過の試合を勝敗に混ぜない | 未実施 |
| REC-08 | 結果再送 | finishの応答消失で成績を二重加算しない | 未実施 |
| REC-09 | 別結果 | 同matchの結果改変をconflictにする | 未実施 |
| REC-10 | Google不明書込 | barrierを残し盲目的なappend再送をしない | 未実施 |
| REC-11 | 退会 | private snapshot・各ゲーム記録の削除範囲を確認する | 未実施 |
| REC-12 | 区画不足 | 保存区画を無断消去・拡張しない | 未実施 |
| PLAY-01 | 文字 | 日本語と数字・マークを実機で複数人が読める | 未実施 |
| PLAY-02 | タッチ | 選択後確認で誤交換・誤入札を防げる | 未実施 |
| PLAY-03 | 4種の違い | 各テーブルで異なる判断を楽しめる | 未実施 |
| PLAY-04 | ポーカー | 用語を知らない人が金額と降りる意味を理解する | 未実施 |
| PLAY-05 | GOPS | 小さい札を残す/使う選択に理由を持てる | 未実施 |
| PLAY-06 | 31 | ノック後の最後の一手を誤解しない | 未実施 |
| PLAY-07 | バカラ | 二つの手札と人間AIを混同しない | 未実施 |
| PLAY-08 | AIの役割 | 同じ手ばかり等がないか実Jev各20試合を観察する | 未実施 |
| PLAY-09 | 電池 | 実電池条件の平均電流・温度・連続時間を測定する | 未実施 |
| PLAY-10 | 中断性 | いつでも一時停止してコーヒー+1へ戻れる | 未実施 |

## Q2. 面白さの試遊と採用判定

初回は少なくとも6人に遊んでもらい、各ゲームを初見の人2人以上が触る。ポーカー経験者だけで全体の分かりやすさを判断しない。個人名を点数表へ公開せず、匿名の感想を集める。
質問は「次に押すものが分かったか」「何で勝ち負けが決まったか説明できるか」「通信待ちが気になったか」「もう一度違う選び方で遊びたいか」。理解できない箇所を優先修正し、派手な演出を追加して隠さない。
Jevの4種類の実力は未測定。合法行動率、呼出し時間、フォールド/ノック等の偏り、再戦意向をモード別に観察する。端末AI相手と比較して意味のある違いがあるかを確認し、すべて同じ勝率目標に合わせた配札操作はしない。

## Q3. トラブル対応・運用

1. LCDが映らない：原本の基板サンプルへ戻して比較。ゲーム用にBSPやPSRAMを再設定しない。
2. タッチがずれる：既存座標と円形レイアウトを確認。ルールエンジンを変更しない。
3. 個人履歴が見えない：共通認証・owner・variant・cohortを確認。別人へ紐付けて復旧しない。
4. Jevが使えない：端末→GAS、GAS→Jev、キー、契約、quotaを切り分け。通信エラーを勝敗にしない。
5. STORAGE_UNCERTAIN：新規ゲーム更新を止め、barrier/receiptを管理者が照合。勝手に行を削除して再送しない。
6. 電池切れ後：本人ならsnapshot検査と再認証、guestなら旧試合破棄。再抽選して続きとして扱わない。
7. 規則改訂：rules_versionを上げ、保存局を互換判定。新旧別統計にし、古いカード状態へ新規則を適用しない。

## Q4. 実際にこの資料作成中に実施した検査

実行環境は`results/environment.json`。以下は配布する参考コードの実測結果で、外部サービスやESP32の結果ではない。
| 検査 | 実行結果 |
|---|---|
| C++基本ルール | 全26グループ成功。通常ビルドは警告をエラー扱い |
| ポーカー役 | 全2,598,960手を列挙し、9カテゴリの件数と一致 |
| ポーカー進行 | 2,000試合・10,000ハンド。全1,024の交換mask組合せ、ベットの52終端経路を検査 |
| GOPS | 7/13合計2,000ゲーム、得点・残札の保存条件を検査 |
| 31 | 全22,100の3枚得点、3,000ハンド進行、ノックと20+1境界 |
| バカラ | 1,000,000の6値列を別表実装と照合。予想の全27組の得点 |
| C++/JavaScript | 独立の役判定・31得点を2,000手で照合 |
| Jev契約 | 23グループ成功。4ゲームで隠れた入力変更の非干渉、不正応答11種類 |
| 観測境界 | 18グループ成功。余分なキー、違う合法ID、公開前カードなど拒否 |
| 通信状態モデル | 72アサーション成功、同時64予約で呼出し枠1回 |
| ローカルAI | ポーカー15,000合法行動、31は10,000条件を検査 |
| データ | 52カード・31矩形の安全円・101確率表・119文言・22ページの整合 |
| 追加メモリー検査 | ASan/UBSanで小規模の25グループ成功 |

全ゲームの全到達状態を網羅した証明ではない。乱数試験の通過もシャッフルの暗号学的安全性の証明ではない。実Jev正解率、GASの処理時間、API課金、本人情報運用、フォント、日本語レイアウト、電池持続、4種類の楽しさは実機受入で確認する。

## Q5. 参考ファイルの使い方

Python3.10以上、Node18以上、C++17対応コンパイラを用意する。ファイルを展開したルートで次を実行する。

```bash
python tools/run_checks.py --full
python tools/run_checks.py --full --sanitize
```

WindowsはMSYS2等のg++またはCXXで指定した対応コンパイラを使う。Sanitizer未対応の環境は通常検査だけ実施し、追加検査の未実施を明記する。結果は標準で`results_local/`へ保存し、配布時の実行結果`results/`を上書きしない。

`core/cards_core.hpp`は4ゲームのルール、`reference/local_policy.hpp`は比較基準の相手、`reference/jev_contract.js`は観測抽出とモデル契約、`reference/observation_gate.js`はGAS境界用の観測・合法ID検証。`reference/decision_protocol.py`は並行予約と遅延応答の実行可能なモデルであり、本物のSheets保存処理ではない。
`tools/baccarat_table.cpp`は確率表の再生成用。生成結果はdoubleへ落とす前に長い精度で重みを加算するが、表は有限桁に丸めてある。ビルドする端末へ重い全列挙を入れる必要はない。

## Q6. 調査した一次資料と確認範囲

ルールの参照部分と、今回のカフェ向け独自変更を本文で分けた。資料確認日2026-09-22。公開情報は実アカウントの利用可否や自社端末の動作を保証しない。

**[S01] Waveshare 2.8C** — ボード・メモリー・タッチ・電池端子。
`https://docs.waveshare.com/ESP32-S3-Touch-LCD-2.8C`

**[S02] TypeSafe Choice** — 型付き候補選択と応答構造。
`https://docs.typesafe.ai/primitives/choice`

**[S03] Loto-Québec Five Card Draw** — 5枚交換型ポーカーの土台。
`https://www.espacejeux.com/en/ok-poker/how-to-play/games/5-card-draw`

**[S04] Bicycle Basics of Poker** — 役の強さ・基本的な決着。
`https://bicyclecards.com/how-to-play/basics-of-poker`

**[S05] TypeSafe Jev jaggedness** — 数値計算をコードへ分ける判断。
`https://docs.typesafe.ai/model-jaggedness/jev-1.13`

**[S06] Coppercod GOPS** — 同時入札と得点札の土台。
`https://coppercod.games/game/gops/`

**[S07] Google DeepMind OpenSpiel Goofspiel** — 札数/順番を分けたゲーム実装。
`https://raw.githubusercontent.com/google-deepmind/open_spiel/master/open_spiel/games/goofspiel/goofspiel.h`

**[S08] Bicycle Thirty-One** — 3枚と公開の場を交換する流派。
`https://bicyclecards.com/how-to-play/thirty-one`

**[S09] Venetian Baccarat** — 配布順・ナチュラル・追加札。
`https://www.venetianlasvegas.com/resort/casino/table-games/how-to-play-baccarat.html`

**[S10] Four Winds Mini Baccarat** — PLAYER停止時のBANKER条件の照合。
`https://fourwindscasino.com/blog/minibaccarat/`

**[S11] TypeSafe Models** — 固定モデルID・文字入力・言語・学習の扱い。
`https://docs.typesafe.ai/models`

**[S12] TypeSafe HTTP API** — エンドポイント・認証・エラー。
`https://docs.typesafe.ai/api`

**[S13] Apps Script Web Apps** — doPost・Web App配備。
`https://developers.google.com/apps-script/guides/web`

**[S14] Apps Script Content Service** — JSON返答とリダイレクト。
`https://developers.google.com/apps-script/guides/content`

**[S15] UrlFetchApp** — 外部HTTP・timeoutSeconds。
`https://developers.google.com/apps-script/reference/url-fetch/url-fetch-app`

**[S16] Properties Service** — スクリプト設定と秘密の保管場所。
`https://developers.google.com/apps-script/guides/properties`

**[S17] LockService** — 同一スクリプト実行の排他。
`https://developers.google.com/apps-script/reference/lock/lock-service`

**[S18] Sheets batchUpdate** — 一括検証/更新と同時編集上の留意。
`https://developers.google.com/workspace/sheets/api/reference/rest/v4/spreadsheets/batchUpdate`

**[S19] Apps Script quotas** — 実際のアカウント上限の確認先。
`https://developers.google.com/apps-script/guides/services/quotas`

**[S20] ESP32-S3 Random Generation** — エントロピー源と本番乱数。
`https://docs.espressif.com/projects/esp-idf/en/stable/esp32s3/api-reference/system/random.html`

**[S21] ESP32-S3 NVS** — 保存・暗号化・実機区画。
`https://docs.espressif.com/projects/esp-idf/en/stable/esp32s3/api-reference/storage/nvs_flash.html`

**[S22] LVGL8 OS porting** — UI所有タスクと排他。
`https://raw.githubusercontent.com/lvgl/lvgl/v8.3.11/docs/porting/os.md`

**[S23] LVGL8 events** — クリックと押下継続の区別。
`https://raw.githubusercontent.com/lvgl/lvgl/v8.3.11/docs/overview/event.md`

### 既存設計書との接続

AI DUEL v1の本人認証・非公開Sheets・ContentService取扱い、JEV REVERSI v1の丸画面と再送原則、CAFE WEREWOLF v2の3〜10人対応を読み合わせた。既存資料の匿名前提を本カード集へ一律コピーしたり、私的手札のあるゲームへ公開盤面だけの復元を流用したりしない。実際のPCワークスペース・GASコードは未取得なので、継承箇所はエージェントが実物と照合する。

## Q7. エージェントへ渡す最終指示

> 本書をCAFE CARDSの正本として、COFFEE TIME第6メニューに4種類を実装してください。既存BSP、LCD/タッチ、コーヒー＋1、5つのゲーム、Google連携を保全してください。まずPC検査、次に端末AIで全ゲーム完走、次に保存・共通本人認証・Googleの再送と復旧、最後にJevへ進めてください。未来の札・相手の非公開手札をJevへ送らず、同時選択はAIを先に確定してください。本文の独自ルールを勝手に別流派へ変えないでください。全受入項目を記録し、書込み済み・実API接続済み・試遊済みを区別して報告してください。
`````

## ファイル：`reference/decision_protocol.py`

<!-- CAFE_CARDS_FILE {"path":"reference/decision_protocol.py","bytes":3625,"sha256":"9edfba7670405296a01c0bfbd6f5466480a6f769c6d7dbddc685f0d17b941b38"} -->
`````python
"""Executable specification of at-most-once decision reservation and UI revision guard.
NOT an Apps Script database implementation. Production persistence and locking are external.
"""
from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
from threading import RLock
import json
from typing import Any


def canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


@dataclass
class Decision:
    fingerprint: str
    status: str
    generation: int
    lease_until: int
    result: dict | None = None


class Ledger:
    """Single-writer model; memory is intentionally not described as durable storage."""
    def __init__(self):
        self.lock = RLock()
        self.jobs: dict[str, Decision] = {}
        self.call_reservations = 0

    def reserve(self, key: str, observation: dict, now_ms: int) -> tuple[Decision, bool]:
        fp = sha256(canonical(observation).encode()).hexdigest()
        with self.lock:
            old = self.jobs.get(key)
            if old is not None:
                if old.fingerprint != fp:
                    raise ValueError("IDEMPOTENCY_CONFLICT")
                return old, False
            job = Decision(fp, "pending", 1, now_ms + 60_000)
            self.jobs[key] = job
            self.call_reservations += 1
            return job, True

    def commit(self, key: str, generation: int, result: dict, now_ms: int) -> bool:
        with self.lock:
            job = self.jobs[key]
            if job.status != "pending" or generation != job.generation or now_ms > job.lease_until:
                return False
            job.status, job.result = "ready", json.loads(canonical(result))
            return True

    def expire(self, key: str, now_ms: int) -> Decision:
        with self.lock:
            job = self.jobs[key]
            if job.status == "pending" and now_ms > job.lease_until:
                job.status, job.result = "unavailable", {"code": "LEASE_EXPIRED"}
                job.generation += 1
            return job


class Controller:
    """A response can resolve only its original pending decision, at most once."""
    def __init__(self, match_id: str, revision: int, decision_id: str, legal: list[str]):
        self.match_id, self.revision, self.decision_id = match_id, revision, decision_id
        self.legal = set(legal)
        self.paused = False
        self.applied: str | None = None
        self.cached: dict | None = None
        self.provider = "jev"

    def accept(self, response: dict) -> str:
        if (response["match_id"], response["revision"], response["decision_id"]) != (
            self.match_id, self.revision, self.decision_id
        ) or self.applied is not None or self.provider != "jev":
            return "ignored"
        if response["selected_id"] not in self.legal:
            raise ValueError("ILLEGAL_ACTION")
        if self.paused:
            self.cached = dict(response)
            return "cached"
        self.applied = response["selected_id"]
        self.revision += 1
        return "applied"

    def resume(self) -> str:
        self.paused = False
        if self.cached is None:
            return "waiting"
        response, self.cached = self.cached, None
        return self.accept(response)

    def choose_local(self, selected: str) -> None:
        if self.applied is not None or selected not in self.legal:
            raise ValueError("ILLEGAL_FALLBACK")
        self.provider, self.applied = "mixed_local", selected
        self.cached = None
        self.revision += 1
`````

## ファイル：`reference/jev_contract.js`

<!-- CAFE_CARDS_FILE {"path":"reference/jev_contract.js","bytes":10683,"sha256":"23ced4de1ebd8e435db101158d5016010b50bd496f15c252bd9d501ebf770531"} -->
`````javascript
'use strict';
// Pure reference for Apps Script V8 / Node. It is NOT a deployed backend.
// full is an adapter DTO; never send full to Jev. This creates a new allowlisted tree.
const SUITS=['C','D','H','S'];
function cardName(c){
  if(!Number.isInteger(c)||c<0||c>415)throw Error('CARD_RANGE');
  const face=c%52,r=face%13+2;
  return SUITS[Math.floor(face/13)]+({11:'J',12:'Q',13:'K',14:'A'}[r]||String(r));
}
function pokerKey(cards){
  if(cards.length!==5 || new Set(cards).size!==5 || cards.some(c=>!Number.isInteger(c)||c<0||c>=52))throw Error('POKER_HAND');
  const ranks=cards.map(c=>c%13+2).sort((a,b)=>b-a), counts=new Map();
  for(const r of ranks)counts.set(r,(counts.get(r)||0)+1);
  const flush=cards.every(c=>Math.floor(c/13)===Math.floor(cards[0]/13));
  let straight=0;if(counts.size===5&&ranks[0]-ranks[4]===4)straight=ranks[0];
  if(JSON.stringify(ranks)==='[14,5,4,3,2]')straight=5;
  const groups=[...counts.entries()].sort((a,b)=>b[1]-a[1]||b[0]-a[0]);
  if(flush&&straight)return [8,straight,0,0,0,0];
  if(groups[0][1]===4)return [7,groups[0][0],groups[1][0],0,0,0];
  if(groups[0][1]===3&&groups[1][1]===2)return [6,groups[0][0],groups[1][0],0,0,0];
  if(flush)return [5,...ranks];if(straight)return [4,straight,0,0,0,0];
  if(groups[0][1]===3)return [3,groups[0][0],groups[1][0],groups[2][0],0,0];
  if(groups[0][1]===2&&groups[1][1]===2)return [2,groups[0][0],groups[1][0],groups[2][0],0,0];
  if(groups[0][1]===2)return [1,groups[0][0],groups[1][0],groups[2][0],groups[3][0],0];
  return [0,...ranks];
}
function score31(cards){
  if(cards.length!==3||new Set(cards).size!==3||cards.some(c=>!Number.isInteger(c)||c<0||c>=52))throw Error('THREE_HAND');
  const sums=[0,0,0,0];for(const c of cards){const r=c%13+2;sums[Math.floor(c/13)]+=r===14?11:Math.min(r,10);}return Math.max(...sums);
}
function mustInt(x,min,max){if(!Number.isInteger(x)||x<min||x>max)throw Error('RANGE');return x;}
function cleanStats(s){
  if(!s)return {sample_n:0};
  const out={sample_n:mustInt(s.sample_n,0,1000000)};
  for(const key of ['fold','check','call','bet','raise','knock','swap','stand','aggressive_opportunities','facing_bet_opportunities']){
    if(s[key]!==undefined)out[key]=mustInt(s[key],0,1000000);
  }
  return out;
}
function actionHistory(events,game){
  return events.slice(-24).map(e=>{
    if(!['H','A'].includes(e.actor))throw Error('ACTOR');
    const allowed=game==='poker'?['CHECK','BET','CALL','RAISE','FOLD','DRAW_COUNT']:['KNOCK','STAND','SWAP'];
    if(!allowed.includes(e.type))throw Error('PUBLIC_EVENT');
    const out={actor:e.actor==='A'?'SELF':'OPPONENT',type:e.type};
    if(e.amount!==undefined)out.amount=mustInt(e.amount,0,200);
    if(e.count!==undefined)out.count=mustInt(e.count,0,5);
    if(game==='thirty_one'&&e.type==='SWAP'&&e.out_card!==undefined)out.out_card=cardName(e.out_card);
    if(game==='thirty_one'&&e.type==='SWAP'&&e.in_card!==undefined)out.in_card=cardName(e.in_card);
    return out;
  });
}
function buildObservation(full){
  const base={game:full.game,variant:full.variant,phase:full.phase,rules_version:'1.0.0'};
  if(full.game==='poker'){
    if(!['bet_pre','draw','bet_post'].includes(full.phase))throw Error('PHASE');
    const s=full.street;
    Object.assign(base,{
      own_cards:full.hands[1].map(cardName),own_poker_key:pokerKey(full.hands[1]),own_discards:(full.discards[1]||[]).map(cardName),
      hand_no:mustInt(full.hand_no,1,5),max_hands:5,
      stacks:{self:full.stacks[1],opponent:full.stacks[0]},pot:full.pot,
      contribution:{self:s.paid[1],opponent:s.paid[0]},unit:s.unit,raises_left:2-s.raises,
      dealer:full.dealer===1?'SELF':'OPPONENT',
      draw_counts:full.phase==='bet_post'?{opponent:full.draw_counts[0],self:full.draw_counts[1]}:null,
      public_actions:actionHistory(full.public_actions||[],full.game),
      statistics:cleanStats(full.statistics)
    });
  }else if(full.game==='gops'){
    if(full.phase!=='bid')throw Error('PHASE');
    Object.assign(base,{n:full.n,round_no:full.round_no,prize:full.prize,
      own_remaining:full.remaining[1].slice(),opponent_remaining:full.remaining[0].slice(),
      scores:{self:full.scores[1],opponent:full.scores[0]},
      history:full.history.map(e=>({prize:e.prize,self:e.ai,opponent:e.human})),
      previous_match_history:(full.previous_match_history||[]).slice(-26).map(e=>({n:e.n,prize:e.prize,self:e.ai,opponent:e.human}))
    });
  }else if(full.game==='thirty_one'){
    if(!['turn','last_reply'].includes(full.phase))throw Error('PHASE');
    Object.assign(base,{own_cards:full.hands[1].map(cardName),own_score:score31(full.hands[1]),market:full.market.map(cardName),
      opponent_known_cards:full.publicly_known[0].map(cardName),
      opponent_unknown_count:3-full.publicly_known[0].length,turn_count:full.turns,
      final_reply:full.phase==='last_reply',public_actions:actionHistory(full.public_actions||[],full.game),statistics:cleanStats(full.statistics)});
  }else if(full.game==='baccarat'){
    if(full.phase!=='predict'||!['open','classic'].includes(full.variant))throw Error('PHASE');
    Object.assign(base,{decks:8,fresh_deck_each_round:true,
      public_first_cards:full.variant==='open'?{PLAYER:cardName(full.first[0]),BANKER:cardName(full.first[1])}:null});
  }else throw Error('GAME');
  return base;
}
function makeCriteria(full){
  const out={};
  if(full.game==='poker' && full.phase==='draw'){
    for(let mask=0;mask<32;mask++){
      const replace=[],keep=[];
      full.hands[1].forEach((c,i)=>((mask&(1<<i))?replace:keep).push(cardName(c)));
      out['DRAW:'+mask]='Replace ['+replace.join(',')+']; keep ['+keep.join(',')+']. Draw only once.';
    }
  }else if(full.game==='poker'){
    const s=full.street,owed=Math.max(...s.paid)-s.paid[1];
    if(owed===0){out.CHECK='Continue without adding chips.';out.BET='Add '+s.unit+' chips and ask the opponent to match.';}
    else{out.FOLD='Concede this hand without revealing cards.';out.CALL='Add '+owed+' chips to match.';if(s.raises<2)out.RAISE='Add '+(owed+s.unit)+' chips, matching and raising by '+s.unit+'.';}
  }else if(full.game==='gops'){
    for(const n of full.remaining[1])out['PLAY:'+n]='Use card '+n+' now; it cannot be used again. Higher card wins the prize; equal bids burn the prize.';
  }else if(full.game==='thirty_one'){
    for(let i=0;i<3;i++)for(let j=0;j<3;j++)out['SWAP:'+i+':'+j]='Exchange own '+cardName(full.hands[1][i])+' for market '+cardName(full.market[j])+'.';
    if(full.phase==='last_reply')out.STAND='Keep current hand and immediately compare scores.';
    else out.KNOCK='Keep current hand; opponent has one last swap or stand, then compare.';
  }else if(full.game==='baccarat'){
    out.PLAYER='The PLAYER table hand will have the higher final point total.';
    out.BANKER='The BANKER table hand will have the higher final point total.';
    out.TIE='Both table hands will have the same final point total.';
  }else throw Error('GAME');
  return out;
}
const RULES={
 poker:'Two-player five-card draw, standard high poker ranking; A2345 is five-high. No suit tie-break. Five hands. The nondealer acts first on both betting streets. Both start the match at 100 nonmonetary chips. Ante 1 per hand; fixed betting unit 2 before draw, 4 after; maximum two raises per street. No blinds/all-in. One simultaneous draw of zero to five cards. Opponent current hand and unexposed discards are unknown. Win by showdown or opponent folding. Maximize expected chip balance, but do not invent missing cards.',
 gops:'Both players start with cards 1..N. A shuffled prize 1..N appears each round. Simultaneous sealed bids use one remaining card each; higher bid wins the prize, equal bids discard the prize. Used cards never return. Maximize total points over N rounds. Opponent pending bid and future prize order are unknown.',
 thirty_one:'Two players, three private cards each and three public market cards. Each normal turn is exactly one swap OR knock. Sum only cards of the same suit; A=11, JQK=10, number cards face value; score is the largest suit sum. No three-of-kind bonus; equal scores draw. 31 ends immediately. A knock gives the opponent one final swap or stand. Twenty normal actions cap the hand; a knock at action20 still permits the last reply. Maximize chance of winning this hand.',
 baccarat:'Both actors predict the same two table hands, PLAYER and BANKER. Fresh eight-deck pack each round, no replacement within round. A=1; 2..9 face value; 10/J/Q/K=0. Totals modulo10. Deal P1 B1 P2 B2. Natural8/9 on either first two cards ends both hands. Otherwise P draws on0..5, stands6..7. If P stands, B draws0..5. If P draws: B0..2 always draws; B3 except P3=8; B4 if P3=2..7; B5 if P3=4..7; B6 if P3=6/7; B7 stands. Higher final total wins. One point per correct prediction, including tie; no payouts. Do not assume a streak predicts the fresh deck.'
};
function makeRequest(full,model='jev-1.13.0'){
  const criteria=makeCriteria(full),keys=Object.keys(criteria);
  if(keys.length<2||keys.length>255)throw Error('CHOICE_COUNT');
  return {model,state:{rules:RULES[full.game],observation:buildObservation(full)},questions:{action:{type:'choice',instructions:full.game==='baccarat'?'Predict the final outcome using ONLY the public information. Output a relative forecast, not certainty.':'Choose ONE listed legal action as SELF. Use only your own cards, public information and allowed history. The opponent private cards, current sealed selection and future deck are not provided. Do not fabricate them.',criteria}}};
}
function validateResponse(response,legal){
  const a=response&&response.answers&&response.answers.action;
  if(!a||a.type!=='choice'||(typeof response.model!=='string'||!response.model.trim()))throw Error('BAD_RESPONSE');
  const keys=Object.keys(a.probabilities||{}).sort(),want=legal.slice().sort();
  if(JSON.stringify(keys)!==JSON.stringify(want))throw Error('CHOICE_KEYS');
  let sum=0,max=-1;
  for(const key of keys){const x=a.probabilities[key];if(typeof x!=='number'||!Number.isFinite(x)||x<0||x>1)throw Error('PROB_RANGE');sum+=x;max=Math.max(max,x);}
  if(Math.abs(sum-1)>0.001||sum<=0)throw Error('PROB_SUM');
  if(!want.includes(a.choice)||Math.abs(a.probabilities[a.choice]-max)>1e-6)throw Error('CHOICE_MAX');
  if(typeof a.confidence!=='number'||!Number.isFinite(a.confidence)||a.confidence<0||a.confidence>1)throw Error('CONFIDENCE');
  const p={};for(const k of keys)p[k]=a.probabilities[k]/sum;
  return {selected_id:a.choice,probabilities:p,confidence:a.confidence,model:response.model,normalization_applied:sum!==1};
}
if(typeof module!=='undefined')module.exports={RULES,cardName,pokerKey,score31,buildObservation,makeCriteria,makeRequest,validateResponse};
`````

## ファイル：`reference/local_policy.hpp`

<!-- CAFE_CARDS_FILE {"path":"reference/local_policy.hpp","bytes":2609,"sha256":"de522c133ca225913c025f8a73c7e64ca0c771495c9d803c34130569c35a3cec"} -->
`````cpp
#pragma once
#include "../core/cards_core.hpp"
// Baseline opponent, not Jev and not an optimal card engine.
// Only the acting AI's own hand and public state may be passed to these functions.
namespace cafe_cards {
inline int local_poker_draw(const std::array<Card,5>& own) {
    auto v=poker_value(own); if(!v.valid)return -1;
    const int cat=v.key[0];
    if(cat==4||cat==5||cat==6||cat==8)return 0;
    std::array<int,15> counts{};for(auto c:own)++counts[rank(c)];
    int mask=0;
    if(cat==1||cat==2||cat==3||cat==7) {
        for(int i=0;i<5;++i)if(counts[rank(own[i])]==1)mask|=1<<i;
        return mask;
    }
    // High-card hand: prefer keeping a four-card flush draw.
    std::array<int,4> suits{};for(auto c:own)++suits[suit(c)];
    for(int s=0;s<4;++s)if(suits[s]==4) {
        for(int i=0;i<5;++i)if(suit(own[i])!=s)mask|=1<<i;
        return mask;
    }
    std::array<int,5> slots{0,1,2,3,4};
    std::sort(slots.begin(),slots.end(),[&](int a,int b){return rank(own[a])!=rank(own[b])?rank(own[a])>rank(own[b]):a<b;});
    for(int i=2;i<5;++i)mask|=1<<slots[i];
    return mask;
}
inline BetAction local_poker_bet(const std::array<Card,5>& own,const Street& s,uint32_t saved_roll) {
    auto v=poker_value(own);int cat=v.key[0],r=int(saved_roll%100);
    bool strong=cat>=2;
    if(s.paid[0]==s.paid[1]) {
        bool attack=strong || (cat==1&&r<45) || (cat==0&&r<12);
        return attack?BetAction::Bet:BetAction::Check;
    }
    if(s.raises<2 && (strong || (cat==1&&r<15) || (cat==0&&r<5)))return BetAction::Raise;
    if(cat>=1 || r<25)return BetAction::Call;
    return BetAction::Fold;
}
// remaining sorted ascending; jitter is -1,0,+1 drawn BEFORE receiving a human bid.
inline int local_gops(const std::array<int,13>& remaining,int count,int prize,int n,int jitter) {
    if(count<1||count>13||(n!=7&&n!=13)||prize<1||prize>n||jitter<-1||jitter>1)return -1;
    int index=((prize-1)*(count-1)+(n-1)/2)/(n-1);
    index=std::max(0,std::min(count-1,index+jitter));return remaining[index];
}
struct Local31 { int hand_slot=-1,market_slot=-1;bool knock=false,stand=false; };
inline Local31 local_thirty_one(const std::array<Card,3>& own,const std::array<Card,3>& market,bool final_reply) {
    Local31 a;int current=score31(own),best=-1;
    for(int i=0;i<3;++i)for(int j=0;j<3;++j) {
        auto h=own;h[i]=market[j];int s=score31(h);
        if(s>best){best=s;a.hand_slot=i;a.market_slot=j;}
    }
    if(final_reply && best<=current){a={};a.stand=true;}
    else if(!final_reply && (current>=27 || best<=current)){a={};a.knock=true;}
    return a;
}
} // namespace cafe_cards
`````

## ファイル：`reference/observation_gate.js`

<!-- CAFE_CARDS_FILE {"path":"reference/observation_gate.js","bytes":9055,"sha256":"6c2ea3a1f67a11c34f12e54ae2f745e600c57fb1ff0e5b33a8cf48d98f9b8349"} -->
`````javascript
'use strict';
// Production-boundary reference. Runs after device/player auth and match ownership.
// It validates sanitized observations, not private full-state snapshots.
const CardsContract=typeof require==='function'?require('./jev_contract.js'):null;
function exactKeys(o,keys){
  if(!o||typeof o!=='object'||Array.isArray(o))throw Error('OBJECT');
  if(JSON.stringify(Object.keys(o).sort())!==JSON.stringify(keys.slice().sort()))throw Error('UNKNOWN_OR_MISSING_KEY');
}
function bounded(x,lo,hi){if(!Number.isInteger(x)||x<lo||x>hi)throw Error('INTEGER');return x;}
function faceId(s){
  if(typeof s!=='string'||!/^([CDHS])([2-9]|10|J|Q|K|A)$/.test(s))throw Error('FACE');
  const r={J:11,Q:12,K:13,A:14}[s.slice(1)]||Number(s.slice(1));return 'CDHS'.indexOf(s[0])*13+r-2;
}
function cardList(a,lo,hi){if(!Array.isArray(a)||a.length<lo||a.length>hi||new Set(a).size!==a.length)throw Error('CARD_LIST');a.forEach(faceId);}
function actorName(s){if(!['SELF','OPPONENT'].includes(s))throw Error('ACTOR');}
function statCheck(s){
  const allowed=['sample_n','fold','check','call','bet','raise','knock','swap','stand','aggressive_opportunities','facing_bet_opportunities'];
  if(!s||typeof s!=='object'||Array.isArray(s)||!Object.hasOwn(s,'sample_n')||Object.keys(s).some(k=>!allowed.includes(k)))throw Error('STATS');
  Object.values(s).forEach(x=>bounded(x,0,1000000));
}
function historyCheck(events,game){
  if(!Array.isArray(events)||events.length>24)throw Error('HISTORY');
  const allowed=game==='poker'?['CHECK','BET','CALL','RAISE','FOLD','DRAW_COUNT']:['SWAP','KNOCK','STAND'];
  for(const e of events){actorName(e.actor);if(!allowed.includes(e.type))throw Error('EVENT_TYPE');
    let keys=['actor','type'];
    if(['BET','CALL','RAISE'].includes(e.type)){keys.push('amount');bounded(e.amount,1,12);}
    if(e.type==='DRAW_COUNT'){keys.push('count');bounded(e.count,0,5);}
    if(e.type==='SWAP'){keys.push('out_card','in_card');faceId(e.out_card);faceId(e.in_card);if(e.out_card===e.in_card)throw Error('IDENTICAL_SWAP');}
    exactKeys(e,keys);
  }
}
function validateObservation(o){
  const base=['game','variant','phase','rules_version'];
  if(!o||o.rules_version!=='1.0.0')throw Error('VERSION');
  const criteria={};
  if(o.game==='poker'){
    exactKeys(o,base.concat(['own_cards','own_poker_key','own_discards','hand_no','max_hands','stacks','pot','contribution','unit','raises_left','dealer','draw_counts','public_actions','statistics']));
    if(o.variant!=='fixed5'||!['bet_pre','draw','bet_post'].includes(o.phase))throw Error('VARIANT_PHASE');
    cardList(o.own_cards,5,5);cardList(o.own_discards,0,5);
    if(o.own_cards.some(c=>o.own_discards.includes(c)))throw Error('DISCARD_OVERLAP');
    const pv=(CardsContract?CardsContract.pokerKey:pokerKey)(o.own_cards.map(faceId));
    if(JSON.stringify(pv)!==JSON.stringify(o.own_poker_key))throw Error('POKER_KEY');
    bounded(o.hand_no,1,5);if(o.max_hands!==5)throw Error('MAX_HANDS');actorName(o.dealer);
    exactKeys(o.stacks,['self','opponent']);exactKeys(o.contribution,['self','opponent']);
    bounded(o.stacks.self,0,200);bounded(o.stacks.opponent,0,200);bounded(o.pot,2,38);
    if(o.stacks.self+o.stacks.opponent+o.pot!==200)throw Error('CHIPS');
    if(o.unit!==(o.phase==='bet_post'?4:2))throw Error('UNIT');bounded(o.raises_left,0,2);
    for(const x of Object.values(o.contribution)){bounded(x,0,3*o.unit);if(x%o.unit)throw Error('CONTRIBUTION');}
    const owed=o.contribution.opponent-o.contribution.self;
    if(owed<0)throw Error('WRONG_TURN');
    if(o.phase==='bet_post'){exactKeys(o.draw_counts,['self','opponent']);Object.values(o.draw_counts).forEach(x=>bounded(x,0,5));}
    else if(o.draw_counts!==null)throw Error('EARLY_DRAW_COUNTS');
    if(o.phase!=='bet_post'&&o.own_discards.length)throw Error('EARLY_DISCARDS');
    if(o.phase==='draw'){
      if(owed!==0)throw Error('UNSETTLED_STREET');
      for(let mask=0;mask<32;mask++){const keep=[],discard=[];o.own_cards.forEach((c,i)=>((mask&(1<<i))?discard:keep).push(c));criteria['DRAW:'+mask]='Replace ['+discard.join(',')+']; keep ['+keep.join(',')+']. Draw once.';}
    }else if(owed===0){if(o.contribution.self!==0)throw Error('CLOSED_STREET');criteria.CHECK='Continue without adding chips.';criteria.BET='Add '+o.unit+' chips.';}
    else{if(owed!==o.unit)throw Error('OWED');criteria.FOLD='Concede the hand without exposing cards.';criteria.CALL='Add '+owed+' chips to match.';if(o.raises_left>0)criteria.RAISE='Add '+(owed+o.unit)+' chips to match and raise.';}
    historyCheck(o.public_actions,'poker');statCheck(o.statistics);
  }else if(o.game==='gops'){
    exactKeys(o,base.concat(['n','round_no','prize','own_remaining','opponent_remaining','scores','history','previous_match_history']));
    if(![7,13].includes(o.n)||o.variant!==(o.n===7?'quick7':'classic13')||o.phase!=='bid')throw Error('VARIANT_PHASE');
    bounded(o.round_no,1,o.n);bounded(o.prize,1,o.n);
    for(const a of [o.own_remaining,o.opponent_remaining]){if(!Array.isArray(a)||a.length!==o.n-o.round_no+1||new Set(a).size!==a.length)throw Error('REMAINING');a.forEach(x=>bounded(x,1,o.n));if(a.some((v,i)=>i&&a[i-1]>=v))throw Error('SORT');}
    if(!Array.isArray(o.history)||o.history.length!==o.round_no-1)throw Error('HISTORY_LENGTH');
    let hs=0,as=0;const prizes=new Set(),self=new Set(),other=new Set();
    for(const e of o.history){exactKeys(e,['prize','self','opponent']);Object.values(e).forEach(x=>bounded(x,1,o.n));if(prizes.has(e.prize)||self.has(e.self)||other.has(e.opponent))throw Error('USED_TWICE');prizes.add(e.prize);self.add(e.self);other.add(e.opponent);if(e.self>e.opponent)as+=e.prize;if(e.self<e.opponent)hs+=e.prize;}
    if(prizes.has(o.prize)||o.own_remaining.some(x=>self.has(x))||o.opponent_remaining.some(x=>other.has(x)))throw Error('ALREADY_USED');
    exactKeys(o.scores,['self','opponent']);if(o.scores.self!==as||o.scores.opponent!==hs)throw Error('SCORE');
    if(!Array.isArray(o.previous_match_history)||o.previous_match_history.length>26)throw Error('PREVIOUS');
    for(const e of o.previous_match_history){exactKeys(e,['n','prize','self','opponent']);if(e.n!==o.n)throw Error('MIXED_VARIANT');['prize','self','opponent'].forEach(k=>bounded(e[k],1,o.n));}
    for(const x of o.own_remaining)criteria['PLAY:'+x]='Use remaining card '+x+' now; it cannot be reused.';
  }else if(o.game==='thirty_one'){
    exactKeys(o,base.concat(['own_cards','own_score','market','opponent_known_cards','opponent_unknown_count','turn_count','final_reply','public_actions','statistics']));
    if(o.variant!=='market3'||!['turn','last_reply'].includes(o.phase)||o.final_reply!==(o.phase==='last_reply'))throw Error('VARIANT_PHASE');
    cardList(o.own_cards,3,3);cardList(o.market,3,3);cardList(o.opponent_known_cards,0,3);
    const all=o.own_cards.concat(o.market,o.opponent_known_cards);if(new Set(all).size!==all.length)throw Error('OVERLAP');
    if(o.opponent_unknown_count!==3-o.opponent_known_cards.length)throw Error('UNKNOWN_COUNT');
    bounded(o.turn_count,o.final_reply?1:0,o.final_reply?20:19);
    const score=(CardsContract?CardsContract.score31:score31)(o.own_cards.map(faceId));if(score!==o.own_score||score===31)throw Error('SCORE');
    for(let i=0;i<3;i++)for(let j=0;j<3;j++)criteria['SWAP:'+i+':'+j]='Exchange '+o.own_cards[i]+' for '+o.market[j]+'.';
    if(o.final_reply)criteria.STAND='Keep cards and compare now.';else criteria.KNOCK='Keep cards; opponent gets one final reply.';
    historyCheck(o.public_actions,'thirty_one');statCheck(o.statistics);
  }else if(o.game==='baccarat'){
    exactKeys(o,base.concat(['decks','fresh_deck_each_round','public_first_cards']));
    if(!['open','classic'].includes(o.variant)||o.phase!=='predict'||o.decks!==8||o.fresh_deck_each_round!==true)throw Error('VARIANT_PHASE');
    if(o.variant==='open'){exactKeys(o.public_first_cards,['PLAYER','BANKER']);Object.values(o.public_first_cards).forEach(faceId);}
    else if(o.public_first_cards!==null)throw Error('EARLY_CARDS');
    criteria.PLAYER='PLAYER final points will exceed BANKER.';criteria.BANKER='BANKER final points will exceed PLAYER.';criteria.TIE='Final point totals will be equal.';
  }else throw Error('GAME');
  return criteria;
}
function requestFromObservation(o,legalIds,model='jev-1.13.0'){
  const criteria=validateObservation(o),keys=Object.keys(criteria).sort();
  if(!Array.isArray(legalIds)||JSON.stringify(legalIds)!==JSON.stringify(keys))throw Error('LEGAL_IDS');
  if(keys.length<2||keys.length>255)throw Error('FORCED_OR_TOO_MANY');
  const rule=(CardsContract?CardsContract.RULES:RULES)[o.game];
  return {model,state:{rules:rule,observation:JSON.parse(JSON.stringify(o))},questions:{action:{type:'choice',instructions:o.game==='baccarat'?'Predict the final table-hand outcome using only the public information.':'As SELF, choose one legal action. Use only your own cards and public information; never invent the opponent cards or future deck.',criteria}}};
}
if(typeof module!=='undefined')module.exports={validateObservation,requestFromObservation};
`````

## ファイル：`results/contract_tests.json`

<!-- CAFE_CARDS_FILE {"path":"results/contract_tests.json","bytes":123,"sha256":"e37098cb2496c1f7c46cd4bf84eaf2d127062665fcfc49dab256badac3d0eba3"} -->
`````json
{"suite":"jev_contract","groups_passed":23,"information_isolation_games":4,"invalid_responses":11,"live_jev_called":false}
`````

## ファイル：`results/cpp_tests.json`

<!-- CAFE_CARDS_FILE {"path":"results/cpp_tests.json","bytes":373,"sha256":"16fd2f98d37adb2d9612dc30cf41b9fc43a27afe7585c89215061ac40468c957"} -->
`````json
{
  "suite": "portable_cpp",
  "full": true,
  "groups_passed": 26,
  "poker_category_hands": 2598960,
  "poker_matches": 2000,
  "poker_hands_simulated": 10000,
  "draw_mask_pairs": 1024,
  "betting_terminal_paths": 52,
  "gops_games": 2000,
  "three_card_hands": 22100,
  "thirty_one_games": 3000,
  "baccarat_value_streams": 1000000,
  "baccarat_prediction_cases": 27
}
`````

## ファイル：`results/cross_tests.json`

<!-- CAFE_CARDS_FILE {"path":"results/cross_tests.json","bytes":99,"sha256":"f4bcdd63da5ef10b7aa6c4616c90b572345aa3491325654a58fe357c1dcc0f59"} -->
`````json
{
  "suite": "cpp_javascript_cross_check",
  "hands": 2000,
  "poker_and_thirty_one_match": true
}
`````

## ファイル：`results/data_tests.json`

<!-- CAFE_CARDS_FILE {"path":"results/data_tests.json","bytes":160,"sha256":"d525982576ebea3ac9393b9352402e6784fd5eb78ac5059333cef013a1e5de63"} -->
`````json
{
  "suite": "catalog_and_geometry",
  "card_records": 52,
  "safe_rectangles": 31,
  "probability_triples": 101,
  "ui_strings": 119,
  "tutorial_pages": 22
}
`````

## ファイル：`results/environment.json`

<!-- CAFE_CARDS_FILE {"path":"results/environment.json","bytes":214,"sha256":"468e13171a5b4e1c7a45b5d6a0f2b838e71ffde321e2dc0c60b462d61d5db6e4"} -->
`````json
{
  "python": "3.13.5",
  "node": "v22.16.0",
  "compiler": "g++ (Debian 14.2.0-19) 14.2.0",
  "full": true,
  "sanitize": true,
  "esp32_tested": false,
  "live_google_tested": false,
  "live_jev_tested": false
}
`````

## ファイル：`results/gate_tests.json`

<!-- CAFE_CARDS_FILE {"path":"results/gate_tests.json","bytes":73,"sha256":"b01b3dcba4bcb168f4b03d27e60d71d94a690384930aa63704382014cb5f0860"} -->
`````json
{"suite":"observation_gate","groups_passed":18,"live_apis_called":false}
`````

## ファイル：`results/local_tests.json`

<!-- CAFE_CARDS_FILE {"path":"results/local_tests.json","bytes":143,"sha256":"9d61f25825662bedabbfe822e7bae512ed904083427e7db454e645fea7f22cdb"} -->
`````json
{
  "suite": "local_policies",
  "poker_legal_actions": 15000,
  "thirty_one_cases": 10000,
  "swap_cases": 8009,
  "live_jev_called": false
}
`````

## ファイル：`results/protocol_tests.json`

<!-- CAFE_CARDS_FILE {"path":"results/protocol_tests.json","bytes":162,"sha256":"d31d31d412867c02f19cd33d793f39aa014b86034444723351907ad37efa250a"} -->
`````json
{
  "suite": "protocol_model",
  "assertions_passed": 72,
  "parallel_reservations": 64,
  "provider_calls_reserved_once": true,
  "real_storage_tested": false
}
`````

## ファイル：`results/sanitizer_tests.json`

<!-- CAFE_CARDS_FILE {"path":"results/sanitizer_tests.json","bytes":362,"sha256":"017315db8e7aad2ad7e9e27523603527024addb8394fa48c5058ab98c2c92b34"} -->
`````json
{
  "suite": "portable_cpp",
  "full": false,
  "groups_passed": 25,
  "poker_category_hands": 0,
  "poker_matches": 200,
  "poker_hands_simulated": 1000,
  "draw_mask_pairs": 1024,
  "betting_terminal_paths": 52,
  "gops_games": 200,
  "three_card_hands": 22100,
  "thirty_one_games": 300,
  "baccarat_value_streams": 10000,
  "baccarat_prediction_cases": 27
}
`````

## ファイル：`tests/contract_test.js`

<!-- CAFE_CARDS_FILE {"path":"tests/contract_test.js","bytes":3665,"sha256":"6828295e5b58962b9fae29138d7769bb0a66e76dc1bf9dd2e70cfc5fef10a65d"} -->
`````javascript
'use strict';
const assert=require('node:assert/strict');
const c=require('../reference/jev_contract.js');
let groups=0;function pass(){groups++;}
const poker={game:'poker',variant:'fixed5',phase:'bet_pre',hands:[[0,1,2,3,4],[5,6,7,8,9]],discards:[[],[]],street:{paid:[2,0],unit:2,raises:0},hand_no:1,stacks:[97,99],pot:4,dealer:0,public_actions:[],statistics:{sample_n:0},deck:['SECRET_DECK'],pending_human_action:'FOLD'};
const gops={game:'gops',variant:'quick7',phase:'bid',n:7,round_no:1,prize:4,remaining:[[1,2,3,4,5,6,7],[1,2,3,4,5,6,7]],scores:[0,0],history:[],future_prizes:[1,7,2],sealed_human:7};
const t31={game:'thirty_one',variant:'market3',phase:'turn',hands:[[0,1,2],[13,14,15]],market:[26,27,28],publicly_known:[[],[]],turns:0,public_actions:[]};
const bac={game:'baccarat',variant:'open',phase:'predict',first:[5,13],cards:[5,13,33,44,22,40],outcome:'BANKER',human_guess:'TIE'};
for(const f of [poker,gops,t31,bac]){
 const a=c.makeRequest(f);const altered=structuredClone(f);
 altered.deck=['CHANGED_SECRET'];altered.pending_human_action='RAISE';altered.future_prizes=[6,5,4];altered.sealed_human=1;altered.outcome='TIE';altered.human_guess='PLAYER';
 if(altered.hands)altered.hands[0]=[40,41,42,43,44].slice(0,altered.hands[0].length);
 if(altered.cards)altered.cards=[5,13,1,2,3,4];
 assert.deepEqual(c.makeRequest(altered),a);assert(!JSON.stringify(a).includes('SECRET'));pass();
}
let pd=structuredClone(poker);pd.phase='draw';assert.equal(Object.keys(c.makeCriteria(pd)).length,32);assert(c.makeCriteria(pd)['DRAW:0'].includes('Replace []'));assert(c.makeCriteria(pd)['DRAW:31'].includes('keep []'));pass();
pd.draw_counts=[5,4];const pre=c.buildObservation(pd);assert.equal(pre.draw_counts,null);pd.phase='bet_post';assert.deepEqual(c.buildObservation(pd).draw_counts,{opponent:5,self:4});pass();
assert.deepEqual(Object.keys(c.makeCriteria(poker)),['FOLD','CALL','RAISE']);poker.street.raises=2;assert.deepEqual(Object.keys(c.makeCriteria(poker)),['FOLD','CALL']);poker.street.paid=[0,0];assert.deepEqual(Object.keys(c.makeCriteria(poker)),['CHECK','BET']);pass();
assert.equal(Object.keys(c.makeCriteria(gops)).length,7);assert.equal(Object.keys(c.makeCriteria(t31)).length,10);t31.phase='last_reply';assert(c.makeCriteria(t31).STAND && !c.makeCriteria(t31).KNOCK);pass();
bac.variant='classic';const classic=c.makeRequest(bac);bac.first=[42,41];assert.deepEqual(c.makeRequest(bac),classic);assert.equal(classic.state.observation.public_first_cards,null);pass();
let ok={model:'jev-1.13.0',answers:{action:{type:'choice',choice:'A',probabilities:{A:.6,B:.4},confidence:.2}}};assert.equal(c.validateResponse(ok,['A','B']).selected_id,'A');pass();
const mutations=[x=>x.answers.action.probabilities.A=-1,x=>x.answers.action.probabilities.A=NaN,x=>x.answers.action.probabilities.A=true,x=>x.answers.action.probabilities.C=.1,x=>delete x.answers.action.probabilities.B,x=>x.answers.action.probabilities.A=.2,x=>x.answers.action.choice='C',x=>x.answers.action.choice='B',x=>x.answers.action.confidence=Infinity,x=>x.answers.action.type='score',x=>x.model=null];
for(const mutate of mutations){let x=structuredClone(ok);mutate(x);assert.throws(()=>c.validateResponse(x,['A','B']));pass();}
let x=structuredClone(ok);x.answers.action.probabilities.A=.6001;assert(c.validateResponse(x,['A','B']).normalization_applied);pass();
assert.throws(()=>c.cardName(416));assert.throws(()=>c.cardName(-1));assert.equal(c.cardName(12),'CA');assert.equal(c.cardName(64),'CA');pass();
const out={suite:'jev_contract',groups_passed:groups,information_isolation_games:4,invalid_responses:mutations.length,live_jev_called:false};console.log(JSON.stringify(out));
`````

## ファイル：`tests/core_test.cpp`

<!-- CAFE_CARDS_FILE {"path":"tests/core_test.cpp","bytes":10289,"sha256":"147bcae6d164b4cc31c63f466f82d2bb943194eb949fea7e54f97d24dc5411ac"} -->
`````cpp
#include "../core/cards_core.hpp"
#include <cassert>
#include <cstdlib>
#include <iostream>
#include <random>
#include <vector>
#include <string>
using namespace cafe_cards;
static std::mt19937 rng(20260922);
static uint32_t next32(void* p){return (*static_cast<std::mt19937*>(p))();}
static Card C(int r,int s){return Card(s*13+r-2);}
static int groups=0;
#define GROUP(name) do{++groups;std::cerr<<"PASS "<<name<<"\n";}while(false)
static std::vector<BetAction> actions(const Street&s){std::vector<BetAction> a;for(int i=0;i<5;++i)if(s.legal(BetAction(i)))a.push_back(BetAction(i));return a;}
static long long street_paths=0;
static void walk(Street s,int depth){
    assert(depth<=5);
    if(s.closed){assert(s.paid[0]<=3*s.unit && s.paid[1]<=3*s.unit);if(s.fold_winner<0)assert(s.paid[0]==s.paid[1]);++street_paths;return;}
    auto as=actions(s);assert(!as.empty());
    for(auto a:as){Street n=s;int delta=-1;assert(n.apply(s.actor,a,delta));assert(delta>=0);walk(n,depth+1);}
}
// Independently encoded third-card table, indexed by original banker total and P3 value.
static const char* TABLE[8]={"1111111111","1111111111","1111111111","1111111101","0011111100","0000111100","0000001100","0000000000"};
static BaccaratResult reference_bac(const std::array<int,6>& v){
    BaccaratResult r;r.valid=true;r.p={v[0],v[2],-1};r.b={v[1],v[3],-1};r.np=r.nb=2;r.used=4;
    const int p0=(v[0]+v[2])%10,b0=(v[1]+v[3])%10;r.pt=p0;r.bt=b0;r.natural=p0>7 || b0>7;
    if(!r.natural){bool phit=p0<6;if(phit){r.p[2]=v[4];r.np=3;r.pt=(p0+v[4])%10;++r.used;}
        bool bhit=phit?TABLE[b0][v[4]]=='1':b0<6;
        if(bhit){r.b[2]=v[phit?5:4];r.nb=3;r.bt=(b0+r.b[2])%10;++r.used;}}
    r.winner=r.pt==r.bt?2:(r.pt>r.bt?0:1);return r;
}
int main(int argc,char**argv){
    bool full=argc>1 && std::string(argv[1])=="--full";
    for(int i=0;i<416;++i){assert(rank(Card(i))>=2 && rank(Card(i))<=14);assert(suit(Card(i))>=0 && suit(Card(i))<4);}
    assert(baccarat_value(C(14,0))==1 && value31(C(14,0))==11 && baccarat_value(C(10,0))==0);GROUP("card values");
    for(int copies:{1,8})for(int k=0;k<100;++k){Deck d;assert(d.init(copies,next32,&rng));assert(d.valid());Card c;for(int i=0;i<d.size;++i)assert(d.take(c));assert(!d.take(c));}
    GROUP("shuffle uniqueness and exhaustion");
    Deck bad;assert(!bad.init(2,next32,&rng));assert(!bad.init(1,nullptr,nullptr));Card dup[2]={0,0};assert(!valid_cards(dup,2));GROUP("invalid deck");
    auto royal=poker_value({C(10,0),C(11,0),C(12,0),C(13,0),C(14,0)});assert(royal.key[0]==8 && royal.key[1]==14);
    auto wheel=poker_value({C(14,0),C(2,1),C(3,2),C(4,3),C(5,0)});assert(wheel.key[0]==4 && wheel.key[1]==5);GROUP("poker royal and wheel");
    assert(!poker_value({0,0,1,2,3}).valid);assert(!poker_value({0,1,2,3,52}).valid);GROUP("poker invalid cards");
    std::array<Card,5>a={C(8,0),C(8,1),C(14,2),C(9,0),C(7,1)};
    auto b=a;b[4]=C(6,1);assert(poker_compare(a,b)==1);b=a;for(auto&c:b)c=Card((c+13)%52);assert(poker_compare(a,b)==0);GROUP("poker kickers and suit ties");
    for(int who=0;who<2;++who)for(int unit:{2,4}){Street s;s.actor=who;s.unit=unit;walk(s,0);}
    GROUP("all betting paths");
    Street s;int debit;assert(!s.apply(1,BetAction::Bet,debit));assert(!s.apply(0,BetAction::Call,debit));assert(!s.apply(0,BetAction::Fold,debit));assert(s.apply(0,BetAction::Bet,debit));assert(!s.legal(BetAction::Check));GROUP("betting invalid action guards");
    Deck d;assert(d.init(1,next32,&rng));
    for(int m0=0;m0<32;++m0)for(int m1=0;m1<32;++m1){PokerHand p;assert(p.start(d,0,{100,100}));assert(p.bet(1,BetAction::Check));assert(p.bet(0,BetAction::Check));auto old=p.hands;
        assert(p.draw(0,m0));assert(p.hands==old);assert(!p.draw(0,m0));assert(p.draw(1,m1));
        Card all[20];int k=0;for(auto&h:p.hands)for(auto c:h)all[k++]=c;for(int i=0;i<p.discard_count;++i)all[k++]=p.discards[i];assert(valid_cards(all,k));
        assert(p.deck.cursor==10+__builtin_popcount(unsigned(m0))+__builtin_popcount(unsigned(m1)));assert(p.phase==PokerPhase::Post);
    }
    GROUP("all 1024 simultaneous draw masks");
    PokerHand p;assert(p.start(d,0,{100,100}));assert(p.bet(1,BetAction::Bet));assert(p.bet(0,BetAction::Fold));assert(p.folded && p.winner==1 && p.pot==0 && p.stack[0]+p.stack[1]==200);GROUP("poker fold settlement");
    int poker_matches=full?2000:200;
    for(int game=0;game<poker_matches;++game){std::array<int,2>chips={100,100};for(int hand=0;hand<5;++hand){Deck dd;dd.init(1,next32,&rng);PokerHand q;assert(q.start(dd,hand%2,chips));int n=0;
        while(q.phase!=PokerPhase::Finished){assert(++n<20);if(q.phase==PokerPhase::Draw){q.draw(1,int(rng()%32));q.draw(0,int(rng()%32));}else{auto aa=actions(q.street);assert(!aa.empty());assert(q.bet(q.street.actor,aa[rng()%aa.size()]));}assert(q.stack[0]+q.stack[1]+q.pot==200);assert(q.stack[0]>=0&&q.stack[1]>=0);}
        chips=q.stack;assert(chips[0]+chips[1]==200);
    }}
    GROUP("five-hand poker match simulations");
    long long poker_hands=0;std::array<long long,9>freq{};
    if(full){for(int i=0;i<48;++i)for(int j=i+1;j<49;++j)for(int k=j+1;k<50;++k)for(int l=k+1;l<51;++l)for(int m=l+1;m<52;++m){auto v=poker_value({Card(i),Card(j),Card(k),Card(l),Card(m)});assert(v.valid);++freq[v.key[0]];++poker_hands;}
        assert((freq==std::array<long long,9>{1302540,1098240,123552,54912,10200,5108,3744,624,40}));GROUP("all 2598960 poker hands");}
    int gops_games=0;
    for(int n:{7,13})for(int g=0;g<(full?1000:100);++g){std::array<int,13>order{};for(int i=0;i<n;++i)order[i]=i+1;std::shuffle(order.begin(),order.begin()+n,rng);Gops q;assert(q.init(n,order));
        int seen=0;while(!q.done()){int bids[2];for(int who=0;who<2;++who){std::vector<int>av;for(int x=1;x<=n;++x)if(q.remaining[who]&(1u<<(x-1)))av.push_back(x);bids[who]=av[rng()%av.size()];}
            auto old=q.remaining;assert(q.choose(1,bids[1]));assert(q.remaining==old);assert(!q.choose(1,bids[1]));assert(q.choose(0,bids[0]));seen+=order[q.index-1];assert(q.score[0]+q.score[1]+q.burned==seen);}
        assert(q.remaining[0]==0 && q.remaining[1]==0 && q.winner()!=NONE);++gops_games;
    }
    GROUP("GOPS 7/13 complete games and conservation");
    std::array<int,13>ord{};for(int i=0;i<13;++i)ord[i]=i+1;Gops g;assert(!g.init(8,ord));assert(g.init(7,ord));for(int i=1;i<=7;++i){g.choose(0,i);g.choose(1,i);}assert(g.burned==28&&g.winner()==DRAW);GROUP("GOPS ties burn points");
    assert(score31({C(14,3),C(13,3),C(12,3)})==31);assert(score31({C(13,0),C(13,1),C(13,2)})==10);assert(score31({0,0,1})==-1);GROUP("31 scoring no three-kind bonus");
    long long hands31=0;for(int i=0;i<50;++i)for(int j=i+1;j<51;++j)for(int k=j+1;k<52;++k){std::array<Card,3>h={Card(i),Card(j),Card(k)};int best=0;for(int s0=0;s0<4;++s0){int sum=0;for(auto c:h)if(suit(c)==s0)sum+=value31(c);best=std::max(best,sum);}assert(score31(h)==best);++hands31;}
    GROUP("all 22100 three-card scores");
    ThirtyOne t;std::array<Card,9>natural={C(14,0),C(14,1),C(13,0),C(13,1),C(12,0),C(12,1),0,1,2};assert(t.init(natural,0)&&t.finished&&t.winner==DRAW);GROUP("31 simultaneous natural draw");
    std::array<Card,9>simple={C(2,0),C(3,1),C(4,2),C(5,3),C(6,0),C(7,1),C(8,2),C(9,3),C(10,0)};
    assert(t.init(simple,0));assert(t.knock(0));assert(!t.knock(1));assert(t.stand(1));assert(t.finished && t.turns==2 && t.end==ThirtyOne::Knocked);GROUP("31 knock final stand");
    assert(t.init(simple,0));Card in=t.market[2];assert(t.swap(0,0,2));assert(t.publicly_known[0]&(uint64_t(1)<<in));assert(t.swap(1,0,0));assert(t.swap(0,0,2));assert(!(t.publicly_known[0]&(uint64_t(1)<<in)));GROUP("31 public knowledge updates");
    assert(t.init(simple,0));for(int i=0;i<19;++i)assert(t.swap(t.actor,0,0));assert(!t.finished);assert(t.knock(t.actor));assert(t.turns==20&&!t.finished);assert(t.stand(t.actor));assert(t.turns==21&&t.finished);GROUP("31 knock on turn20 gets final reply");
    assert(t.init(simple,0));for(int i=0;i<20;++i)assert(t.swap(t.actor,0,0));assert(t.finished&&t.end==ThirtyOne::Limit);GROUP("31 capped swap loop");
    int games31=full?3000:300;for(int z=0;z<games31;++z){Deck dd;dd.init(1,next32,&rng);std::array<Card,9>deal{};for(auto&c:deal)dd.take(c);ThirtyOne q;assert(q.init(deal,z%2));
        while(!q.finished){int who=q.actor;if(q.knocker!=NONE && rng()%3==0)assert(q.stand(who));else if(q.knocker==NONE && rng()%8==0)assert(q.knock(who));else assert(q.swap(who,int(rng()%3),int(rng()%3)));assert(q.turns<=21);Card cs[9];int k=0;for(auto&h:q.hands)for(auto c:h)cs[k++]=c;for(auto c:q.market)cs[k++]=c;assert(valid_cards(cs,9));}
    }
    GROUP("31 complete game simulations");
    for(int b0=0;b0<8;++b0){assert(banker_draws(b0,-1)==(b0<6));for(int p3=0;p3<10;++p3)assert(banker_draws(b0,p3)==(TABLE[b0][p3]=='1'));}
    GROUP("baccarat independent drawing table");
    long long bac_cases=0;int limit=full?1000000:10000;
    for(int i=0;i<limit;++i){int x=full?i:int(rng()%1000000);std::array<int,6>v{};for(int j=0;j<6;++j){v[j]=x%10;x/=10;}auto r=baccarat_from_values(v),rr=reference_bac(v);assert(r.valid&&r.pt==rr.pt&&r.bt==rr.bt&&r.used==rr.used&&r.winner==rr.winner&&r.natural==rr.natural);assert(r.np>=2&&r.np<=3&&r.nb>=2&&r.nb<=3);++bac_cases;}
    GROUP("baccarat value streams independent reference");
    assert(baccarat_from_values({8,2,0,1,9,9}).used==4);assert(baccarat_from_values({6,5,0,0,2,8}).used==5);assert(!baccarat_from_values({-1,0,0,0,0,0}).valid);GROUP("baccarat natural and no P3 fifth card to banker");
    for(int human=0;human<3;++human)for(int ai=0;ai<3;++ai)for(int outcome=0;outcome<3;++outcome){BaccaratPredictions q;assert(q.choose(1,ai));assert(!q.ready());assert(!q.choose(1,ai));assert(q.choose(0,human));auto pts=q.points(outcome);assert(pts[0]==(human==outcome)&&pts[1]==(ai==outcome));}
    GROUP("all 27 baccarat prediction scores");
    std::cout<<"{\"suite\":\"portable_cpp\",\"full\":"<<(full?"true":"false")<<",\"groups_passed\":"<<groups<<",\"poker_category_hands\":"<<poker_hands<<",\"poker_matches\":"<<poker_matches<<",\"poker_hands_simulated\":"<<poker_matches*5<<",\"draw_mask_pairs\":1024,\"betting_terminal_paths\":"<<street_paths<<",\"gops_games\":"<<gops_games<<",\"three_card_hands\":"<<hands31<<",\"thirty_one_games\":"<<games31<<",\"baccarat_value_streams\":"<<bac_cases<<",\"baccarat_prediction_cases\":27}\n";
}
`````

## ファイル：`tests/cross_test.js`

<!-- CAFE_CARDS_FILE {"path":"tests/cross_test.js","bytes":513,"sha256":"5bca058035455cdadda8ec4b794f63d1390b20a2f372c0d90b10f6279e209b20"} -->
`````javascript
'use strict';
const fs=require('fs'),assert=require('assert'),C=require('../reference/jev_contract');
const filename=process.argv[2];if(!filename)throw Error('Pass generated C++ fixture JSON path.');
const rows=JSON.parse(fs.readFileSync(filename,'utf8'));
for(const r of rows){assert.deepStrictEqual(C.pokerKey(r.cards),r.poker_key);assert.strictEqual(C.score31(r.cards.slice(0,3)),r.score31);}
console.log(JSON.stringify({suite:'cpp_javascript_cross_check',hands:rows.length,poker_and_thirty_one_match:true}));
`````

## ファイル：`tests/data_test.py`

<!-- CAFE_CARDS_FILE {"path":"tests/data_test.py","bytes":2582,"sha256":"4158f26011b916a30e4835d80aad2545cebc48a92ebcb8461deba1c23cb76fc4"} -->
`````python
"""Catalog, geometry, and precomputed probability consistency checks."""
from pathlib import Path
import json, math
ROOT=Path(__file__).resolve().parents[1]
def read(name): return json.loads((ROOT/'data'/name).read_text(encoding='utf8'))
r=read('rules.json'); cards=read('cards.json'); layouts=read('layouts.json'); table=read('baccarat_probabilities.json')
assert r['suite_id']=='cafe_cards' and r['menu_slot']==6
# Different files may wrap a catalog in a dictionary; enforce actual shape below.
records=cards if isinstance(cards,list) else cards['cards']
assert len(records)==52
assert len({x['id'] for x in records})==52
circle=layouts['safe_circle'];rectangles=0
for name,items in layouts.items():
    if name=='safe_circle': continue
    if isinstance(items,dict): items=[items]
    for box in items:
        if not all(k in box for k in ['x','y','w','h']):continue
        assert box['w']>0 and box['h']>0
        for x in [box['x'],box['x']+box['w']]:
            for y in [box['y'],box['y']+box['h']]:
                assert math.hypot(x-circle['cx'],y-circle['cy'])<=circle['r']+1e-9,(name,box)
        rectangles+=1
# Table arrays are in explicit PLAYER,BANKER,TIE order.
assert table['order']==['PLAYER','BANKER','TIE']
assert len(table['open'])==100
assert {(e['p_first'],e['b_first']) for e in table['open']}=={(p,b) for p in range(10) for b in range(10)}
triples=[table['classic']]+[e['probabilities'] for e in table['open']]
for v in triples:
    assert len(v)==3 and all(isinstance(x,(float,int)) and 0<=x<=1 for x in v)
    assert abs(sum(v)-1)<1e-10
# Marginalize every OPEN pair with its exact fresh-deck pair probability.
counts=[128]+[32]*9
weighted=[0.0]*3
for e in table['open']:
    p,b=e['p_first'],e['b_first']
    w=counts[p]/416*(counts[b]-(p==b))/415
    for i,x in enumerate(e['probabilities']):weighted[i]+=w*x
assert all(abs(a-b)<1e-11 for a,b in zip(weighted,table['classic']))
content=read('content.ja.json'); tutorials=read('tutorials.ja.json')
def strings(v):
    if isinstance(v,str):return [v]
    if isinstance(v,dict):return sum((strings(x) for x in v.values()),[])
    if isinstance(v,list):return sum((strings(x) for x in v),[])
    return []
texts=strings(content)
assert all(x.strip() for x in texts)
assert len(read('api_contract.json')['actions'])==7
assert len(read('api_contract.json')['sheets'])==5
print(json.dumps({'suite':'catalog_and_geometry','card_records':52,'safe_rectangles':rectangles,'probability_triples':len(triples),'ui_strings':len(texts),'tutorial_pages':sum(len(v) for v in tutorials.values())},ensure_ascii=False))
`````

## ファイル：`tests/gate_test.js`

<!-- CAFE_CARDS_FILE {"path":"tests/gate_test.js","bytes":2042,"sha256":"08e8140af65dd0b37c0c1985938da27ac653834aa912e46f392fd3bd00262047"} -->
`````javascript
'use strict';
const assert=require('assert');const C=require('../reference/jev_contract');const G=require('../reference/observation_gate');
const clone=x=>JSON.parse(JSON.stringify(x));let groups=0;
const samples=[
 {game:'poker',variant:'fixed5',phase:'bet_pre',hands:[[5,6,7,8,9],[0,13,26,39,1]],discards:[[],[]],hand_no:1,stacks:[99,99],pot:2,street:{paid:[0,0],unit:2,raises:0},dealer:0,public_actions:[]},
 {game:'gops',variant:'quick7',phase:'bid',n:7,round_no:1,prize:4,remaining:[[1,2,3,4,5,6,7],[1,2,3,4,5,6,7]],scores:[0,0],history:[]},
 {game:'thirty_one',variant:'market3',phase:'turn',hands:[[3,4,5],[0,13,26]],market:[6,7,8],publicly_known:[[],[]],turns:0,public_actions:[]},
 {game:'baccarat',variant:'open',phase:'predict',first:[0,0]}
];
for(const f of samples){const o=C.buildObservation(f),ids=Object.keys(C.makeCriteria(f)).sort();G.requestFromObservation(o,ids);groups++;
 const bad=clone(o);bad.future_deck=[4,5];assert.throws(()=>G.requestFromObservation(bad,ids));groups++;
 assert.throws(()=>G.requestFromObservation(o,ids.concat('INVENTED')));groups++;
}
let p=C.buildObservation(samples[0]);p.pot=3;assert.throws(()=>G.validateObservation(p));groups++;
p=C.buildObservation(samples[0]);p.public_actions=[{actor:'OPPONENT',type:'DRAW_COUNT',count:2,out_card:'CA'}];assert.throws(()=>G.validateObservation(p));groups++;
const full=clone(samples[0]);full.public_actions=[{actor:'H',type:'DRAW_COUNT',count:2,out_card:12,in_card:13}];p=C.buildObservation(full);assert(!('out_card' in p.public_actions[0]));assert(!('in_card' in p.public_actions[0]));groups++;
const g=C.buildObservation(samples[1]);g.own_remaining=[7,6,5,4,3,2,1];assert.throws(()=>G.validateObservation(g));groups++;
const t=C.buildObservation(samples[2]);t.market[0]=t.own_cards[0];assert.throws(()=>G.validateObservation(t));groups++;
const b=C.buildObservation(samples[3]);b.variant='classic';assert.throws(()=>G.validateObservation(b));groups++;
console.log(JSON.stringify({suite:'observation_gate',groups_passed:groups,live_apis_called:false}));
`````

## ファイル：`tests/local_test.cpp`

<!-- CAFE_CARDS_FILE {"path":"tests/local_test.cpp","bytes":1335,"sha256":"78e61c3cd04610343c3e05e511984eff5c97f91bd7bae81fd0f0dcc05150ab7d"} -->
`````cpp
#include "../reference/local_policy.hpp"
#include <cassert>
#include <iostream>
#include <random>
using namespace cafe_cards;
uint32_t rnd(void* p){return (*static_cast<std::mt19937*>(p))();}
int main(){
  std::mt19937 rng(74107);int actions=0,swaps=0;
  for(int k=0;k<5000;++k){
    Deck d;assert(d.init(1,rnd,&rng));std::array<Card,5> h{};
    for(auto&c:h){assert(d.take(c));}
    int m=local_poker_draw(h);assert(m>=0&&m<=31);
    for(int r=0;r<3;++r){Street s;s.actor=1;s.paid={2*r,0};s.raises=r;
      auto a=local_poker_bet(h,s,uniform(rnd,&rng,100));assert(s.legal(a));++actions;}
    std::array<Card,3> own{},market{};for(auto&c:own)d.take(c);for(auto&c:market)d.take(c);
    for(bool final:{false,true}){auto a=local_thirty_one(own,market,final);
      if(a.knock)assert(!final);else if(a.stand)assert(final);else{assert(a.hand_slot>=0&&a.hand_slot<3&&a.market_slot>=0&&a.market_slot<3);++swaps;}}
  }
  for(int n:{7,13}){std::array<int,13> rem{};for(int i=0;i<n;++i)rem[i]=i+1;
    for(int count=1;count<=n;++count)for(int prize=1;prize<=n;++prize)for(int jitter=-1;jitter<=1;++jitter){int x=local_gops(rem,count,prize,n,jitter);assert(x>=1&&x<=count);}}
  std::cout<<"{\"suite\":\"local_policies\",\"poker_legal_actions\":"<<actions<<",\"thirty_one_cases\":10000,\"swap_cases\":"<<swaps<<",\"live_jev_called\":false}\n";
}
`````

## ファイル：`tests/protocol_test.py`

<!-- CAFE_CARDS_FILE {"path":"tests/protocol_test.py","bytes":2554,"sha256":"cadbbbc9a724f8ecacc77c52b28e4b00931bf98b4567fef98111e388d0b0beba"} -->
`````python
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import sys, json, tempfile, zlib
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "reference"))
from decision_protocol import Ledger, Controller, canonical

count=0

def check(ok):
    global count
    assert ok
    count+=1

l=Ledger();v={"game":"gops","prize":5,"cards":[1,3,7]}
with ThreadPoolExecutor(max_workers=16) as pool:
    results=list(pool.map(lambda _:l.reserve("job1",v,0),range(64)))
check(sum(call for _,call in results)==1)
check(l.call_reservations==1)
try:l.reserve("job1",dict(v,prize=6),1)
except ValueError:check(True)
else:check(False)
check(l.commit("job1",1,{"selected_id":"PLAY:3"},500))
check(not l.commit("job1",1,{"selected_id":"PLAY:7"},501))
check(l.expire("job1",999999).status=="ready")
l.reserve("job2",v,0)
check(l.expire("job2",60000).status=="pending")
check(l.expire("job2",60001).status=="unavailable")
check(not l.commit("job2",1,{"selected_id":"PLAY:7"},60002))
check(not l.reserve("job2",v,99999)[1])

def resp(rev=4,decision="d1",choice="PLAY:3"):
    return {"match_id":"m1","revision":rev,"decision_id":decision,"selected_id":choice}
c=Controller("m1",4,"d1",["PLAY:3","PLAY:7"])
check(c.accept(resp(3))=="ignored")
check(c.accept(resp(decision="OLD"))=="ignored")
c.paused=True
check(c.accept(resp())=="cached")
check(c.applied is None)
check(c.resume()=="applied")
check(c.accept(resp())=="ignored")
c=Controller("m1",4,"d1",["PLAY:3","PLAY:7"])
c.choose_local("PLAY:7")
check(c.accept(resp())=="ignored")
check(c.provider=="mixed_local")
c=Controller("m1",4,"d1",["PLAY:3"])
try:c.accept(resp(choice="PLAY:2"))
except ValueError:check(True)
else:check(False)
check(canonical({"b":2,"a":1})==canonical({"a":1,"b":2}))
# Test the specified generation+CRC envelope selection; not an NVS hardware test.
def pack(generation, value):
    body=canonical({"generation":generation,"state":value}).encode()
    return body+b'\n'+f'{zlib.crc32(body):08x}'.encode()
def unpack(data):
    try:
        body,crc=data.rsplit(b'\n',1)
        if int(crc,16)!=zlib.crc32(body):return None
        return json.loads(body)
    except (ValueError,TypeError):return None
old,new=pack(1,{"phase":"before"}),pack(2,{"phase":"after"})
check(max([unpack(old),unpack(new)],key=lambda s:s['generation'])['generation']==2)
for n in range(len(new)):
    check(unpack(new[:n]) is None)
print(json.dumps({"suite":"protocol_model","assertions_passed":count,"parallel_reservations":64,"provider_calls_reserved_once":True,"real_storage_tested":False}))
`````

## ファイル：`tools/assemble_handoff.py`

<!-- CAFE_CARDS_FILE {"path":"tools/assemble_handoff.py","bytes":3767,"sha256":"c6aa1872ac26f533345be9a4d2bc0aae4f12d1b52c95a3689df27b03977e85eb"} -->
`````python
#!/usr/bin/env python3
"""Build the self-contained Markdown and a ZIP. Run only after source checks."""
from __future__ import annotations
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parent
NAME='COFFEE_TIME_CAFE_CARDS_Design_v1.0.md'
ZIPNAME='COFFEE_TIME_CAFE_CARDS_Handoff_v1.0.zip'
EXCLUDED={'__pycache__','results_local','.git','build'}
files=[p for p in ROOT.rglob('*') if p.is_file() and not any(part in EXCLUDED for part in p.relative_to(ROOT).parts) and p.name!='MANIFEST.json' and p.suffix not in ['.pyc','.o','.exe']]
files.sort(key=lambda p:p.relative_to(ROOT).as_posix())
entries=[]
for p in files:
    data=p.read_bytes()
    if not data.endswith(b'\n'):raise ValueError('Text file missing trailing LF: '+str(p))
    entries.append({'path':p.relative_to(ROOT).as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest={'version':'1.0.0','created':'2026-09-22','files':entries}
mp=ROOT/'MANIFEST.json';mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
files.append(mp)
intro='''# CAFE CARDS — 統合引継ぎ版

**COFFEE TIME第6ゲーム／4種類すべてを実装する設計／v1.0.0／2026-09-22**

このMarkdown一冊に、共通設計、ポーカー、GOPS、サーティワン、バカラ、実装・運用、124項目の受入試験、全設定と参考コードを収録しています。

読む順：共通設計 → 第I〜IV部の4ゲーム → 第V部の実装 → 第VI部の検査。後半の付録は機械で取り出す完全なファイル群です。

**資料中のPC検査は実行済みですが、ESP32への書込み、実Google/実Jev接続、電池時間、社内試遊は未実施です。** 書込み済み完成アプリや、AIの強さを保証した報告ではありません。

---

'''
body=intro+'\n\n---\n\n'.join(p.read_text(encoding='utf8') for p in sorted((ROOT/'docs').glob('*.md')))
extractor=(ROOT/'tools'/'extract_handoff.py').read_text(encoding='utf8')
body+='''

---
# 付録 — 全ファイルと安全な取り出し方

次のPythonコードを、既存プロジェクトとは別の場所へ `extract_handoff.py` として保存します。その後、統合書のパスと、新しい空の取り出し先を指定します。

```bash
python extract_handoff.py COFFEE_TIME_CAFE_CARDS_Design_v1.0.md cafe_cards_source
cd cafe_cards_source
python tools/run_checks.py --full
```

取り出しコードはSHA-256・サイズ・パスを検査し、既存ファイルのあるフォルダーへの上書きを拒否します。既存ファームへ直接展開しないでください。ファイルの内容が編集されている場合は検査を止めます。

````python
'''+extractor+'````\n\n'
for p in files:
    data=p.read_bytes();s=data.decode('utf8');rel=p.relative_to(ROOT).as_posix()
    meta={'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    fence='`'*max(5,max((len(x) for x in __import__('re').findall(r'`+',s)),default=0)+1)
    lang={'.py':'python','.hpp':'cpp','.cpp':'cpp','.js':'javascript','.json':'json','.md':'markdown'}.get(p.suffix,'text')
    body+='\n## ファイル：`'+rel+'`\n\n<!-- CAFE_CARDS_FILE '+json.dumps(meta,ensure_ascii=False,separators=(',',':'))+' -->\n'+fence+lang+'\n'+s+fence+'\n'
(OUT/NAME).write_text(body,encoding='utf8')
with zipfile.ZipFile(OUT/ZIPNAME,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    z.write(OUT/NAME,NAME)
    for p in files:z.write(p,p.relative_to(ROOT).as_posix())
print(json.dumps({'master':str(OUT/NAME),'zip':str(OUT/ZIPNAME),'embedded_file_count':len(files),'master_bytes':(OUT/NAME).stat().st_size,'zip_bytes':(OUT/ZIPNAME).stat().st_size},ensure_ascii=False,indent=2))
`````

## ファイル：`tools/baccarat_table.cpp`

<!-- CAFE_CARDS_FILE {"path":"tools/baccarat_table.cpp","bytes":1470,"sha256":"358e7ade09629f15ac7dd41d3ae533e82d986e3c00a909e7092a04f06e8a9460"} -->
`````cpp
// Build exact (double-precision) enumerations for fresh 8-deck baccarat.
// Enumerates six value positions; summing unused suffixes marginalizes them out.
#include "../core/cards_core.hpp"
#include <array>
#include <iostream>
#include <iomanip>
#include <cmath>
#include <cassert>
int main(){
  std::array<std::array<std::array<double,3>,10>,10> joint{};
  std::array<double,3> total{};
  for(int code=0;code<1000000;++code){
    int x=code;std::array<int,6> v{};std::array<int,10> c{};c.fill(32);c[0]=128;
    double p=1.;for(int k=0;k<6;++k){v[k]=x%10;x/=10;p*=double(c[v[k]]--)/double(416-k);}
    auto r=cafe_cards::baccarat_from_values(v);joint[v[0]][v[1]][r.winner]+=p;total[r.winner]+=p;
  }
  assert(std::abs(total[0]+total[1]+total[2]-1)<1e-10);
  std::cout<<std::setprecision(14)<<"{\"rules\":\"fresh8_v1\",\"order\":[\"PLAYER\",\"BANKER\",\"TIE\"],\"method\":\"enumerate_all_1000000_six_value_streams_without_replacement\",\"classic\":["<<total[0]<<","<<total[1]<<","<<total[2]<<"],\"open\":[";
  bool first=true;
  for(int p=0;p<10;++p)for(int b=0;b<10;++b){double den=(p==0?128.:32.)/416.*((b==0?128.:32.)-(p==b?1.:0.))/415.;
    double sum=0;for(int k=0;k<3;++k)sum+=joint[p][b][k]/den;assert(std::abs(sum-1)<1e-10);
    if(!first)std::cout<<",";first=false;
    std::cout<<"{\"p_first\":"<<p<<",\"b_first\":"<<b<<",\"probabilities\":[";
    for(int k=0;k<3;++k){if(k)std::cout<<",";std::cout<<joint[p][b][k]/den;}std::cout<<"]}";
  }std::cout<<"]}\n";
}
`````

## ファイル：`tools/cross_fixture.cpp`

<!-- CAFE_CARDS_FILE {"path":"tools/cross_fixture.cpp","bytes":656,"sha256":"7614cd64c77ba72f06a7f30d1752c5ff169361cdd2f0fc665ae2f5125e2a4d8d"} -->
`````cpp
#include "../core/cards_core.hpp"
#include <iostream>
#include <random>
using namespace cafe_cards;
uint32_t sample(void* p){return (*static_cast<std::mt19937*>(p))();}
int main(){std::mt19937 rng(80291);std::cout<<"[";
for(int k=0;k<2000;++k){Deck d;d.init(1,sample,&rng);std::array<Card,5> h{};for(auto&c:h)d.take(c);
  std::array<Card,3> t{h[0],h[1],h[2]};auto v=poker_value(h);
  if(k)std::cout<<",";
  std::cout<<"{\"cards\":[";for(int i=0;i<5;++i){if(i)std::cout<<",";std::cout<<h[i];}
  std::cout<<"],\"poker_key\":[";for(int i=0;i<6;++i){if(i)std::cout<<",";std::cout<<v.key[i];}
  std::cout<<"],\"score31\":"<<score31(t)<<"}";
}std::cout<<"]\n";}
`````

## ファイル：`tools/extract_handoff.py`

<!-- CAFE_CARDS_FILE {"path":"tools/extract_handoff.py","bytes":2538,"sha256":"ad2711c6953389f9d743c64decd83b860e953f6407282f4dc3f6ece2017ac303"} -->
`````python
#!/usr/bin/env python3
"""Extract full-text attachments from the master Markdown, verifying SHA-256.
Safe defaults: new/empty directory only; reject traversal, symlinks, duplicates,
unknown absolute paths, and changed/truncated code blocks. No network access.
"""
from __future__ import annotations
import argparse, hashlib, json, re
from pathlib import Path, PurePosixPath

MARKER=re.compile(r'^<!-- CAFE_CARDS_FILE (.+) -->$')

def extract(md: Path, destination: Path) -> dict:
    lines=md.read_text(encoding='utf8').splitlines(keepends=True)
    files=[]; seen=set(); i=0
    while i<len(lines):
        match=MARKER.fullmatch(lines[i].rstrip('\r\n'))
        if not match:i+=1;continue
        info=json.loads(match.group(1)); name=info['path']; pure=PurePosixPath(name)
        if pure.is_absolute() or '..' in pure.parts or '\\' in name or ':' in name or str(pure)!=name or name in seen:
            raise ValueError('Unsafe or duplicate path: '+name)
        seen.add(name);i+=1
        if i>=len(lines):raise ValueError('Missing opening fence')
        opening=re.fullmatch(r'(`{4,})[A-Za-z0-9_-]*\r?\n?',lines[i])
        if not opening:raise ValueError('Bad opening fence for '+name)
        fence=opening.group(1);i+=1;body=[]
        while i<len(lines) and lines[i].rstrip('\r\n')!=fence:
            body.append(lines[i]);i+=1
        if i>=len(lines):raise ValueError('Unclosed file '+name)
        i+=1
        data=''.join(body).encode('utf8')
        if hashlib.sha256(data).hexdigest()!=info['sha256'] or len(data)!=info['bytes']:
            raise ValueError('Content hash/length mismatch: '+name)
        files.append((name,data))
    if not files:raise ValueError('No embedded files found')
    if destination.exists() and (destination.is_symlink() or any(destination.iterdir())):
        raise ValueError('Destination must be a new or empty directory')
    destination.mkdir(parents=True,exist_ok=True);base=destination.resolve()
    for name,data in files:
        path=base/name
        if not path.resolve().is_relative_to(base):raise ValueError('Path escape')
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(data)
    return {'embedded_files_extracted':len(files),'sha256_verified':True,'destination':str(base)}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('markdown',type=Path);ap.add_argument('destination',type=Path)
    args=ap.parse_args();print(json.dumps(extract(args.markdown,args.destination),ensure_ascii=False,indent=2))
if __name__=='__main__':main()
`````

## ファイル：`tools/make_acceptance.py`

<!-- CAFE_CARDS_FILE {"path":"tools/make_acceptance.py","bytes":19767,"sha256":"e8ff57ecc712d06be282e0d6f0c07a23a9e8cfdde5272e24379294ba27479710"} -->
`````python
from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
GROUPS={
'BASE':[
('原本保全','変更前のBSP・LVGL・Google設定・ゲーム登録のバックアップが存在する'),
('型番','実機が2.8Cであることと480×480を確認する'),
('既存カウンター','4本を追加後も+1を2回押すと2だけ増える'),
('既存5ゲーム','人狼3〜10人v2を含む既存5本の起動と終了を確認する'),
('入口一つ','第6メニューCAFE CARDSだけから4種類へ分岐する'),
('全ゲーム完走','端末AIでP5ハンド・G7/13・31は3ハンド・B5回を終了する'),
('文言','全119文言キーと22ページの文字に欠けがない'),
('依存固定','使用core・LVGL・コンパイラ・BSP・ライブラリ版を記録する'),
('練習','固定練習が課金や正式戦績・本番乱数に影響しない'),
('禁止機能','課金・換金・景品・共通財布・人事連携がない')],
'SEC':[
('相手手札隔離','人間の未知手札を変えてもAI要求の意味が変わらない'),
('未来札隔離','山札未来部分を変えても同じ公開状態のAI要求が一致する'),
('GOPS未公開札','人間の仮選択をJev要求に含めない'),
('交換未公開','ポーカーの人間maskをAI交換決定前に送らない'),
('バカラ未公開','人間予想・勝敗・未来6枚を送らない'),
('私的捨て札','ポーカーの相手捨て札が公開履歴・統計から漏れない'),
('31公開既知','正当に公開された取得札だけを既知集合へ追加する'),
('ネスト未知キー','余分なroot・nested keyをGASで拒否する'),
('API鍵','Jev鍵が端末Flash・ソース・ログに存在しない'),
('本人認証','別人token/他deviceでprivate試合と統計を取得できない'),
('PIN','生PINとplayer_tokenがsnapshotへ書かれない'),
('画面退避','カフェ復帰・ログアウト・エラーで手札が残像を含め消える'),
('ログ','例外・シリアルに山札・token・非公開手札を出さない'),
('モデル文言','confidence・行動確率を実勝率と表示しない'),
('役判定分離','Jev応答で役の強さや点数規則を書き換えられない'),
('共有Workbook','一般公開カフェシートにprivate記録を入れない')],
'P':[
('配布順','非dealer→dealerへ交互に5枚、初期cursor=10'),
('先手交代','初回dealerを記録し5ハンドで交互にする'),
('CHECK2回','両CHECKで一度だけ次段階へ進む'),
('CHECK後BET','相手BETへのFOLD/CALL/RAISEが表示される'),
('額一致','CALLは不足額だけを支払う'),
('RAISE','不足額+unitを払い、回数を1だけ増やす'),
('上限','2回上乗せ後のRAISE拒否、CALL/FOLDは可能'),
('段階初期化','交換後unit=4、paid/raises/checksが0'),
('無料FOLD禁止','owed=0でFOLDできない'),
('残点保証','最悪5連敗でも最後に5点以上、補充なし'),
('総点','各確定状態でstacks+pot=200'),
('交換0','双方0枚でも正しく交換後へ進む'),
('交換5','双方5枚を交換しても重複・枯渇しない'),
('交換順','双方mask固定後、非dealer固定slot昇順から引く'),
('ホイール','A2345は5-high、QKA23はストレートではない'),
('同役比較','全カテゴリのキッカー比較とスート同点を確認する'),
('フォールド','一度だけpot授与、未公開札と内訳を見せない'),
('同役分配','偶数potを半分ずつ分ける'),
('試合勝敗','ハンド勝利数でなく5ハンド後の持ち点で決める'),
('再戦','新matchId・新配布、持ち点100へ戻る')],
'G':[
('7枚','7回で終了し総得点+破棄=28'),
('13枚','13回で終了し総得点+破棄=91'),
('場の点','勝ち札の数字でなく得点札の数字を加える'),
('同点','得点破棄・双方消費・持越しなし'),
('両方消費','負けた側の札も残札から消える'),
('重複札','使った札を再度出す操作を拒否する'),
('公開残札','両者の残札が実状態と一致する'),
('秘密確定順','AI札保存より前に人間Confirmできない'),
('最終一枚','強制処理でJevを呼ばずforced記録になる'),
('ページ','13枚目を選べて表示切替でドラフトを保つ'),
('引分け','最終同点で追加回を勝手に作らない'),
('得点順','未来得点が見えず、復旧で順番が変わらない')],
'T':[
('配布','初期9物理札が相異なり場3枚'),
('同スート','別スートの得点を足さない'),
('Aと絵札','A11、JQK10'),
('3枚組','777は7点で特典なし'),
('点数同点','別スートの余り札・キッカーで差をつけない'),
('単交換','一ターン一対一交換だけ'),
('通常STAND禁止','通常でパスボタンが出ない'),
('ノック','交換せず相手へ最終応答権を渡す'),
('最終応答','交換/STANDの後ただちに比べる'),
('再ノック禁止','最終応答でKNOCKを拒否する'),
('初期31','片側/両側31で正しく即終了'),
('交換後31','相手追加ターンなしで終了'),
('20手交換','20番目SWAP後に比べる'),
('20手ノック','21番目の最終応答を一度許す'),
('既知削除','公開取得札を場へ戻すと既知集合から消える'),
('3ハンド','先手交代し勝ち数で試合を比べる')],
'B':[
('新山','5ラウンドそれぞれ416枚から開始する'),
('非復元','同じ物理IDを同一回で二度引かない'),
('見た目重複','copy違いの同じカード表示は許される'),
('配布順','P1B1P2B2の順である'),
('OPEN','1枚ずつだけ表示、2枚合計結果はまだ不明'),
('CLASSIC','一枚も予想前に公開しない'),
('ナチュラル','どちらか8/9で両方止める'),
('P停止B5','P6/7のときB5は引く'),
('B3境界','P3=8のみ止める'),
('B4B5B6境界','追加表80セルと停止分岐を照合する'),
('5枚目行先','P停止時は次札がB3、6枚目を飛ばさない'),
('予想同一','人間AIが同じ予想でも変更せず両者加点可能'),
('TIE得点','TIEを当てても1点、倍率や手数料なし'),
('表とJev','計算値の表示とJev予測を別の出所にする')],
'NET':[
('認証','device/本人/guestの所有権と期限を確認する'),
('型検査','未知action・variant・範囲外を拒否する'),
('モデル固定','使用モデルと要求/応答の実版を記録する'),
('API不正','合計不正・候補漏れ・不正数値・非合法返答を拒否する'),
('同一再送','同ID同要求のJev呼出し枠が一回だけ'),
('別内容再送','同ID別観測をconflictにする'),
('並行要求','複数HTTP要求で同決定が二重予約されない'),
('lease','遅延・クラッシュ後の不明jobを再度推論しない'),
('旧返答','他match/revisionの返答を適用しない'),
('pause返答','pause中readyは保存だけ、勝手に画面復帰しない'),
('途中local','本人選択後は残り試合local、後着Jevを無視'),
('リダイレクト','302/303は本文なしGET、未知ホストは拒否'),
('HTML200','Googleログイン画面をJSON成功と扱わない'),
('quota','上限・429・キー障害でカフェ本体まで停止しない')],
'REC':[
('A/B書込み','古い有効snapshotを残して新slotへ書く'),
('書込み中電断','途中切断時にCRC有効世代だけ復元する'),
('両方破損','再抽選による再開をせず無効を表示する'),
('カード再生','deck順列/cursor/手札/イベント整合を照合する'),
('本人再開','再認証するまで私的手札を表示しない'),
('ゲスト電断','旧guestのprivate試合を別guestへ渡さない'),
('24h期限','期限超過の試合を勝敗に混ぜない'),
('結果再送','finishの応答消失で成績を二重加算しない'),
('別結果','同matchの結果改変をconflictにする'),
('Google不明書込','barrierを残し盲目的なappend再送をしない'),
('退会','private snapshot・各ゲーム記録の削除範囲を確認する'),
('区画不足','保存区画を無断消去・拡張しない')],
'PLAY':[
('文字','日本語と数字・マークを実機で複数人が読める'),
('タッチ','選択後確認で誤交換・誤入札を防げる'),
('4種の違い','各テーブルで異なる判断を楽しめる'),
('ポーカー','用語を知らない人が金額と降りる意味を理解する'),
('GOPS','小さい札を残す/使う選択に理由を持てる'),
('31','ノック後の最後の一手を誤解しない'),
('バカラ','二つの手札と人間AIを混同しない'),
('AIの役割','同じ手ばかり等がないか実Jev各20試合を観察する'),
('電池','実電池条件の平均電流・温度・連続時間を測定する'),
('中断性','いつでも一時停止してコーヒー+1へ戻れる')]
}
rows=[]
for prefix,items in GROUPS.items():
    for i,(title,expect) in enumerate(items,1):
        rows.append({'id':f'{prefix}-{i:02d}','title':title,'expected':expect,'status':'not_run_on_target','evidence':'','tester':'','date':''})
(R/'data'/'acceptance.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
lines=['# 第VI部 — 検査、運用、根拠資料','', '## Q1. 実機・実サービス受入試験', '',f'以下の**{len(rows)}項目**は、コーディングエージェントが実装した対象環境で実施する。全行の初期状態は`not_run_on_target`。PC参考コードの成功を、この表の実機合格へ一括転記しない。証拠、担当者、日時を記録する。','', '| ID | 確認内容 | 合格条件 | 状態 |','|---|---|---|---|']
for row in rows:lines.append(f"| {row['id']} | {row['title']} | {row['expected']} | 未実施 |")
lines+=['','## Q2. 面白さの試遊と採用判定','',
'初回は少なくとも6人に遊んでもらい、各ゲームを初見の人2人以上が触る。ポーカー経験者だけで全体の分かりやすさを判断しない。個人名を点数表へ公開せず、匿名の感想を集める。',
'質問は「次に押すものが分かったか」「何で勝ち負けが決まったか説明できるか」「通信待ちが気になったか」「もう一度違う選び方で遊びたいか」。理解できない箇所を優先修正し、派手な演出を追加して隠さない。',
'Jevの4種類の実力は未測定。合法行動率、呼出し時間、フォールド/ノック等の偏り、再戦意向をモード別に観察する。端末AI相手と比較して意味のある違いがあるかを確認し、すべて同じ勝率目標に合わせた配札操作はしない。',
'', '## Q3. トラブル対応・運用', '',
'1. LCDが映らない：原本の基板サンプルへ戻して比較。ゲーム用にBSPやPSRAMを再設定しない。',
'2. タッチがずれる：既存座標と円形レイアウトを確認。ルールエンジンを変更しない。',
'3. 個人履歴が見えない：共通認証・owner・variant・cohortを確認。別人へ紐付けて復旧しない。',
'4. Jevが使えない：端末→GAS、GAS→Jev、キー、契約、quotaを切り分け。通信エラーを勝敗にしない。',
'5. STORAGE_UNCERTAIN：新規ゲーム更新を止め、barrier/receiptを管理者が照合。勝手に行を削除して再送しない。',
'6. 電池切れ後：本人ならsnapshot検査と再認証、guestなら旧試合破棄。再抽選して続きとして扱わない。',
'7. 規則改訂：rules_versionを上げ、保存局を互換判定。新旧別統計にし、古いカード状態へ新規則を適用しない。',
'', '## Q4. 実際にこの資料作成中に実施した検査','',
'実行環境は`results/environment.json`。以下は配布する参考コードの実測結果で、外部サービスやESP32の結果ではない。',
'| 検査 | 実行結果 |', '|---|---|',
'| C++基本ルール | 全26グループ成功。通常ビルドは警告をエラー扱い |',
'| ポーカー役 | 全2,598,960手を列挙し、9カテゴリの件数と一致 |',
'| ポーカー進行 | 2,000試合・10,000ハンド。全1,024の交換mask組合せ、ベットの52終端経路を検査 |',
'| GOPS | 7/13合計2,000ゲーム、得点・残札の保存条件を検査 |',
'| 31 | 全22,100の3枚得点、3,000ハンド進行、ノックと20+1境界 |',
'| バカラ | 1,000,000の6値列を別表実装と照合。予想の全27組の得点 |',
'| C++/JavaScript | 独立の役判定・31得点を2,000手で照合 |',
'| Jev契約 | 23グループ成功。4ゲームで隠れた入力変更の非干渉、不正応答11種類 |',
'| 観測境界 | 18グループ成功。余分なキー、違う合法ID、公開前カードなど拒否 |',
'| 通信状態モデル | 72アサーション成功、同時64予約で呼出し枠1回 |',
'| ローカルAI | ポーカー15,000合法行動、31は10,000条件を検査 |',
'| データ | 52カード・31矩形の安全円・101確率表・119文言・22ページの整合 |',
'| 追加メモリー検査 | ASan/UBSanで小規模の25グループ成功 |',
'',
'全ゲームの全到達状態を網羅した証明ではない。乱数試験の通過もシャッフルの暗号学的安全性の証明ではない。実Jev正解率、GASの処理時間、API課金、本人情報運用、フォント、日本語レイアウト、電池持続、4種類の楽しさは実機受入で確認する。',
'', '## Q5. 参考ファイルの使い方','',
'Python3.10以上、Node18以上、C++17対応コンパイラを用意する。ファイルを展開したルートで次を実行する。','',
'```bash','python tools/run_checks.py --full','python tools/run_checks.py --full --sanitize','```','',
'WindowsはMSYS2等のg++またはCXXで指定した対応コンパイラを使う。Sanitizer未対応の環境は通常検査だけ実施し、追加検査の未実施を明記する。結果は標準で`results_local/`へ保存し、配布時の実行結果`results/`を上書きしない。','',
'`core/cards_core.hpp`は4ゲームのルール、`reference/local_policy.hpp`は比較基準の相手、`reference/jev_contract.js`は観測抽出とモデル契約、`reference/observation_gate.js`はGAS境界用の観測・合法ID検証。`reference/decision_protocol.py`は並行予約と遅延応答の実行可能なモデルであり、本物のSheets保存処理ではない。',
'`tools/baccarat_table.cpp`は確率表の再生成用。生成結果はdoubleへ落とす前に長い精度で重みを加算するが、表は有限桁に丸めてある。ビルドする端末へ重い全列挙を入れる必要はない。',
'', '## Q6. 調査した一次資料と確認範囲','',
'ルールの参照部分と、今回のカフェ向け独自変更を本文で分けた。資料確認日2026-09-22。公開情報は実アカウントの利用可否や自社端末の動作を保証しない。']
SOURCES=[
('S01','Waveshare 2.8C','https://docs.waveshare.com/ESP32-S3-Touch-LCD-2.8C','ボード・メモリー・タッチ・電池端子'),
('S02','TypeSafe Choice','https://docs.typesafe.ai/primitives/choice','型付き候補選択と応答構造'),
('S03','Loto-Québec Five Card Draw','https://www.espacejeux.com/en/ok-poker/how-to-play/games/5-card-draw','5枚交換型ポーカーの土台'),
('S04','Bicycle Basics of Poker','https://bicyclecards.com/how-to-play/basics-of-poker','役の強さ・基本的な決着'),
('S05','TypeSafe Jev jaggedness','https://docs.typesafe.ai/model-jaggedness/jev-1.13','数値計算をコードへ分ける判断'),
('S06','Coppercod GOPS','https://coppercod.games/game/gops/','同時入札と得点札の土台'),
('S07','Google DeepMind OpenSpiel Goofspiel','https://raw.githubusercontent.com/google-deepmind/open_spiel/master/open_spiel/games/goofspiel/goofspiel.h','札数/順番を分けたゲーム実装'),
('S08','Bicycle Thirty-One','https://bicyclecards.com/how-to-play/thirty-one','3枚と公開の場を交換する流派'),
('S09','Venetian Baccarat','https://www.venetianlasvegas.com/resort/casino/table-games/how-to-play-baccarat.html','配布順・ナチュラル・追加札'),
('S10','Four Winds Mini Baccarat','https://fourwindscasino.com/blog/minibaccarat/','PLAYER停止時のBANKER条件の照合'),
('S11','TypeSafe Models','https://docs.typesafe.ai/models','固定モデルID・文字入力・言語・学習の扱い'),
('S12','TypeSafe HTTP API','https://docs.typesafe.ai/api','エンドポイント・認証・エラー'),
('S13','Apps Script Web Apps','https://developers.google.com/apps-script/guides/web','doPost・Web App配備'),
('S14','Apps Script Content Service','https://developers.google.com/apps-script/guides/content','JSON返答とリダイレクト'),
('S15','UrlFetchApp','https://developers.google.com/apps-script/reference/url-fetch/url-fetch-app','外部HTTP・timeoutSeconds'),
('S16','Properties Service','https://developers.google.com/apps-script/guides/properties','スクリプト設定と秘密の保管場所'),
('S17','LockService','https://developers.google.com/apps-script/reference/lock/lock-service','同一スクリプト実行の排他'),
('S18','Sheets batchUpdate','https://developers.google.com/workspace/sheets/api/reference/rest/v4/spreadsheets/batchUpdate','一括検証/更新と同時編集上の留意'),
('S19','Apps Script quotas','https://developers.google.com/apps-script/guides/services/quotas','実際のアカウント上限の確認先'),
('S20','ESP32-S3 Random Generation','https://docs.espressif.com/projects/esp-idf/en/stable/esp32s3/api-reference/system/random.html','エントロピー源と本番乱数'),
('S21','ESP32-S3 NVS','https://docs.espressif.com/projects/esp-idf/en/stable/esp32s3/api-reference/storage/nvs_flash.html','保存・暗号化・実機区画'),
('S22','LVGL8 OS porting','https://raw.githubusercontent.com/lvgl/lvgl/v8.3.11/docs/porting/os.md','UI所有タスクと排他'),
('S23','LVGL8 events','https://raw.githubusercontent.com/lvgl/lvgl/v8.3.11/docs/overview/event.md','クリックと押下継続の区別')]
for sid,name,url,why in SOURCES:
    lines+=['',f'**[{sid}] {name}** — {why}。',f'`{url}`']
lines+=['','### 既存設計書との接続','',
'AI DUEL v1の本人認証・非公開Sheets・ContentService取扱い、JEV REVERSI v1の丸画面と再送原則、CAFE WEREWOLF v2の3〜10人対応を読み合わせた。既存資料の匿名前提を本カード集へ一律コピーしたり、私的手札のあるゲームへ公開盤面だけの復元を流用したりしない。実際のPCワークスペース・GASコードは未取得なので、継承箇所はエージェントが実物と照合する。',
'', '## Q7. エージェントへ渡す最終指示','',
'> 本書をCAFE CARDSの正本として、COFFEE TIME第6メニューに4種類を実装してください。既存BSP、LCD/タッチ、コーヒー＋1、5つのゲーム、Google連携を保全してください。まずPC検査、次に端末AIで全ゲーム完走、次に保存・共通本人認証・Googleの再送と復旧、最後にJevへ進めてください。未来の札・相手の非公開手札をJevへ送らず、同時選択はAIを先に確定してください。本文の独自ルールを勝手に別流派へ変えないでください。全受入項目を記録し、書込み済み・実API接続済み・試遊済みを区別して報告してください。']
(R/'docs'/'06_TESTS_SOURCES.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
print('Acceptance cases:',len(rows))
`````

## ファイル：`tools/make_data.py`

<!-- CAFE_CARDS_FILE {"path":"tools/make_data.py","bytes":16074,"sha256":"fe3764def82c16f818e7e40b734f548eeee72085a600e148a6d5895a3b64b304"} -->
`````python
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
def write(name,obj):
    (ROOT/'data'/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
rules={
 'suite_id':'cafe_cards','menu_slot':6,'version':'1.0.0','date':'2026-09-22',
 'device':'ESP32-S3-Touch-LCD-2.8C','resolution':[480,480],'initial_opponent':'jev',
 'money':{'real_money':False,'purchase':False,'redemption':False,'prizes':False,'cross_game_wallet':False},
 'poker':{'id':'poker','variant':'fixed5','hands':5,'starting_chips_each':100,'ante_each':1,'bet_units':[2,4],'max_raises_per_street':2,'max_contribution_per_hand':19,'deck_copies':1,'draw_rounds':1,'draw_mask_min':0,'draw_mask_max':31,'deal_first':'nondealer','bet_first':'nondealer','swap_order':['nondealer','dealer'],'side_pots':False,'all_in':False,'suit_tiebreak':False},
 'gops':{'id':'gops','variants':{'quick7':7,'classic13':13},'default':'quick7','tie':'burn_prize','carryover':False,'bids':'simultaneous','last_round_single_option':'forced'},
 'thirty_one':{'id':'thirty_one','variant':'market3','hands':3,'cards_each':3,'market_cards':3,'ace':11,'face':10,'score':'max_same_suit_sum','tie':'draw','three_of_kind_bonus':False,'knock':'instead_of_swap','reply_actions':['SWAP','STAND'],'normal_actions':['SWAP','KNOCK'],'normal_action_cap':20,'max_actions_with_reply':21,'natural31':'immediate_end','both_initial31':'draw','deck_copies':1},
 'baccarat':{'id':'baccarat','variants':['open','classic'],'default':'open','rounds':5,'decks':8,'fresh_pack_each_round':True,'burn_cards':False,'cut_card':False,'prediction_points_correct':1,'tie_prediction_points_correct':1,'payouts':False,'order':['P1','B1','P2','B2','P3_if_required','B3_if_required'],'natural8or9':'end_both','banker_if_player_stands':'draw_0_to_5'},
 'limits':{'idle_pause_ms':120000,'profile_hide_ms':60000,'registered_resume_max_ms':86400000,'snapshot_bytes':32768,'snapshot_slots':2,'max_events':192,'request_bytes':16384,'response_bytes':8192,'jev_timeout_seconds':8,'decision_lease_ms':60000,'ui_http_timeout_ms':15000,'poll_intervals_ms':[2000,4000,8000,8000],'daily_jev_reservations_per_device':1000,'calls_per_match':{'poker':40,'gops':13,'thirty_one':33,'baccarat':5},'retention_days':{'registered_matches':180,'guest_matches':1,'decisions_after_match':2,'receipts':2}}
}
write('rules.json',rules)
cards=[]
for s,suit in enumerate(['C','D','H','S']):
 for r in range(2,15):
  rank={11:'J',12:'Q',13:'K',14:'A'}.get(r,str(r))
  cards.append({'id':s*13+r-2,'code':suit+rank,'suit':suit,'rank':r,'poker_rank':r,'thirty_one_value':11 if r==14 else min(r,10),'baccarat_value':1 if r==14 else r if r<10 else 0})
write('cards.json',{'version':1,'copies':'physical_id=copy*52+id','cards':cards})
write('poker_draw_choices.json',[{'action_id':f'DRAW:{m}','mask':m,'replace_slots':[i for i in range(5) if m&(1<<i)],'count':m.bit_count()} for m in range(32)])
# Geometry uses absolute 480x480 coordinates. All interactive rectangles must fit radius228.
layouts={
 'safe_circle':{'cx':240,'cy':240,'r':228},
 'menu': [{'id':name,'x':x,'y':y,'w':136,'h':104} for name,x,y in [('poker',96,134),('gops',248,134),('thirty_one',96,254),('baccarat',248,254)]],
 'poker_cards':[{'id':f'slot_{i}','x':70+68*i,'y':190,'w':64,'h':92} for i in range(5)],
 'three_actions':[{'id':f'action_{i}','x':96+100*i,'y':346,'w':88,'h':48} for i in range(3)],
 'gops_cards':[{'id':f'page_slot_{i}','x':96+76*i,'y':202,'w':68,'h':96} for i in range(4)],
 'three_market':[{'id':f'market_{i}','x':116+88*i,'y':145,'w':72,'h':86} for i in range(3)],
 'three_hand':[{'id':f'hand_{i}','x':116+88*i,'y':254,'w':72,'h':86} for i in range(3)],
 'two_actions':[{'id':'action_left','x':112,'y':360,'w':120,'h':48},{'id':'action_right','x':248,'y':360,'w':120,'h':48}],
 'footer':[{'id':'cafe','x':168,'y':416,'w':144,'h':36}],
 'baccarat_p':[{'id':f'P{i+1}','x':116+88*i,'y':143,'w':72,'h':84} for i in range(3)],
 'baccarat_b':[{'id':f'B{i+1}','x':116+88*i,'y':252,'w':72,'h':84} for i in range(3)]
}
write('layouts.json',layouts)
text={
 'suite.title':'CAFE CARDS','suite.subtitle':'今日は、どんな勝負にしますか？','suite.notice':'得点はゲーム内だけ。現金・景品との交換はありません。',
 'suite.poker':'POKER','suite.gops':'GOPS','suite.thirty_one':'THIRTY-ONE','suite.baccarat':'BACCARAT',
 'suite.poker_tag':'その強気、本物ですか？','suite.gops_tag':'切り札を出すのは、今ですか？','suite.thirty_one_tag':'もう少し育てる？ 今、勝負する？','suite.baccarat_tag':'あなたとJev、同じ予想ですか？',
 'common.start':'はじめる','common.howto':'遊び方','common.guest':'ゲストで遊ぶ','common.profile':'自分を選ぶ','common.confirm':'これで決定','common.cancel':'選び直す','common.back':'戻る','common.cafe':'カフェへ','common.continue':'続ける','common.pause':'一時停止','common.resume':'再開する','common.abort':'対戦を終了','common.abort_ask':'この対戦を中止しますか？ 勝敗には数えません。','common.restart':'もう一度遊ぶ','common.next':'次へ','common.previous':'前へ','common.round_next':'次の勝負へ','common.your_turn':'あなたの番です','common.ai_turn':'Jevが選んでいます','common.local_turn':'端末AIが選んでいます','common.ready':'相手の選択は確定済み','common.mixed':'途中から端末AI','common.local':'端末AI','common.jevinvalid':'Jevの応答を確認できませんでした','common.fallback_ask':'この対戦の残りを端末AIで続けますか？','common.fallback_yes':'端末AIで続ける','common.wait':'復旧を待つ','common.offline':'通信できません','common.pending_save':'記録の送信待ち','common.saved':'記録しました','common.save_failed':'保存できません。再開地点を守るため中断します。','common.expired':'再開できる期限を過ぎました','common.bad_snapshot':'記録が壊れているため再開できません','common.hidden':'手札を隠しています','common.auth_required':'本人の確認をしてから再開します','common.guest_reboot':'再起動したため、ゲストの対戦は終了しました','common.win':'あなたの勝ち！','common.lose':'今回は相手の勝ち','common.draw':'引き分けです','common.no_winner':'対戦は中止されました','common.tutorial':'練習中：戦績には記録しません','common.forced':'残りの選択肢は一つです','common.detail':'判断の内訳','common.confidence':'候補の偏り：勝率ではありません','common.predict_label':'Jevの予測：実際の勝率とは限りません',
 'poker.hand':'第{n}/5回','poker.chips':'持ち点 {you} / {ai}','poker.pot':'場の持ち点 {pot}','poker.ante':'双方1点を場に出しました','poker.check':'追加せず続ける','poker.bet':'{amount}点出す','poker.call':'{amount}点で勝負','poker.raise':'{amount}点を追加','poker.fold':'この手を降りる','poker.fold_confirm':'この手を降りますか？','poker.replace':'交換する札を選択','poker.draw_confirm':'{n}枚を交換する','poker.draw_zero':'交換せず進む','poker.draw_done':'あなた{you}枚／相手{ai}枚交換','poker.fold_result':'相手が降りました。手札は公開しません。','poker.showdown':'手札を比べます','poker.split':'同じ強さです。場の持ち点を半分ずつ戻します。','poker.no_detail':'降りた手の秘密や判断の内訳は公開しません。','poker.match_end':'5回の合計持ち点で勝負！','poker.check_tip':'相手がまだ出していないので、追加せず続けられます。',
 'gops.prize':'今回の得点 {n}','gops.remain':'残り {n}枚','gops.choose':'出す札を選んでください','gops.confirm':'{n}を出しますか？','gops.tie':'同じ札。今回はどちらも得点なし','gops.gain':'{who}が{n}点獲得','gops.used':'使用済み','gops.score':'得点 {you} / {ai}','gops.last':'最後の札を確定してください','gops.quick':'7枚・短期戦','gops.classic':'13枚・通常戦','gops.no_carry':'同点の得点は次へ持ち越しません。',
 'thirty_one.market':'場の3枚','thirty_one.hand':'あなたの3枚','thirty_one.score':'同じマークの合計：{score}','thirty_one.swap':'札を交換','thirty_one.knock':'勝負を仕掛ける','thirty_one.knock_confirm':'今の手で勝負しますか？ 相手には最後の1回があります。','thirty_one.stand':'この手で勝負','thirty_one.final':'最後に1回、交換するか今の手で勝負できます','thirty_one.natural':'31点！ すぐに勝負です','thirty_one.limit':'20手になったので手を比べます','thirty_one.tie':'同じ点数なので引き分けです','thirty_one.known':'公開された相手の札','thirty_one.match_end':'3回勝負の結果',
 'baccarat.open':'1枚ずつ公開','baccarat.classic':'配る前に予想','baccarat.player':'PLAYER側','baccarat.banker':'BANKER側','baccarat.tie':'引き分け','baccarat.choose':'最後の点数が高い側は？','baccarat.same':'今回は、同じ予想です','baccarat.different':'予想が分かれました','baccarat.correct':'的中！','baccarat.incorrect':'今回は外れました','baccarat.natural':'最初の2枚が8/9点。追加はありません。','baccarat.draw3':'ルールにより3枚目を配ります','baccarat.stand':'この側は2枚で止まります','baccarat.total':'合計の一の位：{score}点','baccarat.result':'{outcome}','baccarat.match_end':'5回の的中数で勝負！','baccarat.fresh':'毎回、新しい8組から配ります','baccarat.no_payout':'引き分けを当てても1点。倍率はありません。'
}
write('content.ja.json',text)
tutorials={
 'poker':[
 ['5枚で役を作ろう','手札5枚を受け取ります。強い役を作るか、相手を降ろすと勝ちです。'],
 ['押しただけでは確定しません','札や行動を選んでから「これで決定」。迷ったら選び直せます。'],
 ['上乗せは決まった額','交換前は2点ずつ、交換後は4点ずつ。上乗せは各段階2回までです。'],
 ['交換は1回だけ','0〜5枚を選びます。相手も同時に決め、双方が確定してから交換します。'],
 ['Aは二つの使い方','A・2・3・4・5は5が上のストレート。Q・K・A・2・3はつながりません。'],
 ['持ち点で決着','100点ずつで始め、5回終わったときに多い側が勝ち。点数に金銭価値はありません。']],
 'gops':[
 ['同じ札でスタート','双方に1〜7、または1〜13の札。使った札は戻りません。'],
 ['得点を取り合う','場に出た得点を見て、自分の札を一つ選びます。相手の今回の札は秘密です。'],
 ['同時に開く','大きな札を出した側が場の得点を獲得。同じ数字なら、両方の札と得点を使い切ります。'],
 ['最後まで考えよう','小さな得点に大きな札を使うと、後で困るかもしれません。最後は合計点で勝負。']],
 'thirty_one':[
 ['同じマークを集める','手札は3枚。4種類のマークごとに足し、一番高い合計があなたの点数です。'],
 ['Aは11、絵札は10','Aは11点、J・Q・Kは10点。同じ数字3枚の特別点はありません。'],
 ['場と1枚ずつ交換','自分の1枚と場の1枚を選んで交換。場へ出した札は相手にも見えます。'],
 ['勝負を仕掛ける','交換の代わりにノックすると、相手に最後の交換チャンスが1回あります。'],
 ['31なら即決着','31点になったらすぐに公開。同点は引き分け。長く続いたら20手で比べます。'],
 ['この端末だけの短期戦','通常の流派とは一部違うカフェルールです。3回の勝ち数で決めます。']],
 'baccarat':[
 ['二つの側を予想','PLAYER側とBANKER側は手札の呼び名。人間とJevの呼び名ではありません。'],
 ['9点に近い方が勝ち','Aは1点、10・J・Q・Kは0点。足した数字の一の位だけを比べます。'],
 ['引くかどうかは自動','追加カードは決まったルールで配られます。人間もJevも引き方を変更できません。'],
 ['1枚ずつ見て予想','OPENでは各側の最初の1枚が見えます。残りのカードは、人間にもJevにも分かりません。'],
 ['当たれば1点','引き分けを当てても1点です。5回の的中数を比べましょう。'],
 ['未来は分かりません','毎回新しい山札を使うため、前の勝敗の並びで次が決まるわけではありません。']]
}
write('tutorials.ja.json',tutorials)
# Complete adapter wire contract. Logical JSON errors; no unsupported TextOutput status API.
actions={
 'hello':{'auth':'device','payload':{},'returns':['capabilities','server_time_ms','rules_version','model','maintenance']},
 'profile.get':{'auth':'player','payload':{'game':'enum:poker|gops|thirty_one|baccarat','variant':'registered_variant'},'returns':['stats','last_completed_at_ms']},
 'match.open':{'auth':'player_or_guest','payload':{'match_id':'hex32','game':'game_enum','variant':'registered_variant','opponent':'jev|local','rules_version':'1.0.0','first_actor':'0|1|null'},'returns':['match_id','status','created_month','expires_at_ms','profile_snapshot_version']},
 'decision.prepare':{'auth':'player_or_guest','payload':{'match_id':'hex32','decision_id':'hex32','decision_seq':'int:1..40','revision':'int:0..192','phase':'game_phase_enum','observation':'strict_allowlisted_view','legal_ids':'ASCII_sorted_unique_list'},'returns':['decision_id','status','observation_hash','result_or_null','lease_until_ms']},
 'decision.get':{'auth':'player_or_guest','payload':{'match_id':'hex32','decision_id':'hex32'},'returns':['decision_id','status','observation_hash','result_or_null','lease_until_ms']},
 'match.finish':{'auth':'player_or_guest','payload':{'match_id':'hex32','result':'strict_match_summary','public_events':'bounded_array','public_events_hash':'sha256hex','provider_counts':'jev/local/forced','rules_version':'1.0.0'},'returns':['record_id','status','stats_version','validation_level']},
 'match.abort':{'auth':'player_or_guest','payload':{'match_id':'hex32','reason':'user|expired|corrupt|guest_restart|fault'},'returns':['match_id','status']}
}
errors=['AUTH_FAILED','AUTH_EXPIRED','FORBIDDEN','BAD_REQUEST','VERSION_MISMATCH','MATCH_ACTIVE','MATCH_EXPIRED','MATCH_TERMINAL','DECISION_NOT_FOUND','IDEMPOTENCY_CONFLICT','ILLEGAL_ACTION','PROVIDER_UNAVAILABLE','PROVIDER_INVALID','RATE_LIMITED','PENDING','STORAGE_UNCERTAIN','MAINTENANCE','RESULT_CONFLICT','REPLAY_TOO_OLD']
sheets={
 'CardsMeta':['key','value_json','updated_at_ms'],
 'CardsMatches_YYYYMM':['match_id','device_id','player_id','is_guest','game','variant','rules_version','opponent_requested','status','created_at_ms','expires_at_ms','completed_at_ms','human_score','opponent_score','winner','end_reason','provider_counts_json','public_events_json','public_events_hash','result_hash','validation_level','stats_applied_version'],
 'CardsDecisions_YYYYMMDD':['job_key','match_id','decision_id','decision_seq','revision','phase','request_hash','observation_hash','status','generation','call_reserved','lease_until_ms','result_json','failure_code','model','input_tokens','latency_ms','created_at_ms','finished_at_ms'],
 'CardsProfiles':['profile_key','player_id','game','variant','rules_version','stats_version','stats_json','history_start_ms','last_match_id','updated_at_ms'],
 'CardsReceipts_YYYYMMDD':['request_key','fingerprint','actor_id','action','resource_ref','status','safe_response_json','created_at_ms','expires_at_ms']}
write('api_contract.json',{'namespace':'cafe_cards','api_version':1,'method':'POST','envelope':['namespace','api_version','action','request_id','device_id','device_token','player_token','created_at_ms','sent_at_ms','payload'],'actions':actions,'errors':errors,'sheets':sheets})
`````

## ファイル：`tools/run_checks.py`

<!-- CAFE_CARDS_FILE {"path":"tools/run_checks.py","bytes":3301,"sha256":"7a1c44d03c677f3e565cf2038b89c581d784566d5460e2733f8e252f22bd614d"} -->
`````python
#!/usr/bin/env python3
"""Run portable checks. Requires Python 3.10+, Node 18+, and a C++17 compiler.
No ESP32, Google, Jev, secrets, network, or third-party Python modules are used.
"""
from __future__ import annotations
import argparse, json, os, shutil, subprocess, sys, tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def main() -> None:
    ap=argparse.ArgumentParser()
    ap.add_argument('--full',action='store_true',help='Enumerate all 2,598,960 poker hands and one million baccarat value streams.')
    ap.add_argument('--sanitize',action='store_true',help='Additionally run ASan/UBSan checks where supported.')
    ap.add_argument('--output',type=Path,default=ROOT/'results_local',help='Do not overwrite the supplied historical results by default.')
    args=ap.parse_args()
    cxx=os.environ.get('CXX','g++');node=shutil.which('node')
    if not shutil.which(cxx) or not node:
        raise SystemExit('Install a C++17 compiler (or set CXX) and Node.js; no external service is required.')
    args.output.mkdir(parents=True,exist_ok=True)
    def run(cmd: list[str], result: str|None=None) -> str:
        p=subprocess.run(cmd,cwd=ROOT,check=True,text=True,capture_output=True,timeout=180)
        if p.stderr:print(p.stderr,file=sys.stderr)
        if result:
            obj=json.loads(p.stdout)
            (args.output/result).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
            print(result+': PASS')
        return p.stdout
    with tempfile.TemporaryDirectory(prefix='cafe_cards_check_') as folder:
        work=Path(folder)
        def compile(src: str,name: str,sanitize=False) -> str:
            exe=str(work/name)
            flags=['-std=c++17','-Wall','-Wextra','-Werror']
            flags+=['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer'] if sanitize else ['-O2']
            run([cxx,*flags,src,'-o',exe]);return exe
        exe=compile('tests/core_test.cpp','core')
        run([exe,*(['--full'] if args.full else [])],'cpp_tests.json')
        exe=compile('tests/local_test.cpp','local')
        run([exe],'local_tests.json')
        for src,out in [('contract_test.js','contract_tests.json'),('gate_test.js','gate_tests.json')]:
            run([node,'tests/'+src],out)
        run([sys.executable,'tests/protocol_test.py'],'protocol_tests.json')
        run([sys.executable,'tests/data_test.py'],'data_tests.json')
        gen=compile('tools/cross_fixture.cpp','cross_fixture')
        fixture=work/'cross.json';fixture.write_text(run([gen]),encoding='utf8')
        run([node,'tests/cross_test.js',str(fixture)],'cross_tests.json')
        if args.sanitize:
            exe=compile('tests/core_test.cpp','sanitize_core',True)
            run([exe],'sanitizer_tests.json')
    (args.output/'environment.json').write_text(json.dumps({
        'python':sys.version.split()[0],'node':run([node,'--version']).strip(),
        'compiler':run([cxx,'--version']).splitlines()[0],
        'full':args.full,'sanitize':args.sanitize,
        'esp32_tested':False,'live_google_tested':False,'live_jev_tested':False
    },ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print('Portable checks complete. This is NOT an ESP32 build or a live API test.')

if __name__=='__main__':main()
`````

## ファイル：`MANIFEST.json`

<!-- CAFE_CARDS_FILE {"path":"MANIFEST.json","bytes":7124,"sha256":"70e348320ca61fa691bf10a2bf2e70e2ac9215e38dc70c80a65ae092d2539203"} -->
`````json
{
  "version": "1.0.0",
  "created": "2026-09-22",
  "files": [
    {
      "path": "README.md",
      "bytes": 1646,
      "sha256": "772d4343ce93545bef87deb18c858150accd8d69c9dca252cbb76992293fc5a7"
    },
    {
      "path": "core/cards_core.hpp",
      "bytes": 12388,
      "sha256": "b53af1f275168095248877839b37708dac52a99a33fe2a80231e2ddbc4cd044d"
    },
    {
      "path": "data/acceptance.json",
      "bytes": 26669,
      "sha256": "4b51a20ccaee234770b1ea20115d62980c8431858edf916e29fe91d002442d79"
    },
    {
      "path": "data/api_contract.json",
      "bytes": 4623,
      "sha256": "9461acf08fc2f221370a9286bcfe20dac3ec851a3a75fb6cb1ed89b8c3a9ff65"
    },
    {
      "path": "data/baccarat_probabilities.json",
      "bytes": 16591,
      "sha256": "fe3b72d2adfcb8cabb5ad18d3a1f5b78a3c62d9d3add255c1e25cbbdd6aaee98"
    },
    {
      "path": "data/cards.json",
      "bytes": 8604,
      "sha256": "bfcda0932d3b3f643f7e9d93d498ac38338edd61cde08e80f26e1f4747c56a67"
    },
    {
      "path": "data/content.ja.json",
      "bytes": 6176,
      "sha256": "9508d2227cc08e8e17c9b76ebafcde8af4e5a4e1fc021911315e4be256fe23dc"
    },
    {
      "path": "data/layouts.json",
      "bytes": 3289,
      "sha256": "895bb318a6624ad522ce8b59d119400f0567d5ba7ff2c0f1b8b2ed70f7a4fcf2"
    },
    {
      "path": "data/poker_draw_choices.json",
      "bytes": 3803,
      "sha256": "15615dd5e3546a09ad76c537caaa3c1fa43ac1f99b56fca6461f64830932c787"
    },
    {
      "path": "data/rules.json",
      "bytes": 2927,
      "sha256": "8741b6b36fe204b1e5067c05ebc4ebf5bf9e83554f2868ecda12d8edab7c9cd3"
    },
    {
      "path": "data/tutorials.ja.json",
      "bytes": 3439,
      "sha256": "e5df01fecd6fb8de42fa67ef75848a08224b44d871cf5d2dd7515b039659245d"
    },
    {
      "path": "docs/00_COMMON.md",
      "bytes": 10390,
      "sha256": "effa3f67da450f9ad98c3120ead62cb0821b687d3ba5fea8831cff57dad6cadb"
    },
    {
      "path": "docs/01_POKER.md",
      "bytes": 9573,
      "sha256": "06e37d32355440ad37946784d593d0db8a490c03ffb475196e72af6443a60acb"
    },
    {
      "path": "docs/02_GOPS.md",
      "bytes": 5494,
      "sha256": "e2c6728fdbcbeb2e274d7a68ea7d5f51d35a50c5ab747e7fd0e0c37b925d2cb7"
    },
    {
      "path": "docs/03_THIRTY_ONE.md",
      "bytes": 7448,
      "sha256": "683735114d1129f9bffc02749794e9a193c65c0a3010dad319011d809af3116c"
    },
    {
      "path": "docs/04_BACCARAT.md",
      "bytes": 7131,
      "sha256": "ab5e21e6d1e8757c92b85659d0c24295227e279cd7cff17b747d182dc9efe589"
    },
    {
      "path": "docs/05_IMPLEMENTATION.md",
      "bytes": 39927,
      "sha256": "77fef45e9c16e7e14b0de624f4967489fcca3283b5e40f7f5c3d13ca65445274"
    },
    {
      "path": "docs/06_TESTS_SOURCES.md",
      "bytes": 21204,
      "sha256": "7ff6de9ca05f717b1117083c75ddf5b85b6ebd909f039ffbc4d8dc71072833fe"
    },
    {
      "path": "reference/decision_protocol.py",
      "bytes": 3625,
      "sha256": "9edfba7670405296a01c0bfbd6f5466480a6f769c6d7dbddc685f0d17b941b38"
    },
    {
      "path": "reference/jev_contract.js",
      "bytes": 10683,
      "sha256": "23ced4de1ebd8e435db101158d5016010b50bd496f15c252bd9d501ebf770531"
    },
    {
      "path": "reference/local_policy.hpp",
      "bytes": 2609,
      "sha256": "de522c133ca225913c025f8a73c7e64ca0c771495c9d803c34130569c35a3cec"
    },
    {
      "path": "reference/observation_gate.js",
      "bytes": 9055,
      "sha256": "6c2ea3a1f67a11c34f12e54ae2f745e600c57fb1ff0e5b33a8cf48d98f9b8349"
    },
    {
      "path": "results/contract_tests.json",
      "bytes": 123,
      "sha256": "e37098cb2496c1f7c46cd4bf84eaf2d127062665fcfc49dab256badac3d0eba3"
    },
    {
      "path": "results/cpp_tests.json",
      "bytes": 373,
      "sha256": "16fd2f98d37adb2d9612dc30cf41b9fc43a27afe7585c89215061ac40468c957"
    },
    {
      "path": "results/cross_tests.json",
      "bytes": 99,
      "sha256": "f4bcdd63da5ef10b7aa6c4616c90b572345aa3491325654a58fe357c1dcc0f59"
    },
    {
      "path": "results/data_tests.json",
      "bytes": 160,
      "sha256": "d525982576ebea3ac9393b9352402e6784fd5eb78ac5059333cef013a1e5de63"
    },
    {
      "path": "results/environment.json",
      "bytes": 214,
      "sha256": "468e13171a5b4e1c7a45b5d6a0f2b838e71ffde321e2dc0c60b462d61d5db6e4"
    },
    {
      "path": "results/gate_tests.json",
      "bytes": 73,
      "sha256": "b01b3dcba4bcb168f4b03d27e60d71d94a690384930aa63704382014cb5f0860"
    },
    {
      "path": "results/local_tests.json",
      "bytes": 143,
      "sha256": "9d61f25825662bedabbfe822e7bae512ed904083427e7db454e645fea7f22cdb"
    },
    {
      "path": "results/protocol_tests.json",
      "bytes": 162,
      "sha256": "d31d31d412867c02f19cd33d793f39aa014b86034444723351907ad37efa250a"
    },
    {
      "path": "results/sanitizer_tests.json",
      "bytes": 362,
      "sha256": "017315db8e7aad2ad7e9e27523603527024addb8394fa48c5058ab98c2c92b34"
    },
    {
      "path": "tests/contract_test.js",
      "bytes": 3665,
      "sha256": "6828295e5b58962b9fae29138d7769bb0a66e76dc1bf9dd2e70cfc5fef10a65d"
    },
    {
      "path": "tests/core_test.cpp",
      "bytes": 10289,
      "sha256": "147bcae6d164b4cc31c63f466f82d2bb943194eb949fea7e54f97d24dc5411ac"
    },
    {
      "path": "tests/cross_test.js",
      "bytes": 513,
      "sha256": "5bca058035455cdadda8ec4b794f63d1390b20a2f372c0d90b10f6279e209b20"
    },
    {
      "path": "tests/data_test.py",
      "bytes": 2582,
      "sha256": "4158f26011b916a30e4835d80aad2545cebc48a92ebcb8461deba1c23cb76fc4"
    },
    {
      "path": "tests/gate_test.js",
      "bytes": 2042,
      "sha256": "08e8140af65dd0b37c0c1985938da27ac653834aa912e46f392fd3bd00262047"
    },
    {
      "path": "tests/local_test.cpp",
      "bytes": 1335,
      "sha256": "78e61c3cd04610343c3e05e511984eff5c97f91bd7bae81fd0f0dcc05150ab7d"
    },
    {
      "path": "tests/protocol_test.py",
      "bytes": 2554,
      "sha256": "cadbbbc9a724f8ecacc77c52b28e4b00931bf98b4567fef98111e388d0b0beba"
    },
    {
      "path": "tools/assemble_handoff.py",
      "bytes": 3767,
      "sha256": "c6aa1872ac26f533345be9a4d2bc0aae4f12d1b52c95a3689df27b03977e85eb"
    },
    {
      "path": "tools/baccarat_table.cpp",
      "bytes": 1470,
      "sha256": "358e7ade09629f15ac7dd41d3ae533e82d986e3c00a909e7092a04f06e8a9460"
    },
    {
      "path": "tools/cross_fixture.cpp",
      "bytes": 656,
      "sha256": "7614cd64c77ba72f06a7f30d1752c5ff169361cdd2f0fc665ae2f5125e2a4d8d"
    },
    {
      "path": "tools/extract_handoff.py",
      "bytes": 2538,
      "sha256": "ad2711c6953389f9d743c64decd83b860e953f6407282f4dc3f6ece2017ac303"
    },
    {
      "path": "tools/make_acceptance.py",
      "bytes": 19767,
      "sha256": "e8ff57ecc712d06be282e0d6f0c07a23a9e8cfdde5272e24379294ba27479710"
    },
    {
      "path": "tools/make_data.py",
      "bytes": 16074,
      "sha256": "fe3764def82c16f818e7e40b734f548eeee72085a600e148a6d5895a3b64b304"
    },
    {
      "path": "tools/run_checks.py",
      "bytes": 3301,
      "sha256": "7a1c44d03c677f3e565cf2038b89c581d784566d5460e2733f8e252f22bd614d"
    }
  ]
}
`````
