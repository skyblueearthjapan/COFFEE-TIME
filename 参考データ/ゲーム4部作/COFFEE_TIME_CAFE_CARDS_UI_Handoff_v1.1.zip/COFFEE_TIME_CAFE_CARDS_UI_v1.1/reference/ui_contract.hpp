#pragma once
#include <array>
#include <cstdint>
namespace cafe::ui {
// Pure C++17 input gate. No LVGL / network dependency. Controller still validates game legality.
struct Stamp {
 std::uint64_t match{0};
 std::uint32_t revision{0}, generation{0};
 friend bool operator==(Stamp a,Stamp b){return a.match==b.match&&a.revision==b.revision&&a.generation==b.generation;}
 friend bool operator!=(Stamp a,Stamp b){return !(a==b);}
};
struct Rect {int x,y,w,h;};
constexpr bool inside(Rect a,int radius=228){
 if(a.w<=0||a.h<=0)return false;
 if(radius<0)return false;
 const auto square=[](std::int64_t x){return x*x;};
 for(const std::int64_t x:{std::int64_t(a.x),std::int64_t(a.x)+a.w})for(const std::int64_t y:{std::int64_t(a.y),std::int64_t(a.y)+a.h})if(square(x-240)+square(y-240)>square(radius))return false;
 return true;
}
struct Command {Stamp stamp{};std::uint16_t action{0};};
class Gate {
 Stamp current_{}, pending_stamp_{};std::uint16_t pending_action_{};
 bool bound_{false},pending_{false},busy_{false},covered_{false};
public:
 void bind(Stamp s){if(!bound_||s!=current_){const bool changed=!bound_||s.match!=current_.match||s.revision!=current_.revision;current_=s;bound_=true;pending_=false;if(changed)busy_=false;}}
 void cover(){covered_=true;pending_=false;}
 void uncover(Stamp s){covered_=false;bind(s);}
 bool releaseRejected(Stamp s,bool no_effect){if(!no_effect||!busy_||!bound_||s.match!=current_.match||s.revision!=current_.revision)return false;busy_=false;pending_=false;return true;}
 void cancel(){pending_=false;}
 bool propose(Stamp s,std::uint16_t action,bool legal,bool simultaneous=false,bool ready=true){
  if(!bound_||covered_||busy_||s!=current_||!legal||(simultaneous&&!ready))return false;
  pending_=true;pending_stamp_=s;pending_action_=action;return true;
 }
 bool confirm(Stamp s,bool still_legal,bool simultaneous,bool ready,Command& out){
  if(!bound_||covered_||busy_||!pending_||s!=current_||s!=pending_stamp_||!still_legal||(simultaneous&&!ready))return false;
  out={s,pending_action_};busy_=true;pending_=false;return true;
 }
 bool busy()const{return busy_;}
};
struct Gesture {
 Stamp press_stamp{};std::uint16_t target{};int x{},y{};bool armed{false};
 void press(Stamp s,std::uint16_t id,int px,int py){press_stamp=s;target=id;x=px;y=py;armed=true;}
 void cancel(){armed=false;}
 bool release(Stamp s,std::uint16_t id,int px,int py){
  const std::int64_t dx=std::int64_t(px)-x,dy=std::int64_t(py)-y;
  const bool bounded=dx>=-8&&dx<=8&&dy>=-8&&dy<=8;
  const bool pass=armed&&s==press_stamp&&id==target&&bounded&&dx*dx+dy*dy<=64;
  armed=false;return pass;
 }
};
enum class Face:std::uint8_t{Absent,Back,FaceUp};
struct DisplayCard {Face face{Face::Absent};std::uint16_t visible_id{0xffff};};
constexpr DisplayCard displayCard(bool exists,bool may_reveal,std::uint16_t id){
 return !exists?DisplayCard{Face::Absent,0xffff}:!may_reveal?DisplayCard{Face::Back,0xffff}:DisplayCard{Face::FaceUp,id};
}
constexpr bool wellFormed(DisplayCard c){return c.face==Face::FaceUp?c.visible_id<416:c.visible_id==0xffff;}
} // namespace cafe::ui
