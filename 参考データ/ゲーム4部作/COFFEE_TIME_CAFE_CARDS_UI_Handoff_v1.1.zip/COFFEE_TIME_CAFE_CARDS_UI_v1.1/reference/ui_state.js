/* Original reference logic. Browser/CommonJS; no network, storage, or game rules. */
(function(root){
'use strict';
const sameStamp=(a,b)=>!!a&&!!b&&a.matchId===b.matchId&&a.revision===b.revision&&a.generation===b.generation;
class ConfirmGate {
 constructor(){this.stamp=null;this.pending=null;this.busy=false;this.covered=false;}
 bind(stamp){if(!sameStamp(this.stamp,stamp)){const newRevision=!this.stamp||this.stamp.matchId!==stamp.matchId||this.stamp.revision!==stamp.revision;this.stamp={...stamp};this.pending=null;if(newRevision)this.busy=false;} }
 propose(stamp,action,legal,aiRequired=false,aiReady=true){
  if(!sameStamp(this.stamp,stamp)||this.covered||this.busy||!Array.isArray(legal)||!legal.includes(action)||(aiRequired&&!aiReady))return false;
  this.pending={action,stamp:{...stamp}};return true;
 }
 releaseRejected(stamp,authoritativeNoEffect){if(!authoritativeNoEffect||!this.busy||!this.stamp||this.stamp.matchId!==stamp.matchId||this.stamp.revision!==stamp.revision)return false;this.busy=false;this.pending=null;return true;}
 cancel(){this.pending=null;}
 cover(){this.covered=true;this.pending=null;}
 uncover(stamp){this.covered=false;this.bind(stamp);}
 confirm(stamp,legal,aiRequired=false,aiReady=true){
  if(this.covered||this.busy||!this.pending||!sameStamp(this.stamp,stamp)||!sameStamp(this.pending.stamp,stamp)||!legal.includes(this.pending.action)||(aiRequired&&!aiReady))return null;
  const out={action:this.pending.action,stamp:{...stamp}};this.busy=true;this.pending=null;return out;
 }
}
function rectInsideCircle(r,cx=240,cy=240,radius=228){
 if(!Array.isArray(r)||r.length!==4||r.some(v=>!Number.isFinite(v))||r[2]<=0||r[3]<=0)return false;
 const[x,y,w,h]=r;return [x,x+w].every(a=>[y,y+h].every(b=>(a-cx)**2+(b-cy)**2<=radius**2));
}
function gopsPage(remaining,page){
 if(!Array.isArray(remaining)||remaining.some(x=>!Number.isInteger(x)||x<1||x>13)||new Set(remaining).size!==remaining.length)throw Error('bad remaining');
 const arr=[...remaining].sort((a,b)=>a-b), pages=Math.max(1,Math.ceil(arr.length/4));
 if(!Number.isInteger(page)||page<0||page>=pages)throw Error('bad page');
 return {values:arr.slice(page*4,page*4+4),page,pages};
}
function drawMask(indices){
 if(!Array.isArray(indices)||new Set(indices).size!==indices.length||indices.some(i=>!Number.isInteger(i)||i<0||i>4))throw Error('bad slots');
 return indices.reduce((v,i)=>v|(1<<i),0);
}
function legalBetActions(owed,raises){
 if(!Number.isInteger(owed)||owed<0||!Number.isInteger(raises)||raises<0||raises>2)throw Error('bad street');
 return owed===0?['CHECK','BET']:raises<2?['FOLD','CALL','RAISE']:['FOLD','CALL'];
}
function decisionVisible(game,phase,folded,provider,humanConfirmed){
 if(provider!=='jev')return false;
 if(game==='poker')return phase==='HAND_RESULT'&&!folded;
 return !!humanConfirmed&&['REVEAL_SCORE','ROUND_RESULT','HAND_RESULT','MATCH_RESULT','REVEAL'].includes(phase);
}
function safeDisplayCard(source,mayReveal){
 // Construct allowlist output; do NOT spread an internal object into this return.
 if(source===null||source===undefined)return {face:'absent',rank:null,suit:null,value:null};
 if(!mayReveal)return {face:'back',rank:null,suit:null,value:null};
 if(!['C','D','H','S'].includes(source.suit)||!Number.isInteger(source.rank)||source.rank<2||source.rank>14)throw Error('bad visible card');
 return {face:'face',rank:source.rank,suit:source.suit,value:null};
}
const api={ConfirmGate,sameStamp,rectInsideCircle,gopsPage,drawMask,legalBetActions,decisionVisible,safeDisplayCard};
if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.CafeUi=api;
})(typeof globalThis!=='undefined'?globalThis:this);
